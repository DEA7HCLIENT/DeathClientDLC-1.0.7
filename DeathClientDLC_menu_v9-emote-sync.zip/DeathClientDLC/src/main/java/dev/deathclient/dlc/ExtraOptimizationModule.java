package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

/**
 * Extra Optimization: turns off a few heavy vanilla visuals (clouds, entity shadows, biome blending, fancy graphics).
 * Only the options you have ticked are changed, and the old values come back when the module is disabled.
 * Works on vanilla option objects, not on anyone else's code.
 */
public class ExtraOptimizationModule extends Module {
    public final BoolSetting clouds = add(new BoolSetting("Clouds off", true));
    public final BoolSetting shadows = add(new BoolSetting("Entity shadows off", true));
    public final BoolSetting fastGraphics = add(new BoolSetting("Fast graphics", true));
    public final BoolSetting noBiomeBlend = add(new BoolSetting("No biome blend", true));

    private static final class Saved {
        final SimpleOption<?> option;
        final Object value;
        Saved(SimpleOption<?> option, Object value) { this.option = option; this.value = value; }
    }

    private final List<Saved> saved = new ArrayList<>();

    public ExtraOptimizationModule() { super("Extra Optimization", Category.MISC); }

    @Override
    protected void onEnable() {
        GameOptions o = MinecraftClient.getInstance().options;
        if (clouds.get()) remember(o.getCloudRenderMode(), "OFF");
        if (shadows.get()) remember(o.getEntityShadows(), false);
        if (fastGraphics.get()) remember(o.getGraphicsMode(), "FAST");
        if (noBiomeBlend.get()) remember(o.getBiomeBlendRadius(), 0);
    }

    @Override
    protected void onDisable() {
        for (int i = saved.size() - 1; i >= 0; i--) restore(saved.get(i));
        saved.clear();
    }

    /** Stores the current value and sets the new one. A string means "the enum constant with this name". */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void remember(SimpleOption option, Object target) {
        Object before = option.getValue();
        if (target instanceof String name) {
            if (!(before instanceof Enum<?> e)) return;
            for (Object constant : e.getDeclaringClass().getEnumConstants()) {
                if (((Enum<?>) constant).name().equals(name)) {
                    saved.add(new Saved(option, before));
                    option.setValue(constant);
                    return;
                }
            }
            return;                                             // no such constant in this version: leave it alone
        }
        saved.add(new Saved(option, before));
        option.setValue(target);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void restore(Saved s) {
        ((SimpleOption) s.option).setValue(s.value);
    }
}
