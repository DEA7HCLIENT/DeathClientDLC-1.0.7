package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;

/**
 * Armor HUD: the four armour pieces you wear, each with a durability bar and percentage. Shown on the left edge,
 * middle height. Empty slots are skipped.
 */
public class ArmorHudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 400, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 120, 0, 400, 1));
    public final BoolSetting names = add(new BoolSetting("Item names", false));
    public final BoolSetting theme = add(new BoolSetting("Theme color", true));

    private static final int BG = 0xB0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94, BAD = 0xFFE05050, GOOD = 0xFF50E070;

    public ArmorHudModule() { super("Armor HUD", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ArmorHudModule m = ModuleManager.get(ArmorHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, p);
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p) {
        int x0 = (int) x.get(), y0 = (int) y.get();
        int accent = (theme.get() ? Theme.current().accent() : 0xFFFFFF) | 0xFF000000;
        int row = 0;
        // getArmorStack(0) is boots, 3 is helmet; show from helmet down.
        for (int slot = 3; slot >= 0; slot--) {
            ItemStack s = p.getInventory().getArmorStack(slot);
            if (s.isEmpty()) continue;
            int ry = y0 + row * 22;
            row++;
            int pw = 90, ph = 18;
            ctx.fill(x0, ry, x0 + pw, ry + ph, BG);
            String label = names.get() ? s.getName().getString() : shortName(slot);
            Fonts.draw(ctx, c.textRenderer, label, x0 + 4, ry + 2, WHITE);
            if (s.isDamageable()) {
                int max = s.getMaxDamage();
                double frac = max <= 0 ? 1 : (max - s.getDamage()) / (double) max;
                int bw = pw - 8, bx = x0 + 4, by = ry + ph - 4;
                ctx.fill(bx, by, bx + bw, by + 2, 0x80202020);
                int col = frac > 0.5 ? GOOD : frac > 0.2 ? accent : BAD;
                ctx.fill(bx, by, bx + (int) Math.round(bw * Math.max(0, Math.min(1, frac))), by + 2, col);
                String pct = (int) Math.round(frac * 100) + "%";
                int pwid = Fonts.width(c.textRenderer, pct);
                Fonts.draw(ctx, c.textRenderer, pct, x0 + pw - pwid - 4, ry + 2, MUTED);
            }
        }
    }

    private static String shortName(int slot) {
        return switch (slot) {
            case 3 -> "Helmet";
            case 2 -> "Chest";
            case 1 -> "Legs";
            default -> "Boots";
        };
    }
}
