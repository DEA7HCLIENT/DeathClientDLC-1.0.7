package dev.deathclient.dlc;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import dev.deathclient.dlc.mixin.RenderLayerInvoker;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The one place that touches the 1.21.11 render-layer API. UNVERIFIED against the 1.21.11 yarn names: if the
 * build or startup fails here, fix only this file and mixin.RenderLayerInvoker. On any failure Chams stays
 * unavailable (layer() == null) and entities render normally.
 */
public final class ChamsLayers {
    private static final Logger LOGGER = LoggerFactory.getLogger("DeathClientDLC/Chams");
    private static RenderLayer layer;
    private static boolean tried;

    private ChamsLayers() {}

    public static boolean available() { return layer() != null; }

    public static synchronized RenderLayer layer() {
        if (tried) return layer;
        tried = true;
        try {
            RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder(RenderPipelines.ENTITY_SNIPPET)
                    .withLocation(Identifier.of("deathclientdlc", "pipeline/chams"))
                    .withShaderDefine("ALPHA_CUTOUT", 0.1f)
                    .withSampler("Sampler1")
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withCull(false)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .build());
            RenderLayer.MultiPhaseParameters params = RenderLayer.MultiPhaseParameters.builder()
                    .texture(new RenderPhase.Texture(Identifier.ofVanilla("textures/misc/white.png"), false))
                    .lightmap(RenderPhase.ENABLE_LIGHTMAP)
                    .overlay(RenderPhase.ENABLE_OVERLAY_COLOR)
                    .build(true);
            layer = RenderLayerInvoker.deathclientdlc$of("deathclientdlc_chams", 1536, true, true, pipeline, params);
        } catch (Throwable t) {
            LOGGER.error("Chams disabled: render layer could not be created", t);
            layer = null;
        }
        return layer;
    }
}
