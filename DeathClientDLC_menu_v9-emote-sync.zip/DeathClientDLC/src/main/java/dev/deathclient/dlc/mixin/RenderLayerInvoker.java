package dev.deathclient.dlc.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Opens RenderLayer.of(...) (package-private). Registered in the optional deathclientdlc.chams.mixins.json. */
@Mixin(RenderLayer.class)
public interface RenderLayerInvoker {
    @Invoker("of")
    static RenderLayer.MultiPhase deathclientdlc$of(String name, int size, boolean hasCrumbling, boolean translucent,
                                                    RenderPipeline pipeline, RenderLayer.MultiPhaseParameters params) {
        throw new AssertionError();
    }
}
