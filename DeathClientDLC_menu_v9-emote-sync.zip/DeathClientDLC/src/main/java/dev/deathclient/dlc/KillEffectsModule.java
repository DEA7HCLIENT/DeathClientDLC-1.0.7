package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

/**
 * Kill Effects: when a living entity dies near you, a shape animation plays where it fell. The shapes are drawn as
 * flat 2D pieces on the screen, placed with ScreenProjector (the same way ESP draws), so they need no render-pipeline
 * hooks. Only you see them; they do not change gameplay.
 */
public class KillEffectsModule extends Module {
    private static final int DURATION = 60;
    private static final double RANGE = 48;
    private static final ScreenProjector PROJ = new ScreenProjector();

    static final String[] NAMES = {
        "Black hole", "Ghost", "Chains", "Fire pillar", "Soul helix", "Lightning", "Halo",
        "Snowfall", "Shatter", "Totem", "Dragon breath", "Hearts"
    };

    public final NumberSetting effect = add(new NumberSetting("Effect", 0, 0, NAMES.length - 1, 1).labels(NAMES));

    /** A dead entity's last known place. Stored at death, because the body is removed a few seconds later. */
    private static final class Anim {
        final Vec3d pos;
        final double w, h;
        final int start;
        Anim(Vec3d pos, double w, double h, int start) { this.pos = pos; this.w = w; this.h = h; this.start = start; }
    }

    private int tick;
    private final Map<Integer, Anim> active = new HashMap<>();

    public KillEffectsModule() { super("Kill Effects", Category.RENDER); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.world == null || c.player == null) { active.clear(); return; }
        tick++;
        for (LivingEntity le : c.world.getEntitiesByClass(LivingEntity.class,
                c.player.getBoundingBox().expand(RANGE), e -> e != c.player)) {
            if (le.getHealth() <= 0) {
                if (!active.containsKey(le.getId())) active.put(le.getId(), new Anim(le.getPos(), le.getWidth(), le.getHeight(), tick));
            }
        }
        Iterator<Map.Entry<Integer, Anim>> it = active.entrySet().iterator();
        while (it.hasNext()) if (tick - it.next().getValue().start > DURATION) it.remove();
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        KillEffectsModule m = ModuleManager.get(KillEffectsModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    // ------------------------------------------------------------------ drawing

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        if (active.isEmpty()) return;
        PROJ.begin(c, delta);
        int mode = (int) Math.round(effect.get());
        for (Anim a : active.values()) {
            double age = (tick - a.start) + delta;
            if (age < 0 || age > DURATION) continue;
            double t = age / DURATION;
            switch (mode) {
                case 0 -> blackHole(ctx, a, age, t);
                case 1 -> ghost(ctx, a, t);
                case 2 -> chains(ctx, a, age);
                case 3 -> firePillar(ctx, a, t);
                case 4 -> soulHelix(ctx, a, age, t);
                case 5 -> lightning(ctx, a, age, t);
                case 6 -> halo(ctx, a, age, t);
                case 7 -> snowfall(ctx, a, age, t);
                case 8 -> shatter(ctx, a, t);
                case 9 -> totem(ctx, a, t);
                case 10 -> dragonBreath(ctx, a, age, t);
                default -> hearts(ctx, a, age, t);
            }
        }
    }

    /** Pixels per world block at the point's depth. Valid only right after a successful project(). */
    private static double scale() { return (PROJ.screenHeight() / 2.0) / (PROJ.tan * PROJ.out[2]); }

    private static int alpha(int a, double t) { return (int) (a * Math.max(0, Math.min(1, 1 - t))) << 24; }

    /** Projects a world point; returns null when it is behind the camera. */
    private static double[] at(Vec3d p) {
        if (!PROJ.project(p)) return null;
        return new double[]{PROJ.out[0], PROJ.out[1], scale()};
    }

    /** A filled square of the given pixel size centred on (x, y). */
    private static void dot(DrawContext ctx, double x, double y, double size, int col) {
        int s = Math.max(1, (int) Math.round(size));
        int x0 = (int) Math.round(x - s / 2.0), y0 = (int) Math.round(y - s / 2.0);
        ctx.fill(x0, y0, x0 + s, y0 + s, col);
    }

    /** A line made of small squares, one every pixel-ish step. */
    private static void line(DrawContext ctx, double x1, double y1, double x2, double y2, double thick, int col) {
        double len = Math.hypot(x2 - x1, y2 - y1);
        int steps = Math.max(1, (int) Math.min(400, len));
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            dot(ctx, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, thick, col);
        }
    }

    /** A filled disc (rows of ctx.fill). */
    private static void disc(DrawContext ctx, double cx, double cy, double r, int col) {
        if (r < 1) return;
        r = Math.min(r, 600);
        int top = (int) Math.round(cy - r), bot = (int) Math.round(cy + r);
        for (int y = top; y <= bot; y++) {
            double dy = y - cy;
            double half = Math.sqrt(Math.max(0, r * r - dy * dy));
            ctx.fill((int) Math.round(cx - half), y, (int) Math.round(cx + half), y + 1, col);
        }
    }

    // ------------------------------------------------------------------ effects

    private void blackHole(DrawContext ctx, Anim a, double age, double t) {
        double[] p = at(a.pos.add(0, a.h / 2, 0));
        if (p == null) return;
        double k = p[2];
        double R = k * 0.5 * (1 - t * 0.7);
        disc(ctx, p[0], p[1], R * 1.6, alpha(0x55, t) | 0x7A3CFF);             // violet glow
        disc(ctx, p[0], p[1], R, alpha(0xE8, 0) | 0x050008);                  // the dark core
        for (int j = 0; j < 8; j++) {
            double ang = age * 0.3 + j * Math.PI / 4;
            double rr = R * (1.6 - t);
            dot(ctx, p[0] + Math.cos(ang) * rr, p[1] + Math.sin(ang) * rr * 0.5, Math.max(2, k * 0.05),
                    alpha(0xFF, t) | 0xB36BFF);
        }
    }

    private void ghost(DrawContext ctx, Anim a, double t) {
        double[] feet = at(a.pos);
        if (feet == null) return;
        double k = feet[2];
        double bw = a.w * k, bh = a.h * k;
        double rise = t * a.h * k * 0.8;
        int col = alpha(0x70, t) | 0xD8F0FF;
        ctx.fill((int) Math.round(feet[0] - bw / 2), (int) Math.round(feet[1] - rise - bh),
                 (int) Math.round(feet[0] + bw / 2), (int) Math.round(feet[1] - rise), col);
    }

    private void chains(DrawContext ctx, Anim a, double age) {
        double sink = Math.min(2.5, age * 0.05);
        int col = 0xFFB8B8C4;
        for (double off : new double[]{-0.3, 0.3}) {
            double[] prev = null;
            for (double dy = 0; dy <= sink; dy += 0.25) {
                double[] p = at(a.pos.add(off, -dy, 0));
                if (p == null) { prev = null; continue; }
                if (prev != null) line(ctx, prev[0], prev[1], p[0], p[1], Math.max(2, p[2] * 0.06), col);
                prev = p;
            }
        }
    }

    private void firePillar(DrawContext ctx, Anim a, double t) {
        double top = a.h * 2.5 * Math.min(1, t * 3);
        int steps = 12;
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            double[] p = at(a.pos.add(0, top * f, 0));
            if (p == null) continue;
            double w = p[2] * 0.45 * (1 - f * 0.5);
            int col = (int) (200 * (1 - f)) << 24 | 0xFF7A1A;
            ctx.fill((int) Math.round(p[0] - w / 2), (int) Math.round(p[1]),
                     (int) Math.round(p[0] + w / 2), (int) Math.round(p[1] + Math.max(2, p[2] * 0.2)), col);
        }
    }

    private void soulHelix(DrawContext ctx, Anim a, double age, double t) {
        int col = alpha(0xFF, t) | 0x5FE6FF;
        double[] prev = null;
        for (int i = 0; i <= 24; i++) {
            double f = i / 24.0;
            double ang = age * 0.2 + f * 4 * Math.PI;
            double y = a.h * 1.5 * t * f;
            double[] p = at(a.pos.add(Math.cos(ang) * 0.5, y, Math.sin(ang) * 0.5));
            if (p != null && prev != null) line(ctx, prev[0], prev[1], p[0], p[1], 2, col);
            prev = p;
        }
    }

    private void lightning(DrawContext ctx, Anim a, double age, double t) {
        if (t > 0.25) return;                                                  // a short flash
        int col = alpha(0xFF, t * 4) | 0xE0F7FF;
        double[] prev = null;
        for (double y = a.h + 20; y >= 0; y -= 0.5) {
            double jx = Math.sin(y * 3.1 + Math.floor(age / 3)) * 0.15;
            double jz = Math.cos(y * 2.7) * 0.15;
            double[] p = at(a.pos.add(jx, y, jz));
            if (p != null && prev != null) line(ctx, prev[0], prev[1], p[0], p[1], 2, col);
            prev = p;
        }
    }

    private void halo(DrawContext ctx, Anim a, double age, double t) {
        double y = a.h + 0.4 - t * 0.6;
        int col = alpha(0xFF, t) | 0xFFD84A;
        double[] first = null, prev = null;
        for (int k = 0; k <= 16; k++) {
            double ang = k * Math.PI / 8 + age * 0.05;
            double[] p = at(a.pos.add(Math.cos(ang) * 0.4, y, Math.sin(ang) * 0.4));
            if (p == null) continue;
            if (first == null) first = p;
            if (prev != null) line(ctx, prev[0], prev[1], p[0], p[1], 2, col);
            prev = p;
        }
    }

    private void snowfall(DrawContext ctx, Anim a, double age, double t) {
        int col = alpha(0xFF, t) | 0xFFFFFF;
        for (int k = 0; k < 14; k++) {
            double ang = k * 2.4 + age * 0.05;
            double fall = ((age * 0.03 + k * 0.13) % 1.0) * a.h;
            double[] p = at(a.pos.add(Math.cos(ang) * a.w * 1.2, a.h - fall, Math.sin(ang) * a.w * 1.2));
            if (p != null) dot(ctx, p[0], p[1], 3, col);
        }
    }

    private void shatter(DrawContext ctx, Anim a, double t) {
        Vec3d core = a.pos.add(0, a.h / 2, 0);
        int col = alpha(0xFF, t) | 0xFF5A3C;
        for (int k = 0; k < 20; k++) {
            double ang = k * 2 * Math.PI / 20;
            double d0 = 0.2, d1 = 0.2 + t * 2.2;
            double[] p0 = at(core.add(Math.cos(ang) * d0, Math.sin(k) * 0.2, Math.sin(ang) * d0));
            double[] p1 = at(core.add(Math.cos(ang) * d1, Math.sin(k) * 0.2, Math.sin(ang) * d1));
            if (p0 != null && p1 != null) line(ctx, p0[0], p0[1], p1[0], p1[1], 2, col);
        }
    }

    private void totem(DrawContext ctx, Anim a, double t) {
        Vec3d core = a.pos.add(0, a.h / 2, 0);
        int col = alpha(0xFF, t) | 0xFFD84A;
        double r = t * 1.5;
        for (int k = 0; k < 24; k++) {
            double ang = k * 2 * Math.PI / 24;
            double[] p = at(core.add(Math.cos(ang) * r, 0, Math.sin(ang) * r));
            if (p != null) dot(ctx, p[0], p[1], 3, col);
        }
    }

    private void dragonBreath(DrawContext ctx, Anim a, double age, double t) {
        double[] c0 = at(a.pos.add(0, a.h * 0.5, 0));
        if (c0 == null) return;
        for (int k = 0; k < 6; k++) {
            double ang = age * 0.05 + k * Math.PI / 3;
            double[] p = at(a.pos.add(Math.cos(ang) * a.w * 1.2, a.h * (0.3 + 0.4 * Math.sin(age * 0.1 + k)),
                    Math.sin(ang) * a.w * 1.2));
            if (p != null) disc(ctx, p[0], p[1], p[2] * 0.35, alpha(0x66, t) | 0xA040FF);
        }
    }

    private static final String[] HEART = {"0110110", "1111111", "1111111", "0111110", "0011100", "0001000"};

    private void hearts(DrawContext ctx, Anim a, double age, double t) {
        double[] p = at(a.pos.add(Math.sin(age * 0.1) * 0.3, a.h + t * 1.2, Math.cos(age * 0.1) * 0.3));
        if (p == null) return;
        int s = Math.max(2, (int) Math.round(p[2] * 0.05));
        int col = alpha(0xFF, t) | 0xFF4D7A;
        for (int row = 0; row < HEART.length; row++) {
            for (int col2 = 0; col2 < HEART[row].length(); col2++) {
                if (HEART[row].charAt(col2) != '1') continue;
                ctx.fill((int) Math.round(p[0]) + (col2 - 3) * s, (int) Math.round(p[1]) + (row - 3) * s,
                         (int) Math.round(p[0]) + (col2 - 2) * s, (int) Math.round(p[1]) + (row - 2) * s, col);
            }
        }
    }
}
