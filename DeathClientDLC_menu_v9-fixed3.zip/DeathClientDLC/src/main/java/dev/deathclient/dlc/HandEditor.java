package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Arm;

/**
 * View Model editor. With the chat open you work on the hand itself, there are no markers:
 *   double click on the item in a hand - it sticks to the mouse;
 *   move the mouse - the hand follows (hold Shift and move up or down to push it away or pull it closer);
 *   mouse wheel - scale (the label next to the cursor shows it);
 *   click - let go.
 * The main hand and the off hand are separate: each one is grabbed on its own side of the screen. Everything goes
 * into the View Model settings, so it is saved with the rest of the config; ".viewmodel reset" puts both back.
 * The mouse is polled by HudEdit every frame (no screen hooks), the wheel comes through MouseScrollMixin.
 */
final class HandEditor {
    private static final long DOUBLE_MS = 400;

    /** 0 = main hand, 1 = off hand, -1 = none. */
    private static int grabbed = -1, hovered = -1, lastPressHand = -1;
    private static long lastPress;
    private static boolean wasDown;
    private static int anchorMx, anchorMy, lastMy;
    private static double anchorX, anchorY;

    private HandEditor() {}

    /** Forget everything (the chat was closed, or View Model is off). */
    static void reset() {
        grabbed = hovered = lastPressHand = -1;
        wasDown = false;
    }

    // ------------------------------------------------------------------ geometry

    private static boolean isMain(int hand) { return hand == 0; }

    private static NumberSetting x(ViewModelModule v, int hand) { return isMain(hand) ? v.mainX : v.offX; }
    private static NumberSetting y(ViewModelModule v, int hand) { return isMain(hand) ? v.mainY : v.offY; }
    private static NumberSetting z(ViewModelModule v, int hand) { return isMain(hand) ? v.mainZ : v.offZ; }
    private static NumberSetting scale(ViewModelModule v, int hand) { return isMain(hand) ? v.mainScale : v.offScale; }

    /** Is this hand on the right side of the screen? (the main hand is, unless the game is set to left-handed) */
    private static boolean right(MinecraftClient c, int hand) {
        boolean mainRight = c.options.getMainArm().getValue() == Arm.RIGHT;
        return isMain(hand) == mainRight;
    }

    /** The area the held item covers on the screen: {x, y, w, h} in GUI pixels. */
    private static int[] area(MinecraftClient c, ViewModelModule v, int hand) {
        double sc = scale(v, hand).get();
        // The hand's pivot in camera space, the same point ViewModelModule.apply moves and scales around.
        // Offsets are applied on top of it, so the pivot moves exactly with the hand.
        double side = right(c, hand) ? 1 : -1;
        double px = side * 0.56 + x(v, hand).get();
        double py = -0.52 + y(v, hand).get();
        double pz = -0.72 + z(v, hand).get();                  // camera looks down -z
        // The item sits up and toward the screen centre from the pivot. Tune these two numbers if the box is off.
        px -= side * 0.10;
        py += 0.20;
        double depth = -pz;
        if (depth < 0.05) return new int[]{0, 0, 0, 0};
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double cx = sw / 2.0 + (px / depth) / tan * (sh / 2.0);
        double cy = sh / 2.0 - (py / depth) / tan * (sh / 2.0);
        // Box size: the item's on-screen size shrinks with depth, scaled by the hand scale.
        double size = (sh / 2.0) / tan / depth;
        int w = (int) Math.round(0.30 * size * sc), h = (int) Math.round(0.42 * size * sc);
        return new int[]{(int) cx - w / 2, (int) cy - h / 2, w, h};
    }

    private static int handUnder(MinecraftClient c, ViewModelModule v, int mx, int my) {
        int best = -1;
        double bestD = Double.MAX_VALUE;
        for (int hand = 0; hand < 2; hand++) {
            int[] a = area(c, v, hand);
            if (mx < a[0] || mx >= a[0] + a[2] || my < a[1] || my >= a[1] + a[3]) continue;
            double d = Math.hypot(mx - (a[0] + a[2] / 2.0), my - (a[1] + a[3] / 2.0));
            if (d < bestD) { bestD = d; best = hand; }
        }
        return best;
    }

    // ------------------------------------------------------------------ per frame

    /** Called by HudEdit every frame while the chat is open. {@code busy}: a HUD element is being dragged right now. */
    static void update(DrawContext ctx, MinecraftClient c, int mx, int my, boolean down, boolean shift, boolean busy) {
        ViewModelModule v = ModuleManager.get(ViewModelModule.class);
        if (v == null || !v.isEnabled()) { reset(); return; }

        hovered = busy && grabbed < 0 ? -1 : handUnder(c, v, mx, my);
        boolean press = down && !wasDown;

        if (grabbed >= 0) {
            NumberSetting sx = x(v, grabbed), sy = y(v, grabbed), sz = z(v, grabbed);
            double u = ViewModelModule.unit(c);
            if (shift) {                                              // push away / pull closer; xy stay where they are
                sz.set(sz.get() + (my - lastMy) * 0.004);
                anchorMx = mx; anchorMy = my; anchorX = sx.get(); anchorY = sy.get();
            } else {                                                  // the hand follows the mouse
                sx.set(anchorX + (mx - anchorMx) / u);
                sy.set(anchorY - (my - anchorMy) / u);
            }
            if (press) grabbed = -1;                                  // a click lets go
        } else if (press && !busy && hovered >= 0) {
            long now = System.currentTimeMillis();
            if (lastPressHand == hovered && now - lastPress < DOUBLE_MS) {          // double click: grab
                grabbed = hovered;
                anchorMx = mx; anchorMy = my;
                anchorX = x(v, grabbed).get();
                anchorY = y(v, grabbed).get();
                lastPressHand = -1;
            } else {
                lastPressHand = hovered;
                lastPress = now;
            }
        }
        wasDown = down;
        lastMy = my;

        draw(ctx, c, v, mx, my);
    }

    private static void draw(DrawContext ctx, MinecraftClient c, ViewModelModule v, int mx, int my) {
        int show = grabbed >= 0 ? grabbed : hovered;
        if (show < 0) return;
        int[] a = area(c, v, show);
        int acc = Theme.current().accent();
        var tr = c.textRenderer;
        boolean held = grabbed >= 0;
        ClickGuiScreen.outline(ctx, a[0], a[1], a[2], a[3], held ? 0xFFFFFFFF : ((acc & 0xFFFFFF) | 0xB0000000), 8);

        if (!held) {                                                   // a hint above the hand
            String t = "двойной клик";
            int tw = Fonts.width(tr, t) + 16, tx = a[0] + (a[2] - tw) / 2, ty = a[1] - 18;
            ClickGuiScreen.rrect(ctx, tx, ty, tw, 14, 0xE0000000 | (acc & 0xFFFFFF), 7);
            Fonts.draw(ctx, tr, t, tx + 8, ty + 3, 0xFFFFFFFF);
            return;
        }
        // Grabbed: a label with a mouse icon and the scale next to the cursor, and what to do next under it.
        String label = (isMain(grabbed) ? "Main" : "Off") + "  ×" + String.format("%.2f", scale(v, grabbed).get());
        int tw = Fonts.width(tr, label) + 26, tx = mx + 14, ty = my + 12;
        if (tx + tw > c.getWindow().getScaledWidth()) tx = mx - 14 - tw;
        ClickGuiScreen.rrect(ctx, tx, ty, tw, 16, 0xE0101018, 8);
        ClickGuiScreen.outline(ctx, tx, ty, tw, 16, 0x66FFFFFF, 8);
        ClickGuiScreen.outline(ctx, tx + 6, ty + 3, 7, 10, 0xFFFFFFFF, 3);        // mouse icon
        ctx.fill(tx + 9, ty + 4, tx + 10, ty + 7, 0xFFFFFFFF);
        Fonts.draw(ctx, tr, label, tx + 18, ty + 4, 0xFFFFFFFF);
        Fonts.draw(ctx, tr, "колесо - размер, Shift - ближе/дальше, клик - отпустить", Math.max(4, tx - 40), ty + 20, 0xFFB8B8C4);
    }

    // ------------------------------------------------------------------ mouse wheel

    /**
     * The mouse wheel (MouseScrollMixin): over a hand or while one is grabbed it changes that hand's scale instead of
     * scrolling the chat. Returns true when it was used.
     */
    static boolean onScroll(double amount) {
        int hand = grabbed >= 0 ? grabbed : hovered;
        if (hand < 0) return false;
        ViewModelModule v = ModuleManager.get(ViewModelModule.class);
        if (v == null || !v.isEnabled()) return false;
        NumberSetting s = scale(v, hand);
        s.set(s.get() + Math.signum(amount) * 0.05);
        return true;
    }
}
