package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * The rule behind NoClip and NoClip Fly (applied by PhaseMixin to every move of your player): blocks do not stop you
 * sideways or upwards, but a floor still holds you up as long as you are not inside a block. Inside a block (a wall) you
 * fall down: with "Fall in walls" on (NoClip) you sink through it; off, the floor check is skipped and you glide through
 * the wall at the same height. Only the floor is checked; the rest is vanilla's no-clip movement.
 */
final class Phase {
    private Phase() {}

    /** True for the local player while NoClip or NoClip Fly is on. */
    static boolean applies(Entity e) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != e || c.world == null) return false;
        if (!c.isInSingleplayer()) return false;                 // NoClip is for singleplayer worlds only
        for (Module m : ModuleManager.all()) {
            if (m.isEnabled() && (m instanceof NoClipModule || (m instanceof FlyModule f && f.isNoClip()))) return true;
        }
        return false;
    }

    static double maxThickness() {
        NoClipModule m = ModuleManager.get(NoClipModule.class);
        return m == null ? 5 : m.maxThickness.get();
    }

    /**
     * Sideways movement into a wall is allowed only if free space lies within maxThickness blocks past the
     * destination in that direction; a thicker wall stops the horizontal movement. Vertical movement is untouched.
     */
    static Vec3d limitThickness(MinecraftClient c, ClientPlayerEntity p, Vec3d m) {
        if (m.x == 0 && m.z == 0) return m;
        Box box = p.getBoundingBox();
        if (c.world.isSpaceEmpty(box.offset(m.x, 0, m.z))) return m;   // destination is free: nothing to limit
        Vec3d dir = new Vec3d(m.x, 0, m.z).normalize();
        double max = maxThickness();
        for (double d = 0.25; d <= max + 1e-6; d += 0.25) {
            if (c.world.isSpaceEmpty(box.offset(m.x + dir.x * d, 0, m.z + dir.z * d))) return m;
        }
        return new Vec3d(0, m.y, 0);
    }

    static boolean fallInWalls() {
        NoClipModule m = ModuleManager.get(NoClipModule.class);
        return m == null || !m.isEnabled() || m.fallInWalls.get();
    }

    /** Whether your body overlaps a block (a hair smaller than the hitbox, so standing on a floor does not count). */
    static boolean inWall(MinecraftClient c, ClientPlayerEntity p) {
        return !c.world.isSpaceEmpty(p.getBoundingBox().contract(0.002));
    }

    /** The movement of this tick with its downward part cut at the floor (when there is a floor to stand on). */
    static Vec3d clip(MinecraftClient c, ClientPlayerEntity p, Vec3d m) {
        m = limitThickness(c, p, m);
        if (m.y > 0) { p.setOnGround(false); return m; }
        if (m.y == 0) return m;
        if (fallInWalls() && inWall(c, p)) return m;              // inside a wall: fall

        Box box = p.getBoundingBox();
        double fall = -m.y;
        if (c.world.isSpaceEmpty(box.offset(0, -fall, 0))) { p.setOnGround(false); return m; }
        double lo = 0, hi = fall;                                  // the largest drop that stays clear of the floor
        for (int i = 0; i < 10; i++) {
            double mid = (lo + hi) / 2;
            if (c.world.isSpaceEmpty(box.offset(0, -mid, 0))) lo = mid; else hi = mid;
        }
        p.setOnGround(true);                                       // so that jumping works
        return new Vec3d(m.x, -lo, m.z);
    }
}
