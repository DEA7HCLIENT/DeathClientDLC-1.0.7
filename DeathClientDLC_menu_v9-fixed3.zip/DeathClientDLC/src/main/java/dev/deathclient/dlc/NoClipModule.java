package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/**
 * NoClip: you walk through walls, but the floor still holds you up while you are not inside a block. Inside a block
 * (a wall) you fall down. "Fall in walls" off: you glide through walls at the same height instead of sinking.
 * The rule itself is in Phase (applied by PhaseMixin on every move).
 */
public class NoClipModule extends Module {
    public final BoolSetting fallInWalls = add(new BoolSetting("Fall in walls", true));
    /** Thickest wall (in blocks) you can pass through sideways. Singleplayer only. */
    public final NumberSetting maxThickness = add(new NumberSetting("Max wall thickness", 5, 1, 5, 1));

    public NoClipModule() { super("NoClip", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player != null && !c.isInSingleplayer() && !notified) {
            notified = true;
            c.player.sendMessage(Text.literal("§7[§cDeath Client§7] §fNoClip работает только в одиночной игре."), false);
        }
    }

    private boolean notified;

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.noClip = false;
    }
}
