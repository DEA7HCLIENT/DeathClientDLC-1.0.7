package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam: the camera detaches from the player and flies freely (WASD along the view, Space up, Shift down, mouse to look).
 * The real player stays where it is and stops reacting to movement keys (see mixin.KeyboardInputMixin).
 * Implemented with a dummy camera entity, the same way vanilla spectating works.
 * The camera is moved every frame (not every tick), so it needs no previous-position interpolation:
 * copyPositionAndRotation() resets the entity's interpolation state to the new values.
 */
public class FreecamModule extends Module {
    /** Blocks per tick (20 ticks = 1 second); movement itself is scaled by frame time. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.8, 0.1, 5.0, 0.1));
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.6, 0.1, 3.0, 0.1));
    /** 0 = the camera starts and stops at once; higher = it eases in and out. */
    public final NumberSetting smooth = add(new NumberSetting("Smoothing", 0.4, 0, 1, 0.1));
    /** Hold the sprint key to fly twice as fast. */
    public final BoolSetting boost = add(new BoolSetting("Sprint boost", true));
    /** Off: attacking, placing and breaking are blocked while the camera is detached (they would aim from the camera). */
    public final BoolSetting interact = add(new BoolSetting("Interact", false));

    private static volatile FreecamModule instance;

    private OtherClientPlayerEntity cam;
    private OtherClientPlayerEntity scratch;   // staging entity: set values here, then copy them to cam
    private ClientWorld camWorld;
    private float savedYaw, savedPitch;
    /** Camera look angles. Once the mouse hook fires they are driven by the mouse and the real player no longer turns. */
    private float camYaw, camPitch;
    private volatile boolean lookHooked;
    private long lastNanos;
    private double vx, vy, vz;                 // camera velocity in blocks per tick (for the smoothing)

    public FreecamModule() {
        super("Freecam", Category.RENDER);
        instance = this;
    }

    /** True while the camera is detached; read by the input mixin. */
    public static boolean active() {
        FreecamModule m = instance;
        return m != null && m.isEnabled() && m.cam != null;
    }

    @Override
    protected void onEnable() { start(MinecraftClient.getInstance()); }

    @Override
    protected void onDisable() { stop(MinecraftClient.getInstance()); }

    private void start(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        cam = new OtherClientPlayerEntity(c.world, p.getGameProfile());
        scratch = new OtherClientPlayerEntity(c.world, p.getGameProfile());
        camWorld = c.world;
        cam.copyPositionAndRotation(p);
        cam.noClip = true;
        scratch.copyPositionAndRotation(p);
        savedYaw = p.getYaw();
        savedPitch = p.getPitch();
        camYaw = savedYaw;
        camPitch = savedPitch;
        lookHooked = false;
        lastNanos = System.nanoTime();
        vx = vy = vz = 0;
        c.setCameraEntity(cam);
    }

    private void stop(MinecraftClient c) {
        if (cam == null) return;
        cam = null;
        scratch = null;
        camWorld = null;
        ClientPlayerEntity p = c.player;
        if (p != null) {
            c.setCameraEntity(p);
            p.setYaw(savedYaw);
            p.setPitch(savedPitch);
        }
    }

    @Override
    public void onTick(MinecraftClient c) {
        // Re-create the camera after a world change (the game resets the camera entity on join).
        if (cam == null || camWorld != c.world) start(c);
        if (cam != null && c.getCameraEntity() != cam) c.setCameraEntity(cam);
    }

    /**
     * Called by EntityLookMixin when the mouse turns the local player. While Freecam is on the mouse turns the camera
     * instead and the real player keeps looking where it was (nothing odd goes to the server). Returns true if consumed.
     */
    public static boolean look(double dx, double dy) {
        FreecamModule m = instance;
        if (m == null || !m.isEnabled() || m.cam == null) return false;
        m.lookHooked = true;
        m.camYaw += (float) dx * 0.15f;                                             // same factor as vanilla
        m.camPitch = Math.max(-90f, Math.min(90f, m.camPitch + (float) dy * 0.15f));
        return true;
    }

    /**
     * Called at the start of every client tick (DeathClientDLC). With Interact off, attack / use / pick presses are
     * thrown away before the game handles them, so nothing is hit, placed or broken from the camera's position.
     */
    public static void blockInteractions(MinecraftClient c) {
        FreecamModule m = instance;
        if (m == null || !m.isEnabled() || m.cam == null || m.interact.get()) return;
        while (c.options.attackKey.wasPressed()) { /* drop */ }
        while (c.options.useKey.wasPressed()) { /* drop */ }
        while (c.options.pickItemKey.wasPressed()) { /* drop */ }
        c.options.attackKey.setPressed(false);                  // also stops holding to break a block
        c.options.useKey.setPressed(false);
    }

    private static volatile long worldHookNanos;

    /**
     * Called by GameRendererMixin at the start of the world render, i.e. after the mouse has turned the player and
     * before the game reads the camera entity: the camera is up to date in the very frame it is drawn.
     */
    public static void worldFrame() {
        worldHookNanos = System.nanoTime();
        run();
    }

    /**
     * HUD callback, runs every frame. The HUD is drawn AFTER the world, so on its own it makes the camera lag one frame
     * behind the mouse (and it stops with F1). It is only a fallback now: skipped while the world hook is working.
     */
    static void frame() {
        if (System.nanoTime() - worldHookNanos < 200_000_000L) return;
        run();
    }

    private static void run() {
        FreecamModule m = instance;
        if (m == null || !m.isEnabled() || m.cam == null) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return;
        m.step(c);
    }

    private void step(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        long now = System.nanoTime();
        double ticks = Math.min((now - lastNanos) / 5.0e7, 3.0);   // frame time in ticks, capped
        lastNanos = now;

        // Without the mouse hook the mouse still turns the player: follow the player's angles then.
        if (!lookHooked) { camYaw = p.getYaw(); camPitch = p.getPitch(); }

        // Wanted velocity (blocks per tick) from the keys.
        double tx = 0, ty = 0, tz = 0;
        if (c.currentScreen == null) {
            // WASD flies along the view direction (W while looking up climbs), Space / Shift go straight up / down.
            double yr = Math.toRadians(camYaw), pr = Math.toRadians(camPitch);
            double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
            double sx = Math.cos(yr), sz = Math.sin(yr);   // to the left
            int f = (c.options.forwardKey.isPressed() ? 1 : 0) - (c.options.backKey.isPressed() ? 1 : 0);
            int s = (c.options.leftKey.isPressed() ? 1 : 0) - (c.options.rightKey.isPressed() ? 1 : 0);
            double dx = fx * f + sx * s, dy = fy * f, dz = fz * f + sz * s;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double boostK = boost.get() && c.options.sprintKey.isPressed() ? 2.0 : 1.0;
            if (len > 1e-6) {
                double k = speed.get() * boostK / len;
                tx = dx * k; ty = dy * k; tz = dz * k;
            }
            ty += ((c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0)) * vertical.get() * boostK;
        }
        // Ease towards it: the time constant grows with Smoothing (up to about 3 ticks).
        double sm = smooth.get();
        double a = sm <= 0 ? 1.0 : 1.0 - Math.exp(-ticks / (sm * 3.0));
        vx += (tx - vx) * a; vy += (ty - vy) * a; vz += (tz - vz) * a;
        double x = cam.getX() + vx * ticks, y = cam.getY() + vy * ticks, z = cam.getZ() + vz * ticks;
        scratch.setPosition(x, y, z);
        scratch.setYaw(camYaw);
        scratch.setPitch(camPitch);
        cam.copyPositionAndRotation(scratch);
    }
}
