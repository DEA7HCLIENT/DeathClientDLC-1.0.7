package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** Friend list (case-insensitive nicknames), saved in config/deathclientdlc/friends.txt. */
final class Friends {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/friends.txt");
    private static final Set<String> NAMES = new TreeSet<>();

    private Friends() {}

    static void load() {
        NAMES.clear();
        if (!Files.exists(FILE)) return;
        try {
            for (String l : Files.readAllLines(FILE)) {
                String s = l.trim().toLowerCase();
                if (!s.isEmpty()) NAMES.add(s);
            }
        } catch (IOException ignored) {}
    }

    static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, new ArrayList<>(NAMES));
        } catch (IOException ignored) {}
    }

    static boolean add(String name) { boolean r = NAMES.add(name.trim().toLowerCase()); if (r) save(); return r; }
    static boolean remove(String name) { boolean r = NAMES.remove(name.trim().toLowerCase()); if (r) save(); return r; }
    static void clear() { NAMES.clear(); save(); }
    static boolean has(String name) { return NAMES.contains(name.trim().toLowerCase()); }
    static List<String> list() { return new ArrayList<>(NAMES); }

    /** True if the entity is a player on the friend list and the Friends module is on. */
    static boolean isFriend(Entity e) {
        if (!(e instanceof PlayerEntity p)) return false;
        FriendsModule m = ModuleManager.get(FriendsModule.class);
        return m != null && m.isEnabled() && NAMES.contains(p.getName().getString().toLowerCase());
    }

    /** True if combat/target modules must leave this entity alone. */
    static boolean skip(Entity e) {
        if (!isFriend(e)) return false;
        FriendsModule m = ModuleManager.get(FriendsModule.class);
        return m.protect.get();
    }
}
