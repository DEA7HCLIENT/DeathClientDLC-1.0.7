package dev.deathclient.dlc;

/**
 * Client Badge: players who use this client get a small badge left of their nickname (above their head and in
 * the tab list). Always on by default. "Tag my chat" is how the others learn that you have the client (an invisible
 * marker at the end of your chat messages); without it you see the badge on others but they do not see it on you.
 */
public class ClientBadgeModule extends Module {
    public final BoolSetting tagChat = add(new BoolSetting("Tag my chat", true));
    public final BoolSetting self = add(new BoolSetting("Show on me", true));

    public ClientBadgeModule() { super("Client Badge", Category.MISC, true); }
}
