package dev.deathclient.dlc;

/**
 * Custom Font: the font of the client's text. Font: Default, DejaVu, Mono, Serif or Custom. Custom is your own
 * .ttf / .otf: drop the file onto the main menu or the cheat menu, or type ".font add <path>" (see CustomFontPack);
 * ".font reset" goes back. "Cheat menu" applies the font to the cheat menu too (otherwise it keeps the game's font).
 * The HUD, the main menu and the target card always use the chosen font.
 */
public class CustomFontModule extends Module {
    public final NumberSetting font = add(new NumberSetting("Font", 1, 1, 5, 1).labels("Default", "DejaVu", "Mono", "Serif", "Custom"));
    public final BoolSetting menus = add(new BoolSetting("Cheat menu", true));

    public CustomFontModule() { super("Custom Font", Category.MISC, true); }
}
