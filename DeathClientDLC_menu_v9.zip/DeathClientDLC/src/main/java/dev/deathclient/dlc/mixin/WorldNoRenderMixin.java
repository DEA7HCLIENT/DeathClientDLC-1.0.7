package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * No Render, Weather: on your client the rain and thunder strength is always 0, so there is no rain or snow, no dark
 * stormy sky and no flashes. Only the client world is changed; the server's weather is not.
 * require = 0: a method that is named differently in this build is skipped.
 */
@Mixin(World.class)
public abstract class WorldNoRenderMixin {
    @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noRain(CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ClientWorld && NoRenderModule.weather()) cir.setReturnValue(0.0f);
    }

    @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noThunder(CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ClientWorld && NoRenderModule.weather()) cir.setReturnValue(0.0f);
    }
}
