package dev.deathclient.dlc;

/**
 * Custom Fog: the color of the fog (which is also the color of the horizon: Hue / Saturation / Brightness, the theme
 * color, or a Rainbow) and, with "Limit distance" on, how close the fog starts: Distance is in chunks and can only bring
 * the fog nearer than your view distance. Client-side only. The hooks (FogRendererMixin) are in the optional mixin config
 * deathclientdlc.sky.mixins.json: if the fog code is named differently in your Minecraft version the game still starts,
 * and the module simply has no effect.
 */
public class CustomFogModule extends Module {
    public final NumberSetting hue = add(new NumberSetting("Hue", 280, 0, 360, 5));
    public final NumberSetting saturation = add(new NumberSetting("Saturation", 60, 0, 100, 5));
    public final NumberSetting brightness = add(new NumberSetting("Brightness", 80, 0, 100, 5));
    public final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));
    public final BoolSetting limitDistance = add(new BoolSetting("Limit distance", false));
    public final NumberSetting distance = add(new NumberSetting("Distance", 8, 2, 32, 1));

    public CustomFogModule() { super("Custom Fog", Category.RENDER); }

    /** The fog color (RGB), or -1 while the module is off. */
    public static int color() {
        CustomFogModule m = ModuleManager.get(CustomFogModule.class);
        return m == null || !m.isEnabled() ? -1 : EnvColor.rgb(m.hue, m.saturation, m.brightness, m.rainbow, m.themeColor);
    }

    /** The view distance (chunks) the fog is computed from: yours, or the smaller Distance. */
    public static int viewDistance(int actual) {
        CustomFogModule m = ModuleManager.get(CustomFogModule.class);
        return m == null || !m.isEnabled() || !m.limitDistance.get() ? actual : Math.min(actual, (int) m.distance.get());
    }
}
