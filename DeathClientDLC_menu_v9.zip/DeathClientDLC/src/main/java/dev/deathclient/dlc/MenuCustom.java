package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.Supplier;

/** Main-menu customisation: own background image and moved buttons (saved between launches). */
final class MenuCustom {
    static final int SLOTS = 8;
    static final int[] offX = new int[SLOTS];
    static final int[] offY = new int[SLOTS];
    /** Button size in GUI pixels; 0 = default size. */
    static final int[] sizeW = new int[SLOTS];
    static final int[] sizeH = new int[SLOTS];

    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc");
    private static final Path BG = DIR.resolve("menu_bg.png");
    private static final Path FILE = DIR.resolve("menu_v2.properties");
    private static final Identifier BG_ID = Identifier.of("deathclientdlc", "custom_menu_bg");

    /** Background follows the mouse a little ("Мышка!" on the main menu). */
    static boolean mouse = true;
    private static String bgName = "";
    private static boolean loaded, hasBg;
    private static int bgW = 1, bgH = 1;

    private MenuCustom() {}

    static boolean hasBackground() { return hasBg; }

    static String bgName() { return bgName; }

    static Path backgroundsDir() { return DIR.resolve("backgrounds"); }

    /** Pictures in the backgrounds folder (png / jpg), by name. */
    static List<Path> listBackgrounds() {
        List<Path> out = new ArrayList<>();
        try {
            Files.createDirectories(backgroundsDir());
            try (var st = Files.list(backgroundsDir())) {
                st.filter(Files::isRegularFile).filter(p -> {
                    String n = p.getFileName().toString().toLowerCase();
                    return n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg");
                }).sorted().forEach(out::add);
            }
        } catch (IOException ignored) {}
        return out;
    }

    /** Uses a picture from the backgrounds folder. */
    static void useFile(Path p) throws Exception {
        setBackground(p);
        bgName = p.getFileName().toString();
        save();
    }

    /** Copies a picture into the backgrounds folder and uses it. */
    static void addAndUse(Path src) throws Exception {
        Files.createDirectories(backgroundsDir());
        Path dst = backgroundsDir().resolve(src.getFileName().toString());
        if (!src.toAbsolutePath().equals(dst.toAbsolutePath())) Files.copy(src, dst, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        useFile(dst);
    }

    /** Call on the render thread (the texture is created here). */
    static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        loadProps();
        if (Files.exists(BG)) {
            try { show(Files.readAllBytes(BG)); } catch (Exception e) { hasBg = false; }
        }
    }

    static void setBackground(Path src) throws Exception {
        byte[] png = toPng(Files.readAllBytes(src));
        Files.createDirectories(DIR);
        Files.write(BG, png);
        show(png);
    }

    static void resetBackground() {
        hasBg = false;
        bgName = "";
        try { Files.deleteIfExists(BG); } catch (IOException ignored) {}
        save();
    }

    static void resetButtons() {
        for (int i = 0; i < SLOTS; i++) { offX[i] = 0; offY[i] = 0; sizeW[i] = 0; sizeH[i] = 0; }
        save();
    }

    static void save() {
        Properties p = new Properties();
        p.setProperty("mouse", mouse ? "1" : "0");
        p.setProperty("bgname", bgName);
        for (int i = 0; i < SLOTS; i++) {
            p.setProperty("x" + i, Integer.toString(offX[i]));
            p.setProperty("y" + i, Integer.toString(offY[i]));
            p.setProperty("w" + i, Integer.toString(sizeW[i]));
            p.setProperty("h" + i, Integer.toString(sizeH[i]));
        }
        try {
            Files.createDirectories(DIR);
            try (var out = Files.newOutputStream(FILE)) { p.store(out, "Death Client main menu layout"); }
        } catch (IOException ignored) {}
    }

    private static void loadProps() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) { p.load(in); } catch (IOException e) { return; }
        mouse = !"0".equals(p.getProperty("mouse"));
        bgName = p.getProperty("bgname", "");
        for (int i = 0; i < SLOTS; i++) {
            offX[i] = num(p.getProperty("x" + i));
            offY[i] = num(p.getProperty("y" + i));
            sizeW[i] = num(p.getProperty("w" + i));
            sizeH[i] = num(p.getProperty("h" + i));
        }
    }

    private static int num(String s) {
        if (s == null) return 0;
        try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return 0; }
    }

    static byte[] toPng(byte[] raw) throws IOException {
        boolean isPng = raw.length > 8 && (raw[0] & 0xFF) == 0x89 && raw[1] == 'P' && raw[2] == 'N' && raw[3] == 'G';
        if (isPng) return raw;
        BufferedImage bi = ImageIO.read(new ByteArrayInputStream(raw));
        if (bi == null) throw new IOException("unsupported image");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(bi, "png", out);
        return out.toByteArray();
    }

    private static void show(byte[] png) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        int w = img.getWidth(), h = img.getHeight();
        AbstractTexture tex = makeTexture(img);
        MinecraftClient.getInstance().getTextureManager().registerTexture(BG_ID, tex);
        bgW = w;
        bgH = h;
        hasBg = true;
    }

    /** The texture constructor changed between versions, so pick whichever one exists. */
    static AbstractTexture makeTexture(NativeImage img) throws Exception {
        Supplier<String> name = () -> "deathclientdlc_menu_bg";
        AbstractTexture tex = null;
        for (Constructor<?> c : NativeImageBackedTexture.class.getConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            if (p.length == 1 && p[0] == NativeImage.class) {
                tex = (AbstractTexture) c.newInstance(img);
                break;
            }
            if (p.length == 2 && p[1] == NativeImage.class) {
                if (p[0] == String.class) { tex = (AbstractTexture) c.newInstance("deathclientdlc_menu_bg", img); break; }
                if (p[0] == Supplier.class) { tex = (AbstractTexture) c.newInstance(name, img); break; }
            }
        }
        if (tex == null) throw new IllegalStateException("no texture constructor");
        try { tex.getClass().getMethod("upload").invoke(tex); } catch (Exception ignored) {}
        return tex;
    }

    /** Cover-fit, centred. */
    static void drawBackground(DrawContext ctx, int width, int height) { drawBackground(ctx, width, height, 0, 0); }

    static void drawBackground(DrawContext ctx, int width, int height, int ox, int oy) {
        double scale = Math.max((double) width / bgW, (double) height / bgH);
        int rw = (int) Math.min(bgW, Math.ceil(width / scale));
        int rh = (int) Math.min(bgH, Math.ceil(height / scale));
        float u = (bgW - rw) / 2f;
        float v = (bgH - rh) / 2f;
        int m = (ox != 0 || oy != 0) ? Ui.PAD : 0;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BG_ID, -m + ox, -m + oy, u, v, width + 2 * m, height + 2 * m, rw, rh, bgW, bgH);
    }
}
