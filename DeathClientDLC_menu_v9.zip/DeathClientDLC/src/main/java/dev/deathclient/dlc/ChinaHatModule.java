package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * China Hat: a flat white disc (textures/gui/hat_disc.png, a plain circle) lying horizontally just above your head.
 * Drawn as a screen overlay glued to that horizontal plane: the texture is cut into thin strips and each strip is
 * placed by projecting the matching line, which gives the correct perspective (same technique as Jump Circle).
 * Visible in third person (hidden in first person by default) and from Freecam.
 */
public class ChinaHatModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/hat_disc.png");
    private static final int TEX = 256;

    /** Radius of the disc in blocks. */
    public final NumberSetting radius = add(new NumberSetting("Radius", 0.7, 0.3, 1.5, 0.05));
    /** How far above the top of the head the disc floats. */
    public final NumberSetting height = add(new NumberSetting("Height", 0.1, 0.0, 1.0, 0.05));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 90, 10, 100, 5));
    /** Strips across the disc: more is smoother and a little heavier. */
    public final NumberSetting quality = add(new NumberSetting("Quality", 40, 20, 64, 4));
    /** Off = plain white as in the texture. */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    private final ScreenProjector proj = new ScreenProjector();

    public ChinaHatModule() { super("China Hat", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ChinaHatModule m = ModuleManager.get(ChinaHatModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        proj.begin(c, delta);
        Vec3d pos = p.getLerpedPos(delta);
        double cx = pos.x, cz = pos.z, cy = pos.y + p.getHeight() + height.get();
        double s = radius.get();                                  // half-size of the textured square = disc radius
        int a = (int) Math.round(opacity.get() / 100.0 * 255);
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;
        int color = (a << 24) | rgb;
        int n = (int) quality.get();
        double rx = proj.rightX(), rz = proj.rightZ();
        double fx = rz, fz = -rx;                                 // ground forward = right rotated 90 degrees

        double[] xl = new double[n + 1], xr = new double[n + 1], y = new double[n + 1];
        boolean[] ok = new boolean[n + 1];
        for (int k = 0; k <= n; k++) {
            double zeta = -s + 2 * s * k / n;                     // far side has the larger zeta
            double bx = cx + fx * zeta, bz = cz + fz * zeta;
            if (!proj.project(new Vec3d(bx - rx * s, cy, bz - rz * s))) continue;
            double lx = proj.out[0], ly = proj.out[1];
            if (!proj.project(new Vec3d(bx + rx * s, cy, bz + rz * s))) continue;
            xl[k] = lx;
            xr[k] = proj.out[0];
            y[k] = (ly + proj.out[1]) / 2.0;
            ok[k] = true;
        }
        for (int k = 0; k < n; k++) {
            if (!ok[k] || !ok[k + 1]) continue;                   // a strip behind the camera is dropped
            int y0 = (int) Math.round(Math.min(y[k], y[k + 1]));
            int y1 = (int) Math.round(Math.max(y[k], y[k + 1]));
            int x0 = (int) Math.round((xl[k] + xl[k + 1]) / 2.0);
            int x1 = (int) Math.round((xr[k] + xr[k + 1]) / 2.0);
            int w = x1 - x0, h = Math.max(1, y1 - y0);
            if (w < 1 || w > 4000 || h > 400) continue;
            int vTop = (n - (k + 1)) * TEX / n, vBot = (n - k) * TEX / n;   // far strips use the top of the texture
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, x0, y0, 0f, (float) vTop,
                    w, h, TEX, Math.max(1, vBot - vTop), TEX, TEX, color);
        }
    }
}
