package dev.deathclient.dlc.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.deathclient.dlc.FreecamModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Freecam: the mouse turns the camera instead of the real player. The two deltas are picked from the method's
 * arguments by type and order. require = 0: if the method is missing in this build the hook is skipped and Freecam
 * falls back to following the player's own rotation.
 */
@Mixin(Entity.class)
public abstract class EntityLookMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$freecamLook(CallbackInfo ci,
                                            @Local(argsOnly = true, ordinal = 0) double dx,
                                            @Local(argsOnly = true, ordinal = 1) double dy) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (FreecamModule.look(dx, dy)) ci.cancel();
    }
}
