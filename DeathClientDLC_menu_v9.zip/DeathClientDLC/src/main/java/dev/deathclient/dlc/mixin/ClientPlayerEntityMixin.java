package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render, Potion effects: the nausea wobble (and the portal swirl) never starts, because its intensity is not updated.
 * require = 0: if the method is named differently in this build, nothing happens.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "tickNausea", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noNausea(CallbackInfo ci) {
        if (NoRenderModule.effects()) ci.cancel();
    }
}
