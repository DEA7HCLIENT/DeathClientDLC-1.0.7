package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * NoClip: you walk through walls, but the floor still holds you up while you are not inside a block. Inside a block
 * (a wall) you fall down. "Fall in walls" off: you glide through walls at the same height instead of sinking.
 * The rule itself is in Phase (applied by PhaseMixin on every move).
 */
public class NoClipModule extends Module {
    public final BoolSetting fallInWalls = add(new BoolSetting("Fall in walls", true));

    public NoClipModule() { super("NoClip", Category.MOVEMENT); }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.noClip = false;
    }
}
