package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TriggerBot: hits whatever your crosshair is on, nothing else. It never turns the camera and never
 * sends a rotation, so you aim and it only clicks (reach is the vanilla one, as for a real click).
 */
public class TriggerBotModule extends Module {
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    /** Hit only while falling, so every hit is a critical. */
    public final BoolSetting criticals = add(new BoolSetting("Criticals only", false));
    public final BoolSetting weaponOnly = add(new BoolSetting("Weapon only", false));
    /** Weapon charge needed before a hit (a little randomness is subtracted each time). */
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.92, 0.1, 1.0, 0.02));
    /** Extra random wait in ticks (0..Delay) after each hit. */
    public final NumberSetting delay = add(new NumberSetting("Delay", 1, 0, 10, 1));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    private int wait;

    public TriggerBotModule() { super("TriggerBot", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (wait > 0) { wait--; return; }
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator() || p.isUsingItem()) return;
        if (!(c.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof LivingEntity t) || !t.isAlive() || t.isSpectator()) return;
        if (playersOnly.get() && !(t instanceof PlayerEntity)) return;
        if (Friends.skip(t)) return;
        if (!invisible.get() && t.isInvisible()) return;
        if (weaponOnly.get() && !isWeapon(p.getMainHandStack())) return;
        if (criticals.get() && !canCrit(p)) return;

        double need = cooldown.get() - ThreadLocalRandom.current().nextDouble(0.0, 0.05);
        if (p.getAttackCooldownProgress(0.5f) < need) return;

        c.interactionManager.attackEntity(p, t);
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        int d = (int) delay.get();
        wait = d == 0 ? 0 : ThreadLocalRandom.current().nextInt(0, d + 1);
    }

    private static boolean isWeapon(ItemStack s) {
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    /** Falling, not on the ground, not climbing or swimming: vanilla's critical-hit conditions. */
    private static boolean canCrit(ClientPlayerEntity p) {
        return !p.isOnGround() && p.getVelocity().y < 0 && !p.isClimbing() && !p.isTouchingWater();
    }
}
