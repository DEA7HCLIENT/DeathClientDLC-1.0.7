package dev.deathclient.dlc;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EmptyBlockView;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * BedWars Helper.
 *
 * Auto bed break: breaks the nearest enemy bed in reach by itself. "Through walls" breaks it even when blocks are in
 * the way; with it off the bed is only broken when it can be seen, and "Break blockers" digs the first block in the
 * way instead of waiting. Your own bed is recognised by distance from where you spawned ("Own bed radius").
 *
 * Auto bed defense: builds layers of blocks around your own bed (the four sides of each half, one to three layers high,
 * then the top), each block placed against a solid neighbour, strongest blocks from the hotbar first.
 *
 * Both turn toward the block first (Rotation: None / Silent / Camera, see AuraRotation).
 * Not checked against any server's anti-cheat; breaking through walls in particular is something many servers flag.
 */
public class BedWarsHelperModule extends Module {
    // --- Auto bed break
    public final BoolSetting breakBed = add(new BoolSetting("Auto break bed", true));
    public final NumberSetting breakRange = add(new NumberSetting("Break range", 4.5, 2.0, 6.0, 0.1));
    public final BoolSetting walls = add(new BoolSetting("Through walls", true));
    public final BoolSetting tunnel = add(new BoolSetting("Break blockers", false));
    public final BoolSetting autoTool = add(new BoolSetting("Auto tool", true));
    public final NumberSetting rotation = add(AuraRotation.setting());

    // --- Auto bed defense
    public final BoolSetting defend = add(new BoolSetting("Auto bed defense", true));
    public final NumberSetting defendRange = add(new NumberSetting("Defend range", 6, 3, 8, 1));
    public final NumberSetting layers = add(new NumberSetting("Layers", 2, 1, 3, 1));
    public final BoolSetting top = add(new BoolSetting("Cover top", true));
    public final NumberSetting perTick = add(new NumberSetting("Blocks per tick", 1, 1, 4, 1));
    public final NumberSetting placeDelay = add(new NumberSetting("Place delay", 1, 0, 5, 1));
    public final BoolSetting strongest = add(new BoolSetting("Strongest blocks first", true));
    public final NumberSetting placeRotation = add(new NumberSetting("Place rotation", AuraRotation.SILENT, 1, 3, 1).labels("None", "Silent", "Camera"));

    // --- Both
    /** Beds within this many blocks of where you spawned are yours: defended, never broken. 0 = no such rule. */
    public final NumberSetting ownRadius = add(new NumberSetting("Own bed radius", 25, 0, 80, 1));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private static final double PLACE_REACH = 4.5;
    private static final Direction[] SIDES = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final Direction[] SUPPORT_ORDER = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};

    private World lastWorld;
    private Vec3d spawn, lastPos;
    private int savedSlot = -1;
    private int cooldown;

    public BedWarsHelperModule() { super("BedWars Helper", Category.MISC); }

    @Override
    protected void onEnable() { spawn = null; lastWorld = null; }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) restore(c.player);
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null) return;

        // Spawn point: where the player is when the world is entered, and again after a teleport (the game start).
        Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());
        if (c.world != lastWorld || spawn == null || (lastPos != null && lastPos.distanceTo(pos) > 20)) {
            lastWorld = c.world;
            spawn = pos;
        }
        lastPos = pos;
        if (cooldown > 0) cooldown--;
        if (c.currentScreen != null) return;

        boolean busy = false;
        if (defend.get()) busy = defend(c, p);
        if (!busy && breakBed.get()) busy = breakNearest(c, p);
        if (!busy) restore(p);
    }

    private void restore(ClientPlayerEntity p) {
        if (savedSlot != -1 && restoreSlot.get()) p.getInventory().setSelectedSlot(savedSlot);
        savedSlot = -1;
    }

    private void select(ClientPlayerEntity p, int slot) {
        int cur = p.getInventory().getSelectedSlot();
        if (slot == cur) return;
        if (savedSlot == -1) savedSlot = cur;
        p.getInventory().setSelectedSlot(slot);
    }

    /** Inside the own-bed radius around the spawn point. With the radius at 0 nothing counts as "own" for breaking. */
    private boolean nearSpawn(Vec3d v) {
        return ownRadius.get() > 0 && spawn != null && v.distanceTo(spawn) <= ownRadius.get();
    }

    // ------------------------------------------------------------------ auto bed break

    private boolean breakNearest(MinecraftClient c, ClientPlayerEntity p) {
        double range = breakRange.get();
        Vec3d eye = p.getEyePos();
        BlockPos base = p.getBlockPos();
        int r = (int) Math.ceil(range);
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            BlockPos pos = base.add(dx, dy, dz);
            if (!(c.world.getBlockState(pos).getBlock() instanceof BedBlock)) continue;
            Vec3d ctr = Vec3d.ofCenter(pos);
            double d = eye.distanceTo(ctr);
            if (d > range || nearSpawn(ctr) || d >= bestD) continue;
            best = pos;
            bestD = d;
        }
        if (best == null) return false;

        BlockPos target = best;
        if (!walls.get()) {
            BlockPos blocker = firstBlocker(c, p, eye, best);
            if (blocker != null) {
                if (!tunnel.get()) return false;                       // not visible: wait
                target = blocker;                                       // dig the way open
            }
        }

        BlockState st = c.world.getBlockState(target);
        Vec3d center = Vec3d.ofCenter(target);
        Direction side = Direction.getFacing(eye.x - center.x, eye.y - center.y, eye.z - center.z);
        if (autoTool.get()) selectTool(p, st);
        int rot = (int) rotation.get();
        AuraRotation.face(c, p, center, rot);
        c.interactionManager.updateBlockBreakingProgress(target, side);
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, rot);
        return true;
    }

    /** The first block between your eyes and the bed (null: the bed itself is hit first, so it can be seen). */
    private BlockPos firstBlocker(MinecraftClient c, ClientPlayerEntity p, Vec3d eye, BlockPos bed) {
        BlockHitResult h = c.world.raycast(new RaycastContext(eye, Vec3d.ofCenter(bed),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (h.getType() == HitResult.Type.MISS) return null;
        BlockPos hit = h.getBlockPos();
        if (c.world.getBlockState(hit).getBlock() instanceof BedBlock) return null;
        return hit;
    }

    private void selectTool(ClientPlayerEntity p, BlockState st) {
        int best = p.getInventory().getSelectedSlot();
        float bestSpeed = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        select(p, best);
    }

    // ------------------------------------------------------------------ auto bed defense

    /** Returns true while there is something left to build (so breaking waits). */
    private boolean defend(MinecraftClient c, ClientPlayerEntity p) {
        BlockPos bed = nearestOwnBed(c, p);
        if (bed == null) return false;

        List<BlockPos> halves = new ArrayList<>();
        halves.add(bed);
        for (Direction d : SIDES) {
            BlockPos n = bed.offset(d);
            if (c.world.getBlockState(n).getBlock() instanceof BedBlock) halves.add(n);
        }
        Set<BlockPos> bedSet = new LinkedHashSet<>(halves);

        // Build order: every layer around the sides from the bottom up, then the top.
        Set<BlockPos> targets = new LinkedHashSet<>();
        for (int layer = 0; layer < (int) layers.get(); layer++)
            for (BlockPos h : halves)
                for (Direction d : SIDES) {
                    BlockPos t = h.offset(d).up(layer);
                    if (!bedSet.contains(t)) targets.add(t);
                }
        if (top.get()) for (BlockPos h : halves) targets.add(h.up());

        Vec3d eye = p.getEyePos();
        boolean pending = false;
        int placed = 0;
        for (BlockPos t : targets) {
            if (!c.world.getBlockState(t).isReplaceable()) continue;
            if (eye.distanceTo(Vec3d.ofCenter(t)) > PLACE_REACH + 1.0) continue;
            pending = true;
            if (placed >= (int) perTick.get() || cooldown > 0) continue;
            Support sup = findSupport(c, eye, t);
            if (sup == null) continue;
            int slot = pickBlockSlot(c, p);
            if (slot < 0) return false;                                  // no usable blocks in the hotbar
            select(p, slot);
            int rot = (int) placeRotation.get();
            AuraRotation.face(c, p, sup.hit(), rot);
            c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(sup.hit(), sup.face(), sup.pos(), false));
            if (swing.get()) p.swingHand(Hand.MAIN_HAND);
            AuraRotation.restore(c, p, rot);
            placed++;
        }
        if (placed > 0) cooldown = (int) placeDelay.get();
        return pending;
    }

    private BlockPos nearestOwnBed(MinecraftClient c, ClientPlayerEntity p) {
        double range = defendRange.get();
        Vec3d eye = p.getEyePos();
        BlockPos base = p.getBlockPos();
        int r = (int) Math.ceil(range);
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            BlockPos pos = base.add(dx, dy, dz);
            if (!(c.world.getBlockState(pos).getBlock() instanceof BedBlock)) continue;
            Vec3d ctr = Vec3d.ofCenter(pos);
            double d = eye.distanceTo(ctr);
            if (d > range || d >= bestD) continue;
            if (ownRadius.get() > 0 && !nearSpawn(ctr)) continue;       // somebody else's bed
            best = pos;
            bestD = d;
        }
        return best;
    }

    private record Support(BlockPos pos, Direction face, Vec3d hit) {}

    /** A solid neighbour of {@code target} to click on: the ground first, then the sides, the top last. */
    private Support findSupport(MinecraftClient c, Vec3d eye, BlockPos target) {
        for (Direction d : SUPPORT_ORDER) {
            BlockPos n = target.offset(d);
            BlockState s = c.world.getBlockState(n);
            if (!s.isSolidBlock(c.world, n) || interactive(s.getBlock())) continue;
            Direction face = d.getOpposite();                            // the face of n that looks at the target
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (eye.distanceTo(hit) > PLACE_REACH) continue;
            return new Support(n, face, hit);
        }
        return null;
    }

    /** Blocks that react to a right click (clicking them would open or use them instead of placing a block). */
    private static boolean interactive(Block b) {
        return b instanceof BedBlock || b instanceof BlockWithEntity || b instanceof CraftingTableBlock
                || b instanceof DoorBlock || b instanceof TrapdoorBlock || b instanceof FenceGateBlock || b instanceof ButtonBlock;
    }

    private static boolean usable(Block b) {
        return !(b instanceof BedBlock || b instanceof TntBlock || b instanceof FallingBlock || b instanceof BlockWithEntity)
                && b.getDefaultState().isFullCube(EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
    }

    /** Hotbar slot with the best block to build with: the strongest one, or the one in hand when strongest is off. */
    private int pickBlockSlot(MinecraftClient c, ClientPlayerEntity p) {
        int held = p.getInventory().getSelectedSlot();
        int best = -1;
        float bestScore = -1f;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!(st.getItem() instanceof BlockItem bi) || !usable(bi.getBlock())) continue;
            float score = strongest.get() ? bi.getBlock().getBlastResistance() : (i == held ? 1f : 0f);
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }
}
