package dev.deathclient.dlc;

/** Accent color schemes for the ClickGUI, the main menu and the HUD. */
public enum Theme {
    CRIMSON("Crimson", 0xFFB3202A, 0xFF4A0D12),
    CYAN("Cyan", 0xFF1FA8C9, 0xFF0C4452),
    VIOLET("Violet", 0xFF8A4FD6, 0xFF3A1F5C),
    EMERALD("Emerald", 0xFF2FA86B, 0xFF12452C),
    MONO("Mono", 0xFF8A8A8A, 0xFF3A3A3A),
    SUNSET("Sunset", 0xFFE8743B, 0xFF5A2410),
    OCEAN("Ocean", 0xFF2F6FDB, 0xFF132F5E),
    ROSE("Rose", 0xFFD9487D, 0xFF551B33),
    GOLD("Gold", 0xFFD4A21F, 0xFF4F3C08),
    ICE("Ice", 0xFF7FC7E8, 0xFF2A4A5A),
    LIME("Lime", 0xFF8BC34A, 0xFF33471C),
    // Two- and three-colour themes (appended: saved configs store the theme by index).
    AURORA("Aurora", new int[]{0xFF2FA86B, 0xFF1FA8C9, 0xFF8A4FD6}),
    FLAME("Flame", new int[]{0xFFB3202A, 0xFFE8743B, 0xFFD4A21F}),
    DUSK("Dusk", new int[]{0xFF2F6FDB, 0xFF8A4FD6, 0xFFD9487D}),
    CANDY("Candy", new int[]{0xFFD9487D, 0xFF8A4FD6}),
    LAGOON("Lagoon", new int[]{0xFF2F6FDB, 0xFF2FD6B0}),

    // One colour.
    MINT("Mint", 0xFF3DDC97, 0xFF14472F),
    CORAL("Coral", 0xFFFF6F61, 0xFF5A2520),
    SKY("Sky", 0xFF4FA3FF, 0xFF1A3A5E),
    AMBER("Amber", 0xFFFFB000, 0xFF5A3F00),
    ORCHID("Orchid", 0xFFC358E8, 0xFF47205A),
    // Two colours.
    FOREST("Forest", new int[]{0xFF1E8F4E, 0xFF9BE15D}),
    MIDNIGHT("Midnight", new int[]{0xFF3B3FD9, 0xFF1FA8C9}),
    BLOOD("Blood", new int[]{0xFF8E0E1A, 0xFFE8451F}),
    FROST("Frost", new int[]{0xFF1FA8C9, 0xFFE6F6FF}),
    PEACH("Peach", new int[]{0xFFFF8A65, 0xFFFF4F9A}),
    // Three colours.
    TROPIC("Tropic", new int[]{0xFF1FD6B0, 0xFFFFD84F, 0xFFFF5F8A}),
    NEON("Neon", new int[]{0xFF00E5FF, 0xFFB34FFF, 0xFFFF2E93}),
    SAKURA("Sakura", new int[]{0xFFFF7AA8, 0xFFC58BFF, 0xFF7FD3FF}),
    TWILIGHT("Twilight", new int[]{0xFF3B2A8F, 0xFFB33F8E, 0xFFFF8A4F}),
    // Four colours.
    RAINBOW("Rainbow", new int[]{0xFFFF3B3B, 0xFFFFD43B, 0xFF3BE07A, 0xFF3B8CFF}),
    SYNTHWAVE("Synthwave", new int[]{0xFF7A3BFF, 0xFFFF3BB8, 0xFFFF8A3B, 0xFFFFD43B}),
    COTTON("Cotton", new int[]{0xFF4FE0FF, 0xFFFF8AD6, 0xFFB69BFF, 0xFF7FFFC8}),
    EMBER("Ember", new int[]{0xFF5A0A12, 0xFFD62828, 0xFFFF7A1A, 0xFFFFD23F}),
    // Your own colours (edit them in the "Custom Theme" module): Custom N uses the first N of its four colours.
    CUSTOM1("Custom 1", 1),
    CUSTOM2("Custom 2", 2),
    CUSTOM3("Custom 3", 3),
    CUSTOM4("Custom 4", 4);

    public final String label;
    private final int accent, dim;
    /** 1 colour = plain theme; 2 to 4 colours = gradient theme. Null for the custom themes (see stops()). */
    private final int[] stops;
    /** 1..4 for the custom themes (how many of the Custom Theme module's colours they use), 0 for the others. */
    private final int custom;

    Theme(String label, int accent, int dim) {
        this.label = label;
        this.accent = accent;
        this.dim = dim;
        this.stops = new int[]{accent};
        this.custom = 0;
    }

    Theme(String label, int[] stops) {
        this.label = label;
        this.accent = stops[0];
        this.dim = mix(stops[0], 0xFF000000, 0.6f);
        this.stops = stops;
        this.custom = 0;
    }

    /** A custom theme with {@code count} colours, taken live from the Custom Theme module. */
    Theme(String label, int count) {
        this.label = label;
        this.accent = 0xFFFFFFFF;
        this.dim = 0xFF303030;
        this.stops = null;
        this.custom = count;
    }

    private int[] stops() { return custom > 0 ? CustomThemeModule.colors(custom) : stops; }

    private static int index = 0;

    public static Theme current() { return values()[index]; }

    public static void set(Theme t) { index = t.ordinal(); }

    public static void set(int i) { index = ((i % values().length) + values().length) % values().length; }

    public static void cycle() { set(index + 1); }

    /**
     * The theme colour. For a gradient theme it drifts slowly through all its colours, so everything that
     * uses accent() (HUD, ESP, menus) shows the whole palette over time.
     */
    public int accent() {
        int[] st = stops();
        if (st.length == 1) return st[0];
        double ph = (System.currentTimeMillis() % 8000L) / 8000.0;               // 0..1 loop
        return at((float) (0.5 - 0.5 * Math.cos(ph * 2 * Math.PI)));            // smooth there-and-back
    }

    public int dim() {
        int[] st = stops();
        if (st.length == 1) return custom > 0 ? mix(st[0], 0xFF000000, 0.6f) : dim;
        return mix(accent(), 0xFF000000, 0.6f);
    }

    /** True for the themes with two to four colours. */
    public boolean gradient() { return stops().length > 1; }

    /** Colour at position t (0..1) along the gradient; for a plain theme always its single colour. */
    public int at(float t) {
        int[] st = stops();
        if (st.length == 1) return st[0];
        t = Math.max(0f, Math.min(1f, t)) * (st.length - 1);
        int i = Math.min((int) t, st.length - 2);
        return mix(st[i], st[i + 1], t - i);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
    public int index() { return ordinal(); }
}
