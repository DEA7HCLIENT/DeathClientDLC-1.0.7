package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Module keybinds and the ClickGUI open key: captured in the GUI (middle click) or with
 * ".bind" in chat, polled manually each tick (not Minecraft's own KeyBinding), persisted
 * in the config folder.
 *
 * Any button can be bound: every keyboard key (letters, F1-F24, numpad, arrows, modifiers, Caps Lock, Backspace...)
 * and every mouse button ("Mouse1" = left, "Mouse2" = right, "Mouse3" = middle, "Mouse4".. = side buttons). A mouse button is stored as
 * MOUSE_BASE + GLFW button, so one int covers both and old saved binds keep working.
 * While a bind is being captured: Esc cancels, Delete clears the bind.
 */
public final class Binds {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc.properties");
    private static Module listening;
    private static int menuKey = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean menuKeyDown;
    private static int unhookKey = GLFW.GLFW_KEY_END;
    private static boolean unhookKeyDown;

    /** Codes at or above this are mouse buttons (code - MOUSE_BASE = GLFW button). */
    public static final int MOUSE_BASE = 1000;
    /** Mouse buttons that were still held when capturing began: ignored until released (the click that started it). */
    private static final boolean[] mouseIgnore = new boolean[8];

    private Binds() {}

    private static boolean listeningMenu;

    public static void listen(Module m) { listening = m; listeningMenu = false; snapshotMouse(); }
    public static void listenMenu() { listeningMenu = true; listening = null; snapshotMouse(); }

    private static void snapshotMouse() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c == null || c.getWindow() == null) return;
        long w = c.getWindow().getHandle();
        for (int b = 0; b < mouseIgnore.length; b++) mouseIgnore[b] = GLFW.glfwGetMouseButton(w, b) == GLFW.GLFW_PRESS;
    }

    /** Is the key or mouse button with this code held right now. */
    private static boolean isDown(long window, int code) {
        if (code >= MOUSE_BASE) return GLFW.glfwGetMouseButton(window, code - MOUSE_BASE) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
    }
    public static boolean listeningMenu() { return listeningMenu; }
    public static Module listening() { return listening; }

    public static int menuKey() { return menuKey; }

    public static int unhookKey() { return unhookKey; }

    public static void setUnhookKey(int key) {
        unhookKey = key;
        save();
    }

    public static void setMenuKey(int key) {
        menuKey = key;
        save();
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.all()) {
            String v = props.getProperty("bind." + m.getName());
            if (v == null) continue;
            try { m.setKey(Integer.parseInt(v.trim())); } catch (NumberFormatException ignored) {}
        }
        String uk = props.getProperty("unhook.key");
        if (uk != null) try { unhookKey = Integer.parseInt(uk.trim()); } catch (NumberFormatException ignored) {}
        String mk = props.getProperty("menu.key");
        if (mk != null) try { menuKey = Integer.parseInt(mk.trim()); } catch (NumberFormatException ignored) {}
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : ModuleManager.all()) {
            if (m.getKey() != -1) props.setProperty("bind." + m.getName(), Integer.toString(m.getKey()));
        }
        props.setProperty("menu.key", Integer.toString(menuKey));
        props.setProperty("unhook.key", Integer.toString(unhookKey));
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) {
                props.store(out, "DeathClientDLC keybinds (GLFW key codes)");
            }
        } catch (IOException ignored) {}
    }

    /** Called every client tick, with or without a world. */
    public static void tick(MinecraftClient c) {
        long window = c.getWindow().getHandle();

        if (listening != null || listeningMenu) {
            int captured = -2;                                        // -2 = nothing pressed yet
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST && captured == -2; k++) {
                if (GLFW.glfwGetKey(window, k) != GLFW.GLFW_PRESS) continue;
                if (k == GLFW.GLFW_KEY_ESCAPE) {
                    listening = null;                                 // cancel
                    listeningMenu = false;
                    return;
                }
                captured = k == GLFW.GLFW_KEY_DELETE ? -1 : k;        // Delete clears; everything else can be bound
            }
            // Mouse: every button, left and right included (the click that started the capture is ignored until released).
            for (int b = 0; b < mouseIgnore.length; b++) {
                boolean pressed = GLFW.glfwGetMouseButton(window, b) == GLFW.GLFW_PRESS;
                if (!pressed) { mouseIgnore[b] = false; continue; }
                if (captured == -2 && !mouseIgnore[b]) captured = MOUSE_BASE + b;
            }
            if (captured == -2) return;
            if (listeningMenu) {
                menuKey = captured;
                menuKeyDown = true;                                   // don't react to the same press
                listeningMenu = false;
            } else {
                listening.setKey(captured);
                listening.keyDown = true;                             // don't toggle on the same press
                listening = null;
            }
            save();
            return;
        }

        // Unhook / rehook: works in both states, but not while typing in chat.
        if (unhookKey != -1) {
            boolean down = isDown(window, unhookKey);
            boolean typing = c.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen;
            if (down && !unhookKeyDown && !typing) Unhook.toggle(c);
            unhookKeyDown = down;
        }
        if (Unhook.active()) {                          // unhooked: no menu key, no module binds
            menuKeyDown = menuKey != -1 && isDown(window, menuKey);
            for (Module m : ModuleManager.all()) m.keyDown = m.getKey() != -1 && isDown(window, m.getKey());
            return;
        }

        // Open/close the ClickGUI on the bound key, from anywhere except typing in another screen.
        if (menuKey != -1) {
            boolean down = isDown(window, menuKey);
            if (down && !menuKeyDown) {
                if (GuiStyleModule.isClickGui(c.currentScreen)) c.currentScreen.close();
                else if (c.currentScreen == null) c.setScreen(GuiStyleModule.create());
            }
            menuKeyDown = down;
        }

        boolean canToggle = c.player != null && c.currentScreen == null;
        for (Module m : ModuleManager.all()) {
            if (m.getKey() == -1) continue;
            boolean down = isDown(window, m.getKey());
            if (down && !m.keyDown && canToggle) m.toggle();
            m.keyDown = down;
        }
    }

    public static String name(int key) {
        if (key == -1) return "none";
        if (key >= MOUSE_BASE) return "Mouse" + (key - MOUSE_BASE + 1);          // Mouse3 = middle button
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        if (key >= GLFW.GLFW_KEY_KP_0 && key <= GLFW.GLFW_KEY_KP_9) return "Num" + (key - GLFW.GLFW_KEY_KP_0);
        switch (key) {
            case GLFW.GLFW_KEY_BACKSPACE: return "Backspace";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "Caps";
            case GLFW.GLFW_KEY_NUM_LOCK: return "NumLock";
            case GLFW.GLFW_KEY_SCROLL_LOCK: return "ScrollLock";
            case GLFW.GLFW_KEY_PAUSE: return "Pause";
            case GLFW.GLFW_KEY_PRINT_SCREEN: return "PrtSc";
            case GLFW.GLFW_KEY_MENU: return "Menu";
            case GLFW.GLFW_KEY_LEFT_SUPER: return "LWin";
            case GLFW.GLFW_KEY_RIGHT_SUPER: return "RWin";
            case GLFW.GLFW_KEY_KP_DECIMAL: return "Num.";
            case GLFW.GLFW_KEY_KP_DIVIDE: return "Num/";
            case GLFW.GLFW_KEY_KP_MULTIPLY: return "Num*";
            case GLFW.GLFW_KEY_KP_SUBTRACT: return "Num-";
            case GLFW.GLFW_KEY_KP_ADD: return "Num+";
            case GLFW.GLFW_KEY_KP_ENTER: return "NumEnter";
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LShift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RShift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCtrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCtrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LAlt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RAlt";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
            case GLFW.GLFW_KEY_INSERT: return "Ins";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PgDn";
            default:
                String n = GLFW.glfwGetKeyName(key, 0);
                return n != null ? n.toUpperCase() : "K" + key;
        }
    }

    /** Parses a key name as typed in chat (".bind killaura f6"). -1 = clear, -2 = not recognized. */
    public static int keyByName(String raw) {
        String s = raw.trim().toUpperCase();
        if (s.equals("NONE") || s.equals("CLEAR")) return -1;
        if (s.length() == 1) {
            char ch = s.charAt(0);
            if (ch >= 'A' && ch <= 'Z') return GLFW.GLFW_KEY_A + (ch - 'A');
            if (ch >= '0' && ch <= '9') return GLFW.GLFW_KEY_0 + (ch - '0');
            if (",-./;=[\\]`'".indexOf(ch) >= 0) return ch == '`' ? GLFW.GLFW_KEY_GRAVE_ACCENT : ch;   // symbol keys
        }
        if (s.matches("F([1-9]|1[0-9]|2[0-5])")) return GLFW.GLFW_KEY_F1 + (Integer.parseInt(s.substring(1)) - 1);
        if (s.matches("NUM[0-9]")) return GLFW.GLFW_KEY_KP_0 + (s.charAt(3) - '0');
        if (s.matches("(MOUSE|M)[1-8]")) return MOUSE_BASE + (s.charAt(s.length() - 1) - '1');   // Mouse3 = middle button
        return switch (s) {
            case "BACKSPACE" -> GLFW.GLFW_KEY_BACKSPACE;
            case "CAPS" -> GLFW.GLFW_KEY_CAPS_LOCK;
            case "NUMLOCK" -> GLFW.GLFW_KEY_NUM_LOCK;
            case "SCROLLLOCK" -> GLFW.GLFW_KEY_SCROLL_LOCK;
            case "PAUSE" -> GLFW.GLFW_KEY_PAUSE;
            case "PRTSC" -> GLFW.GLFW_KEY_PRINT_SCREEN;
            case "MENU" -> GLFW.GLFW_KEY_MENU;
            case "LWIN" -> GLFW.GLFW_KEY_LEFT_SUPER;
            case "RWIN" -> GLFW.GLFW_KEY_RIGHT_SUPER;
            case "DELETE", "DEL" -> GLFW.GLFW_KEY_DELETE;
            case "NUM." -> GLFW.GLFW_KEY_KP_DECIMAL;
            case "NUM/" -> GLFW.GLFW_KEY_KP_DIVIDE;
            case "NUM*" -> GLFW.GLFW_KEY_KP_MULTIPLY;
            case "NUM-" -> GLFW.GLFW_KEY_KP_SUBTRACT;
            case "NUM+" -> GLFW.GLFW_KEY_KP_ADD;
            case "NUMENTER" -> GLFW.GLFW_KEY_KP_ENTER;
            case "SPACE" -> GLFW.GLFW_KEY_SPACE;
            case "TAB" -> GLFW.GLFW_KEY_TAB;
            case "ENTER" -> GLFW.GLFW_KEY_ENTER;
            case "LSHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "RSHIFT" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "LCTRL" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "RCTRL" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "LALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "RALT" -> GLFW.GLFW_KEY_RIGHT_ALT;
            case "UP" -> GLFW.GLFW_KEY_UP;
            case "DOWN" -> GLFW.GLFW_KEY_DOWN;
            case "LEFT" -> GLFW.GLFW_KEY_LEFT;
            case "RIGHT" -> GLFW.GLFW_KEY_RIGHT;
            case "INS" -> GLFW.GLFW_KEY_INSERT;
            case "HOME" -> GLFW.GLFW_KEY_HOME;
            case "END" -> GLFW.GLFW_KEY_END;
            case "PGUP" -> GLFW.GLFW_KEY_PAGE_UP;
            case "PGDN" -> GLFW.GLFW_KEY_PAGE_DOWN;
            default -> -2;
        };
    }
}
