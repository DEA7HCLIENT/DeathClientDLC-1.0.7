package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.FreecamModule;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Freecam: moves the camera entity right before the game reads its position, so the view is never a frame behind,
 * wherever in the frame the camera gets updated. No arguments are read, so the hook does not depend on the
 * signature. require = 0: if the method is named differently in this build the hook is skipped (the GameRenderer
 * hook and the HUD callback still keep Freecam working).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Inject(method = "update", at = @At("HEAD"), require = 0)
    private void deathclientdlc$freecamBeforeCamera(CallbackInfo ci) {
        FreecamModule.worldFrame();
    }
}
