package dev.deathclient.dlc;

public class NumberSetting extends Setting {
    public final double min, max, step;
    private double value;
    private String[] labels;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min; this.max = max; this.step = step;
        set(value);
    }

    /** Names for the integer values min, min+step, ... (mode selectors); shown in the GUI instead of the number. */
    public NumberSetting labels(String... l) { labels = l; return this; }

    /** Label of the current value, or null when this is a plain number. */
    public String label() {
        if (labels == null) return null;
        int i = (int) Math.round((value - min) / step);
        return labels[Math.max(0, Math.min(labels.length - 1, i))];
    }

    public double get() { return value; }

    public void set(double v) {
        double snapped = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, snapped));
    }
}
