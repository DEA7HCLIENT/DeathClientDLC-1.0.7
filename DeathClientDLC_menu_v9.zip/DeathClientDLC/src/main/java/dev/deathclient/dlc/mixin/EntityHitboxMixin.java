package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.HitboxModule;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hitboxes: while the game looks for the entity under the crosshair (HitboxModule.scanning), the box of other
 * entities is returned bigger. Outside that search nothing changes.
 * require = 0: if the method is named differently in this build, nothing happens.
 */
@Mixin(Entity.class)
public abstract class EntityHitboxMixin {
    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$bigHitbox(CallbackInfoReturnable<Box> cir) {
        if (!HitboxModule.scanning) return;
        cir.setReturnValue(HitboxModule.expand((Entity) (Object) this, cir.getReturnValue()));
    }
}
