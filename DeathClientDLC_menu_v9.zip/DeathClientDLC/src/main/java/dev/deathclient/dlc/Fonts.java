package dev.deathclient.dlc;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * UI fonts: assets/deathclientdlc/font/ui*.json. The Custom Font module picks one of them at any time (no reload):
 * Default = ui.ttf (Liberation Sans), DejaVu, Mono, Serif, and Custom = your own file (see CustomFontPack).
 * Text drawn with text() / bold() (HUD, main menu) always uses the chosen font; the cheat menu uses it through gui()
 * when "Cheat menu" is on. All font-specific API usage is kept in this one class.
 */
final class Fonts {
    private static final String[] NAMES = {"ui", "ui_dejavu", "ui_mono", "ui_serif", "ui_custom"};
    private static final Style[] STYLES = new Style[NAMES.length];

    static {
        for (int i = 0; i < NAMES.length; i++) {
            STYLES[i] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("deathclientdlc", NAMES[i])));
        }
    }

    private static CustomFontModule mod;

    private Fonts() {}

    /** The module, looked up once (this is called for every piece of text drawn). */
    private static CustomFontModule module() {
        if (mod == null) mod = ModuleManager.get(CustomFontModule.class);
        return mod;
    }

    /** Index of the chosen font (0 = Default); Default as well while Custom Font is off. */
    private static int chosen() {
        CustomFontModule m = module();
        return m == null || !m.isEnabled() ? 0 : Math.max(0, Math.min(NAMES.length - 1, (int) m.font.get() - 1));
    }

    private static Style style() { return STYLES[chosen()]; }

    static Text text(String s) { return Text.literal(s).setStyle(style()); }

    static Text bold(String s) { return Text.literal(s).setStyle(style().withBold(true)); }

    /**
     * Text of the cheat menu and the other screens that used the game's own font: it keeps that font while Default is
     * chosen or "Cheat menu" is off, and uses the chosen font otherwise.
     */
    static Text gui(String s) {
        CustomFontModule m = module();
        int i = chosen();
        if (m == null || !m.menus.get() || i == 0) return Text.literal(s);
        return Text.literal(s).setStyle(STYLES[i]);
    }

    static int guiWidth(TextRenderer tr, String s) { return tr.getWidth(gui(s)); }

    static int guiWidth(TextRenderer tr, Text t) { return tr.getWidth(t); }

    /** Text drawn at scale f (1 = normal) with its top-left corner at x, y. */
    static void drawScaled(DrawContext ctx, TextRenderer tr, Text t, float x, float y, float f, int color) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(f, f);
        ctx.drawTextWithShadow(tr, t, 0, 0, color);
        m.popMatrix();
    }

    static int width(TextRenderer tr, String s) { return tr.getWidth(text(s)); }

    static void draw(DrawContext ctx, TextRenderer tr, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(tr, text(s), x, y, color);
    }
}
