package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.VelocityModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Velocity hook. The handler runs on the main thread after the packet is applied; if the player's motion
 * changed during the call, the packet was for the player and the Velocity module rescales it.
 * require = 0: if the method name differs in this build the hook is skipped and Velocity does nothing.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Unique private Vec3d deathclientdlc$before;

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), require = 0)
    private void deathclientdlc$velocityHead(CallbackInfo ci) {
        var p = MinecraftClient.getInstance().player;
        deathclientdlc$before = p == null ? null : p.getVelocity();
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"), require = 0)
    private void deathclientdlc$velocityTail(CallbackInfo ci) {
        var p = MinecraftClient.getInstance().player;
        VelocityModule m = ModuleManager.get(VelocityModule.class);
        if (p == null || m == null || !m.isEnabled() || deathclientdlc$before == null) return;
        if (!p.getVelocity().equals(deathclientdlc$before)) m.apply(p);
        deathclientdlc$before = null;
    }
}
