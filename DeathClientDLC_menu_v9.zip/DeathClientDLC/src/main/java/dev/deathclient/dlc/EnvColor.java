package dev.deathclient.dlc;

import java.awt.Color;

/** The color of Custom Sky / Custom Fog: Hue, Saturation, Brightness, or the theme color, or a rainbow that cycles. */
final class EnvColor {
    private EnvColor() {}

    static int rgb(NumberSetting hue, NumberSetting sat, NumberSetting bri, BoolSetting rainbow, BoolSetting theme) {
        if (theme.get()) return Theme.current().accent() & 0xFFFFFF;
        float h = rainbow.get() ? (System.currentTimeMillis() % 12000) / 12000f : (float) (hue.get() / 360.0);
        return Color.HSBtoRGB(h, (float) (sat.get() / 100.0), (float) (bri.get() / 100.0)) & 0xFFFFFF;
    }
}
