package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.EmoteState;
import dev.deathclient.dlc.Emotes;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Emotions: after vanilla has posed the model, the head and arms are turned to the emote pose (only when the
 * render state carries one, i.e. your own player). require = 0: if the method is named differently here, the hook is skipped.
 */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("TAIL"), require = 0)
    private void deathclientdlc$emote(BipedEntityRenderState state, CallbackInfo ci) {
        if (!(state instanceof EmoteState es)) return;
        Emotes.Pose p = es.deathclientdlc$getPose();
        if (p == null) return;
        BipedEntityModel<?> m = (BipedEntityModel<?>) (Object) this;
        set(m.head, p.hp(), p.hy(), p.hr());
        set(m.rightArm, p.rp(), p.ry(), p.rr());
        set(m.leftArm, p.lp(), p.ly(), p.lr());
    }

    private static void set(ModelPart part, float pitch, float yaw, float roll) {
        if (!Float.isNaN(pitch)) part.pitch = pitch;
        if (!Float.isNaN(yaw)) part.yaw = yaw;
        if (!Float.isNaN(roll)) part.roll = roll;
    }
}
