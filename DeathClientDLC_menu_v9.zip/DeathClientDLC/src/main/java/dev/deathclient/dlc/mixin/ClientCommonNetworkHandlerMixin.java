package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.ResourcePackModule;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.ResourcePackStatusC2SPacket;
import net.minecraft.network.packet.s2c.common.ResourcePackSendS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Resource Pack module: a pack the server sends is dropped before the client starts downloading it. The server
 * still gets an answer (see ResourcePackModule.reportLoaded), so it does not wait for one forever.
 * require = 0: if the method is named differently in this build, the hook is skipped and packs load as usual.
 */
@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerMixin {
    @Shadow
    public abstract void sendPacket(Packet<?> packet);

    @Inject(method = "onResourcePackSend", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$blockPack(ResourcePackSendS2CPacket packet, CallbackInfo ci) {
        ResourcePackModule m = ModuleManager.get(ResourcePackModule.class);
        if (m == null || !m.isEnabled()) return;
        if (m.reportLoaded.get()) {
            sendPacket(new ResourcePackStatusC2SPacket(packet.id(), ResourcePackStatusC2SPacket.Status.ACCEPTED));
            sendPacket(new ResourcePackStatusC2SPacket(packet.id(), ResourcePackStatusC2SPacket.Status.DOWNLOADED));
            sendPacket(new ResourcePackStatusC2SPacket(packet.id(), ResourcePackStatusC2SPacket.Status.SUCCESSFULLY_LOADED));
        } else {
            sendPacket(new ResourcePackStatusC2SPacket(packet.id(), ResourcePackStatusC2SPacket.Status.DECLINED));
        }
        ci.cancel();
    }
}
