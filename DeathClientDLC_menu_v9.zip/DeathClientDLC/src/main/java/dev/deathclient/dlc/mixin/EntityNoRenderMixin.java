package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No Render, Entity fire: the flames drawn on burning mobs and players are not rendered. require = 0: skipped if renamed. */
@Mixin(Entity.class)
public abstract class EntityNoRenderMixin {
    @Inject(method = "doesRenderOnFire", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noEntityFire(CallbackInfoReturnable<Boolean> cir) {
        if (NoRenderModule.entityFire()) cir.setReturnValue(false);
    }
}
