package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.PhaseHooks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NoClip / NoClip Fly: on every move of your player the no-clip flag is set (the game clears it every tick), and the
 * movement is cut at the floor (see Phase).
 */
@Mixin(Entity.class)
public abstract class PhaseMixin {
    @Inject(method = "move", at = @At("HEAD"), require = 0)
    private void deathclientdlc$noclip(MovementType type, Vec3d movement, CallbackInfo ci) {
        Entity self = (Entity) (Object) this;
        if (PhaseHooks.applies(self)) self.noClip = true;
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true, require = 0)
    private Vec3d deathclientdlc$floor(Vec3d movement) {
        return PhaseHooks.clip((Entity) (Object) this, movement);
    }
}
