package dev.deathclient.dlc;

/**
 * HUD Style: the shape of the HUD panels (Dynamic Island, effects, module list, Info HUD, Keybinds) and of the main
 * menu buttons: Square, Rounded, Glass square or Glass rounded. Turn the module off to get the old rounded look.
 * (Target HUD has its own, longer list of styles.)
 */
public class HudStyleModule extends Module {
    public static final int SQUARE = 1, ROUNDED = 2, GLASS_SQUARE = 3, GLASS_ROUNDED = 4;

    public final NumberSetting shape = add(new NumberSetting("Shape", ROUNDED, 1, 4, 1)
            .labels("Square", "Rounded", "Glass square", "Glass rounded"));
    public final NumberSetting radius = add(new NumberSetting("Radius", 4, 2, 10, 1));

    public HudStyleModule() { super("HUD Style", Category.MISC, true); }
}
