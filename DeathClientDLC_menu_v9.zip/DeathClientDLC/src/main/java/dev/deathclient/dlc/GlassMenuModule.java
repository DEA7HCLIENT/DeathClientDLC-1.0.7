package dev.deathclient.dlc;

/**
 * Glass Menu: the ClickGUI turns into smoked glass. The window and the cards become translucent (the blurred
 * world, or the background picture on the main menu, shows through), get a bright rim and a soft light band
 * along the top edge. Opacity is the strength of the pane, Tint mixes the theme colour into it.
 * The drawing lives in ClickGuiScreen; this class only holds the settings.
 */
public class GlassMenuModule extends Module {
    /** Opacity of the window pane in percent (lower = more see-through). */
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 40, 10, 90, 5));
    /** How much of the theme colour is mixed into the glass, in percent. */
    public final NumberSetting tint = add(new NumberSetting("Tint", 25, 0, 100, 5));
    public final BoolSetting shine = add(new BoolSetting("Shine", true));
    public final BoolSetting border = add(new BoolSetting("Border", true));

    public GlassMenuModule() { super("Glass Menu", Category.MISC); }
}
