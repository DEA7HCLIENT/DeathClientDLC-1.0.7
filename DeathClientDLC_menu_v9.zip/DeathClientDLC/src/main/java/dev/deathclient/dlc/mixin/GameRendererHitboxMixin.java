package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.HitboxModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hitboxes: switches HitboxModule.scanning on for exactly as long as the game works out what the crosshair points at.
 * No arguments are read, so the hooks do not depend on the method's signature.
 * require = 0: if the method is named differently in this build, nothing happens (the hitboxes stay default).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererHitboxMixin {
    @Inject(method = "updateCrosshairTarget", at = @At("HEAD"), require = 0)
    private void deathclientdlc$scanStart(CallbackInfo ci) { HitboxModule.scanning = true; }

    @Inject(method = "updateCrosshairTarget", at = @At("RETURN"), require = 0)
    private void deathclientdlc$scanEnd(CallbackInfo ci) { HitboxModule.scanning = false; }
}
