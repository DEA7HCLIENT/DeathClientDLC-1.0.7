package dev.deathclient.dlc;

import net.minecraft.util.math.MathHelper;

/**
 * The rotation the server was last told by KillAura / Target Strafe. The camera is not touched; the only
 * place that reads this is the player model in third person (LivingEntityRendererMixin), so you see your own
 * head turn to the enemy while your view stays where you put it.
 */
public final class ServerRotation {
    private static float yaw, pitch, prevYaw, prevPitch;
    private static long until;

    private ServerRotation() {}

    /** Shows this rotation on your model for the next {@code ms} milliseconds. */
    public static void set(float newYaw, float newPitch, int ms) {
        long now = System.currentTimeMillis();
        if (now >= until) { prevYaw = yaw = newYaw; prevPitch = pitch = newPitch; }          // fresh start: no slide from old angles
        else { prevYaw = yaw; prevPitch = pitch; yaw = newYaw; pitch = newPitch; }
        until = now + ms;
    }

    public static boolean active() { return System.currentTimeMillis() < until; }

    /** Yaw between the last two rotations, delta 0..1 (the short way round). */
    public static float yaw(float delta) { return prevYaw + MathHelper.wrapDegrees(yaw - prevYaw) * delta; }

    public static float pitch(float delta) { return MathHelper.lerp(delta, prevPitch, pitch); }
}
