package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ClientUsers;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client Badge: the name shown above a player's head gets the badge in front. */
@Mixin(PlayerEntity.class)
public abstract class PlayerNameMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$badge(CallbackInfoReturnable<Text> cir) {
        PlayerEntity p = (PlayerEntity) (Object) this;
        if (ClientUsers.shows(p)) cir.setReturnValue(ClientUsers.withBadge(cir.getReturnValue()));
    }
}
