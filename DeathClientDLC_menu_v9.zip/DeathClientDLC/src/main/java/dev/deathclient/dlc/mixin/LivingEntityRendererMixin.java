package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.EmoteState;
import dev.deathclient.dlc.Emotes;
import dev.deathclient.dlc.ServerRotation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Third person: while KillAura / Target Strafe hold a server-side rotation, your own model's head (and, past
 * 75 degrees, body) and pitch show that rotation. Only the render state is changed; the camera and the real
 * player rotation are untouched.
 * require = 0: if the method or the fields are named differently in this build, the hook is skipped.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"), require = 0)
    private void deathclientdlc$serverRotation(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (entity != MinecraftClient.getInstance().player || !ServerRotation.active()) return;
        float diff = MathHelper.wrapDegrees(ServerRotation.yaw(tickDelta) - state.bodyYaw);
        if (Math.abs(diff) > 75f) {                       // the body follows once the head cannot turn further
            float over = diff - Math.copySign(75f, diff);
            state.bodyYaw += over;
            diff = Math.copySign(75f, diff);
        }
        state.relativeHeadYaw = diff;
        state.pitch = ServerRotation.pitch(tickDelta);
    }

    /** Emotions: your own render state gets the emote pose (null when nothing plays); everyone else's stays empty. */
    @Inject(method = "updateRenderState", at = @At("TAIL"), require = 0)
    private void deathclientdlc$emote(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (state instanceof EmoteState es) es.deathclientdlc$setPose(entity == MinecraftClient.getInstance().player ? Emotes.pose() : null);
    }
}
