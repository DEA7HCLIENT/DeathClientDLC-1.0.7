package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import net.minecraft.util.math.MathHelper;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Locale;

/**
 * Target HUD: a card with the target's name, health bar, health, armor and distance. The target is KillAura's,
 * else the entity under the crosshair, else the nearest player in range. It fades in and out and the health bar
 * glides. Drag it with the left mouse button while the chat is open (it shows yourself as a preview then).
 *
 * Styles: Square, Rounded, Glass square, Glass rounded, Image rounded (your own picture in the card:
 * ".thud image <path to png/jpg>", or put config/deathclientdlc/target_hud.png), Neon, Minimal, Pill.
 */
public class TargetHudModule extends Module {
    private static final int SQUARE = 1, ROUNDED = 2, GLASS_SQUARE = 3, GLASS_ROUNDED = 4, IMAGE = 5, NEON = 6, MINIMAL = 7, PILL = 8;

    public final NumberSetting style = add(new NumberSetting("Style", ROUNDED, 1, 8, 1)
            .labels("Square", "Rounded", "Glass square", "Glass rounded", "Image rounded", "Neon", "Minimal", "Pill"));
    /** Static = the head looks straight at you, Live = it turns like the target's real head, Letter = just a letter tile. */
    public final NumberSetting head = add(new NumberSetting("Head", 2, 1, 3, 1).labels("Static", "Live", "Letter"));
    public final NumberSetting headZoom = add(new NumberSetting("Head zoom", 1.0, 0.5, 2.0, 0.1));
    /** Moves the head up (+) or down (-) inside its square, in blocks. */
    public final NumberSetting headY = add(new NumberSetting("Head Y", 0.0, -0.6, 0.6, 0.05));
    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.7, 2.0, 0.1));
    public final NumberSetting radius = add(new NumberSetting("Radius", 6, 2, 12, 1));
    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 30, 1));
    public final BoolSetting nearest = add(new BoolSetting("Nearest player", true));
    public final BoolSetting themeBar = add(new BoolSetting("Theme color bar", false));
    public final BoolSetting showArmor = add(new BoolSetting("Armor", true));
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    public final NumberSetting posX = add(new NumberSetting("X", 250, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 150, 0, 1200, 1));

    static final UserPicture PICTURE = new UserPicture("target_hud.png", "custom_target_hud");

    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFB4B7C2;

    /** Set when the head renderer is missing or throws in this game version: the letter tile is used instead. */
    private static boolean headBroken;
    private static Method drawEntity;
    private static boolean drawEntityLooked;

    private LivingEntity target;            // picked each tick
    private LivingEntity shown;             // what is drawn (kept while fading out)
    private float alpha, shownHp;
    private long lastFrame;

    public TargetHudModule() { super("Target HUD", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        target = pick(c);
    }

    @Override
    protected void onDisable() { target = null; shown = null; alpha = 0f; }

    private LivingEntity pick(MinecraftClient c) {
        KillAuraModule ka = ModuleManager.get(KillAuraModule.class);
        if (ka != null && ka.isEnabled()) {
            LivingEntity t = ka.currentTarget();
            if (t != null && t.isAlive()) return t;
        }
        if (c.targetedEntity instanceof LivingEntity le && le.isAlive() && le != c.player) return le;
        if (!nearest.get() || c.player == null || c.world == null) return null;
        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof PlayerEntity pe) || pe == c.player || !pe.isAlive() || pe.isSpectator()) continue;
            double d = c.player.distanceTo(pe);
            if (d <= bestDist) { bestDist = d; best = pe; }
        }
        return best;
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetHudModule m = ModuleManager.get(TargetHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private static int a(int argb, float f) {
        int al = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, f)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    private static int healthColor(float f) {
        f = Math.max(0f, Math.min(1f, f));
        int r = Math.round(255 * Math.min(1f, 2f * (1f - f)));
        int g = Math.round(255 * Math.min(1f, 2f * f));
        return 0xFF000000 | (r << 16) | (g << 8) | 0x40;
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.1f, (now - lastFrame) / 1.0e9f);
        lastFrame = now;

        boolean preview = target == null && c.currentScreen instanceof ChatScreen;
        LivingEntity t = target != null ? target : (preview ? c.player : null);
        float want = t != null ? 1f : 0f;
        alpha += (want - alpha) * Math.min(1f, dt * 9f);
        if (t != null) {
            if (t != shown) { shown = t; shownHp = t.getHealth(); }
        }
        if (alpha < 0.03f || shown == null) return;
        LivingEntity e = shown;

        float max = Math.max(1f, e.getMaxHealth());
        float hp = Math.max(0f, e.getHealth());
        shownHp += (hp - shownHp) * Math.min(1f, dt * 10f);
        float frac = Math.max(0f, Math.min(1f, shownHp / max));

        var tr = c.textRenderer;
        int st = (int) style.get();
        int acc = Theme.current().accent() | 0xFF000000;
        int r = (int) radius.get();
        String name = e.getName().getString();
        String hpText = String.format(Locale.ROOT, "%.1f", hp);
        float abs = e.getAbsorptionAmount();
        if (abs > 0.05f) hpText += String.format(Locale.ROOT, " +%.0f", abs);
        String dist = String.format(Locale.ROOT, "%.1fm", c.player.distanceTo(e));
        int barCol = themeBar.get() ? acc : healthColor(frac);

        int nameW = tr.getWidth(Fonts.bold(name));
        int w, h;
        if (st == MINIMAL) { w = Math.max(110, nameW + 8); h = 24; }
        else if (st == PILL) { w = Math.max(110, 24 + nameW + 10 + tr.getWidth(hpText) + 10); h = 22; }
        else { w = Math.max(140, 44 + nameW + 8 + (showDistance.get() ? tr.getWidth(dist) + 8 : 0)); h = 44; }

        float s = (float) scale.get();
        int x = (int) posX.get(), y = (int) posY.get();
        HudEdit.track(x, y, Math.round(w * s), Math.round(h * s), (nx, ny) -> { posX.set(nx); posY.set(ny); });

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(s, s);

        // ---- card
        switch (st) {
            case SQUARE -> {
                ctx.fill(0, 0, w, h, a(0xD0101014, alpha));
                ctx.fill(0, h - 1, w, h, a(acc, alpha));
            }
            case ROUNDED, IMAGE -> ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xD0101014, alpha), r);
            case GLASS_SQUARE -> {
                ctx.fill(-1, -1, w + 1, h + 1, a(0x55FFFFFF, alpha));
                ctx.fill(0, 0, w, h, a(ClickGuiScreen.mix(0xFF141824, acc, 0.12f) & 0xFFFFFF | 0x78000000, alpha));
                ctx.fillGradient(0, 0, w, h / 2, a(0x30FFFFFF, alpha), 0x00FFFFFF);
                ctx.fill(2, 1, w - 2, 2, a(0x90FFFFFF, alpha));
            }
            case GLASS_ROUNDED -> {
                ClickGuiScreen.rrect(ctx, -1, -1, w + 2, h + 2, a(0x55FFFFFF, alpha), r + 1);
                ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(ClickGuiScreen.mix(0xFF141824, acc, 0.12f) & 0xFFFFFF | 0x78000000, alpha), r);
                ctx.fillGradient(r, 1, w - r, h / 2, a(0x30FFFFFF, alpha), 0x00FFFFFF);
                ctx.fill(r, 1, w - r, 2, a(0x90FFFFFF, alpha));
            }
            case NEON -> {
                for (int g = 4; g >= 1; g--) ClickGuiScreen.rrect(ctx, -g, -g, w + 2 * g, h + 2 * g, a(acc & 0xFFFFFF | 0x20000000, alpha), r + g);
                ClickGuiScreen.rrect(ctx, -1, -1, w + 2, h + 2, a(acc, alpha), r + 1);
                ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xF00A0A10, alpha), r);
            }
            case PILL -> ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xD0101014, alpha), h / 2);
            default -> { }                                                   // Minimal: no card
        }

        // ---- content
        int[] headRect = null;                                               // absolute square where the head is drawn
        boolean headOn = (int) head.get() != 3 && !headBroken;
        boolean rounded = st == ROUNDED || st == GLASS_ROUNDED || st == IMAGE || st == NEON;
        if (st == MINIMAL) {
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 0, 0, a(WHITE, alpha));
            bar(ctx, 0, 13, w - tr.getWidth(hpText) - 6, 4, frac, barCol, false, alpha);
            Fonts.draw(ctx, tr, hpText, w - tr.getWidth(hpText), 11, a(WHITE, alpha));
        } else if (st == PILL) {
            ClickGuiScreen.rrect(ctx, 3, 3, 16, 16, a(acc, alpha), 8);
            if (headOn) headRect = new int[]{Math.round(x + 4 * s), Math.round(y + 4 * s), Math.round(x + 18 * s), Math.round(y + 18 * s)};
            else Fonts.drawScaled(ctx, tr, Fonts.bold(initial(name)), 8f, 5f, 1.0f, a(WHITE, alpha));
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 24, 7, a(WHITE, alpha));
            Fonts.draw(ctx, tr, hpText, w - 10 - tr.getWidth(hpText), 7, a(WHITE, alpha));
            ctx.fill(12, h - 3, w - 12, h - 2, a(0x40FFFFFF, alpha));
            ctx.fill(12, h - 3, 12 + Math.round((w - 24) * frac), h - 2, a(barCol, alpha));
        } else {
            // avatar: your own picture (Image rounded), else a tile with the first letter
            if (st == IMAGE && PICTURE.has()) {
                PICTURE.drawSquare(ctx, 6, 6, 32, a(WHITE, alpha));
            } else {
                if (rounded) ClickGuiScreen.rrect(ctx, 6, 6, 32, 32, a(ClickGuiScreen.mix(0xFF1C1C24, acc, 0.55f), alpha), 4);
                else ctx.fill(6, 6, 38, 38, a(ClickGuiScreen.mix(0xFF1C1C24, acc, 0.55f), alpha));
                if (headOn) headRect = new int[]{Math.round(x + 6 * s), Math.round(y + 6 * s), Math.round(x + 38 * s), Math.round(y + 38 * s)};
                else Fonts.drawScaled(ctx, tr, Fonts.bold(initial(name)), 17f, 16f, 1.8f, a(WHITE, alpha));
            }
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 44, 8, a(WHITE, alpha));
            if (showDistance.get()) Fonts.draw(ctx, tr, dist, w - 6 - tr.getWidth(dist), 8, a(MUTED, alpha));
            String line = "HP " + hpText + (showArmor.get() ? "   AR " + e.getArmor() : "");
            Fonts.draw(ctx, tr, line, 44, 20, a(MUTED, alpha));
            bar(ctx, 44, 32, w - 44 - 6, 6, frac, barCol, rounded, alpha);
        }
        m.popMatrix();

        // The head is drawn outside the scaled matrix, in screen coordinates (it ignores the fade, so only when almost opaque).
        if (headRect != null && alpha > 0.85f) {
            if (!drawHead(ctx, e, headRect, (int) head.get() == 2, headZoom.get(), headY.get())) headBroken = true;
        }
    }

    /**
     * The entity's head inside the square r = {x1, y1, x2, y2}, using the game's own inventory-style entity renderer
     * (found by its parameter types, so it works with any mappings). Static = looks straight ahead, live = the head turns
     * the way the target's real head is turned relative to its body. Returns false if this game version has no such method.
     */
    private static boolean drawHead(DrawContext ctx, LivingEntity e, int[] r, boolean live, double zoom, double yOff) {
        try {
            if (!drawEntityLooked) {
                drawEntityLooked = true;
                for (Method m : InventoryScreen.class.getMethods()) {
                    if (!Modifier.isStatic(m.getModifiers())) continue;
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length != 10 || p[0] != DrawContext.class || p[9] != LivingEntity.class) continue;
                    boolean ok = true;
                    for (int i = 1; i <= 5; i++) ok &= p[i] == int.class;
                    for (int i = 6; i <= 8; i++) ok &= p[i] == float.class;
                    if (ok) { drawEntity = m; break; }
                }
            }
            if (drawEntity == null) return false;

            float cx = (r[0] + r[2]) / 2f, cy = (r[1] + r[3]) / 2f;
            float mx = cx, my = cy;
            if (live) {                                                   // mouse position that turns the head like the real one
                float relYaw = MathHelper.wrapDegrees(e.getHeadYaw() - e.getBodyYaw());
                float hy = MathHelper.clamp(relYaw / 20f, -1.3f, 1.3f);
                float hp = MathHelper.clamp(e.getPitch() / 20f, -1.3f, 1.3f);
                mx = cx - 40f * (float) Math.tan(hy);
                my = cy + 40f * (float) Math.tan(hp);
            }
            float eye = e.getEyeHeight(e.getPose());
            float headWorld = MathHelper.clamp(eye * 0.31f, 0.4f, 0.75f);                 // head size in blocks
            int size = Math.max(8, Math.round((r[2] - r[0]) * 0.9f / headWorld * (float) zoom));
            float o = Math.max(0.1f, e.getScale());
            float shift = 0.0625f + (eye - e.getHeight() / 2f + (float) -yOff) / o;      // brings the head to the middle of the square
            drawEntity.invoke(null, ctx, r[0], r[1], r[2], r[3], size, shift, mx, my, e);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String initial(String name) {
        return name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
    }

    private static void bar(DrawContext ctx, int x, int y, int w, int h, float frac, int col, boolean round, float alpha) {
        int fw = Math.max(0, Math.round(w * frac));
        if (round) {
            ClickGuiScreen.rrect(ctx, x, y, w, h, a(0x50FFFFFF, alpha), h / 2);
            if (fw > 0) ClickGuiScreen.rrect(ctx, x, y, Math.max(fw, h), h, a(col, alpha), h / 2);
        } else {
            ctx.fill(x, y, x + w, y + h, a(0x50FFFFFF, alpha));
            if (fw > 0) ctx.fill(x, y, x + fw, y + h, a(col, alpha));
        }
    }
}
