package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ClientUsers;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Client Badge: every chat message you send ends with the invisible marker other clients look for. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ChatTagMixin {
    @ModifyVariable(method = "sendChatMessage", at = @At("HEAD"), argsOnly = true, require = 0)
    private String deathclientdlc$tag(String content) {
        return ClientUsers.tag(content);
    }
}
