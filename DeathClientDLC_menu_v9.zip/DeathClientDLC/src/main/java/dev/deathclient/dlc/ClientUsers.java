package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Who else has the client, and the badge shown left of their nickname (nametag and tab list).
 * No server is involved: while Client Badge is on, every chat message you send ends with an invisible marker
 * (three zero-width characters). A client that reads a message with that marker remembers the sender, so
 * a player is recognised once he has written in chat while you could see him. Servers or chat plugins that
 * strip zero-width characters hide the marker, and then nobody is recognised.
 * The badge itself is a glyph of the font assets/deathclientdlc/font/badge.json (textures/gui/badge.png).
 */
public final class ClientUsers {
    private static final String MARK = "\u200B\u200D\u200C";
    private static final Style BADGE = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("deathclientdlc", "badge")));
    private static final Set<String> USERS = ConcurrentHashMap.newKeySet();

    private ClientUsers() {}

    private static ClientBadgeModule module() {
        ClientBadgeModule m = ModuleManager.get(ClientBadgeModule.class);
        return m != null && m.isEnabled() ? m : null;
    }

    /** Reads an incoming chat message: if it carries the marker, the player named before it has the client. */
    public static void onMessage(Text message) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null || c.player == null) return;
        String s = message.getString();
        int mark = s.indexOf(MARK);
        if (mark < 0) return;
        String head = s.substring(0, mark).toLowerCase(Locale.ROOT);
        String best = null;
        int bestAt = Integer.MAX_VALUE;
        for (PlayerEntity p : c.world.getPlayers()) {                 // the sender's name comes first in the line
            if (p == c.player) continue;
            String name = p.getName().getString().toLowerCase(Locale.ROOT);
            int at = indexOfWord(head, name);
            if (at >= 0 && (at < bestAt || (at == bestAt && best != null && name.length() > best.length()))) { best = name; bestAt = at; }
        }
        if (best != null) USERS.add(best);
    }

    public static void clear() { USERS.clear(); }

    /** True when this player's name should carry the badge. */
    public static boolean shows(PlayerEntity p) {
        ClientBadgeModule m = module();
        if (m == null || !(p instanceof AbstractClientPlayerEntity)) return false;
        if (p == MinecraftClient.getInstance().player) return m.self.get();
        return USERS.contains(p.getName().getString().toLowerCase(Locale.ROOT));
    }

    public static Text withBadge(Text name) {
        return Text.empty().append(Text.literal("\uE000").setStyle(BADGE)).append(Text.literal(" ")).append(name);
    }

    /** Tab list entry: the badge goes in front of the name of a known client user. */
    public static Text tabName(Text name) {
        ClientBadgeModule m = module();
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || name == null) return name;
        String s = name.getString().toLowerCase(Locale.ROOT);
        if (m.self.get() && c.player != null && indexOfWord(s, c.player.getName().getString().toLowerCase(Locale.ROOT)) >= 0) return withBadge(name);
        for (String u : USERS) if (indexOfWord(s, u) >= 0) return withBadge(name);
        return name;
    }

    /** Outgoing chat: appends the marker (not to commands, which never come through here). */
    public static String tag(String content) {
        ClientBadgeModule m = module();
        if (m == null || !m.tagChat.get() || content == null || content.endsWith(MARK) || content.length() > 250) return content;
        return content + MARK;
    }

    /** Index of {@code word} in {@code s} as a whole nickname (not inside a longer one), or -1. */
    private static int indexOfWord(String s, String word) {
        if (word.isEmpty()) return -1;
        for (int i = s.indexOf(word); i >= 0; i = s.indexOf(word, i + 1)) {
            boolean left = i == 0 || !isNickChar(s.charAt(i - 1));
            boolean right = i + word.length() >= s.length() || !isNickChar(s.charAt(i + word.length()));
            if (left && right) return i;
        }
        return -1;
    }

    private static boolean isNickChar(char ch) { return ch == '_' || Character.isLetterOrDigit(ch); }
}
