package dev.deathclient.dlc.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.deathclient.dlc.HudEdit;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * View Model: with the chat open, the mouse wheel over a hand marker scales that hand (and does not scroll the chat).
 * The vertical amount is picked from the arguments by type and order (the second double), so the hook does not
 * depend on the exact signature. require = 0: if the method is named differently in this build, the wheel does
 * nothing and the scale is still available as a slider.
 */
@Mixin(Mouse.class)
public abstract class MouseScrollMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$handScale(CallbackInfo ci, @Local(argsOnly = true, ordinal = 1) double vertical) {
        if (vertical != 0 && HudEdit.onScroll(vertical)) ci.cancel();
    }
}
