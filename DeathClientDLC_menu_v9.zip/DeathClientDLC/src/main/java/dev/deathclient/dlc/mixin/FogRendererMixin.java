package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.CustomFogModule;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Custom Fog: the fog color the renderer works out, and the view distance its fog is computed from. The target is given
 * by name and lives in the optional mixin config: if the fog code is named differently in this Minecraft version the
 * hooks are skipped and the module has no effect (the game still starts).
 */
@Mixin(targets = "net.minecraft.client.render.fog.FogRenderer")
public abstract class FogRendererMixin {
    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$color(Camera camera, float tickProgress, ClientWorld world, int clampedViewDistance, float skyDarkness,
                                      CallbackInfoReturnable<Vector4f> cir) {
        int rgb = CustomFogModule.color();
        if (rgb == -1) return;
        Vector4f old = cir.getReturnValue();
        cir.setReturnValue(new Vector4f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, old == null ? 1f : old.w));
    }

    @ModifyVariable(method = "applyFog", at = @At("HEAD"), argsOnly = true, require = 0)
    private int deathclientdlc$distance(int viewDistance) {
        return CustomFogModule.viewDistance(viewDistance);
    }
}
