package dev.deathclient.dlc;

/** Carried by the render state of a living entity (added by LivingEntityRenderStateMixin): the emote pose to draw, or null. */
public interface EmoteState {
    void deathclientdlc$setPose(Emotes.Pose pose);

    Emotes.Pose deathclientdlc$getPose();
}
