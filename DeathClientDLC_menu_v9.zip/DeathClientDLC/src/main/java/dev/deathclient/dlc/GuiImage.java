package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** The picture of the GUI Image module: loading, saving (config/deathclientdlc/gui_image.png) and drawing. */
final class GuiImage {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc").resolve("gui_image.png");
    private static final Identifier ID = Identifier.of("deathclientdlc", "custom_gui_image");

    private static boolean loaded, has, dragging;
    private static int w = 1, h = 1, grabX, grabY;

    private GuiImage() {}

    private static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        if (!Files.exists(FILE)) return;
        try { show(Files.readAllBytes(FILE)); } catch (Exception e) { has = false; }
    }

    static boolean has() { ensureLoaded(); return has; }

    /** Takes a png / jpg from anywhere on disk and makes it the GUI image. */
    static void set(Path src) throws Exception {
        byte[] png = MenuCustom.toPng(Files.readAllBytes(src));
        Files.createDirectories(FILE.getParent());
        Files.write(FILE, png);
        loaded = true;
        show(png);
    }

    static void reset() {
        has = false;
        loaded = true;
        try { Files.deleteIfExists(FILE); } catch (IOException ignored) {}
    }

    /** Called by the ClickGUI screens when files are dropped on the window. Returns true if a picture or a font was set. */
    static boolean handleDrop(List<Path> paths) {
        if (paths == null || paths.isEmpty()) return false;
        try {
            if (CustomFontPack.isFontFile(paths.get(0))) {            // a font file: the Custom Font module takes it
                CustomFontPack.installAndUse(MinecraftClient.getInstance(), paths.get(0));
                return true;
            }
            set(paths.get(0));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void show(byte[] png) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        int iw = img.getWidth(), ih = img.getHeight();
        AbstractTexture tex = MenuCustom.makeTexture(img);
        MinecraftClient.getInstance().getTextureManager().registerTexture(ID, tex);
        w = iw;
        h = ih;
        has = true;
    }

    /** Where the picture is on a screen of sw x sh: {x, y, width, height}, or null when it is not shown. */
    private static int[] rect(int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (m == null || !m.isEnabled()) return null;
        ensureLoaded();
        if (!has) return null;
        int dh = Math.round(sh * (float) (m.size.get() / 100.0));
        int dw = Math.round(dh * w / (float) h);
        if (dw > sw) { dw = sw; dh = Math.round(dw * h / (float) w); }     // never wider than the screen
        return new int[]{sw - dw + (int) m.offsetX.get(), sh - dh + (int) m.offsetY.get(), dw, dh};
    }

    /** Mouse pressed on the picture: starts moving it. Returns true if the click was on the picture. */
    static boolean press(double mx, double my, int sw, int sh) {
        int[] r = rect(sw, sh);
        if (r == null || mx < r[0] || mx >= r[0] + r[2] || my < r[1] || my >= r[1] + r[3]) return false;
        dragging = true;
        grabX = (int) mx - r[0];
        grabY = (int) my - r[1];
        return true;
    }

    /** Mouse moved with the button held: moves the picture (Offset X / Y of the module). */
    static boolean drag(double mx, double my, int sw, int sh) {
        if (!dragging) return false;
        int[] r = rect(sw, sh);
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (r == null || m == null) { dragging = false; return false; }
        m.offsetX.set((int) mx - grabX - (sw - r[2]));
        m.offsetY.set((int) my - grabY - (sh - r[3]));
        return true;
    }

    static void release() { dragging = false; }

    /** Draws the picture (call before the window, so the window stays on top). */
    static void draw(DrawContext ctx, int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        int[] r = rect(sw, sh);
        if (m == null || r == null) return;
        int a = Math.round(255f * (float) (m.opacity.get() / 100.0));
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ID, r[0], r[1], 0f, 0f, r[2], r[3], w, h, w, h, (a << 24) | 0xFFFFFF);
    }
}
