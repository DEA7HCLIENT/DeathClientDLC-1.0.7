package dev.deathclient.dlc;

/**
 * GUI Image: your own picture (a character, a logo...) in the bottom-right corner of the ClickGUI, drawn behind
 * the window in all three GUI styles. Drag it with the mouse. Set it by dropping a png / jpg onto the open ClickGUI; ".guiimage reset"
 * removes it. A png with a transparent background looks best. The file is config/deathclientdlc/gui_image.png.
 */
public class GuiImageModule extends Module {
    /** Height of the picture in percent of the screen height. */
    public final NumberSetting size = add(new NumberSetting("Size %", 70, 10, 100, 5));
    public final NumberSetting opacity = add(new NumberSetting("Opacity %", 100, 10, 100, 5));
    /** Shift from the bottom-right corner in GUI pixels (positive X = further right, positive Y = further down). */
    public final NumberSetting offsetX = add(new NumberSetting("Offset X", 0, -1500, 1500, 1));
    public final NumberSetting offsetY = add(new NumberSetting("Offset Y", 0, -1500, 1500, 1));

    public GuiImageModule() { super("GUI Image", Category.MISC, true); }
}
