package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.EmoteState;
import dev.deathclient.dlc.Emotes;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Emotions: gives every living render state a slot for the emote pose (filled for your own player only). */
@Mixin(LivingEntityRenderState.class)
public abstract class LivingEntityRenderStateMixin implements EmoteState {
    @Unique private Emotes.Pose deathclientdlc$pose;

    @Override
    public void deathclientdlc$setPose(Emotes.Pose pose) { this.deathclientdlc$pose = pose; }

    @Override
    public Emotes.Pose deathclientdlc$getPose() { return this.deathclientdlc$pose; }
}
