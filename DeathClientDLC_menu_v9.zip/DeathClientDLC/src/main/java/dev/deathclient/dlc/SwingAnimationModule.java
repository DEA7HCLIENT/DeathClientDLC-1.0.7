package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Swing animation of the first-person hand: 13 styles (and your own, Custom), with two sliders.
 *
 * Power scales how far the hand moves and turns, Speed how fast the swing is (it sets the swing length, see
 * LivingEntityMixin). "Only on target" plays the style only when the crosshair is on a mob or a player; a swing at
 * the air stays vanilla. When the style is changed a small card shows its name for a moment.
 *
 * The styles replace vanilla's swing offset for held items (HeldItemRendererMixin); an empty hand keeps the vanilla swing.
 */
public class SwingAnimationModule extends Module {
    private static final int DEFAULT = 1, SWING = 2, SWING2 = 3, SLAP = 4, BONK = 5, JELLY = 6, CIRCLE = 7, SPEAR = 8,
            LUNGE = 9, BREAK = 10, DOWN = 11, SHIFT = 12, SWIPE = 13, CUSTOM = 14;
    private static final String[] NAMES = {"Default", "Swing", "Swing 2", "Slap", "Bonk", "Jelly", "Circle", "Spear",
            "Lunge", "Break", "Down", "Shift", "Swipe", "Custom"};

    public final NumberSetting mode = add(new NumberSetting("Type", 1, 1, 14, 1).labels(NAMES));
    /** How far the hand moves and turns (1 = as designed). */
    public final NumberSetting power = add(new NumberSetting("Power", 1.0, 0.2, 2.5, 0.05));
    /** Swing speed: 2 = twice as fast as vanilla, 0.5 = half as fast. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.5, 3.0, 0.1));
    /** Play the style only when the crosshair is on a mob or a player. */
    public final BoolSetting onlyOnTarget = add(new BoolSetting("Only on target", false));
    public final BoolSetting popup = add(new BoolSetting("Show type card", true));
    /** Custom type: how far the hand moves (units) and turns (degrees) at the peak of the swing. */
    public final NumberSetting posX = add(new NumberSetting("Pos X", 0, -1, 1, 0.05));
    public final NumberSetting posY = add(new NumberSetting("Pos Y", -0.2, -1, 1, 0.05));
    public final NumberSetting posZ = add(new NumberSetting("Pos Z", -0.2, -1, 1, 0.05));
    public final NumberSetting rotX = add(new NumberSetting("Rot X", -40, -90, 90, 5));
    public final NumberSetting rotY = add(new NumberSetting("Rot Y", 0, -90, 90, 5));
    public final NumberSetting rotZ = add(new NumberSetting("Rot Z", 0, -90, 90, 5));

    /** "Only on target": was the crosshair on a target when the last swing began (sampled while not swinging). */
    private static boolean latch = true;
    private static int lastType = -1;
    private static long popupUntil;

    public SwingAnimationModule() { super("Swing Animation", Category.RENDER); }

    /** Swing length in ticks: vanilla is 6, Speed divides it. */
    public int duration() { return Math.max(1, Math.min(20, (int) Math.round(6.0 / speed.get()))); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null) return;
        if (c.player.getHandSwingProgress(0f) <= 0f) {                // not swinging: remember what the crosshair is on
            latch = c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity;
        }
    }

    @Override
    protected void onDisable() { lastType = -1; }

    /** Applies the chosen swing to the matrix. Returns true if it replaced vanilla's swing offset. */
    public static boolean apply(MatrixStack m, Arm arm, float p) {
        SwingAnimationModule s = ModuleManager.get(SwingAnimationModule.class);
        if (s == null || !s.isEnabled()) return false;
        int type = (int) s.mode.get();
        if (type == DEFAULT || p <= 0f) return false;
        if (s.onlyOnTarget.get() && !latch) return false;             // a swing at the air stays vanilla

        float side = arm == Arm.RIGHT ? 1f : -1f;                     // mirror for the left hand
        float k = (float) s.power.get();
        float g = MathHelper.sin(MathHelper.sqrt(p) * (float) Math.PI);   // 0 -> 1 -> 0 over the swing
        // Vanilla translates the hand by (side * -0.4 * g, 0.2 * sin(2 * sqrt(p) * PI), -0.2 * sin(p * PI)) BEFORE it
        // calls applySwingOffset, so cancelling only that method leaves the vanilla motion stacked under ours.
        // The equip offset is a pure translation, so undoing the vanilla part here is exact.
        float sq = MathHelper.sqrt(p);
        m.translate(side * 0.4f * g,
                -0.2f * MathHelper.sin(sq * (float) Math.PI * 2f),
                0.2f * MathHelper.sin(p * (float) Math.PI));

        switch (type) {
            case SWING -> {                          // a big arc over the shoulder
                m.translate(side * -0.10f * k * g, -0.08f * k * g, -0.18f * k * g);
                rot(m, RotationAxis.POSITIVE_X, -70f * k * g);
                rot(m, RotationAxis.POSITIVE_Y, side * 20f * k * g);
            }
            case SWING2 -> {                         // the other way round: from the outside, across
                m.translate(side * 0.12f * k * g, -0.06f * k * g, -0.12f * k * g);
                rot(m, RotationAxis.POSITIVE_X, -45f * k * g);
                rot(m, RotationAxis.POSITIVE_Z, side * -45f * k * g);
                rot(m, RotationAxis.POSITIVE_Y, side * -15f * k * g);
            }
            case SLAP -> {                           // wind up outwards, then a flat sweep across
                float a = key(p, new float[]{0f, 0.3f, 0.55f, 1f}, new float[]{0f, -1f, 1f, 0f});
                m.translate(side * -0.35f * k * a, 0f, -0.1f * k * g);
                rot(m, RotationAxis.POSITIVE_Y, side * 55f * k * a);
                rot(m, RotationAxis.POSITIVE_Z, side * -20f * k * Math.abs(a));
            }
            case BONK -> {                           // lift, then smash down like a hammer
                float[] t = {0f, 0.3f, 0.55f, 1f};
                rot(m, RotationAxis.POSITIVE_X, k * key(p, t, new float[]{0f, 25f, -85f, 0f}));
                m.translate(0f, k * key(p, t, new float[]{0f, 0.10f, -0.25f, 0f}), -0.12f * k * g);
            }
            case JELLY -> {                          // wobbles like jelly and settles
                float wob = MathHelper.sin(p * (float) Math.PI * 5f) * (1f - p);
                m.translate(0f, -0.04f * k * g, (-0.15f * g + 0.06f * wob) * k);
                rot(m, RotationAxis.POSITIVE_X, (-40f * g + 14f * wob) * k);
                rot(m, RotationAxis.POSITIVE_Z, side * 10f * wob * k);
            }
            case CIRCLE -> {                         // the hand draws a circle
                float th = p * (float) Math.PI * 2f;
                m.translate(side * 0.22f * k * MathHelper.sin(th), 0.15f * k * (1f - MathHelper.cos(th)), -0.1f * k * g);
                rot(m, RotationAxis.POSITIVE_Z, side * 25f * k * MathHelper.sin(th));
                rot(m, RotationAxis.POSITIVE_X, -25f * k * g);
            }
            case SPEAR -> {                          // pull back a little, then thrust forward
                float t = key(p, new float[]{0f, 0.3f, 0.5f, 1f}, new float[]{0f, -0.2f, 1f, 0f});
                m.translate(0f, -0.05f * k * t, -0.55f * k * t);
                rot(m, RotationAxis.POSITIVE_X, -8f * k * t);
                rot(m, RotationAxis.POSITIVE_Y, side * 10f * k * t);
            }
            case LUNGE -> {                          // quick lean forward and down
                float gg = (float) Math.pow(g, 0.7);
                m.translate(0f, -0.15f * k * gg, -0.45f * k * gg);
                rot(m, RotationAxis.POSITIVE_X, -30f * k * gg);
                rot(m, RotationAxis.POSITIVE_Z, side * -10f * k * gg);
            }
            case BREAK -> {                          // a diagonal chop
                m.translate(side * -0.10f * k * g, -0.18f * k * g, 0f);
                rot(m, RotationAxis.POSITIVE_Z, side * -60f * k * g);
                rot(m, RotationAxis.POSITIVE_X, -60f * k * g);
            }
            case DOWN -> {                           // drops down and forward
                m.translate(0f, -0.35f * k * g, -0.15f * k * g);
                rot(m, RotationAxis.POSITIVE_X, -35f * k * g);
            }
            case SHIFT -> {                          // slides inwards across the screen
                m.translate(side * -0.35f * k * g, 0f, 0f);
                rot(m, RotationAxis.POSITIVE_Y, side * 20f * k * g);
                rot(m, RotationAxis.POSITIVE_X, -15f * k * g);
            }
            case SWIPE -> {                          // sweeps sideways
                m.translate(side * -0.45f * k * g, -0.05f * k * g, -0.1f * k * g);
                rot(m, RotationAxis.POSITIVE_Y, side * 50f * k * g);
                rot(m, RotationAxis.POSITIVE_Z, side * -30f * k * g);
            }
            default -> {                             // Custom: your own offsets and angles
                m.translate(side * (float) s.posX.get() * k * g, (float) s.posY.get() * k * g, (float) s.posZ.get() * k * g);
                rot(m, RotationAxis.POSITIVE_X, (float) s.rotX.get() * k * g);
                rot(m, RotationAxis.POSITIVE_Y, side * (float) s.rotY.get() * k * g);
                rot(m, RotationAxis.POSITIVE_Z, side * (float) s.rotZ.get() * k * g);
            }
        }
        return true;
    }

    private static void rot(MatrixStack m, RotationAxis axis, float degrees) {
        m.multiply(axis.rotationDegrees(degrees));
    }

    /** Value at time p between keyframes (times t, values v), eased between neighbouring keys. */
    private static float key(float p, float[] t, float[] v) {
        for (int i = 0; i < t.length - 1; i++) {
            if (p <= t[i + 1]) {
                float f = MathHelper.clamp((p - t[i]) / (t[i + 1] - t[i]), 0f, 1f);
                f = f * f * (3f - 2f * f);
                return v[i] + (v[i + 1] - v[i]) * f;
            }
        }
        return v[v.length - 1];
    }

    // ------------------------------------------------------------------ the "swing type" card

    /** HUD callback (see DeathClientDLC): a card with the style's name for a moment after it was changed. */
    static void renderPopup(DrawContext ctx, RenderTickCounter tickCounter) {
        SwingAnimationModule s = ModuleManager.get(SwingAnimationModule.class);
        if (s == null || !s.isEnabled() || !s.popup.get() || Hud.hidden) { lastType = -1; return; }
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        int type = (int) s.mode.get();
        long now = System.currentTimeMillis();
        if (type != lastType) {
            if (lastType != -1) popupUntil = now + 1800;
            lastType = type;
        }
        if (now >= popupUntil) return;

        float fade = Math.min(1f, (popupUntil - now) / 350f);
        int a = (int) (255 * fade);
        int acc = Theme.current().accent() & 0xFFFFFF;
        var tr = c.textRenderer;
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int w = 150, h = 40, x = (sw - w) / 2, y = sh - 96;
        ClickGuiScreen.rrect(ctx, x, y, w, h, ((int) (0xC0 * fade) << 24) | 0x101018, 8);
        ClickGuiScreen.outline(ctx, x, y, w, h, ((int) (0x55 * fade) << 24) | 0xFFFFFF, 8);
        Fonts.draw(ctx, tr, "SWING TYPE", x + 8, y + 5, (a << 24) | 0x9A9AA6);
        String idx = String.format("%02d/%02d", type, NAMES.length);
        Fonts.draw(ctx, tr, idx, x + w - 8 - Fonts.width(tr, idx), y + 5, (a << 24) | 0x9A9AA6);
        String name = NAMES[type - 1];
        float scale = 1.6f;
        Fonts.drawScaled(ctx, tr, Fonts.bold(name), x + (w - Fonts.width(tr, name) * scale) / 2f, y + 14, scale, (a << 24) | 0xFFFFFF);
        int segW = (w - 16 - (NAMES.length - 1) * 2) / NAMES.length;
        for (int i = 0; i < NAMES.length; i++) {
            int sx = x + 8 + i * (segW + 2);
            ctx.fill(sx, y + h - 6, sx + segW, y + h - 4, i == type - 1 ? (a << 24) | acc : ((int) (0x40 * fade) << 24) | 0xFFFFFF);
        }
    }
}
