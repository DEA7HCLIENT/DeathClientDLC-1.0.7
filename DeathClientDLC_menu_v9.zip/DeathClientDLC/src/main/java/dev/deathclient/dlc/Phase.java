package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * The rule behind NoClip and NoClip Fly (applied by PhaseMixin to every move of your player): blocks do not stop you
 * sideways or upwards, but a floor still holds you up as long as you are not inside a block. Inside a block (a wall) you
 * fall down: with "Fall in walls" on (NoClip) you sink through it; off, the floor check is skipped and you glide through
 * the wall at the same height. Only the floor is checked; the rest is vanilla's no-clip movement.
 */
final class Phase {
    private Phase() {}

    /** True for the local player while NoClip or NoClip Fly is on. */
    static boolean applies(Entity e) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != e || c.world == null) return false;
        for (Module m : ModuleManager.all()) {
            if (m.isEnabled() && (m instanceof NoClipModule || (m instanceof FlyModule f && f.isNoClip()))) return true;
        }
        return false;
    }

    static boolean fallInWalls() {
        NoClipModule m = ModuleManager.get(NoClipModule.class);
        return m == null || !m.isEnabled() || m.fallInWalls.get();
    }

    /** Whether your body overlaps a block (a hair smaller than the hitbox, so standing on a floor does not count). */
    static boolean inWall(MinecraftClient c, ClientPlayerEntity p) {
        return !c.world.isSpaceEmpty(p.getBoundingBox().contract(0.002));
    }

    /** The movement of this tick with its downward part cut at the floor (when there is a floor to stand on). */
    static Vec3d clip(MinecraftClient c, ClientPlayerEntity p, Vec3d m) {
        if (m.y > 0) { p.setOnGround(false); return m; }
        if (m.y == 0) return m;
        if (fallInWalls() && inWall(c, p)) return m;              // inside a wall: fall

        Box box = p.getBoundingBox();
        double fall = -m.y;
        if (c.world.isSpaceEmpty(box.offset(0, -fall, 0))) { p.setOnGround(false); return m; }
        double lo = 0, hi = fall;                                  // the largest drop that stays clear of the floor
        for (int i = 0; i < 10; i++) {
            double mid = (lo + hi) / 2;
            if (c.world.isSpaceEmpty(box.offset(0, -mid, 0))) lo = mid; else hi = mid;
        }
        p.setOnGround(true);                                       // so that jumping works
        return new Vec3d(m.x, -lo, m.z);
    }
}
