package dev.deathclient.dlc;

import net.minecraft.block.BedBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CraftingTableBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EmptyBlockView;

/** Shared helpers for modules that place blocks by themselves (Scaffold): which block, and what to click on. */
final class BlockPlace {
    static final double REACH = 4.5;

    private static final Direction[] DOWN_FIRST = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.UP};
    private static final Direction[] SIDES_FIRST = {Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, Direction.DOWN, Direction.UP};

    private BlockPlace() {}

    /** A solid neighbour of the target and the point on its face to click. */
    record Support(BlockPos pos, Direction face, Vec3d hit) {}

    /** A solid neighbour of {@code target} to click on (the ground first, or the sides first), within reach. */
    static Support findSupport(MinecraftClient c, Vec3d eye, BlockPos target, boolean sidesFirst) {
        for (Direction d : sidesFirst ? SIDES_FIRST : DOWN_FIRST) {
            BlockPos n = target.offset(d);
            BlockState s = c.world.getBlockState(n);
            if (!s.isSolidBlock(c.world, n) || interactive(s.getBlock())) continue;
            Direction face = d.getOpposite();                            // the face of n that looks at the target
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (eye.distanceTo(hit) > REACH) continue;
            return new Support(n, face, hit);
        }
        return null;
    }

    /** Blocks that react to a right click (clicking them would open or use them instead of placing a block). */
    static boolean interactive(Block b) {
        return b instanceof BedBlock || b instanceof BlockWithEntity || b instanceof CraftingTableBlock
                || b instanceof DoorBlock || b instanceof TrapdoorBlock || b instanceof FenceGateBlock || b instanceof ButtonBlock;
    }

    /** A full solid block that is safe to build with (no beds, TNT, sand, chests...). */
    static boolean usable(Block b) {
        return !(b instanceof BedBlock || b instanceof TntBlock || b instanceof FallingBlock || b instanceof BlockWithEntity)
                && b.getDefaultState().isFullCube(EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
    }

    /** Hotbar slot with the best block to build with: the strongest one, or the one in hand when strongest is off. -1: none. */
    static int pickSlot(ClientPlayerEntity p, boolean strongest) {
        int held = p.getInventory().getSelectedSlot();
        int best = -1;
        float bestScore = -1f;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!(st.getItem() instanceof BlockItem bi) || !usable(bi.getBlock())) continue;
            float score = strongest ? bi.getBlock().getBlastResistance() : (i == held ? 1f : 0f);
            if (score > bestScore) { bestScore = score; best = i; }
        }
        return best;
    }

    /** The slot of the block in hand if it is usable, else -1. */
    static int heldSlot(ClientPlayerEntity p) {
        return p.getMainHandStack().getItem() instanceof BlockItem bi && usable(bi.getBlock()) ? p.getInventory().getSelectedSlot() : -1;
    }
}
