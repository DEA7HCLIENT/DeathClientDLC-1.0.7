package dev.deathclient.dlc;

/** Menu entry without logic yet (needs a renderer hook). */
public class PendingModule extends Module {
    public PendingModule(String name, Category category) { super(name, category); }

    @Override
    public boolean isImplemented() { return false; }
}
