package dev.deathclient.dlc;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Start-up screen, shown once per launch before the main menu: black background, the Death DLC icon fades in,
 * slowly grows, fades out, and then the main menu fades in from black (see introFade, used by MainMenuScreen).
 * A click or Esc skips it. The icon is textures/gui/splash_icon.png.
 */
public class SplashScreen extends Screen {
    /** Set when the splash has been started, so it is only ever shown once per launch. */
    static boolean done;

    private static final Identifier ICON = Identifier.of("deathclientdlc", "textures/gui/splash_icon.png");
    private static final int TEX = 512;
    private static final long FADE_IN = 700, TOTAL = 3400, FADE_OUT = 900;   // ms
    private static final long MENU_FADE = 1000;                              // ms, the main menu coming out of black
    private static long menuFadeStart;

    private long start = -1;
    private boolean leaving;

    public SplashScreen() {
        super(Text.literal("Death Client"));
        done = true;
    }

    /** 1 -> 0 over the first second of the main menu; 0 when it is not fading in. Black overlay strength. */
    static float introFade() {
        if (menuFadeStart == 0) return 0f;
        long t = System.currentTimeMillis() - menuFadeStart;
        if (t >= MENU_FADE) { menuFadeStart = 0; return 0f; }
        float a = 1f - t / (float) MENU_FADE;
        return a * a;
    }

    private static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xFF000000);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        long now = System.currentTimeMillis();
        if (start < 0) start = now;
        long t = now - start;

        float p = Math.min(1f, t / (float) TOTAL);
        float ease = 1f - (float) Math.pow(1f - p, 3);                 // fast at first, then settles
        float scale = 0.72f + 0.50f * ease;                            // it grows
        float in = smooth(t / (float) FADE_IN);
        float out = 1f - smooth((t - (TOTAL - FADE_OUT)) / (float) FADE_OUT);
        int a = Math.round(255f * Math.min(in, out));
        if (a <= 0) return;

        int base = (int) (Math.min(width, height) * 0.40f);
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(width / 2f, height / 2f);
        m.scale(scale, scale);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, -base / 2, -base / 2, 0f, 0f, base, base,
                TEX, TEX, TEX, TEX, (a << 24) | 0xFFFFFF);
        m.popMatrix();
    }

    @Override
    public void tick() {
        super.tick();
        if (start >= 0 && System.currentTimeMillis() - start >= TOTAL) finish();
    }

    private void finish() {
        if (leaving || client == null) return;
        leaving = true;
        menuFadeStart = System.currentTimeMillis();
        client.setScreen(new MainMenuScreen());
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        finish();
        return true;
    }

    @Override
    public void close() { finish(); }

    @Override
    public boolean shouldPause() { return false; }
}
