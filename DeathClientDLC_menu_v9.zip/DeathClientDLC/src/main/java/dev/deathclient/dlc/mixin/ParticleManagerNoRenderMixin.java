package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render, Particles: a new particle is dropped before it joins the list, so none are drawn. The descriptor names the
 * one overload that takes a ready particle (all other ways to add a particle end up here).
 * require = 0: skipped if the method is named differently in this build.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleManagerNoRenderMixin {
    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noParticles(CallbackInfo ci) {
        if (NoRenderModule.particles()) ci.cancel();
    }
}
