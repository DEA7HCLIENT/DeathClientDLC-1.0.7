package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Arrows: a ring of arrows around the crosshair, each pointing toward an entity (relative to where you look).
 * Style: Pointer (glowing arrowhead) or Chevron (thin ">" sign). Filters: Players, Mobs, Entities (items, end
 * crystals, TNT, minecarts, armor stands), Invisibles (invisible players) and Naked invisibles (invisible
 * players with no armor at all, the hardest to notice; they get their own red colour).
 */
public class ArrowsModule extends Module {
    private static final Identifier POINTER = Identifier.of("deathclientdlc", "textures/gui/arrow_pointer.png");
    private static final Identifier CHEVRON = Identifier.of("deathclientdlc", "textures/gui/arrow_chevron.png");
    private static final int TEX = 128;
    private static final int MAX_ARROWS = 24;
    private static final int PLAYER = 0, MOB = 1, ENTITY = 2, INVIS = 3, NAKED = 4, FRIEND = 5;
    private static final int[] COLORS = {0, 0xE08A3C, 0x8FB4FF, 0xB06AFF, 0xFF4A4A, 0x5CD65C};   // PLAYER uses the theme

    public final NumberSetting style = add(new NumberSetting("Style", 1, 1, 2, 1).labels("Pointer", "Chevron"));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    public final BoolSetting entities = add(new BoolSetting("Entities", false));
    public final BoolSetting invisibles = add(new BoolSetting("Invisibles", true));
    public final BoolSetting nakedInvisibles = add(new BoolSetting("Naked invisibles", true));
    /** Distance of the arrows from the screen centre, GUI pixels. */
    public final NumberSetting radius = add(new NumberSetting("Radius", 90, 40, 220, 5));
    public final NumberSetting size = add(new NumberSetting("Size", 20, 8, 48, 1));
    /** Only entities closer than this many blocks. */
    public final NumberSetting range = add(new NumberSetting("Range", 64, 8, 160, 4));
    public final BoolSetting fade = add(new BoolSetting("Fade with distance", true));

    private record Target(double dx, double dz, double dist, int kind) {}

    public ArrowsModule() { super("Arrows", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ArrowsModule m = ModuleManager.get(ArrowsModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        Entity cam = c.getCameraEntity() != null ? c.getCameraEntity() : c.player;
        float yaw = cam.getYaw(delta);
        if (cam == c.player && c.options.getPerspective().isFrontView()) yaw += 180f;
        Vec3d from = cam.getLerpedPos(delta);
        double max = range.get();

        List<Target> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e == c.player || e == cam || e.isSpectator() || e.isRemoved()) continue;
            int kind = kind(e);
            if (kind < 0) continue;
            Vec3d p = e.getLerpedPos(delta);
            double dx = p.x - from.x, dz = p.z - from.z;
            double dist = Math.sqrt(dx * dx + (p.y - from.y) * (p.y - from.y) + dz * dz);
            if (dist > max || (dx == 0 && dz == 0)) continue;
            list.add(new Target(dx, dz, dist, kind));
        }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(Target::dist));

        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        float cx = sw / 2f, cy = sh / 2f;
        Identifier tex = (int) style.get() == 2 ? CHEVRON : POINTER;
        int half = (int) Math.round(size.get() / 2.0);
        int theme = Theme.current().accent() & 0xFFFFFF;
        var m = ctx.getMatrices();

        for (int i = 0; i < Math.min(MAX_ARROWS, list.size()); i++) {
            Target t = list.get(i);
            // Yaw of the direction to the target (0 = +Z); relative to the view, positive = to the right.
            double toTarget = Math.toDegrees(Math.atan2(-t.dx(), t.dz()));
            double phi = Math.toRadians(MathHelper.wrapDegrees((float) (toTarget - yaw)) - 90.0);   // screen angle, 0 = right
            float x = cx + (float) (Math.cos(phi) * radius.get());
            float y = cy + (float) (Math.sin(phi) * radius.get());

            double alpha = fade.get() ? 1.0 - 0.6 * (t.dist() / range.get()) : 1.0;
            int a = (int) Math.round(255 * Math.max(0.25, Math.min(1.0, alpha)));
            int rgb = t.kind() == PLAYER ? theme : COLORS[t.kind()];

            m.pushMatrix();
            m.translate(x, y);
            m.rotate((float) phi);
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, -half, -half, 0f, 0f,
                    half * 2, half * 2, TEX, TEX, TEX, TEX, (a << 24) | rgb);
            m.popMatrix();
        }
    }

    /** Which filter (and colour) an entity falls under, or -1 if it is not shown. */
    private int kind(Entity e) {
        if (e instanceof PlayerEntity pl) {
            if (pl.isInvisible()) {
                if (nakedInvisibles.get() && isNaked(pl)) return NAKED;
                return invisibles.get() ? INVIS : -1;
            }
            if (!players.get()) return -1;
            return Friends.isFriend(pl) ? FRIEND : PLAYER;
        }
        if (e instanceof ArmorStandEntity) return entities.get() ? ENTITY : -1;
        if (e instanceof MobEntity) return mobs.get() ? MOB : -1;
        if (e instanceof ItemEntity || e instanceof EndCrystalEntity || e instanceof TntEntity
                || e instanceof AbstractMinecartEntity) {
            return entities.get() ? ENTITY : -1;
        }
        return -1;
    }

    private static boolean isNaked(PlayerEntity p) {
        return p.getEquippedStack(EquipmentSlot.HEAD).isEmpty() && p.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                && p.getEquippedStack(EquipmentSlot.LEGS).isEmpty() && p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }
}
