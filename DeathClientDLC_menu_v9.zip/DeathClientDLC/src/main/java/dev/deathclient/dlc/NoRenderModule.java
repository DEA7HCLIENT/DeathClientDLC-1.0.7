package dev.deathclient.dlc;

import java.util.function.Function;

/**
 * No Render: switches off visuals that get in the way. Every option is a separate hook in a mixin and works only
 * while the module is on:
 *
 * Screen effects: Fire, FOV effects, Potion effects (nausea, blindness, darkness), Hurt cam, Water overlay,
 * Wall overlay (inside a block), Overlays (pumpkin, powder snow), Portal overlay, Spyglass overlay, Vignette.
 * World: Weather (rain and thunder), Particles, Entity fire (flames drawn on burning mobs).
 * HUD: Boss bar, Scoreboard, Titles, Totem pop.
 * Items: Enchant glint.
 *
 * The options marked "off" start switched off; the first three are on, as before.
 * Hooks: InGameOverlayRendererMixin, InGameHudNoRenderMixin, BossBarHudNoRenderMixin, GameRendererNoRenderMixin,
 * WorldNoRenderMixin, ParticleManagerNoRenderMixin, EntityNoRenderMixin, ItemStackNoRenderMixin,
 * AbstractClientPlayerEntityMixin, ClientPlayerEntityMixin, LivingEntityMixin.
 */
public class NoRenderModule extends Module {
    // --- Screen effects
    public final BoolSetting fire = add(new BoolSetting("Fire", true));
    public final BoolSetting fov = add(new BoolSetting("FOV effects", true));
    public final BoolSetting effects = add(new BoolSetting("Potion effects", true));
    public final BoolSetting hurtCam = add(new BoolSetting("Hurt cam", false));
    public final BoolSetting waterOverlay = add(new BoolSetting("Water overlay", false));
    public final BoolSetting wallOverlay = add(new BoolSetting("Wall overlay", false));
    public final BoolSetting overlays = add(new BoolSetting("Pumpkin / snow overlay", false));
    public final BoolSetting portalOverlay = add(new BoolSetting("Portal overlay", false));
    public final BoolSetting spyglassOverlay = add(new BoolSetting("Spyglass overlay", false));
    public final BoolSetting vignette = add(new BoolSetting("Vignette", false));
    // --- World
    public final BoolSetting weather = add(new BoolSetting("Weather", false));
    public final BoolSetting particles = add(new BoolSetting("Particles", false));
    public final BoolSetting entityFire = add(new BoolSetting("Entity fire", false));
    // --- HUD
    public final BoolSetting bossBar = add(new BoolSetting("Boss bar", false));
    public final BoolSetting scoreboard = add(new BoolSetting("Scoreboard", false));
    public final BoolSetting titles = add(new BoolSetting("Titles", false));
    public final BoolSetting totem = add(new BoolSetting("Totem pop", false));
    // --- Items
    public final BoolSetting glint = add(new BoolSetting("Enchant glint", false));

    public NoRenderModule() { super("No Render", Category.RENDER); }

    /** The module is on and the chosen option is set. */
    private static boolean on(Function<NoRenderModule, BoolSetting> option) {
        NoRenderModule m = ModuleManager.get(NoRenderModule.class);
        return m != null && m.isEnabled() && option.apply(m).get();
    }

    public static boolean fire() { return on(m -> m.fire); }
    public static boolean fov() { return on(m -> m.fov); }
    public static boolean effects() { return on(m -> m.effects); }
    public static boolean hurtCam() { return on(m -> m.hurtCam); }
    public static boolean waterOverlay() { return on(m -> m.waterOverlay); }
    public static boolean wallOverlay() { return on(m -> m.wallOverlay); }
    public static boolean overlays() { return on(m -> m.overlays); }
    public static boolean portalOverlay() { return on(m -> m.portalOverlay); }
    public static boolean spyglassOverlay() { return on(m -> m.spyglassOverlay); }
    public static boolean vignette() { return on(m -> m.vignette); }
    public static boolean weather() { return on(m -> m.weather); }
    public static boolean particles() { return on(m -> m.particles); }
    public static boolean entityFire() { return on(m -> m.entityFire); }
    public static boolean bossBar() { return on(m -> m.bossBar); }
    public static boolean scoreboard() { return on(m -> m.scoreboard); }
    public static boolean titles() { return on(m -> m.titles); }
    public static boolean totem() { return on(m -> m.totem); }
    public static boolean glint() { return on(m -> m.glint); }
}
