package dev.deathclient.dlc;

/**
 * Custom Sky: the sky takes the color you choose (Hue / Saturation / Brightness, the theme color, or a Rainbow that
 * cycles), day and night. Client-side only. The sky color is read from ClientWorld.getSkyColor by ClientWorldSkyMixin,
 * which lives in the optional mixin config deathclientdlc.sky.mixins.json: if the method is named differently in your
 * Minecraft version the game still starts, and the module simply has no effect.
 */
public class CustomSkyModule extends Module {
    public final NumberSetting hue = add(new NumberSetting("Hue", 210, 0, 360, 5));
    public final NumberSetting saturation = add(new NumberSetting("Saturation", 70, 0, 100, 5));
    public final NumberSetting brightness = add(new NumberSetting("Brightness", 90, 0, 100, 5));
    public final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    public CustomSkyModule() { super("Custom Sky", Category.RENDER); }

    /** The sky color (RGB), or -1 while the module is off. */
    public static int color() {
        CustomSkyModule m = ModuleManager.get(CustomSkyModule.class);
        return m == null || !m.isEnabled() ? -1 : EnvColor.rgb(m.hue, m.saturation, m.brightness, m.rainbow, m.themeColor);
    }
}
