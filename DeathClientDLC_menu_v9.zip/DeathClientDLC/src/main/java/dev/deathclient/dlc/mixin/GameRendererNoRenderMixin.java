package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render: Hurt cam (the view no longer tilts when you take damage) and Totem pop (the floating totem animation).
 * No arguments are read. require = 0: a method that is named differently in this build is skipped.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererNoRenderMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noHurtCam(CallbackInfo ci) {
        if (NoRenderModule.hurtCam()) ci.cancel();
    }

    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noTotem(CallbackInfo ci) {
        if (NoRenderModule.totem()) ci.cancel();
    }
}
