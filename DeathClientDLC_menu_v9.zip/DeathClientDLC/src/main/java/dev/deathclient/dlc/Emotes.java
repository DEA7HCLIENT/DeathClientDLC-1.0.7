package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

/**
 * The emote that is playing on your own model, and the saved Custom emotes (config/deathclientdlc/emotes.properties).
 * The animation is a function of time that returns the angles (radians) of the head and both arms; the model mixin
 * (BipedEntityModelMixin) applies them after vanilla's own pose. NaN means "leave vanilla's angle".
 */
public final class Emotes {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/emotes.properties");
    private static final double TAU = Math.PI * 2;
    private static final Map<String, double[]> SAVED = new TreeMap<>();

    /** Angles in radians; head pitch/yaw/roll, right arm pitch/yaw/roll, left arm pitch/yaw/roll. */
    public record Pose(float hp, float hy, float hr, float rp, float ry, float rr, float lp, float ly, float lr) {}

    private interface Anim { Pose at(double cycles); }

    private static Anim anim;
    private static long start;
    private static Perspective prevPerspective;

    private Emotes() {}

    // ---- playing ----

    /** Starts an emote by name: 67, hello (привет), custom or a saved name. False if there is no such emote. */
    public static boolean play(String name) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return false;
        String n = name.trim().toLowerCase(Locale.ROOT);
        Anim a = switch (n) {
            case "67", "6-7", "six-seven" -> Emotes::sixSeven;
            case "hello", "hi", "wave", "привет" -> Emotes::hello;
            case "custom" -> {
                EmotionsModule m = ModuleManager.get(EmotionsModule.class);
                yield t -> customPose(m == null ? new double[12] : m.custom(), t);
            }
            default -> {
                double[] v = SAVED.get(n);
                yield v == null ? null : (Anim) (t -> customPose(v, t));
            }
        };
        if (a == null) return false;
        anim = a;
        start = System.nanoTime();
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        if (m != null && m.thirdPerson.get() && prevPerspective == null) {
            prevPerspective = c.options.getPerspective();
            c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
        return true;
    }

    public static void stop() {
        anim = null;
        MinecraftClient c = MinecraftClient.getInstance();
        if (prevPerspective != null && c.options != null) c.options.setPerspective(prevPerspective);
        prevPerspective = null;
    }

    public static boolean active() { return anim != null; }

    /** The pose for this frame, or null when nothing plays. */
    public static Pose pose() {
        Anim a = anim;
        if (a == null) return null;
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        double speed = m == null ? 1.0 : m.speed.get();
        return a.at((System.nanoTime() - start) / 1.0e9 * speed);
    }

    /** Every client tick: stops the emote when you move, and keeps the module's on/off in step with it. */
    static void tick(MinecraftClient c) {
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        ClientPlayerEntity p = c.player;
        if (anim != null && (p == null || !p.isAlive())) stop();
        if (anim != null && m != null && m.stopOnMove.get() && c.currentScreen == null
                && (Util.inputDir(c, p) != net.minecraft.util.math.Vec3d.ZERO
                    || c.options.jumpKey.isPressed() || c.options.sneakKey.isPressed())) stop();
        if (anim == null && m != null && m.isEnabled()) m.toggle();
    }

    // ---- the animations ----

    private static Pose sixSeven(double t) {
        float s = (float) Math.sin(TAU * 2.2 * t);                       // hands move up and down in turns
        return new Pose(0.12f * (float) Math.sin(TAU * 4.4 * t), Float.NaN, Float.NaN,
                -1.5f + 0.6f * s, Float.NaN, 0.08f,
                -1.5f - 0.6f * s, Float.NaN, -0.08f);
    }

    private static Pose hello(double t) {
        float wave = 0.3f + 0.45f * (float) Math.sin(TAU * 2.2 * t);     // right arm up, swinging sideways
        return new Pose(Float.NaN, -0.2f, Float.NaN, -2.9f, Float.NaN, wave, Float.NaN, Float.NaN, Float.NaN);
    }

    /** v = pose A (R arm, R side, L arm, L side, head pitch, head yaw) then pose B, in degrees; one A-B-A trip per cycle. */
    private static Pose customPose(double[] v, double t) {
        double s = 0.5 - 0.5 * Math.cos(TAU * t);
        double[] k = new double[6];
        for (int i = 0; i < 6; i++) k[i] = Math.toRadians(v[i] + (v[i + 6] - v[i]) * s);
        return new Pose((float) k[4], (float) k[5], Float.NaN, (float) k[0], Float.NaN, (float) k[1],
                (float) k[2], Float.NaN, (float) -k[3]);
    }

    // ---- saved custom emotes ----

    /** Keeps the current Custom poses under this name. */
    public static boolean save(String name) {
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (m == null || n.isEmpty() || n.equals("67") || n.equals("hello") || n.equals("custom") || n.equals("привет")) return false;
        SAVED.put(n, m.custom());
        store();
        return true;
    }

    public static boolean delete(String name) {
        boolean r = SAVED.remove(name.trim().toLowerCase(Locale.ROOT)) != null;
        if (r) store();
        return r;
    }

    public static List<String> saved() { return new ArrayList<>(SAVED.keySet()); }

    public static void load() {
        SAVED.clear();
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (String key : props.stringPropertyNames()) {
            String[] parts = props.getProperty(key).split(",");
            if (parts.length != 12) continue;
            try {
                double[] v = new double[12];
                for (int i = 0; i < 12; i++) v[i] = Double.parseDouble(parts[i].trim());
                SAVED.put(key, v);
            } catch (NumberFormatException ignored) {}
        }
    }

    private static void store() {
        Properties props = new Properties();
        for (var e : SAVED.entrySet()) {
            StringBuilder sb = new StringBuilder();
            for (double d : e.getValue()) sb.append(sb.length() == 0 ? "" : ",").append(d);
            props.setProperty(e.getKey(), sb.toString());
        }
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) { props.store(out, "DeathClientDLC saved emotes"); }
        } catch (IOException ignored) {}
    }
}
