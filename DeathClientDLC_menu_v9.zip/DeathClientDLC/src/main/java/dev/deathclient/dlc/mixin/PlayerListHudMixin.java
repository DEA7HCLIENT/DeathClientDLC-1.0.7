package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ClientUsers;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Client Badge: the tab list shows the badge in front of known client users. */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {
    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$badge(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
        cir.setReturnValue(ClientUsers.tabName(cir.getReturnValue()));
    }
}
