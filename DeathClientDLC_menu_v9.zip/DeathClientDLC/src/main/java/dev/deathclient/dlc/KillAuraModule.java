package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Kill Aura: automatically attacks every valid target in reach, no clicking and no aiming needed.
 * <ul>
 *   <li>Rotation: None (attack only), Silent (server is told the aim for each hit, your camera never moves),
 *       Smooth (camera eases toward the target), Neuro (camera, human-like: eased speed, random aim point,
 *       mouse-sensitivity grid), VodkaCraft (server-side smoothed rotation on the sensitivity grid, attacks
 *       only once the aim has arrived), HvH (instant server-side lock on the target, held every tick),
 *       Bezier (camera, slow-fast-slow curve with a slight arc, like a hand moving a mouse),
 *       Spring (camera, inertia with a small overshoot that settles on the target),
 *       Focus (server-side, held; exponential approach, attacks only while the look ray hits the hitbox),
 *       Snap (server-side per hit; one grid-quantized turn to the aim point, then back to the real view),
 *       Matrix (server-side, held; human-like eased turn with a drifting aim point, short rests, a hit cooldown that
 *       varies per hit, line of sight required, reach under 2.95),
 *       Grim (server-side, held; grid-exact steps, no repeated look packets, interior aim point, hits only when the
 *       known look ray crosses the hitbox within 2.95 blocks; no hits while eating / blocking).</li>
 *   <li>Aim point (Bezier / Spring / Focus / Snap): Center, Chest, Head, Nearest (the point of the hitbox
 *       closest to where you already look, i.e. the smallest turn) or Wander (random point, re-rolled).</li>
 *   <li>Reach is measured to the target's hitbox, the way the server measures it.</li>
 *   <li>Normal mode waits for the weapon cooldown; HvH mode hits every tick.</li>
 * </ul>
 * All profiles except None / Silent / Smooth / HvH are heuristics (smoothing, GCD snapping, aim gating);
 * they have not been checked against any particular server's anti-cheat.
 */
public class KillAuraModule extends Module {
    private static final int NONE = 1, SILENT = 2, SMOOTH = 3, NEURO = 4, VODKA = 5, HVH = 6,
            BEZIER = 7, SPRING = 8, FOCUS = 9, SNAP = 10, GRIM = 11, MATRIX = 12;

    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    public final NumberSetting rotation = add(new NumberSetting("Rotation", 2, 1, 12, 1)
            .labels("None", "Silent", "Smooth", "Neuro", "VodkaCraft", "HvH", "Bezier", "Spring", "Focus", "Snap", "Grim", "Matrix"));
    /** Where Bezier / Spring / Focus / Snap aim inside the hitbox. */
    public final NumberSetting aimPoint = add(new NumberSetting("Aim point", 4, 1, 5, 1)
            .labels("Center", "Chest", "Head", "Nearest", "Wander"));
    /** Bezier / Spring / Focus: hit only while the look ray really crosses the target's hitbox. */
    public final BoolSetting hitCheck = add(new BoolSetting("Hit check", true));
    /** Max degrees per tick for Smooth / Neuro / VodkaCraft. */
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));
    /**
     * Off (default): your camera never moves. Every rotation mode aims on the server side only (the server and
     * other players see the aim). On: your own camera turns too, as the Smooth / Neuro / Bezier / Spring modes always did.
     */
    public final BoolSetting visualCamera = add(new BoolSetting("Visual camera", false));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    /** Server-side rotation held by VodkaCraft / HvH while a target exists. */
    private boolean srvActive;
    private float srvYaw, srvPitch;
    /** Neuro: aim point offset inside the hitbox, re-rolled every few ticks. */
    private LivingEntity aimTarget;
    private Vec3d aimOffset = Vec3d.ZERO;
    private int aimTicks;
    /** Bezier: size of the turn when it started, and which side the arc bends to. */
    private float bzStart, bzSign = 1f;
    /** Spring: angular velocity in degrees per tick. */
    private float velYaw, velPitch;
    /** Matrix: ticks the aim rests for (a hand does not move every tick), and this hit's cooldown threshold. */
    private int mxPause;
    private float matrixNeed = 0.95f;

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    /** The entity KillAura is aiming at right now (null when there is none). */
    LivingEntity currentTarget() { return aimTarget; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator()) {
            release(c, p);
            return;
        }

        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            if (reach(p, le) <= rangeFor()) list.add(le);
        }
        if (list.isEmpty()) {
            release(c, p);
            aimTarget = null;
            return;
        }

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(e -> reach(p, e)));

        int mode = (int) rotation.get();
        LivingEntity primary = list.get(0);
        if (primary != aimTarget) {
            aimTarget = primary; aimTicks = 0;
            bzStart = 0; velYaw = velPitch = 0;
            bzSign = ThreadLocalRandom.current().nextBoolean() ? 1f : -1f;
        }
        // Camera modes with Visual camera off: run them on a hidden "server view" so your real camera stays put.
        boolean srvCam = !visualCamera.get() && (mode == SMOOTH || mode == NEURO || mode == BEZIER || mode == SPRING);
        if (mode != VODKA && mode != HVH && mode != FOCUS && mode != GRIM && mode != MATRIX && !srvCam) release(c, p);

        float realYaw = 0f, realPitch = 0f;
        if (srvCam) {
            if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
            realYaw = p.getYaw(); realPitch = p.getPitch();
            p.setYaw(srvYaw); p.setPitch(srvPitch);                      // the mode below turns this view, not yours
        }

        boolean aligned = true;
        switch (mode) {
            case SMOOTH -> turnToward(p, primary);
            case NEURO -> aligned = neuro(c, p, primary);
            case VODKA -> aligned = vodka(c, p, primary);
            case HVH -> hvhLock(c, p, primary);
            case BEZIER -> aligned = bezier(p, primary);
            case SPRING -> aligned = spring(p, primary);
            case FOCUS -> aligned = focus(c, p, primary);
            case GRIM -> aligned = grim(c, p, primary);
            case MATRIX -> aligned = matrix(c, p, primary);
            default -> {}
        }
        if (srvCam) {
            srvYaw = p.getYaw(); srvPitch = p.getPitch();
            p.setYaw(realYaw); p.setPitch(realPitch);                    // your camera goes back untouched
            sendLook(c, p, srvYaw, srvPitch);
        }

        float need = hvh.get() ? 0f : (float) cooldown.get();
        if (mode == GRIM) {
            need = Math.max(need, 0.95f);                                   // full cooldown, like a player who waits for it
            if (p.isUsingItem() || p.isBlocking()) return;                  // no hits while eating / blocking
        } else if (mode == MATRIX) {
            need = Math.max(need, matrixNeed);                              // the cooldown threshold differs from hit to hit
            if (p.isUsingItem() || p.isBlocking() || !p.canSee(primary)) return;   // no hits while eating / blocking / through walls
        }
        if (!aligned || p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        if (mode == NEURO || mode == VODKA || mode == BEZIER || mode == SPRING || mode == FOCUS || mode == GRIM || mode == MATRIX) count = 1;   // one aim point at a time
        for (int i = 0; i < count; i++) {
            LivingEntity t = list.get(i);
            if (mode == SILENT || (mode == HVH && i > 0)) {
                sendLook(c, p, wantYaw(p, t), wantPitch(p, t));   // server sees the aim for this hit
            } else if (mode == SNAP) {
                float[] r = snapRotation(c, p, t);
                sendLook(c, p, r[0], r[1]);
            }
            c.interactionManager.attackEntity(p, t);
        }
        if (mode == MATRIX) matrixNeed = 0.93f + ThreadLocalRandom.current().nextFloat() * 0.07f;
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        if (mode == SILENT || mode == SNAP) sendLook(c, p, p.getYaw(), p.getPitch());                   // back to the real view
        else if (mode == HVH && count > 1) sendLook(c, p, srvYaw, srvPitch);            // back to the lock
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        release(c, c.player);
        aimTarget = null;
    }

    /** Ends a held server-side rotation by telling the server the real view again. */
    private void release(MinecraftClient c, ClientPlayerEntity p) {
        if (!srvActive) return;
        srvActive = false;
        if (p != null) sendLook(c, p, p.getYaw(), p.getPitch());
    }

    // ---- rotation profiles ----

    /** Camera rotation: speed eases with the remaining angle, aim point wanders inside the hitbox, deltas sit on the mouse grid. */
    private boolean neuro(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (aimTicks-- <= 0) {
            Box b = t.getBoundingBox();
            aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                    (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                    r.nextDouble(-0.25, 0.25) * b.getLengthZ());
            aimTicks = r.nextInt(5, 11);
        }
        float[] want = Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter().add(aimOffset));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float gcd = gcd(c);
        float max = (float) turnSpeed.get();
        p.setYaw(p.getYaw() + snap(humanStep(dy, max, r), gcd));
        p.setPitch(MathHelper.clamp(p.getPitch() + snap(humanStep(dp, max * 0.6f, r), gcd), -90f, 90f));
        return Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw())) <= 20f && Math.abs(want[1] - p.getPitch()) <= 20f;
    }

    /** Server-side rotation: held between ticks, advanced by a limited, slightly randomized step on the mouse grid. */
    private boolean vodka(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d point = new Vec3d(b.getCenter().x, b.minY + b.getLengthY() * 0.7 + r.nextDouble(-0.03, 0.03), b.getCenter().z);
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float gcd = gcd(c);
        float max = (float) turnSpeed.get();
        srvYaw += snap(MathHelper.clamp(dy, -max, max) * (float) r.nextDouble(0.85, 1.0), gcd);
        srvPitch = MathHelper.clamp(srvPitch + snap(MathHelper.clamp(dp, -max * 0.5f, max * 0.5f) * (float) r.nextDouble(0.85, 1.0), gcd), -90f, 90f);
        sendLook(c, p, srvYaw, srvPitch);
        return Math.abs(MathHelper.wrapDegrees(want[0] - srvYaw)) <= 12f && Math.abs(want[1] - srvPitch) <= 12f;
    }

    /** Server-side rotation: snaps onto the hitbox center every tick and stays there. */
    private void hvhLock(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        srvActive = true;
        srvYaw = wantYaw(p, t);
        srvPitch = wantPitch(p, t);
        sendLook(c, p, srvYaw, srvPitch);
    }

    /** Fast when far, slow when close, never overshoots. */
    private static float humanStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.min(max, mag * 0.45f + 0.8f) * (float) r.nextDouble(0.85, 1.15);
        return Math.copySign(Math.min(step, mag), diff);
    }

    /** Smallest rotation the mouse can produce at the current sensitivity (degrees per mouse count). */
    private static float gcd(MinecraftClient c) {
        double f = c.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    private static float snap(float delta, float gcd) {
        return Math.round(delta / gcd) * gcd;
    }


    // ---- Grim profile ----

    /** Reach used to pick targets: Grim measures 3.0 to the hitbox and allows little slack, so this profile stays under it. */
    private double rangeFor() {
        int m = (int) rotation.get();
        return m == GRIM || m == MATRIX ? Math.min(range.get(), 2.95) : range.get();
    }

    /**
     * Grim profile: the aim is held on the server side, and every angle sent sits exactly on the mouse-sensitivity
     * grid relative to the last one (so the changes look like real mouse counts). Steps are limited and a little random,
     * a look packet identical to the previous one is never sent (a real client does not repeat one), the aim point is
     * inside the hitbox (not on its edge), and the hit goes out only when the look ray the server knows crosses the
     * hitbox shrunk by 0.03 within 2.95 blocks. No hit while eating or blocking, full weapon cooldown, one target.
     * This follows what is publicly known about Grim's aim and reach checks; it has not been tested against Grim.
     */
    private boolean grim(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d point = new Vec3d(b.getCenter().x + r.nextDouble(-0.12, 0.12) * b.getLengthX(),
                b.minY + b.getLengthY() * (0.62 + r.nextDouble(-0.08, 0.08)),
                b.getCenter().z + r.nextDouble(-0.12, 0.12) * b.getLengthZ());
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float max = (float) turnSpeed.get();
        float gcd = gcd(c);
        float ny = srvYaw + snap(focusStep(dy, max, r), gcd);
        float np = MathHelper.clamp(srvPitch + snap(focusStep(dp, max * 0.6f, r), gcd), -90f, 90f);
        if (ny != srvYaw || np != srvPitch) {                                // never repeat an identical look packet
            srvYaw = ny;
            srvPitch = np;
            sendLook(c, p, srvYaw, srvPitch);
        } else {
            ServerRotation.set(srvYaw, srvPitch, 400);
        }
        return Rotations.rayHits(p.getEyePos(), srvYaw, srvPitch, b.contract(0.03), 2.95, 0.0);
    }

    // ---- Matrix profile ----

    /**
     * Matrix profile: a held server-side aim made to look like a hand on a mouse rather than a lock. The aim point
     * wanders inside the upper body; the turn is fast when far and slow when close (never more than 20 degrees a tick);
     * steps are on the sensitivity grid and never identical packets; every few ticks the aim rests for a moment, and when
     * it is on target the pitch is nudged by one grid step now and then, so it never sits at a constant angle. The hit
     * waits for the look ray to cross the hitbox within 2.95 blocks, needs a clear line of sight, uses a cooldown
     * threshold that changes from hit to hit (0.93-1.0, so the gaps between hits are not even), and is never sent while
     * eating or blocking. Built from the usual aim / reach / click-pattern checks of such anti-cheats; not tested against Matrix.
     */
    private boolean matrix(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); mxPause = 0; aimTicks = 0; }
        Box b = t.getBoundingBox();
        if (aimTicks-- <= 0) {                                                 // the aim point drifts inside the upper body
            aimOffset = new Vec3d(r.nextDouble(-0.18, 0.18) * b.getLengthX(),
                    (r.nextDouble(-0.02, 0.2)) * b.getLengthY(),
                    r.nextDouble(-0.18, 0.18) * b.getLengthZ());
            aimTicks = r.nextInt(4, 10);
        }
        float[] want = Util.rotationsTo(p.getEyePos(), b.getCenter().add(aimOffset));
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float dist = (float) Math.sqrt(dy * dy + dp * dp);
        float gcd = gcd(c);

        if (mxPause > 0) {
            mxPause--;
        } else {
            if (dist < 6f && r.nextInt(8) == 0) mxPause = r.nextInt(1, 3);
            float max = Math.min((float) turnSpeed.get(), 20f);
            float ny = srvYaw + snap(humanStep(dy, max, r), gcd);
            float np = srvPitch + snap(humanStep(dp, max * 0.5f, r), gcd);
            if (dist < 2f && r.nextInt(4) == 0) np += (r.nextBoolean() ? 1 : -1) * gcd;     // never a constant angle
            np = MathHelper.clamp(np, -90f, 90f);
            if (ny != srvYaw || np != srvPitch) {                                // never repeat an identical look packet
                srvYaw = ny;
                srvPitch = np;
                sendLook(c, p, srvYaw, srvPitch);
            }
        }
        ServerRotation.set(srvYaw, srvPitch, 400);
        return Rotations.rayHits(p.getEyePos(), srvYaw, srvPitch, b.contract(0.02), 2.95, 0.0);
    }

    // ---- aim point + new profiles ----

    /** Aim point inside the target's hitbox for the profiles that honour the "Aim point" setting. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t, float fromYaw, float fromPitch) {
        Box b = t.getBoundingBox();
        Vec3d c = b.getCenter();
        double h = b.getLengthY();
        switch ((int) aimPoint.get()) {
            case 2: return new Vec3d(c.x, b.minY + h * 0.65, c.z);
            case 3: return new Vec3d(c.x, b.minY + h * 0.90, c.z);
            case 4: return Rotations.nearestPoint(p.getEyePos(), fromYaw, fromPitch, b);
            case 5: {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                if (aimTicks-- <= 0) {
                    aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                            (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                            r.nextDouble(-0.25, 0.25) * b.getLengthZ());
                    aimTicks = r.nextInt(5, 11);
                }
                return c.add(aimOffset);
            }
            default: return c;
        }
    }

    /** "Aligned" for the new profiles: the look ray really hits the hitbox, or (Hit check off) the error is small. */
    private boolean aligned(ClientPlayerEntity p, LivingEntity t, float yaw, float pitch, float[] want, float tolerance) {
        if (hitCheck.get()) return Rotations.rayHits(p.getEyePos(), yaw, pitch, t.getBoundingBox(), range.get() + 0.1, 0.0);
        return Math.abs(MathHelper.wrapDegrees(want[0] - yaw)) <= tolerance && Math.abs(want[1] - pitch) <= tolerance;
    }

    /**
     * Camera rotation along a curve: starts slow, is fastest in the middle, slows down on arrival, and the
     * path bends slightly sideways in between (a hand does not move in a straight line). Close to the
     * target it only follows, with a little lag.
     */
    private boolean bezier(ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float dist = (float) Math.sqrt(dy * dy + dp * dp);
        if (dist > bzStart) bzStart = dist;
        if (dist > 0.01f) {
            float progress = bzStart > 1f ? MathHelper.clamp(1f - dist / bzStart, 0f, 1f) : 1f;
            float bell = (float) Math.sin(Math.PI * progress);                 // 0 at both ends, 1 in the middle
            float max = (float) turnSpeed.get() * (0.3f + 0.7f * bell) * (float) r.nextDouble(0.9, 1.1);
            float step = Math.min(dist, Math.min(dist * 0.6f + 0.5f, max));
            float k = step / dist;
            float arc = step * 0.25f * bell * bzSign;                          // sideways push, vanishes on arrival
            float gcd = gcd(MinecraftClient.getInstance());
            p.setYaw(p.getYaw() + snap(dy * k - dp / dist * arc, gcd));
            p.setPitch(MathHelper.clamp(p.getPitch() + snap(dp * k + dy / dist * arc, gcd), -90f, 90f));
        }
        return aligned(p, t, p.getYaw(), p.getPitch(), want, 15f);
    }

    /** Camera rotation with inertia: accelerates toward the target, overshoots a hair and settles. */
    private boolean spring(ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float max = (float) turnSpeed.get();
        velYaw = MathHelper.clamp((velYaw + dy * 0.14f) * 0.62f * (float) r.nextDouble(0.95, 1.05), -max, max);
        velPitch = MathHelper.clamp((velPitch + dp * 0.14f) * 0.62f * (float) r.nextDouble(0.95, 1.05), -max * 0.6f, max * 0.6f);
        float gcd = gcd(MinecraftClient.getInstance());
        p.setYaw(p.getYaw() + snap(velYaw, gcd));
        p.setPitch(MathHelper.clamp(p.getPitch() + snap(velPitch, gcd), -90f, 90f));
        return aligned(p, t, p.getYaw(), p.getPitch(), want, 15f);
    }

    /**
     * Server-side rotation, held between ticks: each tick closes a fraction of the remaining angle (never
     * less than a small floor so it does not crawl), on the mouse grid. The hit only goes out while the
     * server-side look ray crosses the hitbox.
     */
    private boolean focus(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, srvYaw, srvPitch));
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float max = (float) turnSpeed.get();
        float gcd = gcd(c);
        srvYaw += snap(focusStep(dy, max, r), gcd);
        srvPitch = MathHelper.clamp(srvPitch + snap(focusStep(dp, max * 0.6f, r), gcd), -90f, 90f);
        sendLook(c, p, srvYaw, srvPitch);
        return aligned(p, t, srvYaw, srvPitch, want, 12f);
    }

    private static float focusStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.max(mag * 0.55f, 0.6f) * (float) r.nextDouble(0.92, 1.08);
        return Math.copySign(Math.min(Math.min(step, max), mag), diff);
    }

    /** Snap: one turn to the aim point, quantized to the mouse grid relative to the real view. */
    private float[] snapRotation(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float gcd = gcd(c);
        float yaw = p.getYaw() + snap(MathHelper.wrapDegrees(want[0] - p.getYaw()), gcd);
        float pitch = MathHelper.clamp(p.getPitch() + snap(want[1] - p.getPitch(), gcd), -90f, 90f);
        return new float[]{yaw, pitch};
    }

    // ---- geometry / packets ----

    /** Distance from the player's eyes to the nearest point of the target's hitbox. */
    private static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static float wantYaw(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[0];
    }

    private static float wantPitch(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[1];
    }

    private void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        ServerRotation.set(yaw, MathHelper.clamp(pitch, -90f, 90f), 400);   // third-person model shows the aim
        // Visual camera: the local view turns to the same angles the server is told, so you see the aim too.
        if (visualCamera.get()) {
            p.setYaw(yaw);
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        }
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }

    /** Smooth mode: turns the camera at most turnSpeed degrees this tick, the shorter way around. */
    private void turnToward(ClientPlayerEntity p, LivingEntity target) {
        float step = (float) turnSpeed.get();
        float yawDiff = MathHelper.wrapDegrees(wantYaw(p, target) - p.getYaw());
        float pitchDiff = MathHelper.wrapDegrees(wantPitch(p, target) - p.getPitch());
        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }
}
