package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Scaffold: places blocks under you while you walk, in four styles.
 *
 * Safe: you stop at the edge (the module holds sneak there) and the next block is placed ahead, so you can not fall.
 * God: fast bridging; blocks are placed two ahead against the side faces of the last block, no sneaking.
 * Telly: you sprint-jump along the bridge (the module jumps for you); the block under you is placed once you have been
 * in the air for "Telly ticks" ticks, so the view only has to turn at the very end of every jump.
 * Fast Telly: the same, but placing from the first tick in the air, one block ahead and two blocks per tick.
 *
 * Every block is placed with a click on a solid neighbour (see BlockPlace), after turning toward it (Rotation:
 * None / Silent / Camera, see AuraRotation). Not checked against any server's anti-cheat.
 */
public class ScaffoldModule extends Module {
    private static final int SAFE = 1, GOD = 2, TELLY = 3, FAST = 4;

    public final NumberSetting mode = add(new NumberSetting("Mode", TELLY, 1, 4, 1).labels("Safe", "God", "Telly", "Fast Telly"));
    public final NumberSetting rotation = add(AuraRotation.setting());
    /** How many blocks ahead of you the bridge is also filled (the modes raise it to their own minimum). */
    public final NumberSetting extend = add(new NumberSetting("Extend", 0, 0, 3, 1));
    public final NumberSetting perTick = add(new NumberSetting("Blocks per tick", 1, 1, 3, 1));
    public final NumberSetting delay = add(new NumberSetting("Delay", 0, 0, 4, 1));
    /** Telly: ticks in the air before the block under you is placed. */
    public final NumberSetting tellyTicks = add(new NumberSetting("Telly ticks", 3, 1, 6, 1));
    /** Telly modes: jump by itself while you move forward. */
    public final BoolSetting autoJump = add(new BoolSetting("Auto jump", true));
    /** Telly modes: keep sprinting while you move forward. */
    public final BoolSetting sprint = add(new BoolSetting("Sprint", true));
    /** Safe mode: hold sneak at the edge. */
    public final BoolSetting edgeSneak = add(new BoolSetting("Edge sneak", true));
    /** Telly modes: build at the height you left the ground, not where the jump has taken you. */
    public final BoolSetting keepY = add(new BoolSetting("Keep Y", true));
    /** Standing still and holding jump builds a tower under you. */
    public final BoolSetting tower = add(new BoolSetting("Tower", true));
    public final BoolSetting onlyMoving = add(new BoolSetting("Only when moving", false));
    public final BoolSetting autoSwitch = add(new BoolSetting("Auto switch", true));
    public final BoolSetting strongest = add(new BoolSetting("Strongest blocks first", false));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));

    private int offGround, bridgeY, cooldown, idle, savedSlot = -1;
    private boolean sneakOwned, jumpOwned, sprintOwned;

    public ScaffoldModule() { super("Scaffold", Category.MOVEMENT); }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        releaseKeys(c);
        if (c.player != null) restore(c.player);
    }

    private void releaseKeys(MinecraftClient c) {
        if (c.options == null) return;
        if (sneakOwned) { c.options.sneakKey.setPressed(false); sneakOwned = false; }
        if (jumpOwned) { c.options.jumpKey.setPressed(false); jumpOwned = false; }
        if (sprintOwned) { c.options.sprintKey.setPressed(false); sprintOwned = false; }
    }

    private void restore(ClientPlayerEntity p) {
        if (savedSlot != -1 && restoreSlot.get()) p.getInventory().setSelectedSlot(savedSlot);
        savedSlot = -1;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null) return;
        if (c.currentScreen != null) { releaseKeys(c); return; }

        int mode = (int) this.mode.get();
        boolean telly = mode == TELLY || mode == FAST;
        boolean fwd = c.options.forwardKey.isPressed(), back = c.options.backKey.isPressed();
        boolean left = c.options.leftKey.isPressed(), right = c.options.rightKey.isPressed();
        boolean moving = fwd || back || left || right;
        boolean towering = tower.get() && c.options.jumpKey.isPressed() && !moving && !jumpOwned;
        if (onlyMoving.get() && !moving && !towering) { releaseKeys(c); return; }

        if (p.isOnGround()) { offGround = 0; bridgeY = (int) Math.floor(p.getY()) - 1; } else offGround++;

        Vec3d dir = moveDirection(p, fwd, back, left, right);
        updateKeys(c, p, mode, telly, fwd, moving, dir);

        if (cooldown > 0) { cooldown--; return; }
        boolean allowed = switch (mode) {
            case TELLY -> offGround >= (int) tellyTicks.get();
            case FAST -> offGround >= 1;
            default -> true;
        };
        if (towering) allowed = true;
        if (!allowed) { idleTick(p); return; }

        int ext = towering ? 0 : switch (mode) {
            case SAFE -> Math.max(1, (int) extend.get());
            case GOD -> Math.max(2, (int) extend.get());
            case FAST -> Math.max(1, (int) extend.get());
            default -> (int) extend.get();
        };
        int count = mode == FAST ? Math.max(2, (int) perTick.get()) : (int) perTick.get();
        boolean keepHeight = keepY.get() && telly && !towering;
        int uy = keepHeight ? bridgeY : (int) Math.floor(p.getY()) - 1;

        Set<BlockPos> targets = new LinkedHashSet<>();
        for (int k = 0; k <= ext; k++) targets.add(BlockPos.ofFloored(p.getX() + dir.x * k, uy, p.getZ() + dir.z * k));

        Vec3d eye = p.getEyePos();
        int placed = 0;
        for (BlockPos t : targets) {
            if (placed >= count) break;
            if (!c.world.getBlockState(t).isReplaceable()) continue;
            BlockPlace.Support sup = BlockPlace.findSupport(c, eye, t, mode == GOD);
            if (sup == null) continue;
            int slot = autoSwitch.get() ? BlockPlace.pickSlot(p, strongest.get()) : BlockPlace.heldSlot(p);
            if (slot < 0) break;                                         // no usable block in the hotbar
            int cur = p.getInventory().getSelectedSlot();
            if (slot != cur) {
                if (savedSlot == -1) savedSlot = cur;
                p.getInventory().setSelectedSlot(slot);
            }
            int rot = (int) rotation.get();
            AuraRotation.face(c, p, sup.hit(), rot);
            c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(sup.hit(), sup.face(), sup.pos(), false));
            if (swing.get()) p.swingHand(Hand.MAIN_HAND);
            AuraRotation.restore(c, p, rot);
            placed++;
        }
        if (placed > 0) { idle = 0; cooldown = mode == FAST ? 0 : (int) delay.get(); }
        else idleTick(p);
    }

    /** Nothing placed this tick: after a short while give the hotbar slot back. */
    private void idleTick(ClientPlayerEntity p) {
        if (++idle >= 10) { restore(p); idle = 0; }
    }

    /** Horizontal unit vector you are heading in: from the keys, else from your speed, else where you look. */
    private Vec3d moveDirection(ClientPlayerEntity p, boolean fwd, boolean back, boolean left, boolean right) {
        double yr = Math.toRadians(p.getYaw());
        double f = (fwd ? 1 : 0) - (back ? 1 : 0), s = (left ? 1 : 0) - (right ? 1 : 0);
        double dx = -Math.sin(yr) * f + Math.cos(yr) * s, dz = Math.cos(yr) * f + Math.sin(yr) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1e-6) {
            Vec3d v = p.getVelocity();
            dx = v.x; dz = v.z;
            len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.03) { dx = -Math.sin(yr); dz = Math.cos(yr); len = 1; }
        }
        return new Vec3d(dx / len, 0, dz / len);
    }

    /** Sneak at the edge (Safe), jump and sprint along the bridge (Telly). Only keys this module pressed are released. */
    private void updateKeys(MinecraftClient c, ClientPlayerEntity p, int mode, boolean telly, boolean fwd, boolean moving, Vec3d dir) {
        boolean wantSneak = false;
        if (mode == SAFE && edgeSneak.get() && p.isOnGround() && moving) {
            Vec3d ahead = new Vec3d(p.getX(), p.getY(), p.getZ()).add(dir.x * 0.45, 0, dir.z * 0.45);
            BlockPos under = BlockPos.ofFloored(ahead.x, p.getY() - 0.5, ahead.z);
            wantSneak = !c.world.getBlockState(under).isSolidBlock(c.world, under);
        }
        if (wantSneak != sneakOwned) { c.options.sneakKey.setPressed(wantSneak); sneakOwned = wantSneak; }

        boolean wantJump = telly && autoJump.get() && fwd && p.isOnGround();
        if (wantJump != jumpOwned) { c.options.jumpKey.setPressed(wantJump); jumpOwned = wantJump; }

        boolean wantSprint = telly && sprint.get() && fwd;
        if (wantSprint != sprintOwned) { c.options.sprintKey.setPressed(wantSprint); sprintOwned = wantSprint; }
    }
}
