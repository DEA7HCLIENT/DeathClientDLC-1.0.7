package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Your own font file. The game loads fonts from resource packs only, so this writes a small resource pack,
 * resourcepacks/DeathClientDLC Font, that replaces the "Custom" font (assets/deathclientdlc/font/ui_custom.json) with your
 * .ttf / .otf, turns the pack on and reloads the resources (a couple of seconds). The file needs the letters you use
 * (Latin and Cyrillic, say). Fonts of the pack stay after a restart; "reset" turns the pack off again.
 */
final class CustomFontPack {
    static final String NAME = "DeathClientDLC Font";
    private static final String ID = "file/" + NAME;

    private CustomFontPack() {}

    static boolean isFontFile(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.endsWith(".ttf") || n.endsWith(".otf");
    }

    private static Path packDir() { return FabricLoader.getInstance().getGameDir().resolve("resourcepacks").resolve(NAME); }

    /** Writes the pack with this font, enables it, reloads and selects the Custom font. Call on the client thread. */
    static void installAndUse(MinecraftClient c, Path font) throws IOException {
        if (!Files.isRegularFile(font) || !isFontFile(font)) throw new IOException("not a .ttf / .otf file");
        Path dir = packDir(), fonts = dir.resolve("assets/deathclientdlc/font");
        Files.createDirectories(fonts);
        Files.writeString(dir.resolve("pack.mcmeta"),
                "{\"pack\":{\"description\":\"DeathClientDLC custom font\",\"pack_format\":34,"
                        + "\"supported_formats\":{\"min_inclusive\":34,\"max_inclusive\":99},\"min_format\":34,\"max_format\":99}}",
                StandardCharsets.UTF_8);
        Files.copy(font, fonts.resolve("ui_custom.ttf"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        Files.writeString(fonts.resolve("ui_custom.json"),
                "{\"providers\":[{\"type\":\"ttf\",\"file\":\"deathclientdlc:ui_custom.ttf\",\"shift\":[0.0,0.0],\"size\":9.0,\"oversample\":8.0}]}",
                StandardCharsets.UTF_8);

        CustomFontModule m = ModuleManager.get(CustomFontModule.class);
        if (m != null) {
            m.font.set(5);
            if (!m.isEnabled()) m.toggle();
        }
        var packs = c.getResourcePackManager();
        packs.scanPacks();
        if (packs.getEnabledIds().contains(ID)) {
            c.reloadResources();                                  // the pack was already on: just re-read the new file
        } else {
            packs.enable(ID);
            c.options.refreshResourcePacks(packs);                // saves the list and reloads the resources
        }
    }

    /** Turns the pack off, goes back to the Default font and removes the pack folder. */
    static void reset(MinecraftClient c) {
        CustomFontModule m = ModuleManager.get(CustomFontModule.class);
        if (m != null) m.font.set(1);
        var packs = c.getResourcePackManager();
        packs.scanPacks();
        if (packs.getEnabledIds().contains(ID)) {
            packs.disable(ID);
            c.options.refreshResourcePacks(packs);
        }
        try (Stream<Path> files = Files.walk(packDir())) {
            files.sorted(java.util.Comparator.reverseOrder()).forEach(p -> { try { Files.deleteIfExists(p); } catch (IOException ignored) {} });
        } catch (IOException ignored) {}
    }
}
