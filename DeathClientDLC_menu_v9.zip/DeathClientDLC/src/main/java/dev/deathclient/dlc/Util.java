package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

final class Util {
    private Util() {}

    static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }

    /** Normalized horizontal movement direction from WASD and yaw; zero vector if no input. */
    static Vec3d inputDir(MinecraftClient c, ClientPlayerEntity p) {
        GameOptions o = c.options;
        int f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        int s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return Vec3d.ZERO;
        double yaw = Math.toRadians(p.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new Vec3d(x / len, 0, z / len);
    }

    /** {yaw, pitch} that make a camera at eye look at point. */
    static float[] rotationsTo(Vec3d eye, Vec3d point) {
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return new float[]{yaw, Math.max(-90f, Math.min(90f, pitch))};
    }

    static PlayerEntity nearestPlayer(MinecraftClient c, double range) {
        PlayerEntity best = null;
        double bestD = range;
        for (PlayerEntity other : c.world.getPlayers()) {
            if (other == c.player || !other.isAlive() || other.isSpectator() || Friends.skip(other)) continue;
            double d = c.player.distanceTo(other);
            if (d <= bestD) { bestD = d; best = other; }
        }
        return best;
    }

    /** Hotbar slot (0-8) holding the item, or -1. */
    static int findHotbar(PlayerEntity p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    /** Distance from the player's eyes to the nearest point of the entity's hitbox (how the server measures reach). */
    static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
