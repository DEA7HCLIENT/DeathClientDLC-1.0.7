package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

/**
 * Unhook: switches every module off, hides the client overlays and stops reacting to the menu key, module binds
 * and chat commands, until the Unhook key (default END; ".bind unhook <key>" changes it) or ".unhook" is used
 * again. The modules that were on come back on then, settings intact. While unhooked the saved on/off state
 * is not overwritten.
 */
final class Unhook {
    private static boolean active;
    private static boolean hudWasHidden;
    private static final List<Module> RESTORE = new ArrayList<>();

    private Unhook() {}

    static boolean active() { return active; }

    static void toggle(MinecraftClient c) {
        if (active) rehook(c); else unhook(c);
    }

    static void unhook(MinecraftClient c) {
        if (active) return;
        Config.autosaveNow();                       // store the current state first, then ignore saves while unhooked
        RESTORE.clear();
        for (Module m : ModuleManager.all()) {
            if (!m.isEnabled()) continue;
            RESTORE.add(m);
            m.toggle();
        }
        hudWasHidden = Hud.hidden;
        Hud.hidden = true;
        active = true;
        if (GuiStyleModule.isClickGui(c.currentScreen)) c.setScreen(null);
    }

    static void rehook(MinecraftClient c) {
        if (!active) return;
        active = false;
        for (Module m : RESTORE) if (!m.isEnabled()) m.toggle();
        RESTORE.clear();
        Hud.hidden = hudWasHidden;
    }
}
