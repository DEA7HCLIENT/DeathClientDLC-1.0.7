package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

/**
 * Account switcher for offline-mode (no licence check) servers: swaps the client session to an offline one
 * with the chosen nickname. Does not work on online-mode servers. The original session can be restored.
 */
final class Accounts {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/accounts.properties");
    private static final List<String> NAMES = new ArrayList<>();
    private static boolean loaded;
    private static Object original;
    private static String originalName = "";
    private static boolean usingOriginal = true;

    private Accounts() {}

    static List<String> list() {
        ensure();
        return NAMES;
    }

    static boolean valid(String n) { return n != null && n.matches("[A-Za-z0-9_]{3,16}"); }

    static boolean add(String n) {
        ensure();
        if (!valid(n) || NAMES.contains(n)) return false;
        NAMES.add(n);
        save();
        return true;
    }

    static void remove(String n) {
        ensure();
        NAMES.remove(n);
        save();
    }

    /** Nickname of the session that is active right now. */
    static String currentName() {
        captureOriginal();
        return MinecraftClient.getInstance().getSession().getUsername();
    }

    static boolean usingOriginal() { return usingOriginal; }

    static String originalName() {
        captureOriginal();
        return originalName;
    }

    private static void captureOriginal() {
        if (original != null) return;
        var s = MinecraftClient.getInstance().getSession();
        original = s;
        originalName = s.getUsername();
    }

    static void switchTo(String name) throws Exception {
        captureOriginal();
        Object current = MinecraftClient.getInstance().getSession();
        Object ns = newSession(current.getClass(), name);
        setSession(ns);
        usingOriginal = false;
    }

    static void restoreOriginal() throws Exception {
        captureOriginal();
        setSession(original);
        usingOriginal = true;
    }

    private static void setSession(Object session) throws Exception {
        MinecraftClient mc = MinecraftClient.getInstance();
        Class<?> type = session.getClass();
        for (Field f : MinecraftClient.class.getDeclaredFields()) {
            if (f.getType() != type) continue;
            f.setAccessible(true);
            f.set(mc, session);
            return;
        }
        throw new IllegalStateException("session field not found");
    }

    /** The Session constructor differs between versions, so fill the biggest one by parameter type. */
    private static Object newSession(Class<?> sc, String name) throws Exception {
        UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        Constructor<?> best = null;
        for (Constructor<?> c : sc.getConstructors()) {
            if (best == null || c.getParameterCount() > best.getParameterCount()) best = c;
        }
        if (best == null) throw new IllegalStateException("no session constructor");
        Class<?>[] pt = best.getParameterTypes();
        Object[] args = new Object[pt.length];
        int strings = 0;
        for (int i = 0; i < pt.length; i++) {
            if (pt[i] == String.class) args[i] = strings++ == 0 ? name : "0";
            else if (pt[i] == UUID.class) args[i] = id;
            else if (pt[i] == Optional.class) args[i] = Optional.empty();
            else if (pt[i].isEnum()) {
                Object[] constants = pt[i].getEnumConstants();
                Object pick = constants[0];
                for (Object o : constants) if (o.toString().equals("LEGACY")) pick = o;
                args[i] = pick;
            }
        }
        return best.newInstance(args);
    }

    private static void ensure() {
        if (loaded) return;
        loaded = true;
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (var in = Files.newInputStream(FILE)) { p.load(in); } catch (IOException e) { return; }
        String names = p.getProperty("names", "");
        for (String n : names.split(",")) {
            n = n.trim();
            if (valid(n) && !NAMES.contains(n)) NAMES.add(n);
        }
    }

    private static void save() {
        Properties p = new Properties();
        p.setProperty("names", String.join(",", NAMES));
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) { p.store(out, "DeathClientDLC saved offline nicknames"); }
        } catch (IOException ignored) {}
    }
}
