package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No Render, Enchant glint: items no longer shimmer (only the picture; the enchantments stay). require = 0: skipped if renamed. */
@Mixin(ItemStack.class)
public abstract class ItemStackNoRenderMixin {
    @Inject(method = "hasGlint", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noGlint(CallbackInfoReturnable<Boolean> cir) {
        if (NoRenderModule.glint()) cir.setReturnValue(false);
    }
}
