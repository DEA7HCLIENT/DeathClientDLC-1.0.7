package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Mace Killer: hits the nearest target with the mace while you fall onto it (smash attack).
 * The mace deals extra damage per block fallen, and only counts as a smash after more than 1.5 blocks,
 * so by default it waits for that much fall distance. It switches to the mace in the hotbar by itself.
 */
public class MaceKillerModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    /** Fall distance needed before the hit (vanilla smash starts above 1.5; 0 = hit any time). */
    public final NumberSetting minFall = add(new NumberSetting("Min fall", 1.5, 0.0, 20.0, 0.5));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final BoolSetting autoSwitch = add(new BoolSetting("Auto switch", true));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    public MaceKillerModule() { super("Mace Killer", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator()) return;
        if (p.isOnGround() || p.fallDistance < minFall.get()) return;
        if (p.getAttackCooldownProgress(0.5f) < cooldown.get()) return;

        int prev = p.getInventory().getSelectedSlot();
        int slot = p.getMainHandStack().isOf(Items.MACE) ? prev : (autoSwitch.get() ? Util.findHotbar(p, Items.MACE) : -1);
        if (slot < 0) return;

        LivingEntity target = nearest(c, p);
        if (target == null) return;

        p.getInventory().setSelectedSlot(slot);
        int mode = (int) rotation.get();
        AuraRotation.face(c, p, target.getBoundingBox().getCenter(), mode);
        c.interactionManager.attackEntity(p, target);
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, mode);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
    }

    private LivingEntity nearest(MinecraftClient c, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestD = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            double d = Util.reach(p, le);
            if (d <= bestD) { bestD = d; best = le; }
        }
        return best;
    }
}
