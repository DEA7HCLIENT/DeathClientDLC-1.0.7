package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Air strafe: redirects current horizontal momentum to the input direction. */
public class StrafeModule extends Module {
    public final NumberSetting baseSpeed = add(new NumberSetting("Base speed", 0.28, 0.1, 0.8, 0.01));

    public StrafeModule() { super("Strafe", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.isOnGround()) return;
        Vec3d d = Util.inputDir(c, p);
        if (d.lengthSquared() == 0) return;
        Vec3d v = p.getVelocity();
        double speed = Math.max(Math.sqrt(v.x * v.x + v.z * v.z), baseSpeed.get());
        p.setVelocity(d.x * speed, v.y, d.z * speed);
    }
}
