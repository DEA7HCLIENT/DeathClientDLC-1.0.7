package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render, Fire: the burning overlay is not drawn. No arguments are read, so the hook does not depend on the
 * method's signature. require = 0: if the method is named differently in this build, nothing happens.
 */
@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void deathclientdlc$noFire(CallbackInfo ci) {
        if (NoRenderModule.fire()) ci.cancel();
    }

    /** No Render, Wall overlay: the dark picture when your head is inside a block. */
    @Inject(method = "renderInWallOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void deathclientdlc$noWall(CallbackInfo ci) {
        if (NoRenderModule.wallOverlay()) ci.cancel();
    }

    /** No Render, Water overlay: the blue picture when your head is under water. */
    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void deathclientdlc$noWater(CallbackInfo ci) {
        if (NoRenderModule.waterOverlay()) ci.cancel();
    }
}
