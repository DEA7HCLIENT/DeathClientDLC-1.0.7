package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Velocity fly. As "NoClip Fly" it also passes through walls (see Phase): the floor still holds you up, and when you are
 * inside a block with no up / down key pressed you fall instead of hovering; jump (or sneak) flies you out of it.
 */
public class FlyModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.5, 0.1, 3.0, 0.05));
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.4, 0.1, 2.0, 0.05));
    private final boolean noClip;

    public FlyModule(String name, boolean noClip) {
        super(name, Category.MOVEMENT);
        this.noClip = noClip;
    }

    boolean isNoClip() { return noClip; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Vec3d d = Util.inputDir(c, p);
        int dir = (c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0);
        double vy = dir * vertical.get();
        if (noClip && dir == 0 && Phase.inWall(c, p)) vy = p.getVelocity().y;     // inside a wall: gravity takes over
        p.setVelocity(d.x * speed.get(), vy, d.z * speed.get());
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (noClip && p != null) p.noClip = false;
    }
}
