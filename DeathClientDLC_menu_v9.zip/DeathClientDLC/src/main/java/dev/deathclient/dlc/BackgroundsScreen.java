package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * "Фоны": pick the main-menu background. The list is the built-in picture plus every png / jpg in
 * config/deathclientdlc/backgrounds. Dropping an image onto the window copies it into that folder and uses it.
 */
public class BackgroundsScreen extends Screen {
    private static final int ROW_W = 230, ROW_H = 22, ROW_GAP = 4;
    private static final int BTN = 0xD04A4D5A, BTN_HOVER = 0xE0636674, BTN_LINE = 0x48FFFFFF;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFA9ACB8;

    private final Screen parent;
    private List<Path> files = new ArrayList<>();
    private double scroll;
    private String status = "";
    private long statusUntil;

    public BackgroundsScreen(Screen parent) {
        super(Text.literal("Фоны"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        MenuCustom.ensureLoaded();
        files = MenuCustom.listBackgrounds();
    }

    private int listX() { return (width - ROW_W) / 2; }
    private int listTop() { return 60; }
    private int listBottom() { return height - 40; }
    private int rows() { return files.size() + 1; }          // row 0 = built-in
    private double maxScroll() { return Math.max(0, rows() * (ROW_H + ROW_GAP) - (listBottom() - listTop())); }
    private int backX() { return (width - 100) / 2; }
    private int backY() { return height - 30; }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void setStatus(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (MenuCustom.hasBackground()) MenuCustom.drawBackground(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
        ctx.fill(0, 0, width, height, 0xA0000000);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int acc = Theme.current().accent() | 0xFF000000;
        scroll = Math.max(0, Math.min(scroll, maxScroll()));

        Text title = Fonts.bold("Фоны");
        Fonts.drawScaled(ctx, textRenderer, title, (width - Math.round(textRenderer.getWidth(title) * 1.8f)) / 2f, 14, 1.8f, WHITE);
        String hint = "Папка: config/deathclientdlc/backgrounds  -  или перетащи картинку в окно";
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui(hint), width / 2, 40, MUTED);

        ctx.enableScissor(0, listTop(), width, listBottom());
        for (int r = 0; r < rows(); r++) {
            int y = listTop() + r * (ROW_H + ROW_GAP) - (int) scroll;
            if (y + ROW_H < listTop() || y > listBottom()) continue;
            String label = r == 0 ? "Встроенный фон" : files.get(r - 1).getFileName().toString();
            boolean selected = r == 0 ? !MenuCustom.hasBackground() : files.get(r - 1).getFileName().toString().equals(MenuCustom.bgName());
            boolean hover = in(mx, my, listX(), y, ROW_W, ROW_H) && my >= listTop() && my < listBottom();
            ClickGuiScreen.rrect(ctx, listX() - 1, y - 1, ROW_W + 2, ROW_H + 2, selected ? acc : BTN_LINE, 8);
            ClickGuiScreen.rrect(ctx, listX(), y, ROW_W, ROW_H, hover ? BTN_HOVER : BTN, 7);
            String shown = label;
            while (shown.length() > 3 && Fonts.guiWidth(textRenderer, shown) > ROW_W - 24) shown = shown.substring(0, shown.length() - 1);
            if (!shown.equals(label)) shown += "...";
            ctx.drawTextWithShadow(textRenderer, Fonts.gui(shown), listX() + 10, y + (ROW_H - 8) / 2, WHITE);
            if (selected) ctx.fill(listX() + ROW_W - 14, y + ROW_H / 2 - 1, listX() + ROW_W - 8, y + ROW_H / 2 + 1, WHITE);
        }
        ctx.disableScissor();

        if (files.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui("Своих фонов пока нет"), width / 2, listTop() + ROW_H + 14, MUTED);
        }
        if (System.currentTimeMillis() < statusUntil) {
            ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui(status), width / 2, backY() - 14, 0xFFFFD866);
        }

        boolean bh = in(mx, my, backX(), backY(), 100, 22);
        ClickGuiScreen.rrect(ctx, backX(), backY(), 100, 22, bh ? acc : BTN, 8);
        ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui("Назад"), width / 2, backY() + 7, WHITE);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x(), my = click.y();
            if (in(mx, my, backX(), backY(), 100, 22)) { close(); return true; }
            if (my >= listTop() && my < listBottom()) {
                for (int r = 0; r < rows(); r++) {
                    int y = listTop() + r * (ROW_H + ROW_GAP) - (int) scroll;
                    if (!in(mx, my, listX(), y, ROW_W, ROW_H)) continue;
                    try {
                        if (r == 0) MenuCustom.resetBackground();
                        else MenuCustom.useFile(files.get(r - 1));
                    } catch (Exception e) {
                        setStatus("Не удалось загрузить картинку");
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(scroll - verticalAmount * 18, maxScroll()));
        return true;
    }

    // Dropped images are copied into the backgrounds folder and used right away.
    public void filesDragged(List<Path> paths) { handleDrop(paths); }

    public void onFilesDropped(List<Path> paths) { handleDrop(paths); }

    private void handleDrop(List<Path> paths) {
        if (paths == null || paths.isEmpty()) return;
        try {
            MenuCustom.addAndUse(paths.get(0));
            files = MenuCustom.listBackgrounds();
            setStatus("Фон добавлен");
        } catch (Exception e) {
            setStatus("Не удалось загрузить картинку (нужен png или jpg)");
        }
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
