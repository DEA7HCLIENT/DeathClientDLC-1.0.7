package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** One picture of the user's own (png / jpg copied to config/deathclientdlc/<file>), loaded lazily on the render thread. */
final class UserPicture {
    private final Path file;
    private final Identifier id;
    private boolean loaded, has;
    private int w = 1, h = 1;

    UserPicture(String fileName, String idPath) {
        this.file = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc").resolve(fileName);
        this.id = Identifier.of("deathclientdlc", idPath);
    }

    private void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        if (!Files.exists(file)) return;
        try { show(Files.readAllBytes(file)); } catch (Exception e) { has = false; }
    }

    boolean has() { ensureLoaded(); return has; }

    /** Takes a png / jpg from anywhere on disk and makes it this picture. */
    void set(Path src) throws Exception {
        byte[] png = MenuCustom.toPng(Files.readAllBytes(src));
        Files.createDirectories(file.getParent());
        Files.write(file, png);
        loaded = true;
        show(png);
    }

    void reset() {
        has = false;
        loaded = true;
        try { Files.deleteIfExists(file); } catch (IOException ignored) {}
    }

    private void show(byte[] png) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        int iw = img.getWidth(), ih = img.getHeight();
        AbstractTexture tex = MenuCustom.makeTexture(img);
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
        w = iw;
        h = ih;
        has = true;
    }

    /** The picture cropped to a centred square and drawn size x size at x, y. Does nothing without a picture. */
    void drawSquare(DrawContext ctx, int x, int y, int size, int color) {
        if (!has()) return;
        int side = Math.min(w, h);
        float u = (w - side) / 2f, v = (h - side) / 2f;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, u, v, size, size, side, side, w, h, color);
    }
}
