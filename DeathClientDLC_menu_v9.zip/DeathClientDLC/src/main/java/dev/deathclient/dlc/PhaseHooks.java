package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** Public entry points for PhaseMixin (the mixin package cannot reach the package-private Phase directly). */
public final class PhaseHooks {
    private PhaseHooks() {}

    public static boolean applies(Entity e) { return Phase.applies(e); }

    public static Vec3d clip(Entity e, Vec3d movement) {
        return Phase.applies(e) ? Phase.clip(MinecraftClient.getInstance(), MinecraftClient.getInstance().player, movement) : movement;
    }
}
