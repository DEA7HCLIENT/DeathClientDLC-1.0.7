package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;

/** Panel backgrounds in the shape chosen by the HUD Style module (shared by the HUD panels and the main menu buttons). */
final class Shapes {
    private Shapes() {}

    /** The chosen shape, or ROUNDED when the module is missing or off. */
    static int shape() {
        HudStyleModule m = ModuleManager.get(HudStyleModule.class);
        return m != null && m.isEnabled() ? (int) m.shape.get() : HudStyleModule.ROUNDED;
    }

    static int radius() {
        HudStyleModule m = ModuleManager.get(HudStyleModule.class);
        return m != null && m.isEnabled() ? (int) m.radius.get() : 4;
    }

    static boolean glass(int shape) { return shape == HudStyleModule.GLASS_SQUARE || shape == HudStyleModule.GLASS_ROUNDED; }

    /** Corner radius for this shape (0 for the square ones). */
    static int corner(int shape) {
        return shape == HudStyleModule.SQUARE || shape == HudStyleModule.GLASS_SQUARE ? 0 : radius();
    }

    /** Translucent glass colour: dark base tinted with the theme colour. */
    static int glassFill(float alpha) {
        int rgb = ClickGuiScreen.mix(0xFF141824, Theme.current().accent(), 0.12f) & 0xFFFFFF;
        return (Math.round(0x78 * alpha) << 24) | rgb;
    }

    /** A panel background at x, y, w, h. bg is the flat colour used by the non-glass shapes. */
    static void panel(DrawContext ctx, int x, int y, int w, int h, int bg) {
        int shape = shape(), r = corner(shape);
        if (!glass(shape)) {
            ClickGuiScreen.rrect(ctx, x, y, w, h, bg, r);
            return;
        }
        ClickGuiScreen.rrect(ctx, x - 1, y - 1, w + 2, h + 2, 0x55FFFFFF, r + 1 > 0 ? r + 1 : 0);    // bright rim
        ClickGuiScreen.rrect(ctx, x, y, w, h, glassFill(1f), r);
        ctx.fillGradient(x + r, y + 1, x + w - r, y + Math.max(2, h / 2), 0x30FFFFFF, 0x00FFFFFF);       // sheen
        ctx.fill(x + r, y + 1, x + w - r, y + 2, 0x80FFFFFF);                                            // top highlight
    }

    /** The coloured strip along the bottom edge of a panel. */
    static void bottomStrip(DrawContext ctx, int x, int y, int w, int h, int color) {
        int r = corner(shape());
        if (r == 0) ctx.fill(x, y + h - 2, x + w, y + h, color);
        else ClickGuiScreen.rect(ctx, x, y + h - 2, w, 2, color, false, true);
    }
}
