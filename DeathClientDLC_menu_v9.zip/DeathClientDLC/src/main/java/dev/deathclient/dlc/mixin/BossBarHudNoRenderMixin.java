package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.gui.hud.BossBarHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No Render, Boss bar: the boss health bars at the top of the screen are not drawn. require = 0: skipped if renamed. */
@Mixin(BossBarHud.class)
public abstract class BossBarHudNoRenderMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noBossBar(CallbackInfo ci) {
        if (NoRenderModule.bossBar()) ci.cancel();
    }
}
