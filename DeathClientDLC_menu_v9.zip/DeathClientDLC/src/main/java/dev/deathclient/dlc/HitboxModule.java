package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

/**
 * Hitboxes: makes other entities easier to hit by enlarging the box the crosshair is tested against, from 0 (the
 * default hitbox) up to 100 blocks. Direction: All sides, Sideways only, or Up only.
 *
 * Only the crosshair target is changed (EntityHitboxMixin and GameRendererHitboxMixin switch the bigger box on while
 * the game looks for the entity under the crosshair); movement, collisions, rendering and the server's own idea of
 * the hitbox stay as they are. A server still checks the distance of the hit itself, so a huge hitbox does not
 * make hits land from far away on a server that enforces reach.
 */
public class HitboxModule extends Module {
    /** Extra size in blocks added to the box; 0 = the default hitbox. */
    public final NumberSetting size = add(new NumberSetting("Size", 0.5, 0, 100, 0.1));
    /** Where the box grows. */
    public final NumberSetting direction = add(new NumberSetting("Direction", 1, 1, 3, 1).labels("All", "Sideways", "Up"));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    /** True only while the game is searching for the entity under the crosshair. */
    public static volatile boolean scanning;

    public HitboxModule() { super("Hitboxes", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient client) { scanning = false; }          // safety: never stays on past a tick

    @Override
    protected void onDisable() { scanning = false; }

    /** The box to test the crosshair against: {@code box} made bigger as set. */
    public static Box expand(Entity e, Box box) {
        HitboxModule m = ModuleManager.get(HitboxModule.class);
        if (m == null || !m.isEnabled()) return box;
        double s = m.size.get();
        if (s <= 0) return box;
        MinecraftClient c = MinecraftClient.getInstance();
        if (e == c.player || e == c.getCameraEntity() || !(e instanceof LivingEntity)) return box;
        if (m.playersOnly.get() && !(e instanceof PlayerEntity)) return box;
        return switch ((int) m.direction.get()) {
            case 2 -> box.expand(s, 0, s);          // sideways
            case 3 -> box.stretch(0, s, 0);         // up only
            default -> box.expand(s);               // all sides
        };
    }
}
