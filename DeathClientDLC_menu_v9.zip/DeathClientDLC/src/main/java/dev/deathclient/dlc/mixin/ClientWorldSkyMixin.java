package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.CustomSkyModule;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom Sky: the sky color the world reports (ARGB int). In the optional mixin config: a different method here means no effect. */
@Mixin(ClientWorld.class)
public abstract class ClientWorldSkyMixin {
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$sky(Vec3d cameraPos, float tickProgress, CallbackInfoReturnable<Integer> cir) {
        int rgb = CustomSkyModule.color();
        if (rgb != -1) cir.setReturnValue(0xFF000000 | rgb);
    }
}
