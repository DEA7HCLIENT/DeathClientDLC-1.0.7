package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Elytra Target: while you glide, steers you toward the nearest player in range. The elytra follows where you look,
 * so the module turns your view toward the target and nudges your velocity in that direction. Speed, turn speed
 * and the stop distance are adjustable, so you can keep up with a target without flying into it.
 *
 * Modes: Camera (your view turns smoothly to the target) or Silent (only the server is told the look, your view
 * stays where you put it, and the third-person model shows the aim, like the other auras).
 * It only steers while gliding, so it does nothing while you walk, swim or fly in creative.
 */
public class ElytraTargetModule extends Module {
    private static final int CAMERA = 1, SILENT = 2;

    public final NumberSetting mode = add(new NumberSetting("Mode", CAMERA, 1, 2, 1).labels("Camera", "Silent"));
    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 2));
    /** Blend toward the target direction each tick: higher = steers harder. */
    public final NumberSetting steer = add(new NumberSetting("Steer", 0.12, 0.02, 0.5, 0.01));
    /** Max speed you are pushed at, blocks per tick (gliding speed stays on top of it). */
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.2, 0.2, 3.0, 0.05));
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 14, 2, 60, 1));
    /** Stop pushing once you are this close (blocks), so you do not ram the target. */
    public final NumberSetting stopDistance = add(new NumberSetting("Stop distance", 3.0, 0.5, 20, 0.5));
    /** Aim height on the target: 0 = feet, 1 = eyes. */
    public final NumberSetting aimHeight = add(new NumberSetting("Aim height", 0.7, 0.0, 1.0, 0.05));
    /** Never steer your view below this many blocks above the ground. */
    public final NumberSetting minAltitude = add(new NumberSetting("Min altitude", 6, 0, 40, 1));

    public ElytraTargetModule() { super("Elytra Target", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || !p.isGliding()) return;

        PlayerEntity t = nearest(c, p);
        if (t == null) return;

        Vec3d aim = new Vec3d(t.getX(), t.getY() + t.getHeight() * aimHeight.get(), t.getZ());
        if (p.getY() - groundBelow(c, p) < minAltitude.get()) return;   // too low: keep flying normally

        float[] want = Util.rotationsTo(p.getEyePos(), aim);
        float wantYaw = want[0];
        float wantPitch = MathHelper.clamp(want[1], -90f, 90f);

        // steer the velocity toward the target, but only while outside the stop distance
        double dist = p.distanceTo(t);
        if (dist > stopDistance.get()) {
            Vec3d dir = aim.subtract(p.getPos());
            double len = dir.length();
            if (len > 1e-4) {
                Vec3d v = p.getVelocity();
                double k = steer.get();
                Vec3d want2 = dir.multiply(speed.get() / len);
                p.setVelocity(
                        v.x + (want2.x - v.x) * k,
                        v.y + (want2.y - v.y) * k * 0.5,            // vertical moves gently
                        v.z + (want2.z - v.z) * k);
            }
        }

        if ((int) mode.get() == SILENT) {
            ServerRotation.set(wantYaw, wantPitch, 400);
            if (c.getNetworkHandler() != null) {
                c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                        wantYaw, wantPitch, p.isOnGround(), p.horizontalCollision));
            }
        } else {
            ThreadLocalRandom r = ThreadLocalRandom.current();
            float max = (float) turnSpeed.get();
            float dy = MathHelper.wrapDegrees(wantYaw - p.getYaw());
            float dp = wantPitch - p.getPitch();
            p.setYaw(p.getYaw() + humanStep(dy, max, r));
            p.setPitch(MathHelper.clamp(p.getPitch() + humanStep(dp, max * 0.6f, r), -90f, 90f));
        }
    }

    private PlayerEntity nearest(MinecraftClient c, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestD = range.get();
        for (PlayerEntity other : c.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator() || Friends.skip(other)) continue;
            double d = p.distanceTo(other);
            if (d <= bestD) { bestD = d; best = other; }
        }
        return best;
    }

    /** Y of the first solid block below the player, scanning at most 64 blocks. */
    private static double groundBelow(MinecraftClient c, ClientPlayerEntity p) {
        int x = (int) Math.floor(p.getX()), z = (int) Math.floor(p.getZ());
        for (int y = (int) Math.floor(p.getY()) - 1; y > p.getY() - 64 && y > c.world.getBottomY(); y--) {
            if (!c.world.getBlockState(new BlockPos(x, y, z)).isAir()) return y + 1;
        }
        return p.getY() - 64;
    }

    private static float humanStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.min(max, mag * 0.45f + 0.8f) * (float) r.nextDouble(0.9, 1.1);
        return Math.copySign(Math.min(step, mag), diff);
    }
}
