package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import java.util.ArrayList;
import java.util.List;

/** HUD elements drawn with the glass style. Each one can be dragged in the open chat (HudEdit). */
final class HudExtras {
    private static final String[] COMPASS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
    private static final String[] ARMOR_NAMES = {"Ботинки", "Поножи", "Нагрудник", "Шлем"};
    private static final EquipmentSlot[] ARMOR_SLOTS = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};

    private HudExtras() {}

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (Hud.hidden) return;
        HudExtrasModule m = ModuleManager.get(HudExtrasModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null || c.options.hudHidden) return;
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();

        if (m.watermark.get()) {
            List<String> lines = new ArrayList<>();
            lines.add("Death Client " + version());
            panel(ctx, c, lines, 6, 4, m.wmX, m.wmY, false);
        }
        if (m.info.get()) {
            List<String> lines = new ArrayList<>();
            lines.add("FPS: " + c.getCurrentFps());
            lines.add("Ping: " + ping(c) + " ms");
            lines.add(String.format("Time: %s", worldTime(c)));
            panel(ctx, c, lines, 6, 24, m.infoX, m.infoY, false);
        }
        if (m.coords.get()) {
            List<String> lines = new ArrayList<>();
            lines.add(String.format("X: %.1f", c.player.getX()));
            lines.add(String.format("Y: %.1f", c.player.getY()));
            lines.add(String.format("Z: %.1f", c.player.getZ()));
            lines.add("Facing: " + compass(c.player.getYaw()));
            panel(ctx, c, lines, 6, sh - 6 - lines.size() * 10 - 6, m.coordX, m.coordY, false);
        }
        if (m.armor.get()) {
            List<String> lines = new ArrayList<>();
            for (int i = 3; i >= 0; i--) {
                ItemStack st = c.player.getEquippedStack(ARMOR_SLOTS[i]);
                if (!st.isEmpty()) lines.add(ARMOR_NAMES[i] + " " + durability(st));
            }
            ItemStack held = c.player.getMainHandStack();
            if (!held.isEmpty()) lines.add("В руке " + durability(held));
            if (!lines.isEmpty()) panel(ctx, c, lines, sw - 6, sh / 2 - 20, m.armorX, m.armorY, true);
        }
    }

    /** One glass box with one line of text per entry. Dragging sets the offset from the base corner. */
    private static void panel(DrawContext ctx, MinecraftClient c, List<String> lines, int bx, int by,
                              NumberSetting sx, NumberSetting sy, boolean rightAligned) {
        var tr = c.textRenderer;
        int tw = 0;
        for (String s : lines) tw = Math.max(tw, Fonts.width(tr, s));
        int w = tw + 12, h = lines.size() * 10 + 6;
        int baseX = rightAligned ? bx - w : bx;
        int x = baseX + (int) sx.get(), y = by + (int) sy.get();
        final int bX = baseX, bY = by;
        HudEdit.track(x, y, w, h, (nx, ny) -> {
            sx.set(nx - bX);
            sy.set(ny - bY);
        });
        Glass.panel(ctx, x, y, w, h, 5, Theme.current().accent());
        int ty = y + 4;
        for (String s : lines) {
            Fonts.draw(ctx, tr, s, x + 6, ty, 0xFFFFFFFF);
            ty += 10;
        }
    }

    private static String version() {
        return FabricLoader.getInstance().getModContainer("deathclientdlc")
                .map(mc -> mc.getMetadata().getVersion().getFriendlyString())
                .orElse("");
    }

    private static int ping(MinecraftClient c) {
        if (c.getNetworkHandler() == null || c.player == null) return 0;
        PlayerListEntry e = c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    /** In-game clock: tick 0 is 06:00. */
    private static String worldTime(MinecraftClient c) {
        long t = (c.world.getTimeOfDay() + 6000) % 24000;
        return String.format("%02d:%02d", t / 1000, (t % 1000) * 60 / 1000);
    }

    /** Minecraft yaw: 0 = south, 90 = west, 180 = north, -90 = east. */
    private static String compass(float yaw) {
        float y = ((yaw % 360) + 360) % 360;
        return COMPASS[Math.round(y / 45f) % 8];
    }

    private static String durability(ItemStack st) {
        if (!st.isDamageable()) return "";
        int max = st.getMaxDamage();
        int left = max - st.getDamage();
        return (left * 100 / max) + "%";
    }
}
