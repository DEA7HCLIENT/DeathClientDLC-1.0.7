package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Fast Peek: one press of its key (bind) and you step out sideways from cover, wait a moment, and step back to where
 * you stood. Built for round-based shooter mini-games (CS-style maps) where you look around a corner and hide again.
 *
 * The move is real movement (the velocity is set every tick, like Spear Dash), to the left or to the right of where
 * you look. "Hold" is how many ticks you stay out at the far point; "Auto shoot" uses the item in your hand once
 * when you get there (the gun of the mini-game). If a wall stops you for a second, you go back at once.
 * It switches itself off when you are home again. Not checked against any server's anti-cheat.
 */
public class FastPeekModule extends Module {
    private static final int OUT = 0, HOLD = 1, BACK = 2;

    public final NumberSetting direction = add(new NumberSetting("Direction", 2, 1, 2, 1).labels("Left", "Right"));
    /** How far to step out, in blocks. */
    public final NumberSetting distance = add(new NumberSetting("Distance", 1.5, 0.5, 4.0, 0.25));
    /** Blocks per tick; keep it low, the servers' movement check lets only a few blocks per tick pass. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.25, 3.0, 0.25));
    /** Ticks to stay at the far point (20 ticks = 1 second). */
    public final NumberSetting hold = add(new NumberSetting("Hold", 2, 0, 20, 1));
    /** Use the item in the main hand once at the far point. */
    public final BoolSetting autoShoot = add(new BoolSetting("Auto shoot", false));

    private int state, wait, stuck;
    private Vec3d origin, far;

    public FastPeekModule() { super("Fast Peek", Category.MOVEMENT); }

    @Override
    protected void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null) return;
        double yaw = Math.toRadians(p.getYaw());
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));              // to your right, flat on the ground
        Vec3d side = (int) direction.get() == 2 ? right : right.multiply(-1);
        origin = p.getEntityPos();
        far = origin.add(side.multiply(distance.get()));
        state = OUT;
        wait = 0;
        stuck = 0;
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.setVelocity(Vec3d.ZERO);
        origin = far = null;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || origin == null) { if (isEnabled()) toggle(); return; }
        switch (state) {
            case OUT -> {
                if (move(p, far)) {                                               // at the far point
                    if (autoShoot.get() && c.interactionManager != null && c.currentScreen == null) {
                        c.interactionManager.interactItem(p, Hand.MAIN_HAND);
                        p.swingHand(Hand.MAIN_HAND);
                    }
                    wait = (int) hold.get();
                    state = HOLD;
                } else if (stuck > 20) state = BACK;                              // a wall: give up and go back
            }
            case HOLD -> {
                p.setVelocity(Vec3d.ZERO);
                if (wait-- <= 0) { state = BACK; stuck = 0; }
            }
            default -> {
                if (move(p, origin) || stuck > 20) toggle();                      // home: switch itself off
            }
        }
    }

    /** Flies one tick towards the point; true when you are there. */
    private boolean move(ClientPlayerEntity p, Vec3d to) {
        Vec3d d = to.subtract(p.getEntityPos());
        d = new Vec3d(d.x, 0, d.z);                                               // sideways only, no up or down
        double dist = d.length();
        if (dist <= 0.1) { p.setVelocity(Vec3d.ZERO); return true; }
        Vec3d v = d.normalize().multiply(Math.min(speed.get(), dist));
        p.setVelocity(v.x, p.getVelocity().y, v.z);                               // gravity stays
        if (p.horizontalCollision) stuck++; else stuck = 0;
        return false;
    }
}
