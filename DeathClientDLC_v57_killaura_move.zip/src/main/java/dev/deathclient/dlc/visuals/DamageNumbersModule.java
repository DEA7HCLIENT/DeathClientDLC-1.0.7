package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Damage Numbers: when a nearby living entity loses health, the amount floats up from it and fades out
 * (red for damage, green for healing). It only reads the health values the server already sends.
 */
public class DamageNumbersModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final NumberSetting life = add(new NumberSetting("Life", 25, 10, 60, 5));
    public final BoolSetting healing = add(new BoolSetting("Show healing", false));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", false));

    private record Num(Vec3d pos, String text, boolean heal, long born) {}

    private final Map<UUID, Float> last = new HashMap<>();
    private final List<Num> nums = new ArrayList<>();
    private final Random rnd = new Random();
    private final ScreenProjector proj = new ScreenProjector();
    private long tick;

    public DamageNumbersModule() { super("Damage Numbers", Category.VISUALS); }

    @Override
    protected void onDisable() { last.clear(); nums.clear(); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.world == null || c.player == null) return;
        tick++;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == c.player || !le.isAlive()) continue;
            if (playersOnly.get() && !(e instanceof net.minecraft.entity.player.PlayerEntity)) continue;
            if (c.player.distanceTo(e) > range.get()) continue;
            float hp = le.getHealth(), old = last.getOrDefault(le.getUuid(), hp);
            float d = old - hp;
            if (Math.abs(d) >= 0.1f && (d > 0 || healing.get())) {
                Vec3d at = le.getEntityPos().add((rnd.nextDouble() - 0.5) * 0.6, le.getHeight() * 0.8, (rnd.nextDouble() - 0.5) * 0.6);
                String txt = (d > 0 ? "-" : "+") + (Math.abs(d) >= 10 ? String.valueOf(Math.round(Math.abs(d))) : String.format("%.1f", Math.abs(d)));
                nums.add(new Num(at, txt, d < 0, tick));
            }
            last.put(le.getUuid(), hp);
        }
        nums.removeIf(n -> tick - n.born > life.get());
        if (last.size() > 500) last.clear();                                       // keeps the map from growing forever
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter t) {
        DamageNumbersModule m = ModuleManager.get(DamageNumbersModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, t.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        for (Num n : nums) {
            float age = (tick - n.born + delta) / (float) life.get();
            Vec3d at = n.pos.add(0, age * 0.9, 0);
            if (!proj.project(at)) continue;
            int a = Math.max(5, Math.min(255, (int) (255 * (1 - age * age))));
            int rgb = n.heal ? 0x55FF77 : 0xFF4458;
            ctx.drawCenteredTextWithShadow(c.textRenderer, n.text, (int) proj.out[0], (int) proj.out[1], (a << 24) | rgb);
        }
    }
}
