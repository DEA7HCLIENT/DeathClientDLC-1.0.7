package dev.deathclient.dlc;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Stream;

/**
 * Figure: a Figura-like model on you. Put .gltf models (Blockbench export, "glTF" with the texture embedded) in
 * .minecraft/config/deathclient/figures/, pick one in "Figure", and it stands next to you and turns with your body.
 * One model (black_ninja.gltf) is copied there on first start. Models are loaded as a still pose (animations are
 * not played) and each triangle gets the colour of the texture at its centre, so a Blockbench model with
 * 16-pixel-style textures looks right. It is drawn as the projected-triangle overlay, like the China Hat.
 * Only use models you are allowed to use: check the licence of each model.
 */
public class FigureModule extends Module {
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclient").resolve("figures");
    private static final List<String> FILES = scan();

    public final NumberSetting figure = add(new NumberSetting("Figure", 1, 1, Math.max(1, FILES.size()), 1)
            .labels(FILES.isEmpty() ? new String[]{"none"} : FILES.toArray(new String[0])));
    public final NumberSetting height = add(new NumberSetting("Height", 1.8, 0.5, 4.0, 0.1));
    public final NumberSetting side = add(new NumberSetting("Side", 2, 1, 2, 1).labels("Left", "Right"));
    public final NumberSetting sideDistance = add(new NumberSetting("Side distance", 1.2, 0.3, 4.0, 0.1));
    public final NumberSetting behind = add(new NumberSetting("Behind", 0.0, -2.0, 3.0, 0.1));
    /** Quarter turns added to the model's facing: use it if the model looks the wrong way. */
    public final NumberSetting turn = add(new NumberSetting("Turn", 1, 1, 4, 1).labels("0", "90", "180", "270"));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 100, 10, 100, 5));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", false));

    private final ScreenProjector proj = new ScreenProjector();
    private Model model;
    private String loaded = "";

    public FigureModule() { super("Figure", Category.VISUALS); }

    // ---------------------------------------------------------------- files

    private static List<String> scan() {
        List<String> out = new ArrayList<>();
        try {
            Files.createDirectories(DIR);
            try (Stream<Path> s = Files.list(DIR)) {
                if (s.noneMatch(f -> f.toString().toLowerCase().endsWith(".gltf"))) {
                    try (InputStream in = FigureModule.class.getResourceAsStream("/assets/deathclientdlc/figures/black_ninja.gltf")) {
                        if (in != null) Files.copy(in, DIR.resolve("black_ninja.gltf"), StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
            try (Stream<Path> s = Files.list(DIR)) {
                s.map(f -> f.getFileName().toString()).filter(n -> n.toLowerCase().endsWith(".gltf")).sorted().forEach(out::add);
            }
        } catch (Exception ignored) { }
        return out;
    }

    // ---------------------------------------------------------------- model

    private static final class Model {
        float[] pos;     // 9 per triangle (3 points)
        float[] nrm;     // 3 per triangle
        int[] col;       // rgb per triangle
        float minX = 1e9f, maxX = -1e9f, minY = 1e9f, maxY = -1e9f, minZ = 1e9f, maxZ = -1e9f;
        int tris;
    }

    private static byte[] uriBytes(String uri, Path base) throws Exception {
        if (uri.startsWith("data:")) return Base64.getDecoder().decode(uri.substring(uri.indexOf(',') + 1));
        return Files.readAllBytes(base.resolveSibling(uri));
    }

    private static float[] floats(JsonObject g, byte[][] bufs, int acc, int comps) {
        JsonObject a = g.getAsJsonArray("accessors").get(acc).getAsJsonObject();
        JsonObject bv = g.getAsJsonArray("bufferViews").get(a.get("bufferView").getAsInt()).getAsJsonObject();
        ByteBuffer b = ByteBuffer.wrap(bufs[bv.get("buffer").getAsInt()]).order(ByteOrder.LITTLE_ENDIAN);
        int off = (bv.has("byteOffset") ? bv.get("byteOffset").getAsInt() : 0) + (a.has("byteOffset") ? a.get("byteOffset").getAsInt() : 0);
        int stride = bv.has("byteStride") ? bv.get("byteStride").getAsInt() : comps * 4;
        int n = a.get("count").getAsInt();
        float[] r = new float[n * comps];
        for (int i = 0; i < n; i++) for (int k = 0; k < comps; k++) r[i * comps + k] = b.getFloat(off + i * stride + k * 4);
        return r;
    }

    private static int[] indices(JsonObject g, byte[][] bufs, int acc) {
        JsonObject a = g.getAsJsonArray("accessors").get(acc).getAsJsonObject();
        JsonObject bv = g.getAsJsonArray("bufferViews").get(a.get("bufferView").getAsInt()).getAsJsonObject();
        ByteBuffer b = ByteBuffer.wrap(bufs[bv.get("buffer").getAsInt()]).order(ByteOrder.LITTLE_ENDIAN);
        int off = (bv.has("byteOffset") ? bv.get("byteOffset").getAsInt() : 0) + (a.has("byteOffset") ? a.get("byteOffset").getAsInt() : 0);
        int type = a.get("componentType").getAsInt(), n = a.get("count").getAsInt();
        int size = type == 5125 ? 4 : type == 5123 ? 2 : 1;
        int stride = bv.has("byteStride") ? bv.get("byteStride").getAsInt() : size;
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            int p = off + i * stride;
            r[i] = type == 5125 ? b.getInt(p) : type == 5123 ? (b.getShort(p) & 0xFFFF) : (b.get(p) & 0xFF);
        }
        return r;
    }

    private static double[] mul(double[] a, double[] b) {          // column-major 4x4: a * b
        double[] r = new double[16];
        for (int c = 0; c < 4; c++) for (int rr = 0; rr < 4; rr++) {
            double s = 0;
            for (int k = 0; k < 4; k++) s += a[k * 4 + rr] * b[c * 4 + k];
            r[c * 4 + rr] = s;
        }
        return r;
    }

    private static double[] local(JsonObject n) {
        if (n.has("matrix")) { double[] m = new double[16]; for (int i = 0; i < 16; i++) m[i] = n.getAsJsonArray("matrix").get(i).getAsDouble(); return m; }
        double[] t = {0, 0, 0}, q = {0, 0, 0, 1}, s = {1, 1, 1};
        if (n.has("translation")) for (int i = 0; i < 3; i++) t[i] = n.getAsJsonArray("translation").get(i).getAsDouble();
        if (n.has("rotation")) for (int i = 0; i < 4; i++) q[i] = n.getAsJsonArray("rotation").get(i).getAsDouble();
        if (n.has("scale")) for (int i = 0; i < 3; i++) s[i] = n.getAsJsonArray("scale").get(i).getAsDouble();
        double x = q[0], y = q[1], z = q[2], w = q[3];
        return new double[]{
            (1 - 2 * (y * y + z * z)) * s[0], (2 * (x * y + z * w)) * s[0], (2 * (x * z - y * w)) * s[0], 0,
            (2 * (x * y - z * w)) * s[1], (1 - 2 * (x * x + z * z)) * s[1], (2 * (y * z + x * w)) * s[1], 0,
            (2 * (x * z + y * w)) * s[2], (2 * (y * z - x * w)) * s[2], (1 - 2 * (x * x + y * y)) * s[2], 0,
            t[0], t[1], t[2], 1};
    }

    private static Model load(Path file) throws Exception {
        JsonObject g = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
        JsonArray bj = g.getAsJsonArray("buffers");
        byte[][] bufs = new byte[bj.size()][];
        for (int i = 0; i < bufs.length; i++) bufs[i] = uriBytes(bj.get(i).getAsJsonObject().get("uri").getAsString(), file);
        BufferedImage tex = null;
        if (g.has("images")) tex = ImageIO.read(new ByteArrayInputStream(uriBytes(g.getAsJsonArray("images").get(0).getAsJsonObject().get("uri").getAsString(), file)));

        List<float[]> P = new ArrayList<>(), N = new ArrayList<>();
        List<Integer> C = new ArrayList<>();
        JsonArray nodes = g.getAsJsonArray("nodes");
        int sc = g.has("scene") ? g.get("scene").getAsInt() : 0;
        double[] id = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
        for (JsonElement root : g.getAsJsonArray("scenes").get(sc).getAsJsonObject().getAsJsonArray("nodes"))
            walk(g, nodes, root.getAsInt(), id, bufs, tex, P, N, C);

        Model m = new Model();
        m.tris = C.size();
        m.pos = new float[m.tris * 9]; m.nrm = new float[m.tris * 3]; m.col = new int[m.tris];
        for (int i = 0; i < m.tris; i++) {
            System.arraycopy(P.get(i), 0, m.pos, i * 9, 9);
            System.arraycopy(N.get(i), 0, m.nrm, i * 3, 3);
            m.col[i] = C.get(i);
            for (int k = 0; k < 3; k++) {
                float x = m.pos[i * 9 + k * 3], y = m.pos[i * 9 + k * 3 + 1], z = m.pos[i * 9 + k * 3 + 2];
                m.minX = Math.min(m.minX, x); m.maxX = Math.max(m.maxX, x);
                m.minY = Math.min(m.minY, y); m.maxY = Math.max(m.maxY, y);
                m.minZ = Math.min(m.minZ, z); m.maxZ = Math.max(m.maxZ, z);
            }
        }
        return m;
    }

    private static void walk(JsonObject g, JsonArray nodes, int idx, double[] parent, byte[][] bufs, BufferedImage tex,
                             List<float[]> P, List<float[]> N, List<Integer> C) {
        JsonObject n = nodes.get(idx).getAsJsonObject();
        double[] w = mul(parent, local(n));
        if (n.has("mesh")) {
            for (JsonElement pe : g.getAsJsonArray("meshes").get(n.get("mesh").getAsInt()).getAsJsonObject().getAsJsonArray("primitives")) {
                JsonObject pr = pe.getAsJsonObject(), at = pr.getAsJsonObject("attributes");
                float[] pos = floats(g, bufs, at.get("POSITION").getAsInt(), 3);
                float[] nor = at.has("NORMAL") ? floats(g, bufs, at.get("NORMAL").getAsInt(), 3) : null;
                float[] uv = at.has("TEXCOORD_0") ? floats(g, bufs, at.get("TEXCOORD_0").getAsInt(), 2) : null;
                int[] ix = pr.has("indices") ? indices(g, bufs, pr.get("indices").getAsInt()) : null;
                int count = ix != null ? ix.length : pos.length / 3;
                for (int t = 0; t + 2 < count; t += 3) {
                    int[] v = ix != null ? new int[]{ix[t], ix[t + 1], ix[t + 2]} : new int[]{t, t + 1, t + 2};
                    float[] pp = new float[9]; double[] nn = {0, 0, 0}; double u = 0, vv = 0;
                    for (int k = 0; k < 3; k++) {
                        double x = pos[v[k] * 3], y = pos[v[k] * 3 + 1], z = pos[v[k] * 3 + 2];
                        pp[k * 3] = (float) (w[0] * x + w[4] * y + w[8] * z + w[12]);
                        pp[k * 3 + 1] = (float) (w[1] * x + w[5] * y + w[9] * z + w[13]);
                        pp[k * 3 + 2] = (float) (w[2] * x + w[6] * y + w[10] * z + w[14]);
                        if (nor != null) {
                            double a = nor[v[k] * 3], b = nor[v[k] * 3 + 1], c = nor[v[k] * 3 + 2];
                            nn[0] += w[0] * a + w[4] * b + w[8] * c; nn[1] += w[1] * a + w[5] * b + w[9] * c; nn[2] += w[2] * a + w[6] * b + w[10] * c;
                        }
                        if (uv != null) { u += uv[v[k] * 2] / 3; vv += uv[v[k] * 2 + 1] / 3; }
                    }
                    if (nor == null) {                                           // flat normal from the corners
                        double ax = pp[3] - pp[0], ay = pp[4] - pp[1], az = pp[5] - pp[2], bx = pp[6] - pp[0], by = pp[7] - pp[1], bz = pp[8] - pp[2];
                        nn = new double[]{ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx};
                    }
                    double l = Math.sqrt(nn[0] * nn[0] + nn[1] * nn[1] + nn[2] * nn[2]);
                    if (l < 1e-9) continue;
                    int rgb = 0xB0B0B0;
                    if (tex != null && uv != null) {
                        int px = MathHelper.clamp((int) (u * tex.getWidth()), 0, tex.getWidth() - 1);
                        int py = MathHelper.clamp((int) (vv * tex.getHeight()), 0, tex.getHeight() - 1);
                        int argb = tex.getRGB(px, py);
                        if (((argb >>> 24) & 0xFF) < 13) continue;                // transparent texel: no triangle
                        rgb = argb & 0xFFFFFF;
                    }
                    P.add(pp); N.add(new float[]{(float) (nn[0] / l), (float) (nn[1] / l), (float) (nn[2] / l)}); C.add(rgb);
                }
            }
        }
        if (n.has("children")) for (JsonElement ch : n.getAsJsonArray("children")) walk(g, nodes, ch.getAsInt(), w, bufs, tex, P, N, C);
    }

    // ---------------------------------------------------------------- drawing

    private static final class Tri {
        final double[] a, b, c; final double depth; final int color;
        Tri(double[] a, double[] b, double[] c, int color) { this.a = a; this.b = b; this.c = c; this.color = color; depth = (a[2] + b[2] + c[2]) / 3.0; }
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        FigureModule m = ModuleManager.get(FigureModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden || c.currentScreen != null || FILES.isEmpty()) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tick.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        String name = FILES.get(Math.min(FILES.size(), (int) figure.get()) - 1);
        if (!name.equals(loaded)) {
            loaded = name;
            try { model = load(DIR.resolve(name)); } catch (Exception e) { model = null; }
        }
        if (model == null || model.tris == 0) return;

        double bodyYaw = MathHelper.lerpAngleDegrees(delta, p.lastBodyYaw, p.bodyYaw);
        double yr = Math.toRadians(bodyYaw);
        double[] right = {-Math.cos(yr), -Math.sin(yr)}, back = {Math.sin(yr), -Math.cos(yr)};
        double sd = (int) side.get() == 2 ? 1 : -1;
        Vec3d at = p.getLerpedPos(delta);
        double bx = at.x + right[0] * sd * sideDistance.get() + back[0] * behind.get();
        double bz = at.z + right[1] * sd * sideDistance.get() + back[1] * behind.get();
        Vec3d eye = (c.getCameraEntity() != null ? c.getCameraEntity() : p).getEyePos();
        if (eye.squaredDistanceTo(bx, at.y, bz) > 64 * 64) return;

        double th = Math.toRadians(bodyYaw + ((int) turn.get() - 1) * 90.0), co = Math.cos(th), si = Math.sin(th);
        double scale = height.get() / Math.max(1e-6, model.maxY - model.minY);
        double cx = (model.minX + model.maxX) / 2, cz = (model.minZ + model.maxZ) / 2;
        int alpha = ((int) Math.round(opacity.get() / 100.0 * 255)) << 24;

        proj.begin(c, delta);
        List<Tri> tris = new ArrayList<>(model.tris);
        for (int i = 0; i < model.tris; i++) {
            double[][] w = new double[3][3];
            for (int k = 0; k < 3; k++) {
                double lx = (model.pos[i * 9 + k * 3] - cx) * scale, ly = (model.pos[i * 9 + k * 3 + 1] - model.minY) * scale, lz = (model.pos[i * 9 + k * 3 + 2] - cz) * scale;
                w[k][0] = bx + lx * co - lz * si; w[k][1] = at.y + ly; w[k][2] = bz + lx * si + lz * co;
            }
            double nx = model.nrm[i * 3] * co - model.nrm[i * 3 + 2] * si, ny = model.nrm[i * 3 + 1], nz = model.nrm[i * 3] * si + model.nrm[i * 3 + 2] * co;
            double mx = (w[0][0] + w[1][0] + w[2][0]) / 3, my = (w[0][1] + w[1][1] + w[2][1]) / 3, mz = (w[0][2] + w[1][2] + w[2][2]) / 3;
            if (nx * (eye.x - mx) + ny * (eye.y - my) + nz * (eye.z - mz) <= 0) continue;     // faces away from the camera
            double[][] s = new double[3][];
            boolean ok = true;
            for (int k = 0; k < 3 && ok; k++) {
                if (!proj.project(new Vec3d(w[k][0], w[k][1], w[k][2]))) { ok = false; break; }
                s[k] = new double[]{proj.out[0], proj.out[1], proj.out[2]};
            }
            if (!ok) continue;
            double light = 0.55 + 0.45 * Math.max(0, nx * -0.35 + ny * 0.8 + nz * -0.45);
            int rgb = model.col[i];
            int r = (int) Math.min(255, ((rgb >> 16) & 0xFF) * light), gg = (int) Math.min(255, ((rgb >> 8) & 0xFF) * light), b = (int) Math.min(255, (rgb & 0xFF) * light);
            tris.add(new Tri(s[0], s[1], s[2], alpha | (r << 16) | (gg << 8) | b));
        }
        tris.sort((x, y) -> Double.compare(y.depth, x.depth));
        for (Tri t : tris) ChinaHatModule.fillTriangle(ctx, t.a, t.b, t.c, t.color);
    }
}
