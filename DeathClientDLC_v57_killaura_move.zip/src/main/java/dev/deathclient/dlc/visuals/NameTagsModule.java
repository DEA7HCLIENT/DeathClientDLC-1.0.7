package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Name Tags: a clean tag above every player: name, health and the item in the main hand. It is drawn as an
 * overlay at the projected position (the game's own tag stays too). Friends are shown in green.
 */
public class NameTagsModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 4));
    public final BoolSetting health = add(new BoolSetting("Health", true));
    public final BoolSetting heldItem = add(new BoolSetting("Held item", true));

    private final ScreenProjector proj = new ScreenProjector();

    public NameTagsModule() { super("Name Tags", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        NameTagsModule m = ModuleManager.get(NameTagsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tick.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof PlayerEntity pl) || pl == c.player || !pl.isAlive() || pl.isSpectator()) continue;
            if (c.player.distanceTo(pl) > range.get()) continue;
            Vec3d at = pl.getLerpedPos(delta).add(0, pl.getHeight() + 0.55, 0);
            if (!proj.project(at)) continue;
            int x = (int) proj.out[0], y = (int) proj.out[1];

            String name = pl.getName().getString();
            String hp = health.get() ? "  " + Math.round(pl.getHealth() + pl.getAbsorptionAmount()) : "";
            int w = c.textRenderer.getWidth(name + hp) + 8;
            ctx.fill(x - w / 2, y - 12, x + w / 2, y, 0x90000000);
            int nameCol = Friends.skip(pl) ? 0xFF6BFF8A : 0xFFFFFFFF;
            ctx.drawTextWithShadow(c.textRenderer, name, x - w / 2 + 4, y - 10, nameCol);
            if (health.get()) {
                float f = Math.max(0f, Math.min(1f, pl.getHealth() / pl.getMaxHealth()));
                int col = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8) | 0x40;
                ctx.drawTextWithShadow(c.textRenderer, hp.trim(), x - w / 2 + 4 + c.textRenderer.getWidth(name + "  "), y - 10, col);
            }
            if (heldItem.get() && !pl.getMainHandStack().isEmpty()) {
                ctx.drawCenteredTextWithShadow(c.textRenderer, pl.getMainHandStack().getName().getString(), x, y + 2, 0xFFB8B8D0);
            }
        }
    }
}
