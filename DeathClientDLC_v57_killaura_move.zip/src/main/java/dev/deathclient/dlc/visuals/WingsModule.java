package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Wings: a pair of wings on your back, made of a fan of feathers over a darker membrane. The wings are our own
 * simple geometry (no model file), drawn like the China Hat with the projected-triangle overlay.
 * They flap slowly while you stand, harder when you move, and spread flat while you glide with an elytra.
 */
public class WingsModule extends Module {
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.5, 2.5, 0.1));
    public final NumberSetting feathers = add(new NumberSetting("Feathers", 6, 3, 10, 1));
    public final NumberSetting flapSpeed = add(new NumberSetting("Flap speed", 1.0, 0.25, 3.0, 0.25));
    public final NumberSetting flapAmount = add(new NumberSetting("Flap amount", 1.0, 0.0, 2.0, 0.25));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 95, 10, 100, 5));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    private final ScreenProjector proj = new ScreenProjector();

    private static final class Tri {
        final double[] a, b, c; final double depth; final int color;
        Tri(double[] a, double[] b, double[] c, int color) { this.a = a; this.b = b; this.c = c; this.color = color; depth = (a[2] + b[2] + c[2]) / 3.0; }
    }

    public WingsModule() { super("Wings", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        WingsModule m = ModuleManager.get(WingsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tick.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        proj.begin(c, delta);
        Vec3d base = p.getLerpedPos(delta);
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(delta, p.lastBodyYaw, p.bodyYaw));
        double[] right = {-Math.cos(yaw), 0, -Math.sin(yaw)};
        double[] back = {Math.sin(yaw), 0, -Math.cos(yaw)};
        boolean glide = p.isGliding();
        double speed = Math.hypot(p.getVelocity().x, p.getVelocity().z);
        double t = (p.age + delta) * 0.22 * flapSpeed.get();
        double flap = glide ? 0 : Math.sin(t * (1 + Math.min(speed * 6, 2))) * 0.35 * flapAmount.get();
        double lift = glide ? -0.25 : 0.25 + flap;                       // radians: how high the wing is raised
        double up0 = glide ? 0.0 : 1.0;
        double S = size.get();
        int nf = (int) feathers.get();
        int alpha = ((int) Math.round(opacity.get() / 100.0 * 255)) << 24;
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xF4F1FF) & 0xFFFFFF;
        double bodyY = glide ? 0.45 : 1.25;
        List<Tri> tris = new ArrayList<>();

        for (int side = -1; side <= 1; side += 2) {
            double[] root = {base.x + back[0] * 0.18 + right[0] * 0.14 * side, base.y + bodyY, base.z + back[2] * 0.18 + right[2] * 0.14 * side};
            double[][] tips = new double[nf][];
            for (int i = 0; i < nf; i++) {
                double k = nf == 1 ? 0 : i / (double) (nf - 1);                // 0 = top feather, 1 = bottom feather
                double a = lift + 0.9 - k * 1.7;                                // fan angle, radians
                double len = (1.15 - 0.55 * Math.abs(k - 0.25)) * S;
                double ox = right[0] * side * Math.cos(a) + back[0] * 0.45;
                double oz = right[2] * side * Math.cos(a) + back[2] * 0.45;
                double oy = Math.sin(a) * up0 + (glide ? 0 : 0);
                double l = Math.sqrt(ox * ox + oy * oy + oz * oz);
                double[] tip = {root[0] + ox / l * len, root[1] + oy / l * len, root[2] + oz / l * len};
                tips[i] = pr(tip);
                double[] pe = norm(cross(new double[]{ox, oy, oz}, right));      // feather width direction
                double w = 0.07 * S;
                double[] r1 = pr(new double[]{root[0] - pe[0] * w, root[1] - pe[1] * w, root[2] - pe[2] * w});
                double[] r2 = pr(new double[]{root[0] + pe[0] * w, root[1] + pe[1] * w, root[2] + pe[2] * w});
                double shade = 0.78 + 0.22 * (1 - k);
                if (r1 != null && r2 != null && tips[i] != null) tris.add(new Tri(r1, r2, tips[i], alpha | shadeRgb(rgb, shade)));
            }
            double[] rp = pr(root);
            for (int i = 0; i + 1 < nf; i++) {                                  // membrane between neighbouring feathers
                if (rp != null && tips[i] != null && tips[i + 1] != null) tris.add(new Tri(rp, tips[i], tips[i + 1], alpha | shadeRgb(rgb, 0.5)));
            }
        }
        tris.sort((x, y) -> Double.compare(y.depth, x.depth));
        for (Tri tr : tris) ChinaHatModule.fillTriangle(ctx, tr.a, tr.b, tr.c, tr.color);
    }

    private double[] pr(double[] q) {
        if (!proj.project(new Vec3d(q[0], q[1], q[2]))) return null;
        return new double[]{proj.out[0], proj.out[1], proj.out[2]};
    }
    private static double[] cross(double[] a, double[] b) { return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
    private static double[] norm(double[] v) { double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return l < 1e-9 ? new double[]{0, 1, 0} : new double[]{v[0] / l, v[1] / l, v[2] / l}; }
    private static int shadeRgb(int rgb, double s) {
        int r = (int) Math.min(255, ((rgb >> 16) & 0xFF) * s), g = (int) Math.min(255, ((rgb >> 8) & 0xFF) * s), b = (int) Math.min(255, (rgb & 0xFF) * s);
        return r << 16 | g << 8 | b;
    }
}
