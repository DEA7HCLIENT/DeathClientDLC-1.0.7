package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;

/**
 * Zoom: a smooth lens. Put it on a key (bind): the first press eases the field of view down to "Zoom FOV",
 * the second press eases back to what it was. The game does not let the FOV go below 30, so 30 is the
 * strongest zoom (about 2.5x from a 70 FOV). "Smooth" is how fast the view eases (low = slow and soft).
 */
public class ZoomModule extends Module {
    public final NumberSetting zoomFov = add(new NumberSetting("Zoom FOV", 30, 30, 90, 5));
    public final NumberSetting smooth = add(new NumberSetting("Smooth", 0.25, 0.05, 1.0, 0.05));

    private Integer old;
    private double cur;

    public ZoomModule() { super("Zoom", Category.VISUALS); }

    @Override
    protected void onEnable() {
        old = MinecraftClient.getInstance().options.getFov().getValue();
        cur = old;
    }

    @Override
    public void onTick(MinecraftClient c) {
        cur += (zoomFov.get() - cur) * smooth.get();
        int want = (int) Math.round(cur);
        if (c.options.getFov().getValue().intValue() != want) c.options.getFov().setValue(want);
    }

    @Override
    protected void onDisable() {
        if (old != null) MinecraftClient.getInstance().options.getFov().setValue(old);
        old = null;
    }
}
