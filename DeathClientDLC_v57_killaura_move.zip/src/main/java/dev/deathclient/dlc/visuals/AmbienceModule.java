package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.Random;

/**
 * Ambience: soft particles floating over the screen. Styles: Motes (glowing dots drifting up), Stardust
 * (twinkling four-point sparkles), Petals (pink petals falling and swaying), Snow (white flakes falling).
 * Pure overlay, needs no textures. "Theme color" tints Motes and Stardust with the client theme.
 */
public class AmbienceModule extends Module {
    private static final int MOTES = 1, STARDUST = 2, PETALS = 3, SNOW = 4;

    public final NumberSetting style = add(new NumberSetting("Style", STARDUST, 1, 4, 1).labels("Motes", "Stardust", "Petals", "Snow"));
    public final NumberSetting amount = add(new NumberSetting("Amount", 60, 10, 200, 10));
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.25, 3.0, 0.25));
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.5, 3.0, 0.25));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    private final Random rnd = new Random();
    private float[] x, y, vy, ph, sz;
    private int n, lastSw, lastSh;
    private long last;

    public AmbienceModule() { super("Ambience", Category.VISUALS); }

    @Override
    protected void onDisable() { x = null; }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        AmbienceModule m = ModuleManager.get(AmbienceModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void respawn(int i, int sw, int sh, boolean anywhere) {
        x[i] = rnd.nextFloat() * sw;
        boolean falling = (int) style.get() >= PETALS;
        y[i] = anywhere ? rnd.nextFloat() * sh : (falling ? -6 : sh + 6);
        float s = (float) speed.get();
        vy[i] = (falling ? 1 : -1) * (6 + rnd.nextFloat() * 22) * s;
        ph[i] = rnd.nextFloat() * 6.28f;
        sz[i] = 0.7f + rnd.nextFloat() * 0.9f;
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int want = (int) amount.get();
        if (x == null || n != want || sw != lastSw || sh != lastSh) {
            n = want; lastSw = sw; lastSh = sh;
            x = new float[n]; y = new float[n]; vy = new float[n]; ph = new float[n]; sz = new float[n];
            for (int i = 0; i < n; i++) respawn(i, sw, sh, true);
            last = System.nanoTime();
        }
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1.0e9f);
        last = now;
        double t = now / 1.0e9;
        int st = (int) style.get();
        int rgb = themeColor.get() ? (Theme.current().accent() & 0xFFFFFF) : 0xBEA0FF;
        float k = (float) size.get();

        for (int i = 0; i < n; i++) {
            y[i] += vy[i] * dt;
            float sway = (float) Math.sin(t * (st == PETALS ? 1.4 : 0.6) + ph[i]) * (st == PETALS ? 26f : 8f);
            x[i] += sway * dt;
            if (y[i] < -8 || y[i] > sh + 8 || x[i] < -8 || x[i] > sw + 8) { respawn(i, sw, sh, false); continue; }

            float tw = 0.35f + 0.65f * (float) Math.abs(Math.sin(t * 1.3 + ph[i]));
            int px = (int) x[i], py = (int) y[i];
            float s = sz[i] * k;
            switch (st) {
                case MOTES -> {
                    dot(ctx, px, py, s * 3.5f, rgb, tw * 0.18f);                // soft halo
                    dot(ctx, px, py, s * 1.6f, rgb, tw * 0.9f);
                }
                case STARDUST -> {
                    int arm = Math.max(2, Math.round(s * 4 * tw));
                    int col = argb(rgb, tw);
                    ctx.fill(px - arm, py, px + arm + 1, py + 1, col);          // the four-point sparkle
                    ctx.fill(px, py - arm, px + 1, py + arm + 1, col);
                    dot(ctx, px, py, s * 1.4f, 0xFFFFFF, tw);
                }
                case PETALS -> dot(ctx, px, py, s * 2.2f, 0xFFA0C8, 0.85f);
                default -> dot(ctx, px, py, s * 1.5f, 0xFFFFFF, 0.8f);          // SNOW
            }
        }
    }

    private static void dot(DrawContext ctx, int cx, int cy, float size, int rgb, float alpha) {
        int h = Math.max(1, Math.round(size / 2));
        ctx.fill(cx - h, cy - h, cx + h, cy + h, argb(rgb, alpha));
    }

    private static int argb(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }
}
