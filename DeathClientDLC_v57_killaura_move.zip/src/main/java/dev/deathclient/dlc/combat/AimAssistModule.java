package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/** AimAssist: smoothly pulls your crosshair towards the nearest target in front of you. */
public class AimAssistModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 5.0, 2.0, 10.0, 0.5));
    public final NumberSetting fov = add(new NumberSetting("FOV", 90, 10, 360, 5));
    public final NumberSetting speed = add(new NumberSetting("Speed", 6, 1, 30, 0.5));
    /** Share of the remaining angle covered per tick: low = slow, soft, no snapping; 1.0 = full Speed all the way. */
    public final NumberSetting smoothing = add(new NumberSetting("Smoothing", 0.25, 0.05, 1.0, 0.05));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting onClick = add(new BoolSetting("Only while attacking", false));

    public AimAssistModule() { super("AimAssist", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null) return;
        if (onClick.get() && !c.options.attackKey.isPressed()) return;
        LivingEntity t = AimUtil.pick(c, p, range.get(), fov.get(), playersOnly.get());
        if (t != null) AimUtil.turn(c, p, t.getBoundingBox().getCenter(), speed.get(), smoothing.get());
    }
}
