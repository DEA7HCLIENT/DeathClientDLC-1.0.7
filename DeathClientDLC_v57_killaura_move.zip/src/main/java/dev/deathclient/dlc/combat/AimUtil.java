package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Shared by the aiming modules (AimAssist, ProjectileHelper, ElytraTarget): picking a target and turning the camera towards it. */
final class AimUtil {
    private AimUtil() {}

    /** The living entity closest to your crosshair (within range and fov degrees), or null. Friends and bots are skipped. */
    static LivingEntity pick(MinecraftClient c, ClientPlayerEntity p, double range, double fov, boolean playersOnly) {
        if (c.world == null) return null;
        LivingEntity best = null;
        double bestAngle = fov / 2.0;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly && !(e instanceof PlayerEntity)) continue;
            if (Friends.skip(e) || AntiBotModule.isBot(e)) continue;
            if (p.distanceTo(e) > range) continue;
            float[] r = Util.rotationsTo(p.getEyePos(), le.getBoundingBox().getCenter());
            double a = Math.hypot(MathHelper.wrapDegrees(r[0] - p.getYaw()), r[1] - p.getPitch());
            if (a < bestAngle) { bestAngle = a; best = le; }
        }
        return best;
    }

    /** Turns the camera towards point by at most speed degrees per axis, rounded to what a mouse could do. */
    static void turn(MinecraftClient c, ClientPlayerEntity p, Vec3d point, double speed) {
        turn(c, p, point, speed, 1.0);
    }

    /**
     * Same, but eased: each tick it covers only the fraction "ease" (0.05 to 1.0) of the angle that is left, so the
     * aim slows down as it gets closer instead of moving at full speed up to the target. ease 1.0 = the old behaviour.
     */
    static void turn(MinecraftClient c, ClientPlayerEntity p, Vec3d point, double speed, double ease) {
        float[] r = Util.rotationsTo(p.getEyePos(), point);
        float dy = (float) (MathHelper.wrapDegrees(r[0] - p.getYaw()) * ease);
        float dp = (float) ((MathHelper.clamp(r[1], -90f, 90f) - p.getPitch()) * ease);
        float g = Rotations.gcd(c);
        dy = Rotations.snap(MathHelper.clamp(dy, (float) -speed, (float) speed), g);
        dp = Rotations.snap(MathHelper.clamp(dp, (float) -speed, (float) speed), g);
        p.setYaw(p.getYaw() + dy);
        p.setPitch(MathHelper.clamp(p.getPitch() + dp, -90f, 90f));
    }
}
