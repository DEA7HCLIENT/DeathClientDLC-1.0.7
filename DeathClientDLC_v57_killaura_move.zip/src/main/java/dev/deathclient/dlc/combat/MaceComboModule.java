package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Mace Combo: the normal wind charge + mace combo of the game. When a target is near and you stand on the ground,
 * it throws a wind charge at your own feet (you are launched up) and switches back to the mace. The hit itself
 * comes from Mace Killer, which waits for the real fall, so keep Mace Killer on. Nothing is faked: all the
 * height and fall distance are the real ones. You need a wind charge and a mace in the hotbar.
 */
public class MaceComboModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Target range", 8.0, 3.0, 20.0, 0.5));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting delay = add(new NumberSetting("Delay", 40, 10, 100, 5));
    public final NumberSetting rotation = add(AuraRotation.setting());

    private int cd;

    public MaceComboModule() { super("Mace Combo", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.currentScreen != null || !p.isAlive()) return;
        if (cd > 0) { cd--; return; }
        if (!p.isOnGround() || !hasTarget(c, p)) return;
        int wind = Util.findHotbar(p, Items.WIND_CHARGE), mace = Util.findHotbar(p, Items.MACE);
        if (wind < 0 || mace < 0) return;

        int prev = p.getInventory().getSelectedSlot();
        int mode = (int) rotation.get();
        p.getInventory().setSelectedSlot(wind);
        AuraRotation.face(c, p, p.getEntityPos().add(0, -1.0, 0), mode);          // straight down, at your feet
        c.interactionManager.interactItem(p, Hand.MAIN_HAND);
        AuraRotation.restore(c, p, mode);
        p.getInventory().setSelectedSlot(mace);                                    // the mace is ready for the fall
        cd = (int) delay.get();
    }

    private boolean hasTarget(MinecraftClient c, ClientPlayerEntity p) {
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le) || AntiBotModule.isBot(le)) continue;
            if (p.distanceTo(le) <= range.get()) return true;
        }
        return false;
    }
}
