package dev.deathclient.dlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.Identifier;

public class DeathClientDLC implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Replace the vanilla title screen (exact class check, so our own screen is never replaced).
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen.getClass() == TitleScreen.class) client.setScreen(new MainMenuScreen());
        });

        Binds.load();
        Friends.load();
        Config.restore();                       // settings + theme now, on/off flags on first world join
        ChatCommands.init();
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud"), Hud::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "keybinds"), KeybindsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "block_esp"), BlockEspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_esp"), TargetEspImageModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_esp_ghost"), TargetEspGhostModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "glass_hand"), GlassHandModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud_edit"), HudEdit::render);   // last: drag HUD in chat

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Binds.tick(client);                 // also opens/closes the ClickGUI on its bound key
            ModuleManager.tick(client);
            Config.autosaveTick();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.autosaveNow());
    }
}
