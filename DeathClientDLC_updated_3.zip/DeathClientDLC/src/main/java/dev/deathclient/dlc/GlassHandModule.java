package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

/**
 * Glass Hand: a frosted-glass glow around your first-person hand and / or held item, in the color of the
 * hand (skin tone) or of the item. It is drawn as a screen-space overlay on top of the hand, placed with the
 * same base positions as the View Model editor, and it follows the View Model offsets, scale and the swing.
 * Position is approximate: nudge it with Offset X / Offset Y.
 * Colors: Auto = skin tone for the hand and the item's own color for the item; Theme; Rainbow; Custom (H / S / B).
 */
public class GlassHandModule extends Module {
    private static final String[] ITEM_KEYS = {
            "netherite", "diamond", "emerald", "golden", "gold", "iron", "chainmail", "copper", "amethyst", "lapis",
            "redstone", "end_crystal", "ender", "totem", "tnt", "apple", "blaze", "fire", "slime", "obsidian",
            "wooden", "stone", "bow", "shield", "elytra", "trident", "mace", "turtle"};
    private static final int[] ITEM_COLORS = {
            0x6B5F6E, 0x4AEDD9, 0x17DD62, 0xFCEE4B, 0xFCEE4B, 0xD8D8D8, 0xA8A8B8, 0xE77C56, 0xB066E8, 0x345EC3,
            0xFF2B2B, 0xFF5FD0, 0x2FB59F, 0xFFD83A, 0xFF4B3B, 0xFF3B3B, 0xFF9A1F, 0xFF9A1F, 0x7BE35A, 0x3A2A5A,
            0x9C7A45, 0x8F8F8F, 0xB08A55, 0x9AA0AA, 0xB9B4D0, 0x2FB5A8, 0xC9C3D6, 0x5DBB63};
    private static final int[] SKIN_TONES = {0xF0C8A0, 0xD9A47B, 0xB07A55, 0x7A4B33};
    private static final int LAYERS = 10;

    public final NumberSetting target = add(new NumberSetting("Glow target", 3, 1, 3, 1).labels("Hand", "Item", "Both"));
    public final NumberSetting color = add(new NumberSetting("Color", 1, 1, 4, 1).labels("Auto", "Theme", "Rainbow", "Custom"));
    public final NumberSetting handTone = add(new NumberSetting("Hand tone", 1, 1, 4, 1).labels("Light", "Medium", "Tan", "Dark"));
    public final NumberSetting hue = add(new NumberSetting("Custom hue", 200, 0, 360, 5));
    public final NumberSetting sat = add(new NumberSetting("Custom saturation", 0.8, 0, 1, 0.05));
    public final NumberSetting bri = add(new NumberSetting("Custom brightness", 1, 0.2, 1, 0.05));
    public final NumberSetting size = add(new NumberSetting("Glow size", 14, 4, 40, 1));
    public final NumberSetting strength = add(new NumberSetting("Glow strength %", 45, 5, 100, 5));
    public final NumberSetting frost = add(new NumberSetting("Glass frost %", 18, 0, 60, 2));
    public final BoolSetting pulse = add(new BoolSetting("Pulse", false));
    public final NumberSetting offX = add(new NumberSetting("Offset X", 0, -150, 150, 1));
    public final NumberSetting offY = add(new NumberSetting("Offset Y", 0, -150, 150, 1));

    public GlassHandModule() { super("Glass Hand", Category.VISUALS); }

    /** HUD element: runs every frame, after the world and the hands are drawn. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (Hud.hidden) return;
        GlassHandModule g = ModuleManager.get(GlassHandModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (g == null || !g.isEnabled() || p == null || c.options.hudHidden || p.isSpectator()
                || !c.options.getPerspective().isFirstPerson()) return;

        float delta = tickCounter.getTickProgress(false);
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int tgt = (int) g.target.get();
        boolean mainRight = c.options.getMainArm().getValue() == Arm.RIGHT;
        float pulse = g.pulse.get() ? 0.75f + 0.25f * MathHelper.sin(System.currentTimeMillis() / 250f) : 1f;

        for (int i = 0; i < 2; i++) {
            boolean main = i == 0;
            Hand hand = main ? Hand.MAIN_HAND : Hand.OFF_HAND;
            ItemStack stack = main ? p.getMainHandStack() : p.getOffHandStack();
            if (!main && stack.isEmpty()) continue;           // vanilla draws the off hand only with an item
            boolean right = main == mainRight;
            int side = right ? 1 : -1;

            double[] vm = ViewModelModule.screenShift(main);
            float sp = p.preferredHand == hand ? p.getHandSwingProgress(delta) : 0f;
            float swing = MathHelper.sin(MathHelper.sqrt(sp) * (float) Math.PI);
            int cx = (int) (sw * (right ? 0.78 : 0.22) + vm[0] + g.offX.get() - side * swing * sw * 0.06);
            int cy = (int) (sh * 0.62 + vm[1] + g.offY.get() + swing * sh * 0.05);
            float scale = (float) vm[2];

            if (tgt != 2) {
                int w = (int) (sh * 0.16 * scale), h = (int) (sh * 0.38 * scale);
                g.glow(ctx, cx, cy + (int) (sh * 0.12), w, h, g.colorFor(false, stack), pulse);
            }
            if (tgt != 1 && !stack.isEmpty()) {
                int s = (int) (sh * 0.20 * scale);
                g.glow(ctx, cx - side * (int) (sh * 0.03), cy - (int) (sh * 0.06), s, s, g.colorFor(true, stack), pulse);
            }
        }
    }

    /** Soft glow made of stacked translucent rounded rects, plus a faint frosted-glass core. */
    private void glow(DrawContext ctx, int cx, int cy, int w, int h, int rgb, float mul) {
        int grow = (int) size.get();
        float str = (float) (strength.get() / 100.0) * mul;
        for (int i = LAYERS; i >= 1; i--) {
            float t = i / (float) LAYERS;                      // 1 = outermost layer
            int g = Math.round(grow * t);
            int a = Math.min(255, Math.round(str * 255f * 0.16f * (1.2f - t)));
            if (a <= 0) continue;
            int ww = w + g * 2, hh = h + g * 2;
            ClickGuiScreen.rrect(ctx, cx - ww / 2, cy - hh / 2, ww, hh, (a << 24) | rgb, Math.min(ww, hh) / 2);
        }
        int fa = Math.round((float) (frost.get() / 100.0) * 255f * mul);
        if (fa > 0) {
            int r = Math.min(w, h) / 2;
            ClickGuiScreen.rrect(ctx, cx - w / 2, cy - h / 2, w, h, (fa << 24) | 0xFFFFFF, r);
            // Glass rim: a brighter thin outline hugging the core.
            int ra = Math.min(255, fa * 2);
            ctx.fill(cx - w / 2 + r, cy - h / 2, cx + w / 2 - r, cy - h / 2 + 1, (ra << 24) | 0xFFFFFF);
        }
    }

    // ---- colors ----

    private int colorFor(boolean forItem, ItemStack stack) {
        return switch ((int) color.get()) {
            case 1 -> forItem ? itemColor(stack) : SKIN_TONES[(int) handTone.get() - 1];
            case 2 -> Theme.current().accent() & 0xFFFFFF;
            case 3 -> hsv((System.currentTimeMillis() % 4000L) / 4000f, 0.8f, 1f);
            default -> hsv((float) hue.get() / 360f, (float) sat.get(), (float) bri.get());
        };
    }

    /** The item's own color: dyed color, known material names, block map color, else a stable color per item id. */
    private static int itemColor(ItemStack stack) {
        var dyed = stack.get(DataComponentTypes.DYED_COLOR);
        if (dyed != null) return dyed.rgb() & 0xFFFFFF;
        String id = Registries.ITEM.getId(stack.getItem()).getPath();
        for (int i = 0; i < ITEM_KEYS.length; i++) if (id.contains(ITEM_KEYS[i])) return ITEM_COLORS[i];
        if (stack.getItem() instanceof BlockItem bi) {
            Block b = bi.getBlock();
            return b.getDefaultMapColor().color & 0xFFFFFF;
        }
        return hsv(Math.abs(id.hashCode() % 360) / 360f, 0.6f, 1f);
    }

    /** h, s, v in 0..1 -> 0xRRGGBB. */
    private static int hsv(float h, float s, float v) {
        float h6 = (h - (float) Math.floor(h)) * 6f;
        int i = (int) h6;
        float f = h6 - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
