package dev.deathclient.dlc.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.deathclient.dlc.SwingAnimationModule;
import dev.deathclient.dlc.ViewModelModule;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * First-person hand hooks. Arguments are picked by type, so the hooks do not depend on their order.
 * require = 0: if a method is missing in this build the hook is skipped and the module does nothing.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    /** View Model: shifts / scales the matrix before a first-person hand is drawn. */
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), require = 0)
    private void deathclientdlc$viewModel(CallbackInfo ci,
                                          @Local(argsOnly = true) Hand hand,
                                          @Local(argsOnly = true) MatrixStack matrices) {
        ViewModelModule.apply(hand, matrices);
    }

    /** Swing Animation: replaces vanilla's swing transform unless the mode is Default. */
    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$swing(CallbackInfo ci,
                                      @Local(argsOnly = true) MatrixStack matrices,
                                      @Local(argsOnly = true) Arm arm,
                                      @Local(argsOnly = true) float progress) {
        if (SwingAnimationModule.apply(matrices, arm, progress)) ci.cancel();
    }
}
