package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderTickCounter;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * HUD editor: while the chat is open every HUD element that registered itself this frame can be dragged with
 * the left mouse button. The mouse is polled here (no screen hooks), so it needs no mixin. HUD elements call
 * track() while they draw; this is the last HUD layer, so by then it knows every element's bounds.
 */
final class HudEdit {
    /** nx, ny: where the element's top-left corner should go; fdx, fdy: mouse movement since the last frame. */
    interface Dragger { void move(int nx, int ny, int fdx, int fdy, boolean shift); }

    private record El(int x, int y, int w, int h, boolean hand, Dragger drag) {}

    private static final List<El> FRAME = new ArrayList<>();
    private static int active = -1, grabDX, grabDY, lastMx, lastMy;
    private static boolean wasDown;

    private HudEdit() {}

    /** A plain element: dragging sets its top-left corner. */
    static void track(int x, int y, int w, int h, BiConsumer<Integer, Integer> setPos) {
        FRAME.add(new El(x, y, w, h, false, (nx, ny, fdx, fdy, shift) -> setPos.accept(nx, ny)));
    }

    /** A hand model (View Model editor) with its own drag behaviour. */
    static void trackHand(int x, int y, int w, int h, Dragger drag) {
        FRAME.add(new El(x, y, w, h, true, drag));
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient c = MinecraftClient.getInstance();
        boolean chat = c.player != null && c.currentScreen instanceof ChatScreen && !Hud.hidden && !c.options.hudHidden;
        if (!chat) { FRAME.clear(); active = -1; wasDown = false; return; }

        ViewModelModule.trackEditor(c);
        var win = c.getWindow();
        int sw = win.getScaledWidth(), sh = win.getScaledHeight();
        int mx = (int) (c.mouse.getX() * sw / (double) win.getWidth());
        int my = (int) (c.mouse.getY() * sh / (double) win.getHeight());
        boolean down = GLFW.glfwGetMouseButton(win.getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean shift = GLFW.glfwGetKey(win.getHandle(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(win.getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;

        if (down && !wasDown) {                               // press: grab the topmost element under the mouse
            active = -1;
            for (int i = FRAME.size() - 1; i >= 0; i--) {
                El e = FRAME.get(i);
                if (mx >= e.x && mx < e.x + e.w && my >= e.y && my < e.y + e.h) {
                    active = i;
                    grabDX = mx - e.x;
                    grabDY = my - e.y;
                    break;
                }
            }
        }
        if (!down) active = -1;
        if (down && active >= 0 && active < FRAME.size()) {
            El e = FRAME.get(active);
            int nx = Math.max(0, Math.min(sw - e.w, mx - grabDX));
            int ny = Math.max(0, Math.min(sh - e.h, my - grabDY));
            e.drag.move(nx, ny, mx - lastMx, my - lastMy, shift);
        }
        wasDown = down;
        lastMx = mx;
        lastMy = my;

        int accent = Theme.current().accent();
        for (int i = 0; i < FRAME.size(); i++) {
            El e = FRAME.get(i);
            boolean hover = mx >= e.x && mx < e.x + e.w && my >= e.y && my < e.y + e.h;
            int col = (i == active || hover) ? 0xFFFFFFFF : (accent & 0x00FFFFFF) | 0xA0000000;   // white outline on hover
            if (e.hand) drawArm(ctx, e.x, e.y, e.w, e.h);
            ctx.fill(e.x - 1, e.y - 1, e.x + e.w + 1, e.y, col);
            ctx.fill(e.x - 1, e.y + e.h, e.x + e.w + 1, e.y + e.h + 1, col);
            ctx.fill(e.x - 1, e.y, e.x, e.y + e.h, col);
            ctx.fill(e.x + e.w, e.y, e.x + e.w + 1, e.y + e.h, col);
        }
        FRAME.clear();                                            // rebuilt by the HUD layers next frame
    }

    /** A small first-person arm: skin hand on top, sleeve below, with a light left edge and a shaded right edge. */
    private static void drawArm(DrawContext ctx, int x, int y, int w, int h) {
        int pad = 3;
        int ax = x + pad, ay = y + pad, aw = w - 2 * pad, ah = h - 2 * pad;
        int handH = Math.round(ah * 0.42f);
        ClickGuiScreen.rect(ctx, ax, ay, aw, handH, 0xFFC9967A, true, false);                   // hand
        ClickGuiScreen.rect(ctx, ax, ay + handH, aw, ah - handH, 0xFF2C9AA8, false, true);     // sleeve
        ctx.fill(ax, ay + 1, ax + 2, ay + ah - 1, 0x30FFFFFF);                                  // light edge
        ctx.fill(ax + aw - 3, ay + 1, ax + aw, ay + ah - 1, 0x40000000);                        // shade
        ctx.fill(ax, ay + handH, ax + aw, ay + handH + 1, 0x50000000);                          // sleeve seam
        for (int k = 1; k < 3; k++) {                                                           // finger lines
            int fx = ax + k * aw / 3;
            ctx.fill(fx, ay + 2, fx + 1, ay + handH / 2, 0x30000000);
        }
    }
}
