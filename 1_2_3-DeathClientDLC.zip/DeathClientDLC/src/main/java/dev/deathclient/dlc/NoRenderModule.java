package dev.deathclient.dlc;

/**
 * No Render: switches off visual effects that get in the way.
 * Fire: the burning overlay on the screen edges. FOV effects: the field of view no longer changes with speed,
 * sprinting, slowness, bow draw or spyglass zoom. Potion effects: nausea wobble, blindness and darkness are not
 * shown (the effects still work, only the picture stays clear). The hooks are in the mixins: InGameOverlayRendererMixin,
 * AbstractClientPlayerEntityMixin, ClientPlayerEntityMixin and LivingEntityMixin.
 */
public class NoRenderModule extends Module {
    public final BoolSetting fire = add(new BoolSetting("Fire", true));
    public final BoolSetting fov = add(new BoolSetting("FOV effects", true));
    public final BoolSetting effects = add(new BoolSetting("Potion effects", true));

    public NoRenderModule() { super("No Render", Category.RENDER); }

    /** The module is on and the given option is set (null module = off). */
    public static boolean fire() { NoRenderModule m = ModuleManager.get(NoRenderModule.class); return m != null && m.isEnabled() && m.fire.get(); }
    public static boolean fov() { NoRenderModule m = ModuleManager.get(NoRenderModule.class); return m != null && m.isEnabled() && m.fov.get(); }
    public static boolean effects() { NoRenderModule m = ModuleManager.get(NoRenderModule.class); return m != null && m.isEnabled() && m.effects.get(); }
}
