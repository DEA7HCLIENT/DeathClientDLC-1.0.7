package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Account switcher window (offline nicknames). Matches the ClickGUI style. */
public class AccountsScreen extends Screen {
    private static final int AW = 300, AH = 236, RH = 20, PITCH = 24;
    private static final int WIN_BG = 0xF2101016, CARD_BG = 0xFF16161F, CARD_HOVER = 0xFF1F1F2A, FIELD = 0xFF22222E;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF8C8C99;
    private static final String ORIG = "\u0000orig";

    private final Screen parent;
    private String input = "";
    private double scroll;
    private String status = "";
    private long statusUntil;
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private long repeatAt;

    public AccountsScreen(Screen parent) {
        super(Text.literal("Accounts"));
        this.parent = parent;
    }

    private int ax() { return (width - AW) / 2; }
    private int ay() { return (height - AH) / 2; }
    private int listTop() { return ay() + 88; }
    private int listBottom() { return ay() + AH - 44; }

    private List<String> rows() {
        List<String> r = new ArrayList<>();
        r.add(ORIG);
        r.addAll(Accounts.list());
        return r;
    }

    private double maxScroll() { return Math.max(0, rows().size() * PITCH - (listBottom() - listTop())); }

    private void setStatus(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    private static int accent() { return Theme.current().accent(); }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    private void centered(DrawContext ctx, String s, int cx, int y, int color) {
        text(ctx, s, cx - textRenderer.getWidth(s) / 2, y, color);
    }

    // ------------------------------------------------------------------ typing

    private void poll() {
        if (client == null) return;
        long win = client.getWindow().getHandle();
        boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        for (int k = GLFW.GLFW_KEY_MINUS; k <= GLFW.GLFW_KEY_Z; k++) {
            boolean letter = k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z;
            boolean digit = k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9;
            boolean minus = k == GLFW.GLFW_KEY_MINUS;
            if (!(letter || digit || minus)) continue;
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (down && !prevKey[k] && input.length() < 16) {
                if (letter) input += (char) ((shift ? 'A' : 'a') + (k - GLFW.GLFW_KEY_A));
                else if (digit) input += (char) k;
                else if (shift) input += '_';
            }
            prevKey[k] = down;
        }
        int bs = GLFW.GLFW_KEY_BACKSPACE;
        boolean bsDown = GLFW.glfwGetKey(win, bs) == GLFW.GLFW_PRESS;
        if (bsDown) {
            if (!prevKey[bs]) { backspace(); repeatAt = now + 350; }
            else if (now >= repeatAt) { backspace(); repeatAt = now + 45; }
        }
        prevKey[bs] = bsDown;
        int en = GLFW.GLFW_KEY_ENTER;
        boolean enDown = GLFW.glfwGetKey(win, en) == GLFW.GLFW_PRESS;
        if (enDown && !prevKey[en]) addInput();
        prevKey[en] = enDown;
    }

    private void backspace() {
        if (!input.isEmpty()) input = input.substring(0, input.length() - 1);
    }

    private void addInput() {
        if (!Accounts.valid(input)) { setStatus("Ник: 3-16 символов, A-Z, 0-9, _"); return; }
        if (Accounts.add(input)) { setStatus("Добавлен: " + input); input = ""; }
        else setStatus("Такой ник уже есть");
    }

    private void use(String row) {
        try {
            if (row.equals(ORIG)) {
                Accounts.restoreOriginal();
                setStatus("Вернул оригинальный аккаунт");
            } else {
                Accounts.switchTo(row);
                setStatus("Теперь ты: " + row);
            }
        } catch (Exception e) {
            setStatus("Не удалось сменить аккаунт");
        }
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) super.renderBackground(ctx, mx, my, delta);
        else Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        poll();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        int x = ax(), y = ay(), acc = accent();

        ClickGuiScreen.rrect(ctx, x - 1, y - 1, AW + 2, AH + 2, 0x33FFFFFF, 7);
        ClickGuiScreen.rrect(ctx, x, y, AW, AH, WIN_BG, 6);

        text(ctx, "Аккаунты", x + 12, y + 10, WHITE);
        String cur = "Сейчас: " + Accounts.currentName();
        text(ctx, cur, x + AW - 12 - textRenderer.getWidth(cur), y + 10, MUTED);

        // Nickname field + Add
        int fy = y + 30;
        ClickGuiScreen.rrect(ctx, x + 12, fy, AW - 24 - 72, 18, FIELD, 5);
        String shown = input.isEmpty() ? "Введи ник..." : input + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        text(ctx, shown, x + 20, fy + 5, input.isEmpty() ? MUTED : WHITE);
        int bx = x + AW - 12 - 64;
        ClickGuiScreen.rrect(ctx, bx, fy, 64, 18, ClickGuiScreen.in(mx, my, bx, fy, 64, 18) ? acc : CARD_BG, 5);
        centered(ctx, "Добавить", bx + 32, fy + 5, WHITE);

        // Random nickname
        int ry = y + 54;
        ClickGuiScreen.rrect(ctx, x + 12, ry, 110, 18, ClickGuiScreen.in(mx, my, x + 12, ry, 110, 18) ? acc : CARD_BG, 5);
        centered(ctx, "Случайный ник", x + 12 + 55, ry + 5, WHITE);
        text(ctx, "Клик - войти, ПКМ или x - удалить", x + 130, ry + 5, 0xFF5E5E6B);

        // List
        text(ctx, "Сохранённые ники", x + 12, y + 76, MUTED);
        int lt = listTop(), lb = listBottom();
        ctx.enableScissor(x + 12, lt, x + AW - 12, lb);
        List<String> rows = rows();
        for (int i = 0; i < rows.size(); i++) {
            String row = rows.get(i);
            int yy = lt + i * PITCH - (int) scroll;
            if (yy + RH < lt || yy > lb) continue;
            boolean orig = row.equals(ORIG);
            boolean active = orig ? Accounts.usingOriginal() : (!Accounts.usingOriginal() && row.equals(Accounts.currentName()));
            boolean hover = ClickGuiScreen.in(mx, my, x + 12, lt, AW - 24, lb - lt) && ClickGuiScreen.in(mx, my, x + 12, yy, AW - 24, RH);
            ClickGuiScreen.rrect(ctx, x + 12, yy, AW - 24, RH, active ? ClickGuiScreen.mix(acc, 0xFF000000, 0.45f) : (hover ? CARD_HOVER : CARD_BG), 5);
            String label = orig ? "Оригинальный (" + Accounts.originalName() + ")" : row;
            text(ctx, label, x + 20, yy + 6, WHITE);
            if (active) text(ctx, "активен", x + AW - 20 - textRenderer.getWidth("активен") - (orig ? 0 : 14), yy + 6, MUTED);
            if (!orig) text(ctx, "x", x + AW - 12 - 12, yy + 6, hover ? WHITE : MUTED);
        }
        ctx.disableScissor();

        // Bottom: status / warning + Back
        boolean showStatus = System.currentTimeMillis() < statusUntil;
        text(ctx, showStatus ? status : "Только для серверов без лицензии", x + 12, y + AH - 22, showStatus ? 0xFFFFD866 : 0xFF5E5E6B);
        int by = y + AH - 28, bw = 70;
        ClickGuiScreen.rrect(ctx, x + AW - 12 - bw, by, bw, 18, ClickGuiScreen.in(mx, my, x + AW - 12 - bw, by, bw, 18) ? acc : CARD_BG, 5);
        centered(ctx, "Назад", x + AW - 12 - bw / 2, by + 5, WHITE);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        int x = ax(), y = ay();

        int bw = 70, by = y + AH - 28;
        if (btn == 0 && ClickGuiScreen.in(mx, my, x + AW - 12 - bw, by, bw, 18)) { close(); return true; }
        if (btn == 0 && ClickGuiScreen.in(mx, my, x + AW - 12 - 64, y + 30, 64, 18)) { addInput(); return true; }
        if (btn == 0 && ClickGuiScreen.in(mx, my, x + 12, y + 54, 110, 18)) {
            input = "Player" + (1000 + new Random().nextInt(9000));
            return true;
        }

        int lt = listTop(), lb = listBottom();
        if (ClickGuiScreen.in(mx, my, x + 12, lt, AW - 24, lb - lt)) {
            List<String> rows = rows();
            for (int i = 0; i < rows.size(); i++) {
                int yy = lt + i * PITCH - (int) scroll;
                if (!ClickGuiScreen.in(mx, my, x + 12, yy, AW - 24, RH)) continue;
                String row = rows.get(i);
                boolean orig = row.equals(ORIG);
                boolean onX = mx >= x + AW - 12 - 18;
                if (!orig && (btn == 1 || (btn == 0 && onX))) { Accounts.remove(row); return true; }
                if (btn == 0) use(row);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(scroll - verticalAmount * 14, maxScroll()));
        return true;
    }

    @Override
    public void close() { client.setScreen(parent); }
}
