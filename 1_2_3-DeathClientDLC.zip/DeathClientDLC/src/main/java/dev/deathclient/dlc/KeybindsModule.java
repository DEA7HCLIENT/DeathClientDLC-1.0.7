package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import java.util.ArrayList;
import java.util.List;

/** On-screen keybind list (custom font): every module that has a key, active ones bright, inactive ones dim. */
public class KeybindsModule extends Module {
    public final BoolSetting onlyActive = add(new BoolSetting("Only active", true));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 40, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;

    public KeybindsModule() { super("Keybinds", Category.MISC, true); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        KeybindsModule m = ModuleManager.get(KeybindsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;

        List<Module> rows = new ArrayList<>();
        for (Module mod : ModuleManager.all()) {
            if (mod.getKey() == -1 || mod == m) continue;
            if (m.onlyActive.get() && !mod.isEnabled()) continue;
            rows.add(mod);
        }
        if (rows.isEmpty()) return;

        var tr = c.textRenderer;
        String title = "Keybinds";
        int rowH = 12, pad = 6;
        int w = Fonts.width(tr, title);
        for (Module mod : rows) {
            w = Math.max(w, Fonts.width(tr, mod.getName()) + 14 + Fonts.width(tr, tag(mod)));
        }
        w += pad * 2;
        int h = 16 + rows.size() * rowH + 3;
        int x = (int) m.posX.get(), y = (int) m.posY.get();

        HudEdit.track(x, y, w, h, (nx, ny) -> { m.posX.set(nx); m.posY.set(ny); });
        ClickGuiScreen.rect(ctx, x, y, w, h, BG, true, true);
        ctx.fill(x, y + 14, x + w, y + 15, Theme.current().accent());
        Fonts.draw(ctx, tr, title, x + pad, y + 3, WHITE);

        int ry = y + 18;
        for (Module mod : rows) {
            int col = mod.isEnabled() ? WHITE : MUTED;
            Fonts.draw(ctx, tr, mod.getName(), x + pad, ry, col);
            String t = tag(mod);
            Fonts.draw(ctx, tr, t, x + w - pad - Fonts.width(tr, t), ry, mod.isEnabled() ? Theme.current().accent() : MUTED);
            ry += rowH;
        }
    }

    private static String tag(Module m) { return "[" + Binds.name(m.getKey()) + "]"; }
}
