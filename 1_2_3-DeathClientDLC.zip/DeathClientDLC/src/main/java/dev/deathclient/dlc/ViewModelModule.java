package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;

/**
 * First-person hands. Every hand has its own X / Y / Z offset and scale (applied by HeldItemRendererMixin).
 * With the chat open each hand shows as a small arm model: drag it to move the hand, Shift+drag to push it away or
 * pull it closer. The same values are sliders in the module settings.
 */
public class ViewModelModule extends Module {

    public final NumberSetting mainX = add(new NumberSetting("Main X", 0, -1.5, 1.5, 0.01));
    public final NumberSetting mainY = add(new NumberSetting("Main Y", 0, -1.5, 1.5, 0.01));
    public final NumberSetting mainZ = add(new NumberSetting("Main Z", 0, -2.0, 1.0, 0.01));
    public final NumberSetting mainScale = add(new NumberSetting("Main scale", 1, 0.3, 2.0, 0.05));
    public final NumberSetting offX = add(new NumberSetting("Off X", 0, -1.5, 1.5, 0.01));
    public final NumberSetting offY = add(new NumberSetting("Off Y", 0, -1.5, 1.5, 0.01));
    public final NumberSetting offZ = add(new NumberSetting("Off Z", 0, -2.0, 1.0, 0.01));
    public final NumberSetting offScale = add(new NumberSetting("Off scale", 1, 0.3, 2.0, 0.05));

    public ViewModelModule() { super("View Model", Category.RENDER); }

    /** GUI pixels per unit of offset: one unit at the hand's depth is about one screen height. */
    static double unit(MinecraftClient c) { return c.getWindow().getScaledHeight(); }

    /** Screen position of a resting hand (no offsets), in GUI pixels. */
    static double baseX(MinecraftClient c, boolean right) {
        return c.getWindow().getScaledWidth() / 2.0 + (right ? 1 : -1) * 0.45 * unit(c);
    }

    static double baseY(MinecraftClient c) { return c.getWindow().getScaledHeight() * 0.75; }

    /** Called by HeldItemRendererMixin before vanilla draws a hand; the matrix is in camera space. */
    public static void apply(Hand hand, MatrixStack m) {
        ViewModelModule v = ModuleManager.get(ViewModelModule.class);
        if (v == null || !v.isEnabled()) return;
        boolean main = hand == Hand.MAIN_HAND;
        float s = (float) (main ? v.mainScale.get() : v.offScale.get());
        boolean mainRight = MinecraftClient.getInstance().options.getMainArm().getValue() == Arm.RIGHT;
        float side = main == mainRight ? 1f : -1f;      // which side of the screen this hand is on
        m.translate(main ? v.mainX.get() : v.offX.get(), main ? v.mainY.get() : v.offY.get(), main ? v.mainZ.get() : v.offZ.get());
        // Scale around where the hand sits, not around the camera.
        m.translate(side * 0.56f, -0.52f, -0.72f);
        m.scale(s, s, s);
        m.translate(-side * 0.56f, 0.52f, 0.72f);
    }

    /** Adds the two draggable hand markers to the HUD editor (chat open). */
    static void trackEditor(MinecraftClient c) {
        ViewModelModule v = ModuleManager.get(ViewModelModule.class);
        if (v == null || !v.isEnabled()) return;
        final double K = unit(c);
        boolean mainRight = c.options.getMainArm().getValue() == Arm.RIGHT;
        for (int i = 0; i < 2; i++) {
            final boolean main = i == 0;
            final boolean right = main == mainRight;
            final NumberSetting sx = main ? v.mainX : v.offX, sy = main ? v.mainY : v.offY, sz = main ? v.mainZ : v.offZ;
            final int bw = 26, bh = 66;
            final double baseX = baseX(c, right), baseY = baseY(c);
            int cx = (int) (baseX + sx.get() * K), cy = (int) (baseY - sy.get() * K);
            HudEdit.trackHand(cx - bw / 2, cy - bh / 2, bw, bh,
                    (nx, ny, fdx, fdy, shift) -> {
                        if (shift) sz.set(sz.get() + fdy * 0.004);       // drag up = closer, down = farther
                        else {
                            sx.set((nx + bw / 2.0 - baseX) / K);
                            sy.set(-(ny + bh / 2.0 - baseY) / K);
                        }
                    });
        }
    }
}
