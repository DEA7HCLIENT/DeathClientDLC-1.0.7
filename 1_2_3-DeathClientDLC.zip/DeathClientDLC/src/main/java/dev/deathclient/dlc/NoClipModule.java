package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Disables block collision for the local player (gravity still applies). */
public class NoClipModule extends Module {
    public NoClipModule() { super("NoClip", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) { c.player.noClip = true; }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.noClip = false;
    }
}
