package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import java.util.ArrayList;
import java.util.List;

/**
 * Info HUD: a small panel with FPS, ping, coordinates (with facing) and speed in blocks per second.
 * The strip under the title is the theme colour, a gradient for the two- and three-colour themes.
 * Drag it with the left mouse button while the chat is open (HudEdit).
 */
public class InfoHudModule extends Module {
    public final BoolSetting showFps = add(new BoolSetting("FPS", true));
    public final BoolSetting showPing = add(new BoolSetting("Ping", true));
    public final BoolSetting showCoords = add(new BoolSetting("Coords", true));
    public final BoolSetting showSpeed = add(new BoolSetting("Speed", true));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 110, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;

    // Frame-time and speed sampling (smoothed), all updated from the HUD callback.
    private static long lastFrame, lastSample;
    private static double fps = 60, speed, lastX, lastZ;
    private static boolean haveSample;

    public InfoHudModule() { super("Info HUD", Category.MISC, true); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        InfoHudModule m = ModuleManager.get(InfoHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        long now = System.nanoTime();

        // FPS: exponential average of the frame time.
        if (lastFrame != 0) {
            double dt = (now - lastFrame) / 1.0e9;
            if (dt > 0 && dt < 1) fps += (1.0 / dt - fps) * 0.05;
        }
        lastFrame = now;

        // Speed: horizontal distance over at least 100 ms, smoothed.
        double px = c.player.getX(), pz = c.player.getZ();
        if (!haveSample) { lastX = px; lastZ = pz; lastSample = now; haveSample = true; }
        else if (now - lastSample >= 100_000_000L) {
            double dt = (now - lastSample) / 1.0e9;
            double v = Math.hypot(px - lastX, pz - lastZ) / dt;
            if (v > 200) v = speed;                                   // teleport / world change: ignore the jump
            speed += (v - speed) * 0.3;
            lastX = px; lastZ = pz; lastSample = now;
        }

        List<String[]> rows = new ArrayList<>();                      // {label, value, colour as hex}
        if (m.showFps.get()) rows.add(new String[]{"FPS", String.valueOf((int) Math.round(fps)), null});
        if (m.showPing.get()) {
            int ping = -1;
            var nh = c.getNetworkHandler();
            if (nh != null) {
                var e = nh.getPlayerListEntry(c.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            String col = ping < 0 ? null : ping < 80 ? "55FF55" : ping < 150 ? "FFD455" : "FF5555";
            rows.add(new String[]{"Ping", ping < 0 ? "-" : ping + " ms", col});
        }
        if (m.showCoords.get()) {
            String face = c.player.getHorizontalFacing().name().substring(0, 1);
            rows.add(new String[]{"XYZ", Math.round(px) + " " + Math.round(c.player.getY()) + " " + Math.round(pz) + "  " + face, null});
        }
        if (m.showSpeed.get()) rows.add(new String[]{"Speed", String.format("%.1f b/s", speed), null});
        if (rows.isEmpty()) return;

        var tr = c.textRenderer;
        String title = "Info";
        int pad = 6, rowH = 12;
        int w = Fonts.width(tr, title);
        for (String[] r : rows) w = Math.max(w, Fonts.width(tr, r[0]) + 12 + Fonts.width(tr, r[1]));
        w += pad * 2;
        int h = 16 + rows.size() * rowH + 3;
        int x = (int) m.posX.get(), y = (int) m.posY.get();

        HudEdit.track(x, y, w, h, (nx, ny) -> { m.posX.set(nx); m.posY.set(ny); });
        ClickGuiScreen.rect(ctx, x, y, w, h, BG, true, true);
        stripe(ctx, x, y + 14, w);
        Fonts.draw(ctx, tr, title, x + pad, y + 3, WHITE);

        int ry = y + 18;
        for (String[] r : rows) {
            Fonts.draw(ctx, tr, r[0], x + pad, ry, MUTED);
            int col = r[2] == null ? WHITE : 0xFF000000 | Integer.parseInt(r[2], 16);
            Fonts.draw(ctx, tr, r[1], x + w - pad - Fonts.width(tr, r[1]), ry, col);
            ry += rowH;
        }
    }

    /** 1 px line in the theme colour; gradient themes are drawn left to right in 2 px slices. */
    private static void stripe(DrawContext ctx, int x, int y, int w) {
        Theme t = Theme.current();
        if (!t.gradient()) { ctx.fill(x, y, x + w, y + 1, t.accent()); return; }
        for (int i = 0; i < w; i += 2) {
            ctx.fill(x + i, y, x + Math.min(w, i + 2), y + 1, t.at((i + 1f) / w));
        }
    }
}
