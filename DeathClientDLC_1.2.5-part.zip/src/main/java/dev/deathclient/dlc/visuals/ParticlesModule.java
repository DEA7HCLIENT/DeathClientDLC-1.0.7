package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Particles: little icons (stars, hearts, dollars, ...) burst out of the place where something happens. Pick when they appear
 * (Hit, Crit, Jump, Run), which icon ("All" = a mix), how many, whether they fly or fall and how far they scatter.
 * They are drawn on the screen with ScreenProjector (like the Jump Circle and China Hat), so only you see them.
 * The icons are textures/gui/particle/*.png (white; white on screen unless "Theme color" is on).
 * The hit trigger comes from Fabric's AttackEntityCallback, registered in DeathClientDLC.
 */
public class ParticlesModule extends Module {
    static final String[] TYPES = {"All", "Dollar", "Heart", "Dot", "Crown", "Lightning", "Dot 2", "Star", "Snowflake", "Crystal", "Star 2", "Lightning 2"};
    /** Texture of each type after "All", in the same order. */
    private static final String[] FILES = {"dollar", "heart", "dot", "crown", "bolt", "dot2", "star4", "snow", "crystal", "star5", "bolt2"};
    private static final Identifier[] TEX = new Identifier[FILES.length];
    static {
        for (int i = 0; i < FILES.length; i++) TEX[i] = Identifier.of("deathclientdlc", "textures/gui/particle/" + FILES[i] + ".png");
    }
    private static final int TEX_PX = 128, MAX_PARTICLES = 500;

    public final BoolSetting hit = add(new BoolSetting("Hit", true));
    public final BoolSetting crit = add(new BoolSetting("Crit", true));
    public final BoolSetting jump = add(new BoolSetting("Jump", false));
    public final BoolSetting run = add(new BoolSetting("Run", false));
    public final NumberSetting type = add(new NumberSetting("Particle", 1, 1, TYPES.length, 1).labels(TYPES));
    public final NumberSetting count = add(new NumberSetting("Count", 12, 1, 60, 1));
    public final NumberSetting motion = add(new NumberSetting("Motion", 1, 1, 2, 1).labels("Fly", "Fall"));
    public final NumberSetting spread = add(new NumberSetting("Spread (blocks)", 1.5, 0.5, 5.0, 0.1));
    public final NumberSetting size = add(new NumberSetting("Size", 0.18, 0.05, 0.6, 0.01));
    public final NumberSetting life = add(new NumberSetting("Lifetime (ticks)", 24, 8, 60, 1));
    public final BoolSetting spin = add(new BoolSetting("Spin", true));
    /** Off = white. On = a colour from the theme (its gradient, if the theme has one). */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    private static final class P {
        Vec3d origin, dir;
        int age, life, tex;
        float rot, rotSpeed;
        int rgb;
        double scale;
    }

    private final List<P> list = new ArrayList<>();
    private final Random rnd = new Random();
    private final ScreenProjector proj = new ScreenProjector();
    private boolean wasGround = true;

    public ParticlesModule() { super("Particles", Category.VISUALS); }

    @Override
    protected void onDisable() { list.clear(); }

    // ---- triggers ----

    /** Fabric AttackEntityCallback (see DeathClientDLC): you attacked an entity. */
    static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hitResult) {
        ParticlesModule m = ModuleManager.get(ParticlesModule.class);
        if (m == null || !m.isEnabled() || !world.isClient() || player != MinecraftClient.getInstance().player) return ActionResult.PASS;
        // The same conditions vanilla uses for a critical hit.
        boolean isCrit = player.fallDistance > 0.0 && !player.isOnGround() && !player.isClimbing() && !player.isTouchingWater()
                && !player.hasVehicle() && !player.isSprinting();
        Vec3d at = new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.6, entity.getZ());
        if (isCrit && m.crit.get()) m.burst(at.add(0, entity.getHeight() * 0.3, 0), (int) Math.round(m.count.get() * 1.3), false);
        else if (m.hit.get()) m.burst(at, (int) m.count.get(), false);
        return ActionResult.PASS;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        for (int i = list.size() - 1; i >= 0; i--) {
            P q = list.get(i);
            if (++q.age >= q.life) list.remove(i);
        }
        if (p == null) return;
        boolean ground = p.isOnGround();
        if (jump.get() && wasGround && !ground && p.getVelocity().y > 0.1) burst(new Vec3d(p.getX(), p.getY() + 0.1, p.getZ()), (int) count.get(), true);
        wasGround = ground;
        if (run.get() && p.isSprinting() && ground && p.age % 3 == 0) burst(new Vec3d(p.getX(), p.getY() + 0.1, p.getZ()), Math.max(1, (int) count.get() / 4), true);
    }

    /** Spawns n particles at origin. ground = they scatter sideways along the ground (jump, run) instead of in every direction. */
    private void burst(Vec3d origin, int n, boolean ground) {
        int sel = (int) Math.round(type.get()) - 1;
        Theme th = Theme.current();
        for (int i = 0; i < n && list.size() < MAX_PARTICLES; i++) {
            P q = new P();
            q.origin = origin;
            double ang = rnd.nextDouble() * Math.PI * 2;
            if (ground) {
                q.dir = new Vec3d(Math.cos(ang), 0.15 + rnd.nextDouble() * 0.35, Math.sin(ang)).multiply(0.5 + rnd.nextDouble() * 0.5);
            } else {
                double y = rnd.nextDouble() * 2 - 1, r = Math.sqrt(1 - y * y);
                q.dir = new Vec3d(r * Math.cos(ang), y * 0.8 + 0.1, r * Math.sin(ang)).multiply(0.5 + rnd.nextDouble() * 0.5);
            }
            q.life = (int) life.get() + rnd.nextInt(5);
            q.tex = sel <= 0 ? rnd.nextInt(TEX.length) : Math.min(sel - 1, TEX.length - 1);
            q.rot = rnd.nextFloat() * 6.2832f;
            q.rotSpeed = spin.get() ? (rnd.nextFloat() - 0.5f) * 0.3f : 0f;
            q.scale = 0.7 + rnd.nextDouble() * 0.6;
            q.rgb = themeColor.get() ? (th.at(rnd.nextFloat()) & 0xFFFFFF) : 0xFFFFFF;
            list.add(q);
        }
    }

    // ---- drawing ----

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ParticlesModule m = ModuleManager.get(ParticlesModule.class);
        if (m == null || !m.isEnabled() || m.list.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        boolean fall = motion.get() >= 1.5;
        double sp = spread.get(), baseSize = size.get();
        // far particles first, so the near ones are on top
        List<double[]> items = new ArrayList<>(list.size());
        List<P> src = new ArrayList<>(list);
        for (int i = 0; i < src.size(); i++) {
            P q = src.get(i);
            double age = q.age + delta, t = Math.min(1.0, age / q.life);
            double out = 1.0 - Math.pow(1.0 - t, 2.2);                           // flies out fast, then slows down
            double x = q.origin.x + q.dir.x * sp * out, z = q.origin.z + q.dir.z * sp * out;
            double y = q.origin.y + q.dir.y * sp * out + (fall ? -sp * 0.9 * t * t : sp * 0.25 * t);
            if (!proj.project(new Vec3d(x, y, z))) continue;
            double px = baseSize * q.scale * (0.6 + 0.4 * Math.min(1.0, t * 4)) * (1.0 - 0.3 * t)
                    * (proj.screenHeight() / 2.0) / (proj.tan * proj.out[2]);
            px = Math.max(3, Math.min(90, px));
            items.add(new double[]{proj.out[2], proj.out[0], proj.out[1], px, t, i});
        }
        items.sort((a, b) -> Double.compare(b[0], a[0]));
        var mat = ctx.getMatrices();
        for (double[] it : items) {
            P q = src.get((int) it[5]);
            double t = it[4];
            int a = (int) Math.round(255 * Math.max(0.0, 1.0 - t * t));
            if (a < 6) continue;
            int sz = (int) Math.round(it[3]);
            float rot = (float) (q.rot + q.rotSpeed * (q.age + delta));
            mat.pushMatrix();
            mat.translate((float) it[1], (float) it[2]);
            if (rot != 0f) mat.rotate(rot);
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEX[q.tex], -sz / 2, -sz / 2, 0f, 0f, sz, sz, TEX_PX, TEX_PX, TEX_PX, TEX_PX,
                    (a << 24) | q.rgb);
            mat.popMatrix();
        }
    }
}
