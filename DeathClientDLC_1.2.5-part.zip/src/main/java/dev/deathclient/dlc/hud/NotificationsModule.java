package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Notifications: small cards that slide in from the side for things the client wants to tell you (a module turned
 * on by a keybind, a friend joining, a module warning you about something) without having to watch the chat or the
 * module list. Call {@link #push} from anywhere in the client to show one; this module only draws the queue.
 */
public class NotificationsModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 120, 0, 1200, 1));
    public final NumberSetting duration = add(new NumberSetting("Duration", 3.0, 1.0, 8.0, 0.5));
    public final NumberSetting maxShown = add(new NumberSetting("Max shown", 4, 1, 8, 1));

    private static final int BG = 0xE0120C1E, WHITE = 0xFFFFFFFF, MUTED = 0xFFB9B2C8;
    private static final int SLIDE_TICKS = 6;

    private record Toast(String title, String message, long shownAt, int accent) {}
    private static final Deque<Toast> QUEUE = new ArrayDeque<>();

    public NotificationsModule() { super("Notifications", Category.MISC, true); }

    /** Shows a notification in the client's own theme colour. */
    public static void push(String title, String message) { push(title, message, -1); }

    /** Shows a notification in a specific colour (0xRRGGBB), e.g. red for a warning. -1 uses the theme accent. */
    public static void push(String title, String message, int accent) {
        synchronized (QUEUE) {
            QUEUE.addLast(new Toast(title, message, System.currentTimeMillis(), accent));
            while (QUEUE.size() > 20) QUEUE.pollFirst();                      // don't let it grow forever if unread
        }
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        NotificationsModule m = ModuleManager.get(NotificationsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        long now = System.currentTimeMillis();
        long life = (long) (duration.get() * 1000);
        List<Toast> live;
        synchronized (QUEUE) {
            QUEUE.removeIf(t -> now - t.shownAt() > life);
            live = new ArrayList<>(QUEUE);
        }
        int max = (int) maxShown.get();
        if (live.size() > max) live = live.subList(live.size() - max, live.size());

        var tr = c.textRenderer;
        int w = 180, rowH = 34, gap = 4, pad = 8;
        int x0 = (int) x.get(), y0 = (int) y.get();
        int accentDefault = Theme.current().accent() | 0xFF000000;
        for (int i = 0; i < live.size(); i++) {
            Toast t = live.get(i);
            long age = now - t.shownAt();
            float slide = Math.min(1f, age / (SLIDE_TICKS * 50f));
            long remaining = life - age;
            float fade = remaining < 400 ? Math.max(0f, remaining / 400f) : 1f;
            int ry = y0 + i * (rowH + gap);
            int rx = x0 - (int) ((1f - slide) * (w + 20));
            int acc = t.accent() == -1 ? accentDefault : (t.accent() | 0xFF000000);
            int alpha = Math.round(fade * 255);
            Shapes.panel(ctx, rx, ry, w, rowH, (alpha << 24) | (BG & 0xFFFFFF));
            ClickGuiScreen.outline(ctx, rx, ry, w, rowH, (Math.min(0xE0, alpha) << 24) | (acc & 0xFFFFFF), Shapes.corner(Shapes.shape()));
            ctx.fill(rx + 4, ry + 5, rx + 7, ry + rowH - 5, (alpha << 24) | (acc & 0xFFFFFF));
            Fonts.draw(ctx, tr, t.title(), rx + pad + 4, ry + 6, (alpha << 24) | 0xFFFFFF);
            Fonts.draw(ctx, tr, t.message(), rx + pad + 4, ry + 18, (Math.min(0xC0, alpha) << 24) | 0xFFFFFF);
        }
        int totalH = Math.max(1, live.size()) * (rowH + gap) - gap;
        HudEdit.track(x0, y0, w, totalH, (nx, ny) -> { x.set(nx); y.set(ny); });
    }
}
