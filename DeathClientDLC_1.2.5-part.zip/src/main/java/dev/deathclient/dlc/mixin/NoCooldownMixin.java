package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoCooldownModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No Cooldown: our own player always reads back a fully charged weapon. require = 0: safe if the method is renamed. */
@Mixin(PlayerEntity.class)
public abstract class NoCooldownMixin {
    @Inject(method = "getAttackCooldownProgress", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$noCooldown(float baseTime, CallbackInfoReturnable<Float> cir) {
        if (NoCooldownModule.active() && (Object) this == MinecraftClient.getInstance().player) cir.setReturnValue(1.0f);
    }
}
