package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Nuker: breaks every block in a cube around you (or around where you're looking), one at a time, without you
 * having to aim or hold the mouse down. Each block is broken the normal way (AuraRotation turns to it and the
 * module holds the mouse down on it across ticks, the same as actually mining it), so hardness and tool still
 * matter; this only removes the aiming and clicking.
 */
public class NukerModule extends Module {
    public final NumberSetting radius = add(new NumberSetting("Radius", 3, 1, 6, 1));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final BoolSetting aroundCrosshair = add(new BoolSetting("Around crosshair", false));
    public final BoolSetting autoTool = add(new BoolSetting("Auto tool", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    /** Skip blocks nothing drops from breaking by hand that you'd never mine on purpose. */
    public final BoolSetting skipUnbreakable = add(new BoolSetting("Skip bedrock etc.", true));

    private BlockPos current;

    public NukerModule() { super("Nuker", Category.MISC); }

    @Override
    protected void onDisable() { current = null; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null || c.currentScreen != null) return;

        BlockPos origin = BlockPos.ofFloored(aroundCrosshair.get() && c.crosshairTarget != null
                ? c.crosshairTarget.getPos() : p.getEyePos());
        int r = (int) radius.get();

        if (current != null && (!isTarget(c, p, current, origin, r))) current = null;
        if (current == null) current = pick(c, p, origin, r);
        if (current == null) return;

        if (autoTool.get()) selectTool(p, c.world.getBlockState(current));
        int rot = (int) rotation.get();
        AuraRotation.face(c, p, Vec3d.ofCenter(current), rot);
        c.interactionManager.updateBlockBreakingProgress(current, Direction.UP);
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, rot);
        if (c.world.getBlockState(current).isAir()) current = null;             // broken: pick a new one next tick
    }

    private boolean isTarget(MinecraftClient c, ClientPlayerEntity p, BlockPos pos, BlockPos origin, int r) {
        return !c.world.getBlockState(pos).isAir() && inRange(p, pos) && pos.isWithinDistance(origin, r + 0.6);
    }

    private BlockPos pick(MinecraftClient c, ClientPlayerEntity p, BlockPos origin, int r) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = origin.add(x, y, z);
            BlockState st = c.world.getBlockState(pos);
            if (st.isAir()) continue;
            if (skipUnbreakable.get() && st.getHardness(c.world, pos) < 0) continue;
            if (!inRange(p, pos)) continue;
            double d = p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos));
            if (d < bestD) { bestD = d; best = pos; }
        }
        return best;
    }

    private boolean inRange(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 36.0;      // 6 blocks, the vanilla reach
    }

    /** Picks the best hotbar tool for the block, the way AutoTool does. */
    private void selectTool(ClientPlayerEntity p, BlockState state) {
        int cur = p.getInventory().getSelectedSlot();
        int best = cur;
        float bestSpeed = p.getInventory().getStack(cur).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        if (best != cur) p.getInventory().setSelectedSlot(best);
    }
}
