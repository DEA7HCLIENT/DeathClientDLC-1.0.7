package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * TP Back: every tick, teleports you to a spot directly behind the nearest target, facing the same way they are -
 * so you end up on their back side, wherever they turn. The teleport distance (how far behind them you stand) is
 * a setting. It keeps re-teleporting every tick while a target is in range, so it tracks them as they move and turn.
 */
public class TpBackModule extends Module {
    private static final double STEP = 8.0;        // max blocks per movement packet; vanilla rejects bigger jumps

    public final NumberSetting range = add(new NumberSetting("Range", 15, 3, 40, 1));
    public final NumberSetting distance = add(new NumberSetting("Distance", 1.2, 0.3, 4.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting throughWalls = add(new BoolSetting("Through walls", false));
    public final NumberSetting rotation = add(AuraRotation.setting());

    public TpBackModule() { super("TP Back", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.currentScreen != null) return;

        LivingEntity target = nearest(c, p);
        if (target == null) return;

        double yaw = Math.toRadians(target.bodyYaw);
        double fwdX = -Math.sin(yaw), fwdZ = Math.cos(yaw);                // the direction the target is facing
        Vec3d tp = Util.pos(target);
        Vec3d goal = new Vec3d(tp.x - fwdX * distance.get(), tp.y, tp.z - fwdZ * distance.get());  // their back side

        Vec3d start = Util.pos(p);
        if (!throughWalls.get() && !isClear(c, p, start, goal)) return;

        for (Vec3d v : path(start, goal)) send(p, v, groundAt(c, p, v));
        p.setPosition(goal.x, goal.y, goal.z);

        int rot = (int) rotation.get();
        AuraRotation.face(c, p, Util.pos(target).add(0, target.getEyeHeight(target.getPose()) * 0.8, 0), rot);
        AuraRotation.restore(c, p, rot);
    }

    private LivingEntity nearest(MinecraftClient c, ClientPlayerEntity p) {
        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (p.distanceTo(le) <= range.get()) candidates.add(le);
        }
        candidates.sort(Comparator.comparingDouble(p::distanceTo));
        return candidates.isEmpty() ? null : candidates.get(0);
    }

    /** Points from (excluded) to to (included), at most STEP apart. */
    private static List<Vec3d> path(Vec3d from, Vec3d to) {
        double total = from.distanceTo(to);
        List<Vec3d> points = new ArrayList<>();
        int n = Math.max(1, (int) Math.ceil(total / STEP));
        for (int i = 1; i <= n; i++) points.add(from.lerp(to, (double) i / n));
        return points;
    }

    private static boolean isClear(MinecraftClient c, ClientPlayerEntity p, Vec3d from, Vec3d to) {
        for (Vec3d v : path(from, to)) {
            Box box = p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ());
            if (!c.world.isSpaceEmpty(box)) return false;
        }
        return true;
    }

    /** True when the player's box at v is free and has a block right below it. */
    private static boolean groundAt(MinecraftClient c, ClientPlayerEntity p, Vec3d v) {
        Box box = p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ());
        return c.world.isSpaceEmpty(box) && !c.world.isSpaceEmpty(box.offset(0, -0.05, 0));
    }

    private static void send(ClientPlayerEntity p, Vec3d v, boolean onGround) {
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(v.x, v.y, v.z, onGround, false));
    }
}
