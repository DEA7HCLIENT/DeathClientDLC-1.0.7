package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Criticals: a vanilla hit deals extra damage when you are falling (not on the ground, not swimming, climbing or
 * blind) at the moment it lands. This jumps you a split second before your weapon is ready, so the hit itself
 * lands on the way down and always counts as a critical, without you having to time the little hop yourself.
 */
public class CriticalsModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.2, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", false));
    /** Jump this many ticks before the weapon is ready, so you are already falling when the hit lands. */
    public final NumberSetting lead = add(new NumberSetting("Lead", 4, 1, 8, 1));

    public CriticalsModule() { super("Criticals", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.currentScreen != null || !p.isOnGround() || p.isTouchingWater()
                || p.isClimbing() || p.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.BLINDNESS)) return;
        if (!hasTarget(c, p)) return;

        float cd = p.getAttackCooldownProgress(0.5f);
        float ticksLeft = (1f - cd) / (1f / 20f);                 // rough ticks until the swing is back at 100%
        if (ticksLeft <= lead.get()) p.jump();
    }

    /** A valid target under the crosshair, or any valid target in range if that is not the case. */
    private boolean hasTarget(MinecraftClient c, ClientPlayerEntity p) {
        if (c.crosshairTarget instanceof EntityHitResult hit && accept(hit.getEntity(), p)) return true;
        for (Entity e : c.world.getEntities()) if (accept(e, p) && Util.reach(p, e) <= range.get()) return true;
        return false;
    }

    private boolean accept(Entity e, ClientPlayerEntity p) {
        if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) return false;
        if (playersOnly.get() && !(le instanceof PlayerEntity)) return false;
        return !Friends.skip(le);
    }
}
