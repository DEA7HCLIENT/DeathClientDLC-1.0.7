package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * W-Tap: for one tick around every hit you land, lets go of the forward key even if it's held, the way 1.8
 * players manually tapped W off and straight back on to cut the knockback they take. Same hit-detection caveat
 * as Sprint Reset: there is no "you just attacked" event here, so a cooldown reset is used as the signal.
 */
public class WTapModule extends Module {
    public final NumberSetting ticks = add(new NumberSetting("Ticks", 1, 1, 4, 1));

    private float lastCooldown = 1f;
    private int releaseFor;

    public WTapModule() { super("W-Tap", Category.COMBAT); }

    @Override
    protected void onDisable() { lastCooldown = 1f; releaseFor = 0; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) { lastCooldown = 1f; return; }
        float cd = p.getAttackCooldownProgress(0.5f);
        boolean justHit = lastCooldown > 0.9f && cd < 0.3f;
        lastCooldown = cd;
        if (justHit) releaseFor = (int) ticks.get();

        if (releaseFor > 0) {
            c.options.forwardKey.setPressed(false);
            releaseFor--;
        }
    }
}
