package dev.deathclient.dlc;

/**
 * No Cooldown: your weapon always shows as fully charged, the way it felt in 1.8, before attack cooldown existed.
 * This only changes what your own client believes and displays (the swing timing, the crosshair hit indicator,
 * your own view of the game); the server still applies its own combat rules and decides real damage, so this
 * does nothing on a server that enforces the modern cooldown itself.
 */
public class NoCooldownModule extends Module {
    private static NoCooldownModule instance;

    public NoCooldownModule() { super("No Cooldown", Category.COMBAT); instance = this; }

    /** Read by the mixin: true while this module should flatten the cooldown to 100%. */
    public static boolean active() { return instance != null && instance.isEnabled(); }
}
