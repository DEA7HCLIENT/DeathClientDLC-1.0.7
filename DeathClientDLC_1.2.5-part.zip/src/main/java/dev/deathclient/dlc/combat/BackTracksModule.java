package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Back Tracks: remembers where every nearby entity was over the last fraction of a second, so the combat modules
 * that call {@link Util#reach} (KillAura, TPAura, Crystal Aura, Hitbox, ...) measure their distance to a slightly
 * old position instead of this instant's. That papers over normal network lag: the position the server itself is
 * about to resolve your hit against is already a little old by the time it reaches you, so aiming at "a moment
 * ago" lands more often than aiming at "right now". It does not touch what gets sent to the server, only what the
 * other modules treat as the target's position.
 */
public class BackTracksModule extends Module {
    /** How far back to aim, in milliseconds. */
    public final NumberSetting delay = add(new NumberSetting("Delay", 150, 0, 400, 10));
    /** How long a position is kept once an entity is no longer tracked, so old entries don't pile up. */
    private static final long MAX_AGE_MS = 1000;

    private static final Map<UUID, Deque<long[]>> RAW = new HashMap<>();              // timestamp packed with index into POS
    private static final Map<UUID, Deque<Vec3d>> POS = new HashMap<>();

    private static BackTracksModule instance;

    public BackTracksModule() { super("Back Tracks", Category.COMBAT); instance = this; }

    @Override
    protected void onDisable() { RAW.clear(); POS.clear(); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.world == null || c.player == null) return;
        long now = System.currentTimeMillis();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == c.player) continue;
            Deque<long[]> times = RAW.computeIfAbsent(e.getUuid(), k -> new ArrayDeque<>());
            Deque<Vec3d> pos = POS.computeIfAbsent(e.getUuid(), k -> new ArrayDeque<>());
            times.addLast(new long[]{now});
            pos.addLast(Util.pos(e));
            while (!times.isEmpty() && now - times.peekFirst()[0] > MAX_AGE_MS) { times.pollFirst(); pos.pollFirst(); }
        }
        if (RAW.size() > 200) { RAW.clear(); POS.clear(); }                           // safety net, should not happen
    }

    /** The position Back Tracks says to use for {@code e} right now: delayed if enabled, its live position otherwise. */
    static Vec3d effectivePos(Entity e) {
        if (instance == null || !instance.isEnabled()) return Util.pos(e);
        Deque<long[]> times = RAW.get(e.getUuid());
        Deque<Vec3d> pos = POS.get(e.getUuid());
        if (times == null || times.isEmpty()) return Util.pos(e);
        long target = System.currentTimeMillis() - (long) instance.delay.get();
        return nearest(times, pos, target);
    }

    private static Vec3d nearest(Deque<long[]> times, Deque<Vec3d> pos, long target) {
        long[][] ts = times.toArray(new long[0][]);
        Vec3d[] ps = pos.toArray(new Vec3d[0]);
        Vec3d result = ps.length > 0 ? ps[ps.length - 1] : Vec3d.ZERO;
        for (int i = 0; i < ts.length; i++) {
            if (ts[i][0] >= target) { result = ps[i]; break; }
        }
        return result;
    }
}
