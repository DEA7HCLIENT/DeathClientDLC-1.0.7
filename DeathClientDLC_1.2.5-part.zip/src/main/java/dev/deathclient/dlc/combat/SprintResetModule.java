package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Sprint Reset: drops sprinting for the tick you land a hit, the way 1.8 players tapped a direction key to do by
 * hand. In 1.8-era combat, hitting while sprinting carries extra outgoing knockback onto the other player but
 * also extra knockback back onto you; cutting your own sprint right as the hit lands removes your side of that.
 * Detected from the weapon cooldown resetting (going from nearly full back down near 0) rather than a direct
 * "you just hit something" event, since the client has no such event to hook here.
 */
public class SprintResetModule extends Module {
    private float lastCooldown = 1f;

    public SprintResetModule() { super("Sprint Reset", Category.COMBAT); }

    @Override
    protected void onDisable() { lastCooldown = 1f; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) { lastCooldown = 1f; return; }
        float cd = p.getAttackCooldownProgress(0.5f);
        boolean justHit = lastCooldown > 0.9f && cd < 0.3f;
        lastCooldown = cd;
        if (justHit && p.isSprinting()) p.setSprinting(false);
    }
}
