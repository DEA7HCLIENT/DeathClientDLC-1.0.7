package dev.deathclient.dlc;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;

/**
 * Combo Counter: hits in a row. Every hit on a living entity adds one; the combo ends when you are hurt or when
 * you do not hit for Timeout seconds. Shows the current combo and the best one. Drag it while the chat is open.
 */
public class ComboCounterModule extends Module {
    public final NumberSetting timeout = add(new NumberSetting("Timeout (s)", 2.0, 0.5, 6.0, 0.5));
    public final BoolSetting best = add(new BoolSetting("Show best", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 248, 0, 1200, 1));

    private int combo, bestCombo;
    private long lastHit;
    private float lastHealth;

    public ComboCounterModule() {
        super("Combo Counter", Category.MISC);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (isEnabled() && world.isClient() && player == MinecraftClient.getInstance().player
                    && entity instanceof LivingEntity && (!playersOnly.get() || entity instanceof net.minecraft.entity.player.PlayerEntity)) {
                combo++;
                bestCombo = Math.max(bestCombo, combo);
                lastHit = System.currentTimeMillis();
            }
            return ActionResult.PASS;
        });
    }

    @Override
    protected void onDisable() { combo = 0; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) return;
        float hp = p.getHealth() + p.getAbsorptionAmount();
        if (hp < lastHealth - 0.01f) combo = 0;                                   // you were hurt: the combo is over
        lastHealth = hp;
        if (combo > 0 && System.currentTimeMillis() - lastHit > timeout.get() * 1000) combo = 0;
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ComboCounterModule m = ModuleManager.get(ComboCounterModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || Hud.hidden || c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        var tr = c.textRenderer;
        String text = combo > 0 ? "Combo x" + combo : "Combo -";
        String sub = best.get() ? "Best " + bestCombo : null;
        int w = Math.max(Fonts.width(tr, text), sub == null ? 0 : Fonts.width(tr, sub)) + 12;
        int h = sub == null ? 16 : 28;
        int x = (int) posX.get(), y = (int) posY.get();
        HudEdit.track(x, y, w, h, (nx, ny) -> { posX.set(nx); posY.set(ny); });
        Shapes.panel(ctx, x, y, w, h, 0xD0101010);
        int color = combo >= 10 ? 0xFFFF5555 : combo >= 5 ? 0xFFFFD24A : combo > 0 ? 0xFFFFFFFF : 0xFF909090;
        Fonts.draw(ctx, tr, text, x + 6, y + 4, color);
        if (sub != null) Fonts.draw(ctx, tr, sub, x + 6, y + 16, 0xFF909090);
    }
}
