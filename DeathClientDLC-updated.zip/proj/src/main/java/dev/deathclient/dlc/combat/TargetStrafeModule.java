package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Target Strafe (from the second client): circles the Kill Aura target.
 * <ul>
 *   <li>Matrix: sets your motion towards the next point of a circle / cube / spot behind the target every tick.</li>
 *   <li>Grim: does not touch your motion, it presses W/A/S/D for you (in {@link #apply}, called from KeyboardInputMixin)
 *       so that you walk to the next point of the walk circle / cube; movement stays vanilla.</li>
 * </ul>
 * The target is the one Kill Aura is aiming at, so turn Kill Aura on.
 */
public class TargetStrafeModule extends Module {
    public static final int MATRIX = 1, GRIM = 2;

    public final NumberSetting mode = add(new NumberSetting("Mode", MATRIX, 1, 2, 1).labels("Matrix", "Grim"));
    /** Grim: where it walks to. */
    public final NumberSetting walkPoint = add(new NumberSetting("Walk Point", 1, 1, 3, 1).labels("Cube", "Center", "Circle"));
    /** Matrix: shape of the path. */
    public final NumberSetting bypassPoint = add(new NumberSetting("Bypass Point", 2, 1, 2, 1).labels("Cube", "Circle"));
    public final NumberSetting walkRadius = add(new NumberSetting("Walk Radius", 0.87, 0.1, 1.5, 0.01));
    public final NumberSetting radius = add(new NumberSetting("Radius", 2.5, 0.1, 7.0, 0.1));
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.3, 0.1, 1.0, 0.01));
    public final BoolSetting autoJump = add(new BoolSetting("Auto Jump", true));
    public final BoolSetting onlyWhilePressing = add(new BoolSetting("Only While Pressing", false));
    /** Stay in front of the target instead of circling it. */
    public final BoolSetting front = add(new BoolSetting("Front", false));
    public final BoolSetting directionMode = add(new BoolSetting("Direction Mode", false));
    public final NumberSetting direction = add(new NumberSetting("Direction", 1, 1, 3, 1).labels("Clockwise", "Counter Clockwise", "Random"));

    private static TargetStrafeModule instance;
    private int pointIndex;

    public TargetStrafeModule() { super("Target Strafe", Category.MOVEMENT); instance = this; }

    @Override
    protected void onEnable() { pointIndex = 0; }

    private LivingEntity target() {
        KillAuraModule ka = ModuleManager.get(KillAuraModule.class);
        LivingEntity t = ka == null || !ka.isEnabled() ? null : ka.currentTarget();
        return t != null && t.isAlive() ? t : null;
    }

    private static boolean movementKey(MinecraftClient c) {
        var o = c.options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    private int dir() {
        if (directionMode.get()) {
            int d = (int) direction.get();
            if (d == 2) return -1;
            if (d == 3) return System.currentTimeMillis() / 3000L % 2L == 0L ? 1 : -1;
        }
        return 1;
    }

    // ---------------------------------------------------------------- Matrix: motion

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity t = target();
        if (p == null || t == null || (int) mode.get() != MATRIX) return;
        if (onlyWhilePressing.get() && !movementKey(c)) return;
        if (autoJump.get() && p.isOnGround()) p.jump();

        Vec3d pp = Util.pos(p), tp = Util.pos(t);
        double r = radius.get();
        int d = dir();
        if (front.get()) {
            double yaw = Math.toRadians(t.getYaw());
            moveTo(p, pp, tp.x - Math.sin(yaw) * r * d, tp.z + Math.cos(yaw) * r * d);
        } else if ((int) bypassPoint.get() == 1) {
            Vec3d next = normalPoint(pp, tp, r, d, 1);
            moveTo(p, pp, next.x, next.z);
        } else {
            double a = Math.atan2(pp.z - tp.z, pp.x - tp.x);
            a += d * speed.get() / Math.max(pp.distanceTo(tp), r);
            moveTo(p, pp, tp.x + r * Math.cos(a), tp.z + r * Math.sin(a));
        }
    }

    private void moveTo(ClientPlayerEntity p, Vec3d pp, double x, double z) {
        float yaw = (float) Math.toDegrees(Math.atan2(z - pp.z, x - pp.x)) - 90f;
        double s = speed.get();
        p.setVelocity(-Math.sin(Math.toRadians(yaw)) * s, p.getVelocity().y, Math.cos(Math.toRadians(yaw)) * s);
    }

    /** Cube: the four corners around the target (the next corner once you are within 0.5); Circle: a point running round it; else its centre. */
    private Vec3d normalPoint(Vec3d pp, Vec3d tp, double r, int d, int type) {
        if (type == 1) {
            Vec3d[] pts = {new Vec3d(tp.x - r, pp.y, tp.z - r), new Vec3d(tp.x - r, pp.y, tp.z + r),
                    new Vec3d(tp.x + r, pp.y, tp.z + r), new Vec3d(tp.x + r, pp.y, tp.z - r)};
            if (pp.distanceTo(pts[pointIndex]) < 0.5) pointIndex = (pointIndex + d + pts.length) % pts.length;
            return pts[pointIndex];
        } else if (type == 3) {
            double base = System.currentTimeMillis() % 3600L / 3600.0 * 4.0 * Math.PI;
            double a = d > 0 ? base : Math.PI * 2 - base;
            return new Vec3d(tp.x + Math.cos(a) * r, pp.y, tp.z + Math.sin(a) * r);
        }
        return new Vec3d(tp.x, pp.y, tp.z);
    }

    // ---------------------------------------------------------------- Grim: key presses

    /** The input of this tick with W/A/S/D chosen so that you walk to the next point (unchanged when Grim mode is off). */
    public static PlayerInput apply(PlayerInput in) {
        TargetStrafeModule m = instance;
        if (m == null || !m.isEnabled() || (int) m.mode.get() != GRIM) return in;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        LivingEntity t = m.target();
        if (p == null || t == null || c.currentScreen != null) return in;
        if (m.onlyWhilePressing.get() && !movementKey(c)) return in;

        Vec3d pp = Util.pos(p), tp = Util.pos(t);
        double r = m.walkRadius.get();
        int d = m.dir();
        Vec3d next;
        if (m.front.get()) {
            double yaw = Math.toRadians(t.getYaw());
            next = (int) m.walkPoint.get() == 2
                    ? tp.add(-Math.sin(yaw) * r * d, 0, Math.cos(yaw) * r * d)
                    : tp.add(-Math.sin(yaw) * r + Math.cos(yaw) * Math.cos(System.currentTimeMillis() / 500.0) * r * d, 0,
                            Math.cos(yaw) * r + Math.sin(yaw) * Math.cos(System.currentTimeMillis() / 500.0) * r * d);
        } else {
            next = m.normalPoint(pp, tp, r, d, (int) m.walkPoint.get() == 1 ? 1 : (int) m.walkPoint.get() == 3 ? 3 : 2);
        }
        Vec3d dv = next.subtract(pp);
        if (dv.lengthSquared() < 1.0E-6) return in;
        float yaw = ServerRotation.active() ? ServerRotation.yaw(1f) : p.getYaw();
        float diff = MathHelper.wrapDegrees((float) Math.toDegrees(Math.atan2(dv.z, dv.x)) - 90f - yaw);
        boolean fw = false, bk = false, lf = false, rt = false;
        if (diff >= -22.5f && diff < 22.5f) fw = true;
        else if (diff >= 22.5f && diff < 67.5f) { fw = true; rt = true; }
        else if (diff >= 67.5f && diff < 112.5f) rt = true;
        else if (diff >= 112.5f && diff < 157.5f) { bk = true; rt = true; }
        else if (diff >= -67.5f && diff < -22.5f) { fw = true; lf = true; }
        else if (diff >= -112.5f && diff < -67.5f) lf = true;
        else if (diff >= -157.5f && diff < -112.5f) { bk = true; lf = true; }
        else bk = true;
        boolean jump = in.jump() || (m.autoJump.get() && p.isOnGround());
        return new PlayerInput(fw, bk, lf, rt, jump, in.sneak(), in.sprint());
    }
}
