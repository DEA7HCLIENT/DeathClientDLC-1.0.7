package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AutoClicker (1.8 style): while you hold the attack key with the crosshair on a living entity, it keeps hitting by
 * itself at a random speed between Min CPS and Max CPS, with a little jitter in the gaps. Nothing happens while you
 * look at blocks or air, so mining is not affected.
 */
public class AutoClickerModule extends Module {
    public final NumberSetting minCps = add(new NumberSetting("Min CPS", 8, 1, 20, 1));
    public final NumberSetting maxCps = add(new NumberSetting("Max CPS", 13, 1, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", false));

    private long nextAt;

    public AutoClickerModule() { super("AutoClicker", Category.COMBAT); }

    @Override
    protected void onDisable() { nextAt = 0; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null || c.currentScreen != null) return;
        if (!c.options.attackKey.isPressed()) return;
        if (!(c.crosshairTarget instanceof EntityHitResult h) || !(h.getEntity() instanceof LivingEntity le) || !le.isAlive()) return;
        if (playersOnly.get() && !(le instanceof net.minecraft.entity.player.PlayerEntity)) return;
        long now = System.currentTimeMillis();
        if (now < nextAt) return;
        c.interactionManager.attackEntity(p, le);
        p.swingHand(Hand.MAIN_HAND);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double lo = Math.min(minCps.get(), maxCps.get()), hi = Math.max(minCps.get(), maxCps.get());
        double cps = lo + r.nextDouble() * (hi - lo);
        nextAt = now + (long) (1000.0 / cps * (0.9 + r.nextDouble() * 0.2));
    }
}
