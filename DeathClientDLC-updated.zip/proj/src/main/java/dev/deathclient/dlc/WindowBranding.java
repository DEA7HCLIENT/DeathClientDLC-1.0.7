package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * Renames the OS window to "DeathClient" and swaps its taskbar / title-bar icon for the "DC" logo. The icon comes in several
 * sizes (assets/deathclientdlc/icon_16x16.png ... icon_256x256.png) and the system picks the one that fits. It shows in
 * windowed mode (in full screen there is no title bar); macOS ignores window icons.
 */
public final class WindowBranding {
    private static final int[] SIZES = {16, 32, 48, 64, 128, 256};

    private WindowBranding() {}

    public static void apply(MinecraftClient client) {
        long handle = client.getWindow().getHandle();
        GLFW.glfwSetWindowTitle(handle, "DeathClient");

        // The pixel data must stay alive until GLFW has copied it, so it is kept here and freed afterwards.
        List<ByteBuffer> pixels = new ArrayList<>();
        List<int[]> dims = new ArrayList<>();
        for (int s : SIZES) {
            try (InputStream in = WindowBranding.class.getResourceAsStream("/assets/deathclientdlc/icon_" + s + "x" + s + ".png")) {
                if (in == null) continue;
                BufferedImage img = ImageIO.read(in);
                int w = img.getWidth(), h = img.getHeight();
                ByteBuffer buf = MemoryUtil.memAlloc(w * h * 4);
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        int p = img.getRGB(x, y);
                        buf.put((byte) ((p >> 16) & 0xFF)).put((byte) ((p >> 8) & 0xFF)).put((byte) (p & 0xFF)).put((byte) ((p >> 24) & 0xFF));
                    }
                }
                buf.flip();
                pixels.add(buf);
                dims.add(new int[]{w, h});
            } catch (Exception ignored) {
                // a missing or broken size is skipped
            }
        }
        try (MemoryStack stack = MemoryStack.stackPush()) {
            if (!pixels.isEmpty()) {
                GLFWImage.Buffer icons = GLFWImage.malloc(pixels.size(), stack);
                for (int i = 0; i < pixels.size(); i++) icons.get(i).set(dims.get(i)[0], dims.get(i)[1], pixels.get(i));
                GLFW.glfwSetWindowIcon(handle, icons);
            }
        } catch (Exception ignored) {
        } finally {
            for (ByteBuffer b : pixels) MemoryUtil.memFree(b);
        }
    }
}
