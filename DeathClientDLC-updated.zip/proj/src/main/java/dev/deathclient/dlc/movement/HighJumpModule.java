package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** HighJump: the vertical speed of every jump is raised to Power (the normal jump is about 0.42). */
public class HighJumpModule extends Module {
    public final NumberSetting power = add(new NumberSetting("Power", 0.7, 0.45, 1.5, 0.05));
    private boolean boosted;

    public HighJumpModule() { super("HighJump", Category.MOVEMENT); }

    @Override
    protected void onDisable() { boosted = false; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) return;
        if (p.isOnGround()) { boosted = false; return; }
        Vec3d v = p.getVelocity();
        if (!boosted && v.y > 0.38 && v.y < 0.5 && p.fallDistance <= 0.1f) {   // the first tick of a jump
            p.setVelocity(v.x, power.get(), v.z);
            boosted = true;
        }
    }
}
