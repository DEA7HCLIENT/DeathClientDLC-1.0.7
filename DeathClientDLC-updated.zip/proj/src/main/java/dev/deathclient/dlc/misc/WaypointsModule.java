package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Waypoints: saved places drawn on the screen with their name and distance (only in the dimension they were made in).
 * Manage them with chat commands: .wp add <name>, .wp del <name>, .wp list, .wp clear. They are kept in
 * config/deathclient/waypoints.txt.
 */
public class WaypointsModule extends Module {
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    /** 0 = no limit. */
    public final NumberSetting maxDistance = add(new NumberSetting("Max distance", 0, 0, 5000, 50));

    private static final class Wp {
        final String name, dim;
        final double x, y, z;
        Wp(String name, String dim, double x, double y, double z) { this.name = name; this.dim = dim; this.x = x; this.y = y; this.z = z; }
    }

    private static final List<Wp> LIST = new CopyOnWriteArrayList<>();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclient").resolve("waypoints.txt");

    private final ScreenProjector proj = new ScreenProjector();

    public WaypointsModule() { super("Waypoints", Category.VISUALS); }

    // ---- storage ----

    public static void load() {
        LIST.clear();
        try {
            if (!Files.exists(FILE)) return;
            for (String line : Files.readAllLines(FILE)) {
                String[] t = line.split("\t");
                if (t.length < 5) continue;
                LIST.add(new Wp(t[1], t[0], Double.parseDouble(t[2]), Double.parseDouble(t[3]), Double.parseDouble(t[4])));
            }
        } catch (Exception ignored) { }
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            List<String> out = new ArrayList<>();
            for (Wp w : LIST) out.add(w.dim + "\t" + w.name + "\t" + w.x + "\t" + w.y + "\t" + w.z);
            Files.write(FILE, out);
        } catch (Exception ignored) { }
    }

    private static String dimension(MinecraftClient c) {
        return c.world.getRegistryKey().getValue().toString();
    }

    /** Saves your current position under this name (an existing point with the same name in this dimension is replaced). */
    public static boolean add(String name) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null) return false;
        String dim = dimension(c);
        LIST.removeIf(w -> w.name.equalsIgnoreCase(name) && w.dim.equals(dim));
        LIST.add(new Wp(name, dim, c.player.getX(), c.player.getY(), c.player.getZ()));
        save();
        return true;
    }

    public static boolean remove(String name) {
        boolean r = LIST.removeIf(w -> w.name.equalsIgnoreCase(name));
        if (r) save();
        return r;
    }

    public static void clear() { LIST.clear(); save(); }

    public static List<String> describe() {
        List<String> out = new ArrayList<>();
        for (Wp w : LIST) out.add(w.name + " (" + Math.round(w.x) + " " + Math.round(w.y) + " " + Math.round(w.z) + ")");
        return out;
    }

    // ---- drawing ----

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        WaypointsModule m = ModuleManager.get(WaypointsModule.class);
        if (m == null || !m.isEnabled() || LIST.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        String dim = dimension(c);
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int accent = 0xFF000000 | Theme.current().accent();
        Vec3d me = c.player.getLerpedPos(delta);
        double max = maxDistance.get();
        var tr = c.textRenderer;
        for (Wp w : LIST) {
            if (!w.dim.equals(dim)) continue;
            Vec3d at = new Vec3d(w.x, w.y + 1.0, w.z);
            double dist = me.distanceTo(at);
            if (max > 0 && dist > max) continue;
            if (!proj.project(at)) continue;
            int x = (int) proj.out[0], y = (int) proj.out[1];
            if (x < 0 || x > sw || y < 0 || y > sh) continue;
            String label = showDistance.get() ? w.name + "  " + Math.round(dist) + "m" : w.name;
            int tw = tr.getWidth(label) + 8;
            ctx.fill(x - tw / 2, y - 22, x + tw / 2, y - 10, 0x90000000);
            ctx.drawCenteredTextWithShadow(tr, label, x, y - 20, 0xFFFFFFFF);
            ctx.fill(x - 3, y - 3, x + 3, y + 3, accent);          // the marker itself
        }
    }
}
