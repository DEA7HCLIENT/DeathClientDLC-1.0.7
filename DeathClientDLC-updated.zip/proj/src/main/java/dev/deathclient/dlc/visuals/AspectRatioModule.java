package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;

/**
 * Aspect Ratio (from the second client): stretches or squeezes the 3D world as if the window had another aspect ratio
 * (1.0 = square, 1.78 = 16:9, 2.0 = wide). Only the world projection changes; the menu and HUD stay as they are.
 * The work is done by GameRendererMixin through {@link #adjust}.
 */
public class AspectRatioModule extends Module {
    private static AspectRatioModule instance;
    public final NumberSetting ratio = add(new NumberSetting("Ratio", 1.5, 1.0, 2.0, 0.01));

    public AspectRatioModule() { super("Aspect Ratio", Category.RENDER); instance = this; }

    /** The projection matrix with the aspect ratio of the setting; the same matrix when the module is off. */
    public static Matrix4f adjust(Matrix4f projection) {
        AspectRatioModule m = instance;
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c == null || c.getWindow() == null) return projection;
        int w = c.getWindow().getFramebufferWidth(), h = c.getWindow().getFramebufferHeight();
        if (w <= 0 || h <= 0) return projection;
        float current = (float) w / h;
        float target = (float) m.ratio.get();
        if (target <= 1.0E-4f || Math.abs(current - target) <= 1.0E-4f) return projection;
        Matrix4f out = new Matrix4f(projection);
        out.m00(out.m00() * (current / target));
        return out;
    }
}
