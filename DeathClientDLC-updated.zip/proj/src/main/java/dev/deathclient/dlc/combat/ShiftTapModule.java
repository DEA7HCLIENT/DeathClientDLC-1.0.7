package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

/** Shift Tap (from the second client): every hit on a living entity makes you sneak for a moment (the sneak flag of the input, see KeyboardInputMixin). */
public class ShiftTapModule extends Module {
    private static ShiftTapModule instance;
    private long until;

    public ShiftTapModule() { super("Shift Tap", Category.COMBAT); instance = this; }

    /** AttackEntityCallback. */
    static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        ShiftTapModule m = instance;
        if (m != null && m.isEnabled() && world.isClient() && entity instanceof LivingEntity) m.until = System.currentTimeMillis() + 60;
        return ActionResult.PASS;
    }

    @Override
    protected void onDisable() { until = 0; }

    public static PlayerInput apply(PlayerInput in) {
        ShiftTapModule m = instance;
        if (m == null || !m.isEnabled() || System.currentTimeMillis() > m.until || in.sneak()) return in;
        return new PlayerInput(in.forward(), in.backward(), in.left(), in.right(), in.jump(), true, in.sprint());
    }
}
