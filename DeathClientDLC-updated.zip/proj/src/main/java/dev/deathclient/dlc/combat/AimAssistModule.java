package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Aim Assist (from the second client): pulls your view (yaw only) to the best target in range. The turn follows the
 * remaining angle with smoothing, is limited by Speed per frame, has a random per-target personality (speed factor,
 * a slow sine wobble, an aim point that drifts inside the hitbox) and never overshoots. It runs every rendered frame
 * (from the HUD callback), with the tick as a fallback.
 */
public class AimAssistModule extends Module {
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting nakedPlayers = add(new BoolSetting("Naked Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    public final BoolSetting animals = add(new BoolSetting("Animals", true));
    public final BoolSetting friends = add(new BoolSetting("Friends", false));
    public final BoolSetting armorStands = add(new BoolSetting("Armor Stands", false));
    public final NumberSetting distance = add(new NumberSetting("Distance", 6.0, 1.0, 6.0, 0.1));
    public final NumberSetting fov = add(new NumberSetting("FOV", 360, 20, 360, 1));
    public final BoolSetting showFov = add(new BoolSetting("Show FOV", false));
    public final NumberSetting speed = add(new NumberSetting("Speed", 4.0, 0.5, 10.0, 0.1));
    public final NumberSetting smoothness = add(new NumberSetting("Smoothness", 6.0, 1.0, 10.0, 0.1));
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1).labels("Distance", "Health"));
    public final BoolSetting onlyWeapon = add(new BoolSetting("Only Weapon", false));
    public final BoolSetting onlyPlayers = add(new BoolSetting("Only Players", false));
    public final BoolSetting noInventoryAim = add(new BoolSetting("No Inventory Aim", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", false));
    public final BoolSetting onlyArmored = add(new BoolSetting("Only Armored", false));
    public final BoolSetting ignoreNaked = add(new BoolSetting("Ignore Naked", false));
    public final BoolSetting wallCheck = add(new BoolSetting("Wall Check", false));

    private static final double AIM_HEIGHT = 0.85;

    private LivingEntity target;
    private long targetAcquiredAtMs, lastFrameNs, lastRenderAimNs;
    private double prevYawStep, prevPitchStep, yawVel, pitchVel;
    private double yawPhase, pitchPhase, yawWaveSpeed, pitchWaveSpeed, speedMul, heightNoise;
    private long nextHeightNoiseMs;
    private double curX, curY, curZ, nextX, nextY, nextZ, pointLerp;
    private long nextPointAtMs;

    public AimAssistModule() { super("AimAssist", Category.COMBAT); resetMotion(); }

    @Override
    protected void onEnable() { resetMotion(); }

    @Override
    protected void onDisable() { resetMotion(); }

    @Override
    public void onTick(MinecraftClient c) {
        long now = System.nanoTime();
        if (lastRenderAimNs == 0L || now - lastRenderAimNs > 75_000_000L) update(c);
    }

    /** HUD callback (every frame, see DeathClientDLC): aims, then draws the FOV circle. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        AimAssistModule m = ModuleManager.get(AimAssistModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        m.lastRenderAimNs = System.nanoTime();
        m.update(c);
        if (m.showFov.get() && !Hud.hidden && !c.options.hudHidden && c.currentScreen == null) m.drawFov(ctx, c);
    }

    // ---------------------------------------------------------------- aiming

    private void update(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) { resetMotion(); return; }
        if ((onlyWeapon.get() && !holdingWeapon(p)) || (noInventoryAim.get() && c.currentScreen instanceof HandledScreen<?>)) { resetMotion(); return; }
        long frameNs = System.nanoTime();
        double frameScale = lastFrameNs > 0L ? (frameNs - lastFrameNs) / 1.66666667E7 : 1.0;
        frameScale = MathHelper.clamp(frameScale, 0.05, 3.0);
        lastFrameNs = frameNs;
        LivingEntity t = find(c, p);
        if (t == null) { resetMotion(); return; }
        long nowMs = System.currentTimeMillis();
        if (t != target) { target = t; targetAcquiredAtMs = nowMs; randomizeProfile(nowMs); }
        humanize(nowMs, frameScale);
        rotate(p, t, frameScale, nowMs);
    }

    private void rotate(ClientPlayerEntity p, LivingEntity t, double frameScale, long nowMs) {
        Vec3d delta = aimPoint(t).subtract(p.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        if (horizontal < 1.0E-4) return;
        float curYaw = p.getYaw();
        double targetYaw = Math.toDegrees(Math.atan2(-delta.x, delta.z));
        double yawDiff = MathHelper.wrapDegrees(targetYaw - curYaw);
        double response = MathHelper.clamp(1.0 / smoothness.get(), 0.08, 1.0);
        double maxYawStep = Math.max(0.35, speed.get() * frameScale * speedMul);
        double follow = MathHelper.clamp(0.18 * frameScale + response * 0.45, 0.08, 1.0);
        yawVel = smooth(yawVel, yawDiff * response, follow);
        pitchVel = smooth(pitchVel, 0.0, follow);                                    // yaw only: pitch is left to you
        double yawStep = MathHelper.clamp(yawVel, -maxYawStep, maxYawStep);
        double seconds = (nowMs - targetAcquiredAtMs) / 1000.0;
        yawStep += Math.sin(yawPhase + seconds * yawWaveSpeed * 6.0) * 0.08 * frameScale;      // micro movements
        yawStep = clampToRemaining(clampStep(yawStep, prevYawStep, maxYawStep * 0.9), yawDiff);
        if (Math.abs(yawDiff) < 0.02) yawStep = yawDiff;
        float newYaw = curYaw + (float) yawStep;
        if (!Float.isNaN(newYaw)) {
            p.setYaw(newYaw);
            prevYawStep = yawStep;
            prevPitchStep = 0.0;
        }
    }

    private LivingEntity find(MinecraftClient c, ClientPlayerEntity p) {
        double max = distance.get(), halfFov = fov.get() / 2.0;
        boolean health = (int) priority.get() == 2;
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(p, e, le)) continue;
            double d = p.distanceTo(e);
            if (d > max || d < 0.5) continue;
            if (wallCheck.get() && blocked(c, p, eye, aimPoint(e))) continue;
            double ang = angleTo(p, eye, e);
            if (ang > halfFov) continue;
            double score = health ? le.getHealth() + d * 0.05 : d + ang * 0.01;
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }

    private boolean valid(ClientPlayerEntity p, Entity e, LivingEntity le) {
        if (e == p || !e.isAlive() || le.isInvulnerable() || le.getHealth() <= 0f) return false;
        if (onlyPlayers.get() && !(e instanceof PlayerEntity)) return false;
        if (!invisible.get() && le.isInvisible()) return false;
        if (e instanceof PlayerEntity pl) {
            if (AntiBotModule.isBot(pl)) return false;
            if (!players.get() || pl.isSpectator()) return false;
            boolean armor = hasArmor(le);
            if (!nakedPlayers.get() && !armor) return false;
            if (onlyArmored.get() && !armor) return false;
            if (ignoreNaked.get() && !armor) return false;
            return !Friends.isFriend(pl) || friends.get();
        }
        if (e instanceof AnimalEntity) return animals.get();
        if (e instanceof MobEntity) return mobs.get();
        return e instanceof ArmorStandEntity && armorStands.get();
    }

    private Vec3d aimPoint(Entity e) {
        double h = AIM_HEIGHT + heightNoise + curY;
        double r = e.getWidth() * 0.5;
        return new Vec3d(e.getX() + curX * r, e.getY() + e.getHeight() * MathHelper.clamp(h, 0.05, 0.95), e.getZ() + curZ * r);
    }

    private double angleTo(ClientPlayerEntity p, Vec3d eye, Entity e) {
        Vec3d v = aimPoint(e).subtract(eye);
        double len = v.length();
        if (len < 0.001) return 0.0;
        double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
        double lx = -Math.sin(yaw) * Math.cos(pitch), ly = -Math.sin(pitch), lz = Math.cos(yaw) * Math.cos(pitch);
        double dot = (lx * v.x + ly * v.y + lz * v.z) / len;
        return Math.toDegrees(Math.acos(MathHelper.clamp(dot, -1.0, 1.0)));
    }

    private static boolean holdingWeapon(ClientPlayerEntity p) {
        ItemStack s = p.getMainHandStack();
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    private static boolean hasArmor(LivingEntity e) {
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!e.getEquippedStack(s).isEmpty()) return true;
        }
        return false;
    }

    private static boolean blocked(MinecraftClient c, ClientPlayerEntity p, Vec3d from, Vec3d to) {
        BlockHitResult hit = c.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (hit.getType() == HitResult.Type.MISS) return false;
        var state = c.world.getBlockState(hit.getBlockPos());
        return state.isSolidBlock(c.world, hit.getBlockPos()) && state.isFullCube(c.world, hit.getBlockPos());
    }

    // ---------------------------------------------------------------- humanization / state

    private void humanize(long nowMs, double frameScale) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (nowMs >= nextHeightNoiseMs) { heightNoise = r.nextDouble(-0.02, 0.02); nextHeightNoiseMs = nowMs + r.nextLong(180L, 450L); }
        if (nowMs >= nextPointAtMs) randomizePoint(nowMs);
        double f = MathHelper.clamp(pointLerp * frameScale, 0.01, 1.0);
        curX += (nextX - curX) * f;
        curY += (nextY - curY) * f;
        curZ += (nextZ - curZ) * f;
    }

    private void randomizeProfile(long nowMs) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        yawPhase = r.nextDouble(Math.PI * 2);
        pitchPhase = r.nextDouble(Math.PI * 2);
        yawWaveSpeed = r.nextDouble(0.08, 0.25);
        pitchWaveSpeed = r.nextDouble(0.06, 0.2);
        speedMul = r.nextDouble(0.75, 1.25);
        heightNoise = r.nextDouble(-0.02, 0.02);
        nextHeightNoiseMs = nowMs + r.nextLong(180L, 450L);
        randomizePoint(nowMs);
    }

    private void randomizePoint(long nowMs) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        nextX = r.nextDouble(-0.35, 0.35);
        nextY = r.nextDouble(-0.12, 0.12);
        nextZ = r.nextDouble(-0.35, 0.35);
        nextPointAtMs = nowMs + r.nextLong(600L, 1900L);
        pointLerp = r.nextDouble(0.008, 0.025);
    }

    private void resetMotion() {
        target = null;
        targetAcquiredAtMs = 0L; lastFrameNs = 0L; lastRenderAimNs = 0L;
        prevYawStep = prevPitchStep = yawVel = pitchVel = 0.0;
        curX = curY = curZ = nextX = nextY = nextZ = 0.0;
        nextPointAtMs = 0L;
        randomizeProfile(System.currentTimeMillis());
    }

    private static double clampStep(double value, double prev, double maxDelta) {
        double d = value - prev;
        return Math.abs(d) > maxDelta ? prev + Math.signum(d) * maxDelta : value;
    }

    private static double smooth(double prev, double tgt, double resp) {
        double r = MathHelper.clamp(resp, 0.05, 1.0);
        return prev + (tgt - prev) * r;
    }

    private static double clampToRemaining(double step, double remaining) {
        return Math.abs(step) > Math.abs(remaining) ? remaining : step;
    }

    // ---------------------------------------------------------------- FOV circle

    /** The targets taken have an angle from the crosshair below FOV / 2: on screen a circle of radius (h/2) * tan(FOV/2) / tan(game FOV/2). */
    private void drawFov(DrawContext ctx, MinecraftClient c) {
        double half = fov.get() / 2.0;
        if (half >= 85.0) return;
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        double tanGame = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double r = (sh / 2.0) * Math.tan(Math.toRadians(half)) / tanGame;
        if (r < 3 || r > 4000) return;
        int color = target != null ? 0xFF55FF55 : 0xB0000000 | Theme.current().accent();
        double cx = sw / 2.0, cy = sh / 2.0;
        int seg = (int) Math.max(32, Math.min(96, r / 3));
        int px = (int) Math.round(cx + r), py = (int) Math.round(cy);
        for (int i = 1; i <= seg; i++) {
            double a = Math.PI * 2 * i / seg;
            int x = (int) Math.round(cx + Math.cos(a) * r), y = (int) Math.round(cy + Math.sin(a) * r);
            EspModule.line(ctx, px, py, x, y, 1, color);
            px = x; py = y;
        }
    }
}
