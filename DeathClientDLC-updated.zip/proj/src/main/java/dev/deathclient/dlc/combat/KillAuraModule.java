package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Kill Aura: automatically attacks every valid target in reach, no clicking and no aiming needed.
 * This class only picks targets and attacks; everything about aiming lives in {@link KillAuraRotation}
 * (modes None, Silent, and the profiles ReallyWorld, MLSAC, Sloth, SpookyTime, FTAngle, FunTime New, LegitSnap,
 * Matrix2, Grim2; see there for what each does).
 * <ul>
 *   <li>Aim point (the held profiles): Center, Chest, Head, Nearest or Wander.</li>
 *   <li>Reach is measured to the target's hitbox, the way the server measures it.</li>
 *   <li>Normal mode waits for the weapon cooldown; HvH mode hits every tick.</li>
 * </ul>
 */
public class KillAuraModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    public final NumberSetting rotation = add(new NumberSetting("Rotation", KillAuraRotation.SILENT, 1, KillAuraRotation.LABELS.length, 1)
            .labels(KillAuraRotation.LABELS));
    /** Where Bezier / Spring / Focus / Snap aim inside the hitbox. */
    public final NumberSetting aimPoint = add(new NumberSetting("Aim point", 4, 1, 5, 1)
            .labels("Center", "Chest", "Head", "Nearest", "Wander"));
    /** Bezier / Spring / Focus: hit only while the look ray really crosses the target's hitbox. */
    public final BoolSetting hitCheck = add(new BoolSetting("Hit check", true));
    /** Max degrees per tick for Smooth / Neuro / VodkaCraft. */
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));
    /**
     * Off (default): your camera never moves. Every rotation mode aims on the server side only (the server and
     * other players see the aim). On: your own camera turns too, as the Smooth / Neuro / Bezier / Spring modes always did.
     */
    public final BoolSetting visualCamera = add(new BoolSetting("Visual camera", false));
    /**
     * How you move while KillAura has an enemy near: Free = you move yourself, nothing changes. Focus = while you hold a
     * movement key, "forward" is turned to point at the enemy (W goes at him, A / D circle him). Target = it walks
     * to the enemy by itself and stops at melee distance.
     */
    public final NumberSetting moveMode = add(new NumberSetting("Move", 1, 1, 3, 1).labels("Free", "Focus", "Target"));
    /** Focus / Target: how far away an enemy still steers your movement. */
    public final NumberSetting followRange = add(new NumberSetting("Follow range", 8.0, 3.0, 20.0, 0.5));
    /** Target: blocks per tick when it walks to the enemy (0.28 is a normal sprint). */
    public final NumberSetting followSpeed = add(new NumberSetting("Follow speed", 0.28, 0.1, 0.6, 0.01));
    /** Jumps by itself while an enemy is near (any Move mode). */
    public final BoolSetting autoJump = add(new BoolSetting("Auto jump", false));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    private final KillAuraRotation rot = new KillAuraRotation(this);
    private LivingEntity aimTarget;

    public KillAuraModule() { super("Aura", Category.COMBAT); }

    /** The entity KillAura is aiming at right now (null when there is none). */
    LivingEntity currentTarget() { return aimTarget; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator()) {
            rot.release(c, p);
            return;
        }

        applyMovement(c, p);

        int mode = (int) rotation.get();
        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            if (Util.reach(p, le) <= rangeFor(mode)) list.add(le);
        }
        if (list.isEmpty()) {
            rot.release(c, p);
            aimTarget = null;
            return;
        }

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(e -> Util.reach(p, e)));

        LivingEntity primary = list.get(0);
        if (primary != aimTarget) {
            aimTarget = primary;
            rot.onNewTarget();
        }

        boolean aligned = rot.update(c, p, primary, mode);

        float need = rot.minCooldown(mode, hvh.get() ? 0f : (float) cooldown.get());
        if (rot.hitBlocked(p, primary, mode)) return;
        if (!aligned || p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        if (KillAuraRotation.singleTarget(mode)) count = 1;          // one aim point at a time
        for (int i = 0; i < count; i++) {
            LivingEntity t = list.get(i);
            rot.beforeHit(c, p, t, mode, i);
            c.interactionManager.attackEntity(p, t);
        }
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        rot.afterHits(c, p, mode, count);
    }

    /** Move modes and auto jump; runs before the aiming and attacking above. */
    private void applyMovement(MinecraftClient c, ClientPlayerEntity p) {
        int mm = (int) moveMode.get();
        if (mm == 1 && !autoJump.get()) return;
        double reach = mm == 1 ? range.get() : followRange.get();
        LivingEntity t = nearestForMove(c, p, reach);
        if (t == null) return;

        double dx = t.getX() - p.getX(), dz = t.getZ() - p.getZ();
        double dist = Math.hypot(dx, dz);
        Vec3d v = p.getVelocity();
        boolean keys = c.options.forwardKey.isPressed() || c.options.backKey.isPressed()
                || c.options.leftKey.isPressed() || c.options.rightKey.isPressed();
        double stop = Math.max(1.2, range.get() * 0.7);
        boolean walking = false;

        if (mm == 3) {                                                   // Target: walk to the enemy by itself
            if (dist > stop && dist > 1.0E-4) {
                double sp = followSpeed.get();
                p.setSprinting(true);
                p.setVelocity(dx / dist * sp, v.y, dz / dist * sp);
                walking = true;
            }
        } else if (mm == 2 && keys && dist > 1.0E-4) {                    // Focus: your input is turned to face the enemy
            double a = Math.toRadians(MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0) - p.getYaw()));
            double cs = Math.cos(a), sn = Math.sin(a);
            p.setVelocity(v.x * cs - v.z * sn, v.y, v.x * sn + v.z * cs);
            walking = true;
        }
        if (autoJump.get() && p.isOnGround() && !p.isTouchingWater() && (mm == 1 || walking)) p.jump();
    }

    private LivingEntity nearestForMove(MinecraftClient c, ClientPlayerEntity p, double reach) {
        LivingEntity best = null;
        double bestD = reach;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            double d = p.distanceTo(le);
            if (d <= bestD) { bestD = d; best = le; }
        }
        return best;
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        rot.release(c, c.player);
        aimTarget = null;
    }

    /** Reach used to pick targets: Grim / Matrix stay under 2.95 (Grim measures 3.0 to the hitbox and allows little slack). */
    private double rangeFor(int mode) {
        return KillAuraRotation.strictReach(mode) ? Math.min(range.get(), 2.95) : range.get();
    }
}
