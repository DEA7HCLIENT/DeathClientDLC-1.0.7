package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.ScreenshotRecorder;

/**
 * Screenshot: bind it to a key (.bind Screenshot <key>) and every press saves a screenshot to the game's screenshots
 * folder, then the module switches itself off again, ready for the next press. With "Hide HUD" the HUD is hidden for
 * one frame first, so the picture is clean.
 */
public class ScreenshotModule extends Module {
    public final BoolSetting hideHud = add(new BoolSetting("Hide HUD", true));

    private int stage;
    private boolean hudWasHidden;

    public ScreenshotModule() { super("Screenshot", Category.MISC); }

    @Override
    protected void onDisable() { stage = 0; }

    @Override
    public void onTick(MinecraftClient c) {
        if (stage == 0) {
            if (hideHud.get()) {
                hudWasHidden = c.options.hudHidden;
                c.options.hudHidden = true;
                stage = 1;                                  // let one frame draw without the HUD
                return;
            }
            stage = 2;
        }
        if (stage == 1) { stage = 2; return; }
        try {
            ScreenshotRecorder.saveScreenshot(c.runDirectory, c.getFramebuffer(),
                    msg -> c.execute(() -> c.inGameHud.getChatHud().addMessage(msg)));
        } catch (Exception ignored) { }
        if (hideHud.get()) c.options.hudHidden = hudWasHidden;
        stage = 0;
        toggle();                                           // one screenshot per press
    }
}
