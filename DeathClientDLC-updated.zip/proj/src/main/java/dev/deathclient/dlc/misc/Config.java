package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.TreeSet;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Named presets (".cfg" in chat): module on/off state, their settings, keybinds and the active theme. */
final class Config {
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/configs");
    private static String currentName = "default";

    private Config() {}

    static String currentName() { return currentName; }

    static List<String> list() {
        if (!Files.isDirectory(DIR)) return List.of();
        try (var s = Files.list(DIR)) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".properties"))
                    .map(n -> n.substring(0, n.length() - ".properties".length()))
                    .sorted()
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return List.of();
        }
    }

    private static Properties snapshot() {
        Properties p = new Properties();
        p.setProperty("theme", Integer.toString(Theme.current().index()));
        p.setProperty("menu.key", Integer.toString(Binds.menuKey()));
        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            p.setProperty(key + ".enabled", m.isEnabled() ? "1" : "0");
            p.setProperty(key + ".key", Integer.toString(m.getKey()));
            for (Setting s : m.getSettings()) {
                if (s instanceof BoolSetting b) p.setProperty(key + "." + sanitize(s.name), b.get() ? "1" : "0");
                else if (s instanceof NumberSetting n) p.setProperty(key + "." + sanitize(s.name), Double.toString(n.get()));
            }
        }
        return p;
    }

    static void save(String name) {
        try {
            Files.createDirectories(DIR);
            try (var out = Files.newOutputStream(DIR.resolve(name + ".properties"))) {
                snapshot().store(out, "DeathClientDLC config: " + name);
            }
            currentName = name;
        } catch (IOException ignored) {}
    }

    // ---- Automatic state: what is on/off and every setting survive a restart ----

    private static final Path STATE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/state.properties");
    /** Saved on/off flags, applied on the first world join (onEnable() may need a player). */
    private static Properties pendingEnabled;
    /** Autosave stays off until the saved state has been restored, so defaults never overwrite it. */
    private static boolean autosaveReady;
    private static Properties lastSaved;
    private static int autosaveTicks;

    /** At startup: restores settings and theme right away; on/off flags wait for the first world. */
    static void restore() {
        if (defaults == null) defaults = snapshot();         // the factory values, kept for config codes (see below)
        if (!Files.exists(STATE)) { autosaveReady = true; return; }
        Properties p = new Properties();
        try (var in = Files.newInputStream(STATE)) {
            p.load(in);
        } catch (IOException e) {
            autosaveReady = true;
            return;
        }
        String theme = p.getProperty("theme");
        if (theme != null) try { Theme.set(Integer.parseInt(theme.trim())); } catch (NumberFormatException ignored) {}
        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            for (Setting s : m.getSettings()) {
                String v = p.getProperty(key + "." + sanitize(s.name));
                if (v == null) continue;
                try {
                    if (s instanceof BoolSetting b) b.set(v.equals("1"));
                    else if (s instanceof NumberSetting n) n.set(Double.parseDouble(v.trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
        pendingEnabled = p;
        lastSaved = p;
    }

    /** Called from the tick loop once a world is loaded: turns the saved modules back on. */
    static void applyPendingEnabled() {
        if (pendingEnabled == null) return;
        Properties p = pendingEnabled;
        pendingEnabled = null;
        for (Module m : ModuleManager.all()) {
            String en = p.getProperty(sanitize(m.getName()) + ".enabled");
            if (en != null && en.equals("1") != m.isEnabled()) m.toggle();
        }
        autosaveReady = true;
    }

    /** Called every client tick; writes the state about once a second, and only when it changed. */
    static void autosaveTick() {
        if (++autosaveTicks < 20) return;
        autosaveTicks = 0;
        autosaveNow();
    }

    static void autosaveNow() {
        if (!autosaveReady || Unhook.active()) return;    // unhooked: keep the last saved state
        Properties now = snapshot();
        if (now.equals(lastSaved)) return;
        try {
            Files.createDirectories(STATE.getParent());
            try (var out = Files.newOutputStream(STATE)) {
                now.store(out, "DeathClientDLC state (written automatically)");
            }
            lastSaved = now;
        } catch (IOException ignored) {}
    }

    static boolean load(String name) {
        Path file = DIR.resolve(name + ".properties");
        if (!Files.exists(file)) return false;
        Properties p = new Properties();
        try (var in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException e) {
            return false;
        }
        String theme = p.getProperty("theme");
        if (theme != null) try { Theme.set(Integer.parseInt(theme.trim())); } catch (NumberFormatException ignored) {}
        String menuKey = p.getProperty("menu.key");
        if (menuKey != null) try { Binds.setMenuKey(Integer.parseInt(menuKey.trim())); } catch (NumberFormatException ignored) {}

        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            String en = p.getProperty(key + ".enabled");
            if (en != null && en.equals("1") != m.isEnabled()) m.toggle();
            String k = p.getProperty(key + ".key");
            if (k != null) try { m.setKey(Integer.parseInt(k.trim())); } catch (NumberFormatException ignored) {}
            for (Setting s : m.getSettings()) {
                String v = p.getProperty(key + "." + sanitize(s.name));
                if (v == null) continue;
                try {
                    if (s instanceof BoolSetting b) b.set(v.equals("1"));
                    else if (s instanceof NumberSetting n) n.set(Double.parseDouble(v.trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
        currentName = name;
        Binds.save();
        return true;
    }

    static boolean delete(String name) {
        try {
            boolean existed = Files.deleteIfExists(DIR.resolve(name + ".properties"));
            if (existed && currentName.equals(name)) currentName = "default";
            return existed;
        } catch (IOException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ config codes
    //
    // Two kinds of code:
    //  * A short code (like TGD37AH, 4..12 letters and digits) names a config file. It is looked up in your saved configs, then
    //    in the mod (assets/deathclientdlc/config_codes/<CODE>.properties), then downloaded from <source>/<CODE>.properties
    //    (the source is a folder URL, by default the "configs" folder of the project's GitHub repository; .cfg source <url> changes it).
    //    ".cfg publish" writes the file for a new code; whoever runs the repository puts it in that folder and from then on
    //    everybody can open the config by its code.
    //  * A share code ("DC1.....") contains the config itself (only what differs from the defaults, packed). It needs no server:
    //    copy it, send it to another player in any chat, they paste it. Key binds are not part of either kind.

    /** Value of every setting at startup, before the saved state is restored. */
    private static Properties defaults;
    private static final String DEFAULT_SOURCE = "https://raw.githubusercontent.com/DEA7HCLIENT/DeathClientDLC-1.0.7/main/configs/";
    private static final Path SOURCE_FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/code_source.txt");
    private static final Path PUBLISH_DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/publish");
    private static final int MAX_CODE_FILE = 64 * 1024;

    static String sourceUrl() {
        try {
            if (Files.exists(SOURCE_FILE)) {
                String u = Files.readString(SOURCE_FILE).trim();
                if (!u.isEmpty()) return u.endsWith("/") ? u : u + "/";
            }
        } catch (IOException ignored) {}
        return DEFAULT_SOURCE;
    }

    static void setSource(String url) {
        try {
            Files.createDirectories(SOURCE_FILE.getParent());
            Files.writeString(SOURCE_FILE, url.trim());
        } catch (IOException ignored) {}
    }

    static void copy(String text) {
        GLFW.glfwSetClipboardString(MinecraftClient.getInstance().getWindow().getHandle(), text);
    }

    static String paste() {
        return GLFW.glfwGetClipboardString(MinecraftClient.getInstance().getWindow().getHandle());
    }

    /** Applies exactly what the properties say: what they do not mention goes back to its default (key binds are untouched). */
    private static void applyShared(Properties p) {
        Properties base = defaults == null ? new Properties() : defaults;
        String theme = p.getProperty("theme", base.getProperty("theme"));
        if (theme != null) try { Theme.set(Integer.parseInt(theme.trim())); } catch (NumberFormatException ignored) {}
        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            String en = p.getProperty(key + ".enabled", base.getProperty(key + ".enabled"));
            if (en != null && en.equals("1") != m.isEnabled()) m.toggle();
            for (Setting s : m.getSettings()) {
                String k = key + "." + sanitize(s.name);
                String v = p.getProperty(k, base.getProperty(k));
                if (v == null) continue;
                try {
                    if (s instanceof BoolSetting b) b.set(v.equals("1"));
                    else if (s instanceof NumberSetting n) n.set(Double.parseDouble(v.trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /** The current setup as a share code: "DC1." + packed list of the values that differ from the defaults. */
    static String exportCode() {
        Properties now = snapshot();
        StringBuilder sb = new StringBuilder();
        for (String k : new TreeSet<>(now.stringPropertyNames())) {
            if (k.endsWith(".key")) continue;                                   // key binds stay yours
            String v = now.getProperty(k);
            String d = defaults == null ? null : defaults.getProperty(k);
            if (!v.equals(d)) sb.append(k).append('=').append(v).append('\n');
        }
        byte[] raw = sb.toString().getBytes(StandardCharsets.UTF_8);
        Deflater df = new Deflater(Deflater.BEST_COMPRESSION);
        df.setInput(raw);
        df.finish();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        while (!df.finished()) out.write(buf, 0, df.deflate(buf));
        df.end();
        return "DC1." + Base64.getUrlEncoder().withoutPadding().encodeToString(out.toByteArray());
    }

    /** Applies a share code and saves the result as a config ("shared_xxxxxx"). Returns the message to show. */
    static String importCode(String code) {
        String c = code.trim().replaceAll("\\s+", "");
        if (!c.startsWith("DC1.")) return "Это не код конфига";
        try {
            byte[] packed = Base64.getUrlDecoder().decode(c.substring(4));
            Inflater inf = new Inflater();
            inf.setInput(packed);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            while (!inf.finished()) {
                int n = inf.inflate(buf);
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                out.write(buf, 0, n);
                if (out.size() > 256 * 1024) { inf.end(); return "Код слишком большой"; }
            }
            inf.end();
            Properties p = new Properties();
            p.load(new StringReader(out.toString(StandardCharsets.UTF_8)));
            applyShared(p);
            CRC32 crc = new CRC32();
            crc.update(c.getBytes(StandardCharsets.UTF_8));
            String name = "shared_" + String.format("%06x", crc.getValue() & 0xFFFFFF);
            save(name);
            return "Конфиг применён и сохранён как " + name;
        } catch (Exception e) {
            return "Код повреждён или не подходит";
        }
    }

    /**
     * Opens a config by its short code: your saved configs, then the mod's own, then the online source (downloaded in the
     * background). done gets the message and is always called on the game thread.
     */
    static void fetchByCode(String code, Consumer<String> done) {
        String c = code.trim().toUpperCase();
        if (!c.matches("[A-Z0-9]{4,12}")) { done.accept("Код: 4–12 букв и цифр"); return; }
        if (Files.exists(DIR.resolve(c + ".properties"))) {
            done.accept(load(c) ? "Конфиг " + c + " загружен" : "Не удалось прочитать конфиг " + c);
            return;
        }
        try (InputStream in = Config.class.getResourceAsStream("/assets/deathclientdlc/config_codes/" + c + ".properties")) {
            if (in != null) {
                byte[] data = in.readNBytes(MAX_CODE_FILE + 1);
                if (data.length <= MAX_CODE_FILE) { done.accept(storeAndLoad(c, data)); return; }
            }
        } catch (IOException ignored) {}

        String url = sourceUrl() + c + ".properties";
        MinecraftClient mc = MinecraftClient.getInstance();
        Thread t = new Thread(() -> {
            String msg;
            byte[] data = null;
            try {
                HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                con.setConnectTimeout(6000);
                con.setReadTimeout(6000);
                con.setRequestProperty("User-Agent", "DeathClientDLC");
                int status = con.getResponseCode();
                if (status == 200) {
                    try (InputStream in = con.getInputStream()) { data = in.readNBytes(MAX_CODE_FILE + 1); }
                    msg = data.length > MAX_CODE_FILE ? "Файл конфига слишком большой" : null;
                    if (msg != null) data = null;
                } else {
                    msg = status == 404 ? "Конфиг с кодом " + c + " не найден" : "Сервер конфигов ответил: " + status;
                }
            } catch (Exception e) {
                msg = "Нет связи с сервером конфигов";
            }
            byte[] finalData = data;
            String finalMsg = msg;
            mc.execute(() -> done.accept(finalData != null ? storeAndLoad(c, finalData) : finalMsg));
        }, "DeathClient-config-code");
        t.setDaemon(true);
        t.start();
    }

    /** Checks that the bytes are a properties file, keeps them as config <code> and loads it. */
    private static String storeAndLoad(String code, byte[] data) {
        try {
            new Properties().load(new StringReader(new String(data, StandardCharsets.UTF_8)));
            Files.createDirectories(DIR);
            Files.write(DIR.resolve(code + ".properties"), data);
        } catch (Exception e) {
            return "Файл конфига повреждён";
        }
        return load(code) ? "Конфиг " + code + " загружен и сохранён" : "Не удалось применить конфиг " + code;
    }

    /** Writes the current setup as a file for a brand-new short code (like TGD37AH) and returns the message to show. */
    static String publish() {
        String code = genCode();
        Properties pr = snapshot();
        for (String k : new TreeSet<>(pr.stringPropertyNames())) if (k.endsWith(".key")) pr.remove(k);
        try {
            Files.createDirectories(PUBLISH_DIR);
            Path file = PUBLISH_DIR.resolve(code + ".properties");
            try (var out = Files.newOutputStream(file)) { pr.store(out, "DeathClientDLC config " + code); }
            copy(code);
            return "Код " + code + " (скопирован). Файл: " + file + " . Положите его в папку configs репозитория, "
                    + "и тогда любой игрок откроет этот конфиг по коду.";
        } catch (IOException e) {
            return "Не удалось записать файл конфига";
        }
    }

    /** Three letters, two digits, two letters (TGD37AH). */
    private static String genCode() {
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) sb.append((char) ('A' + r.nextInt(26)));
        sb.append(r.nextInt(10)).append(r.nextInt(10));
        for (int i = 0; i < 2; i++) sb.append((char) ('A' + r.nextInt(26)));
        return sb.toString();
    }

    private static String sanitize(String s) { return s.toLowerCase().replace(' ', '_'); }
}
