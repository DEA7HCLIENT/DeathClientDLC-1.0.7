package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Parkour: you jump by yourself at the very edge of a block while you run, so you never lose a step on a gap. */
public class ParkourModule extends Module {
    public ParkourModule() { super("Parkour", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || p.isSneaking() || p.isTouchingWater()) return;
        if (!SafeWalkModule.atEdge(c, p)) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.42, v.z);                   // vanilla jump impulse
    }
}
