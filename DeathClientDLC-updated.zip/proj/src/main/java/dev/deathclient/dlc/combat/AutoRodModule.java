package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * AutoRod (1.8 style rod PvP): when a target is in front of you at the right distance and a fishing rod is in your
 * hotbar, it turns to the target, switches to the rod, casts, reels the line in a few ticks later and switches back
 * to the item you were holding. Then it waits for the cooldown.
 */
public class AutoRodModule extends Module {
    public final NumberSetting minRange = add(new NumberSetting("Min range", 3.5, 2.0, 8.0, 0.5));
    public final NumberSetting maxRange = add(new NumberSetting("Max range", 8.0, 4.0, 14.0, 0.5));
    public final NumberSetting fov = add(new NumberSetting("FOV", 90, 20, 180, 5));
    public final BoolSetting faceTarget = add(new BoolSetting("Face target", true));
    public final BoolSetting reelIn = add(new BoolSetting("Reel in", true));
    public final NumberSetting reelDelay = add(new NumberSetting("Reel delay (ticks)", 6, 2, 20, 1));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown (ticks)", 25, 5, 100, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    private int stage, wait, cd, prevSlot;
    private LivingEntity target;

    public AutoRodModule() { super("AutoRod", Category.COMBAT); }

    @Override
    protected void onDisable() { stage = 0; wait = 0; target = null; }

    private void restore(ClientPlayerEntity p) {
        if (prevSlot >= 0 && prevSlot < 9) p.getInventory().setSelectedSlot(prevSlot);
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null || c.currentScreen != null) { stage = 0; return; }
        switch (stage) {
            case 0 -> {                                                   // look for a target
                if (cd > 0) { cd--; return; }
                int slot = Util.findHotbar(p, Items.FISHING_ROD);
                if (slot < 0) return;
                LivingEntity t = AimUtil.pick(c, p, maxRange.get(), fov.get(), playersOnly.get());
                if (t == null || p.distanceTo(t) < minRange.get()) return;
                target = t;
                prevSlot = p.getInventory().getSelectedSlot();
                if (faceTarget.get()) { AimUtil.turn(c, p, t.getBoundingBox().getCenter(), 60, 1.0); stage = 1; }
                else stage = 2;
            }
            case 1 -> stage = 2;                                          // one tick for the turn to be sent
            case 2 -> {                                                   // switch to the rod and cast
                int slot = Util.findHotbar(p, Items.FISHING_ROD);
                if (slot < 0) { stage = 0; return; }
                p.getInventory().setSelectedSlot(slot);
                c.interactionManager.interactItem(p, Hand.MAIN_HAND);
                wait = (int) reelDelay.get();
                stage = reelIn.get() ? 3 : 4;
                if (stage == 4) wait = 2;
            }
            case 3 -> {                                                   // reel the line in
                if (--wait > 0) return;
                if (p.getMainHandStack().isOf(Items.FISHING_ROD)) c.interactionManager.interactItem(p, Hand.MAIN_HAND);
                wait = 2;
                stage = 4;
            }
            case 4 -> {                                                   // back to the old item
                if (--wait > 0) return;
                restore(p);
                stage = 0;
                cd = (int) cooldown.get();
            }
            default -> stage = 0;
        }
    }
}
