package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayDeque;

/**
 * CPS: a small panel with your clicks per second (left | right). Clicks are read from the mouse buttons every frame,
 * so fast clicking is not missed. Drag it while the chat is open (HUD editor). Only counts while the module is on.
 */
public class CpsHudModule extends Module {
    public final BoolSetting rightButton = add(new BoolSetting("Right button", true));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 200, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF;

    private final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private boolean leftDown, rightDown;

    public CpsHudModule() { super("CPS", Category.MISC); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CpsHudModule m = ModuleManager.get(CpsHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        long now = System.currentTimeMillis();
        long win = c.getWindow().getHandle();
        boolean free = c.currentScreen == null;
        boolean l = free && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = free && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !leftDown) left.add(now);
        if (r && !rightDown) right.add(now);
        leftDown = l;
        rightDown = r;
        while (!left.isEmpty() && now - left.peekFirst() > 1000) left.pollFirst();
        while (!right.isEmpty() && now - right.peekFirst() > 1000) right.pollFirst();

        String text = rightButton.get() ? left.size() + " | " + right.size() + " CPS" : left.size() + " CPS";
        var tr = c.textRenderer;
        int w = Fonts.width(tr, text) + 12, h = 16;
        int x = (int) posX.get(), y = (int) posY.get();
        HudEdit.track(x, y, w, h, (nx, ny) -> { posX.set(nx); posY.set(ny); });
        Shapes.panel(ctx, x, y, w, h, BG);
        Fonts.draw(ctx, tr, text, x + 6, y + 4, WHITE);
    }
}
