package dev.deathclient.dlc;

import net.minecraft.util.math.MathHelper;
import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Rotation profiles ported from the the second client client (SCR_by_wexor): ReallyWorld, MLSAC, Sloth, SpookyTime, FTAngle,
 * FunTime New, LegitSnap, Matrix and Grim. In the second client every profile is a RotateConstructor that gets the current angle,
 * the wanted angle and its AttackHandler; here each is a {@link Profile} that gets a {@link State} filled by
 * {@link KillAuraRotation}, which runs them as held server-side rotations (mouse-grid snap, look packets, ray check).
 * <p>
 * Differences from the original: the second client's attack-handler questions ("canAttack(config, n)", "attackTimer.finished(ms)",
 * "getCount()") are answered from the weapon cooldown, the time since the last hit and a hit counter. The profile
 * output is snapped to the mouse grid by the caller (the second client did that in Angle.adjustSensitivity). FunTime New no longer
 * presses the attack key by itself (it only rotates). Profiles that depend on the second client's Animator spring
 * (SPAngle, FunTimeSnapAngle) and the Neuro* model/dataset classes are not ported.
 */
final class ExtraRotations {
    private ExtraRotations() {}

    // mode offsets inside KillAuraRotation (REALLYWORLD = first)
    static final String[] LABELS = {"ReallyWorld", "MLSAC", "Sloth", "SpookyTime", "FTAngle", "FunTime New",
            "LegitSnap", "Matrix2", "Grim2", "SpookyTime 2", "SpookyTime 3"};

    /** Everything a profile may look at in one tick. Angles are the held server-side view. */
    static final class State {
        float curYaw, curPitch;          // where the server thinks you look
        float tYaw, tPitch;              // wanted angle (aim point)
        float closeYaw, closePitch;      // wanted angle to the nearest point of the hitbox
        float viewYaw, viewPitch;        // your real camera
        double distance, range;          // to the target / the module's range
        boolean ready;                   // weapon cooldown is ready (the second client: canAttack)
        long sinceHitMs;                 // time since the last hit
        int hits;                        // hits so far
        float cooldown;                  // 0..1
        float gcd;                       // mouse-sensitivity step of the angles
        net.minecraft.util.math.Vec3d eye;   // your eye position
        net.minecraft.util.math.Box box;     // target hitbox grown by its targeting margin (what the server tests the look ray against)
        boolean rayHit;                  // look ray at (curYaw, curPitch) crosses the hitbox within range
        boolean rayHitNear;              // same with reach 4.0
        boolean rayHitShort;             // same with range - 0.5
    }

    abstract static class Profile {
        /** Next {yaw, pitch}; yaw is continuous (not wrapped), pitch is clamped by the caller. */
        abstract float[] step(State s);
    }

    static Profile create(int index) {
        return switch (index) {
            case 0 -> new ReallyWorld();
            case 1 -> new Mlsac();
            case 2 -> new Sloth();
            case 3 -> new SpookyTime();
            case 4 -> new FtAngle();
            case 5 -> new FunTimeNew();
            case 6 -> new LegitSnap();
            case 7 -> new Matrix();
            case 9 -> new SpookyTime2();
            case 10 -> new SpookyTime3();
            default -> new Grim();
        };
    }

    // ---- shared helpers ----

    private static float rnd(float min, float max) {
        if (min == max) return min;
        if (max < min) { float t = min; min = max; max = t; }
        return (float) ThreadLocalRandom.current().nextDouble(min, max);
    }

    /** the second client MathUtils.smoothRandom: a sine of the clock mapped to min..max. */
    private static float smoothRandom(float min, float max, float smoothness) {
        if (max < min) { float t = min; min = max; max = t; }
        double time = System.currentTimeMillis() / (Math.max(1f, smoothness) * 50.0);
        float progress = (float) ((Math.sin(time) + 1.0) * 0.5);
        return MathHelper.lerp(progress, min, max);
    }

    /** the second client FTMathUtil.smoothRandom. */
    private static float ftSmooth(float min, float max, float speed) {
        double t = (double) System.currentTimeMillis() * speed / 1000.0;
        float n = (float) (Math.sin(t) * 0.5 + 0.5);
        return min + (max - min) * n;
    }

    private static float diff(float dy, float dp) { return Math.max((float) Math.hypot(Math.abs(dy), Math.abs(dp)), 1.0E-4f); }

    /** The eased "animate" shared by ReallyWorld / MLSAC / Matrix: restarts when the target moves, easeOutBack on the way. */
    private static final class Ease {
        float progress = 1f, startYaw, startPitch, lastYaw, lastPitch;

        float[] animate(float fromYaw, float fromPitch, float targetYaw, float targetPitch, float speed) {
            float chY = Math.abs(MathHelper.wrapDegrees(targetYaw - lastYaw));
            float chP = Math.abs(targetPitch - lastPitch);
            if (progress >= 1f || chY > 6f || chP > 6f) {
                startYaw = fromYaw; startPitch = fromPitch;
                lastYaw = targetYaw; lastPitch = targetPitch;
                progress = 0f;
            }
            progress = MathHelper.clamp(progress + speed, 0f, 1f);
            float e = easeOutBack(progress);
            float dy = MathHelper.wrapDegrees(lastYaw - startYaw);
            float dp = lastPitch - startPitch;
            return new float[]{startYaw + dy * e, MathHelper.clamp(startPitch + dp * e, -89f, 89f)};
        }

        static float easeOutBack(float x) {
            float c1 = 1.70158f, c3 = c1 + 1f;
            return 1f + c3 * (float) Math.pow(x - 1f, 3.0) + c1 * (float) Math.pow(x - 1f, 2.0);
        }
    }

    // ---- profiles ----

    /** ReallyWorld: full-speed straight turn, 1 degree sine jitter, eased with a very fast animation. */
    static final class ReallyWorld extends Profile {
        private final Ease ease = new Ease();
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float d = diff(dy, dp);
            float yawJit = (float) Math.cos(System.currentTimeMillis() / 21.0);
            float pitchJit = (float) Math.sin(System.currentTimeMillis() / 21.0);
            float sly = Math.abs(dy / d) * 360f, slp = Math.abs(dp / d) * 360f;
            float fy = s.curYaw + MathHelper.clamp(dy, -sly, sly);
            float fp = MathHelper.clamp(s.curPitch + MathHelper.clamp(dp, -slp, slp), -89f, 89f);
            return ease.animate(s.curYaw, s.curPitch, fy + yawJit, fp + pitchJit, rnd(15f, 16f));
        }
    }

    /** MLSAC: fast yaw (180), slow pitch (5), big random sine jitter, slow easeOutBack animation. */
    static final class Mlsac extends Profile {
        private final Ease ease = new Ease();
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float d = diff(dy, dp);
            float yawJit = (float) (rnd(5f, 35f) * Math.cos(System.currentTimeMillis() / 90.0));
            float pitchJit = (float) (rnd(5f, 15f) * Math.sin(System.currentTimeMillis() / 90.0));
            float sy = Math.abs(dy / d) * 180f, sp = Math.abs(dp / d) * 5f;
            float fy = s.curYaw + MathHelper.clamp(dy, -sy, sy);
            float fp = MathHelper.clamp(s.curPitch + MathHelper.clamp(dp, -sp, sp), -89f, 89f);
            return ease.animate(s.curYaw, s.curPitch, fy + yawJit, fp + pitchJit, rnd(0.1f, 0.4f));
        }
    }

    /** Sloth: yaw 70 / pitch 15 per tick, strong cosine shake that stops while a hit is ready. */
    static final class Sloth extends Profile {
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float yawjt = 64f * (float) Math.cos(System.currentTimeMillis() / 29.0);
            float yawjt2 = 12f * (float) Math.cos(System.currentTimeMillis() / 29.0);
            if (s.ready) { yawjt = 0f; yawjt2 = 0f; }
            float yaw = s.curYaw + MathHelper.clamp(dy, -70f, 70f) + yawjt;
            float pitch = MathHelper.clamp(s.curPitch + MathHelper.clamp(dp, -15f, 15f), -90f, 90f) + yawjt2;
            return new float[]{yaw, pitch};
        }
    }

    /** SpookyTime: tiny randomized steps whose size follows the weapon cooldown (bounce curve); every 8th hit is slower. */
    static final class SpookyTime extends Profile {
        private static final SecureRandom R = new SecureRandom();
        private static float lerpR(float min, float max) { return MathHelper.lerp(R.nextFloat(), min, max); }
        private static float bounceInOut(float t) {
            if (t < 0.5f) return 8f * t * t * t * t;
            float f = t - 1f;
            return 1f - 8f * f * f * f * f;
        }
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            if ((float) Math.hypot(dy, dp) < 1.0E-4f) return new float[]{s.curYaw, s.curPitch};
            boolean boosted = s.hits % 8 != 3;
            float yawW = boosted ? lerpR(0.6f, 0.8f) : lerpR(0.3f, 0.4f);
            float pitchW = boosted ? lerpR(0.6f, 0.8f) : lerpR(0.3f, 0.4f);
            float lerpTo = lerpR(50f, 55f);
            float interp = MathHelper.lerp(R.nextFloat(), lerpTo, 0.1f);
            float ease = bounceInOut(MathHelper.clamp(s.cooldown, 0f, 1f));
            float yawStep = yawW * interp * 0.1f;
            float pitchStep = pitchW * lerpR(0.05f, 0.5f) * 0.1f;
            if (boosted) yawStep *= 0.5f;
            float jy = lerpR(-0.14f, 0.14f), jp = lerpR(-0.14f, 0.14f);
            float scale = 0.1f + 0.5f * ease;
            return new float[]{s.curYaw + (dy + jy) * yawStep * scale,
                    MathHelper.clamp(s.curPitch + (dp + jp) * pitchStep * scale, -89f, 90f)};
        }
    }

    /** FTAngle: a per-session random "hand" (own step size, fatigue, drifting error, layered sines); pauses after a hit. */
    static final class FtAngle extends Profile {
        private final Random random = new Random(System.nanoTime() * 31L ^ System.currentTimeMillis());
        private final float baseYaw = 34.4f + random.nextFloat() * 15f;
        private final float basePitch = 2.8f + random.nextFloat() * 5.2f;
        private final float jitterBase = 0.12f + random.nextFloat() * 1.45f;
        private int fatigue, variant = random.nextInt(5);
        private long lockUntil;
        private float errYaw, errPitch;

        @Override float[] step(State s) {
            long now = System.currentTimeMillis();
            if (now < lockUntil) return new float[]{s.curYaw, s.curPitch};
            if (random.nextDouble() < 0.055) variant = random.nextInt(5);
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float yawStep = MathHelper.clamp(dy, -baseYaw, baseYaw);
            float pitchStep = MathHelper.clamp(dp, -basePitch, basePitch);
            if (s.distance < 4.5) { yawStep *= 0.62f; pitchStep *= 0.71f; }
            if (random.nextDouble() < (variant == 4 ? 0.19 : 0.08)) {
                yawStep += (random.nextFloat() - 0.5f) * 7.5f;
                pitchStep += (random.nextFloat() - 0.5f) * 5.2f;
                fatigue = 13 + random.nextInt(18);
            } else if (fatigue > 0) {
                yawStep *= 0.58f; pitchStep *= 0.61f; fatigue--;
            }
            float ny = s.curYaw + yawStep, np = s.curPitch + pitchStep;
            errYaw = errYaw * 0.73f + (random.nextFloat() - 0.5f) * 0.95f;
            errPitch = errPitch * 0.71f + (random.nextFloat() - 0.5f) * 0.72f;
            ny += errYaw; np += errPitch;
            ny += (float) (Math.sin(now / 23.7) * 0.62 + Math.sin(now / 71.0) * 0.48 + Math.cos(now / 124.0) * 0.33
                    + Math.sin(now / 189.0) * 0.21 + random.nextGaussian() * jitterBase);
            np += (float) (Math.cos(now / 38.4) * 0.51 + Math.sin(now / 103.0) * 0.29 + random.nextGaussian() * (jitterBase * 0.85f));
            if (variant == 1) ny = s.curYaw + (ny - s.curYaw) * 0.58f;
            np = MathHelper.clamp(np, -89f, 89f);
            if (s.ready) lockUntil = now + 132L + random.nextInt(148);
            return new float[]{ny, np};
        }
    }

    /** FunTime New: yaw turns fast only while a hit is ready (otherwise slow, with offsets after a hit); pitch stays near the camera pitch. */
    static final class FunTimeNew extends Profile {
        @Override float[] step(State s) {
            float ty = s.tYaw;
            if (!s.ready) ty = s.closeYaw;                                      // not ready: aim at the nearest point of the box
            float dy = MathHelper.wrapDegrees(ty - s.curYaw);
            boolean window = s.ready;
            boolean afterAttack = s.sinceHitMs < 400;
            float yawSpeed = window ? 60f : rnd(0f, 20f);
            float yawJitter = smoothRandom(-smoothRandom(12f, 16f, 0f), smoothRandom(22f, 26f, 0f), 0f);
            float pitchJitter = smoothRandom(-smoothRandom(1f, 4f, 12f), smoothRandom(1f, 4f, 12f), 5f);
            float yawOffset = afterAttack ? smoothRandom(-35f, 35f, 8f) + yawJitter : yawJitter;
            if (window) yawOffset = 0f;
            float yaw = s.curYaw + MathHelper.clamp(dy + yawOffset, -yawSpeed, yawSpeed);
            return new float[]{yaw, s.viewPitch + pitchJitter};
        }
    }

    /** LegitSnap: snaps to the target at 82.5 degrees/tick when a hit is ready, otherwise drifts back to your camera at ~23. */
    static final class LegitSnap extends Profile {
        @Override float[] step(State s) {
            if (s.ready) return towards(s.curYaw, s.curPitch, s.tYaw, s.tPitch, 82.5f);
            return towards(s.curYaw, s.curPitch, s.viewYaw, s.viewPitch, 23.333334f);
        }
        private static float[] towards(float cy, float cp, float ty, float tp, float speed) {
            float dy = MathHelper.wrapDegrees(ty - cy), dp = MathHelper.wrapDegrees(tp - cp);
            float d = diff(dy, dp);
            float sy = Math.abs(dy / d) * speed, sp = Math.abs(dp / d) * speed;
            return new float[]{cy + Math.min(Math.max(dy, -sy), sy), cp + Math.min(Math.max(dp, -sp), sp)};
        }
    }

    /** Matrix (the second client version): holds still while the ray already hits (reach - 0.5), else eased with a sine wobble. */
    static final class Matrix extends Profile {
        private final Ease ease = new Ease();
        @Override float[] step(State s) {
            boolean outOfRange = s.distance > s.range;
            if (s.rayHitShort || outOfRange) return new float[]{s.curYaw, s.curPitch};
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float d = diff(dy, dp);
            float sy = Math.abs(dy / d) * 180f, sp = Math.abs(dp / d) * 180f;
            float yawJit = (float) (8.0 * Math.cos(System.currentTimeMillis() / 70.0));
            float pitchJit = (float) (6.0 * Math.sin(System.currentTimeMillis() / 70.0));
            return ease.animate(s.curYaw, s.curPitch,
                    s.curYaw + MathHelper.clamp(dy, -sy, sy) + yawJit,
                    s.curPitch + MathHelper.clamp(dp, -sp, sp) + pitchJit, rnd(0.5f, 0.75f));
        }
    }

    /** Grim (the second client version): 25-50 / 5-25 degrees a tick, 100 when a hit is ready, frozen for 50-100 ms after a hit. */
    static final class Grim extends Profile {
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float d = diff(dy, dp);
            float sy = Math.abs(dy / d) * (s.ready ? 100f : rnd(25f, 50f));
            float sp = Math.abs(dp / d) * (s.ready ? 100f : rnd(5f, 25f));
            if (s.sinceHitMs < rnd(50f, 100f)) { sy = 0f; sp = 0f; }
            return new float[]{s.curYaw + Math.min(Math.max(dy, -sy), sy), s.curPitch + Math.min(Math.max(dp, -sp), sp)};
        }
    }

    /**
     * SpookyTime 2: yaw up to a random 25-360 degrees a tick, pitch 4-10, a 5 / 4 degree sine wobble, a pause one tick in
     * eight (and whenever it is within 2 degrees), and the result eased with a slow easeOutBack animation.
     */
    static final class SpookyTime2 extends Profile {
        private static final SecureRandom R = new SecureRandom();
        private final Ease ease = new Ease();
        private static float lerpR(float min, float max) { return MathHelper.lerp(R.nextFloat(), min, max); }
        @Override float[] step(State s) {
            float dy = MathHelper.wrapDegrees(s.tYaw - s.curYaw), dp = s.tPitch - s.curPitch;
            float len = diff(dy, dp);
            float yawSpeed = lerpR(25f, 360f), pitchSpeed = lerpR(4f, 10f);
            double time = System.currentTimeMillis() / 70.0;
            float oscYaw = (float) (5.0 * Math.cos(time)), oscPitch = (float) (4.0 * Math.sin(time));
            boolean pause = (Math.abs(dy) < 2f && Math.abs(dp) < 2f) || R.nextInt(8) == 0;
            if (pause) { yawSpeed = 0f; pitchSpeed = 0f; oscYaw = 0f; oscPitch = 0f; }
            float yawStep = Math.abs(dy / len) * yawSpeed, pitchStep = Math.abs(dp / len) * pitchSpeed;
            float ny = s.curYaw + MathHelper.clamp(dy, -yawStep, yawStep);
            float np = MathHelper.clamp(s.curPitch + MathHelper.clamp(dp, -pitchStep, pitchStep), -89f, 89f);
            return ease.animate(s.curYaw, s.curPitch, ny + oscYaw, np + oscPitch, lerpR(0.1f, 0.4f));
        }
    }

    /**
     * SpookyTime 3: big steps (yaw 50, pitch 16 a tick; 40 / 0.2 once the look ray already crosses the hitbox), a smoothed
     * random shake re-rolled every 30 ms, on the mouse grid. If the step would take the ray off the hitbox it is
     * halved (down to 1/16) until the ray still hits, otherwise the angle stays.
     */
    static final class SpookyTime3 extends Profile {
        private static final SecureRandom R = new SecureRandom();
        private long lastRandomAt;
        private float smoothYaw, smoothPitch, randYaw, randPitch;

        private static boolean hits(State s, float yaw, float pitch) {
            return s.box.contains(s.eye) || Rotations.rayHits(s.eye, yaw, pitch, s.box, s.distance, 0.0);
        }

        @Override float[] step(State s) {
            if (s.box == null || s.eye == null || s.box.contains(s.eye)) return new float[]{s.curYaw, s.curPitch};
            float cy = s.curYaw, cp = s.curPitch;
            float dy = MathHelper.wrapDegrees(s.tYaw - cy), dp = MathHelper.wrapDegrees(s.tPitch - cp);
            boolean hit = hits(s, cy, cp);
            float stepY = Math.min(Math.abs(dy), hit ? 40.2f : 50.2f);
            float stepP = Math.min(Math.abs(dp), hit ? 0.2f : 16.2f);
            float ny = cy + (dy > 0f ? stepY : -stepY) * 0.977f;
            float np = cp + (dp > 0f ? stepP : -stepP) * 0.977f;
            long now = System.currentTimeMillis();
            if (now - lastRandomAt > 30L) {
                lastRandomAt = now;
                randYaw = (float) (R.nextDouble() * 15.0 - 7.5);
                randPitch = (float) (R.nextDouble() * 4.0 - 2.0);
            }
            smoothYaw += (randYaw - smoothYaw) * 0.7f;
            smoothPitch += (randPitch - smoothPitch) * 0.7f;
            ny += smoothYaw;
            np = MathHelper.clamp(np + smoothPitch, -90f, 90f);
            float gcd = s.gcd;
            ny -= (ny - cy) % gcd;
            np -= (np - cp) % gcd;
            if (hit && !hits(s, ny, np)) {
                for (float k = 0.5f; k >= 0.0625f; k *= 0.5f) {
                    float ty = cy + (ny - cy) * k, tp = cp + (np - cp) * k;
                    ty -= (ty - cy) % gcd;
                    tp -= (tp - cp) % gcd;
                    if (hits(s, ty, tp)) return new float[]{ty, tp};
                }
                return new float[]{cy, cp};
            }
            return new float[]{ny, np};
        }
    }
}
