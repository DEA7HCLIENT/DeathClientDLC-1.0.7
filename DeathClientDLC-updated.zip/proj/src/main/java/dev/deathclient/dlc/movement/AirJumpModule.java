package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;

/** Air Jump (from the second client): while jump is held and a block is within a block below you, you jump again every other tick. */
public class AirJumpModule extends Module {
    public AirJumpModule() { super("Air Jump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || !c.options.jumpKey.isPressed()) return;
        Box box = p.getBoundingBox().stretch(0.0, -1.0, 0.0).expand(0.1, 0.0, 0.1);
        if (!c.world.isSpaceEmpty(p, box) && p.age % 2 == 0) {
            p.fallDistance = 0;
            p.jump();
        }
    }
}
