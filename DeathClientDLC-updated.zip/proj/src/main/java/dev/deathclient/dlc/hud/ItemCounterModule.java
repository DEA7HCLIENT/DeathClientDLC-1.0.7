package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import java.util.ArrayList;
import java.util.List;

/**
 * Item Counter: how many totems (and optionally ender pearls / golden apples) you carry, counted over the whole
 * inventory including the off hand. A count of 0 turns red. Drag it while the chat is open (HUD editor).
 */
public class ItemCounterModule extends Module {
    public final BoolSetting totems = add(new BoolSetting("Totems", true));
    public final BoolSetting pearls = add(new BoolSetting("Ender pearls", false));
    public final BoolSetting gapples = add(new BoolSetting("Golden apples", false));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 224, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, RED = 0xFFFF5555;

    public ItemCounterModule() { super("Item Counter", Category.MISC); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ItemCounterModule m = ModuleManager.get(ItemCounterModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private static int count(MinecraftClient c, Item item) {
        int n = 0;
        var inv = c.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        List<Item> items = new ArrayList<>();
        if (totems.get()) items.add(Items.TOTEM_OF_UNDYING);
        if (pearls.get()) items.add(Items.ENDER_PEARL);
        if (gapples.get()) items.add(Items.GOLDEN_APPLE);
        if (items.isEmpty()) return;

        var tr = c.textRenderer;
        int rowH = 18, w = 50, h = items.size() * rowH + 2;
        int x = (int) posX.get(), y = (int) posY.get();
        HudEdit.track(x, y, w, h, (nx, ny) -> { posX.set(nx); posY.set(ny); });
        Shapes.panel(ctx, x, y, w, h, BG);
        int ry = y + 1;
        for (Item it : items) {
            int n = count(c, it);
            ctx.drawItem(new ItemStack(it), x + 3, ry + 1);
            Fonts.draw(ctx, tr, "x" + n, x + 24, ry + 5, n == 0 ? RED : WHITE);
            ry += rowH;
        }
    }
}
