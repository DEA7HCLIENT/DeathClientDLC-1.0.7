package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.AspectRatioModule;
import dev.deathclient.dlc.FreecamModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.joml.Matrix4f;

/**
 * Freecam: moves the camera entity right before the world is rendered, so the view follows the mouse and keys
 * without a frame of delay. No arguments are read, so the hook does not depend on the method's signature.
 * require = 0: if renderWorld is named differently in this build the hook is skipped and Freecam falls back to the
 * HUD callback (works, but one frame late).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderWorld", at = @At("HEAD"), require = 0)
    private void deathclientdlc$freecamFrame(CallbackInfo ci) {
        FreecamModule.worldFrame();
    }

    /** Aspect Ratio: the projection of the world gets the aspect ratio of the module (unchanged while it is off). */
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$aspectRatio(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        Matrix4f adjusted = AspectRatioModule.adjust(cir.getReturnValue());
        if (adjusted != cir.getReturnValue()) cir.setReturnValue(adjusted);
    }
}
