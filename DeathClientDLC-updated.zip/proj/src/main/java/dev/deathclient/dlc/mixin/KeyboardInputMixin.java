package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.FreecamModule;
import dev.deathclient.dlc.SafeWalkModule;
import dev.deathclient.dlc.ShiftTapModule;
import dev.deathclient.dlc.TargetStrafeModule;
import dev.deathclient.dlc.ToggleSneakModule;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freecam is on, the real player ignores movement keys (the keys fly the camera instead). In 1.21.11 movement is derived from playerInput, so resetting it is enough. */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$freecamFreeze(CallbackInfo ci) {
        if (!FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = PlayerInput.DEFAULT;
    }

    /** Toggle Sneak: the sneak flag of this tick's input is replaced by the toggled state. */
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$toggleSneak(CallbackInfo ci) {
        if (FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = ToggleSneakModule.apply(self.playerInput);
    }

    /** SafeWalk: sneak is switched on at the edge of a block. */
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$safeWalk(CallbackInfo ci) {
        if (FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = SafeWalkModule.apply(self.playerInput);
    }

    /** Target Strafe (Grim mode): W/A/S/D are chosen so that you walk to the next point round the target. */
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$targetStrafe(CallbackInfo ci) {
        if (FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = TargetStrafeModule.apply(self.playerInput);
    }

    /** Shift Tap: sneak for a moment after a hit. */
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$shiftTap(CallbackInfo ci) {
        if (FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = ShiftTapModule.apply(self.playerInput);
    }
}
