package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Target ESP: one module, four looks on the nearest target (the one KillAura / TPAura would pick).
 * Particles = rotating particle ring, Image = spinning picture (textures/gui/target.png),
 * Brackets = spinning corner frame (target_brackets.png), Ghost = glowing orbs with fading tails (ghost.png).
 * Image, Brackets and Ghost are screen overlays drawn through ScreenProjector.
 */
public class TargetEspModule extends Module {
    private static final Identifier IMAGE = Identifier.of("deathclientdlc", "textures/gui/target.png");
    private static final Identifier BRACKETS = Identifier.of("deathclientdlc", "textures/gui/target_brackets.png");
    private static final Identifier GHOST = Identifier.of("deathclientdlc", "textures/gui/ghost.png");
    private static final int IMAGE_TEX = 512, BRACKETS_TEX = 1280, GHOST_TEX = 256;
    private static final int PARTICLES = 1, IMG = 2, BRK = 3, GHO = 4;

    public final NumberSetting mode = add(new NumberSetting("Mode", GHO, 1, 4, 1).labels("Particles", "Image", "Brackets", "Ghost"));
    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting size = add(new NumberSetting("Size", 1.0, 0.4, 2.5, 0.1));
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.3, 3.0, 0.1));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));
    public final BoolSetting redOnHit = add(new BoolSetting("Red on hit", true));
    /** Particles mode: which vanilla particle. */
    public final NumberSetting style = add(Fx.styleSetting());
    /** Image / Brackets modes. */
    public final BoolSetting reverse = add(new BoolSetting("Reverse", false));
    public final BoolSetting pulse = add(new BoolSetting("Pulse", true));
    /** Ghost mode. */
    public final NumberSetting orbs = add(new NumberSetting("Orbs", 3, 1, 8, 1));
    public final NumberSetting tail = add(new NumberSetting("Tail", 14, 1, 30, 1));

    private final ScreenProjector proj = new ScreenProjector();
    private LivingEntity target;

    public TargetEspModule() { super("Target ESP", Category.VISUALS); }

    @Override
    protected void onDisable() { target = null; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            double d = p.distanceTo(le);
            if (d <= bestDist) { bestDist = d; best = le; }
        }
        target = best;
        if (best != null && (int) mode.get() == PARTICLES) particles(c, p, best);
    }

    /** Particles mode: three particles run around the target on a ring, bobbing up and down. */
    private void particles(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        var effect = Fx.style(style);
        double radius = t.getWidth() * 0.9 + 0.2;
        double y = t.getY() + (0.5 + 0.5 * Math.sin(p.age * 0.15)) * t.getHeight();
        for (int i = 0; i < 3; i++) {
            double a = p.age * 0.35 * speed.get() + i * (2 * Math.PI / 3);
            Fx.spawn(c, effect, t.getX() + Math.cos(a) * radius, y, t.getZ() + Math.sin(a) * radius);
        }
    }

    // ---- drawing ----

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetEspModule m = ModuleManager.get(TargetEspModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        LivingEntity t = m.target;
        if (t == null || !t.isAlive()) return;
        int md = (int) m.mode.get();
        if (md == PARTICLES) return;
        float delta = tickCounter.getTickProgress(false);
        if (md == GHO) m.drawGhost(ctx, c, t, delta); else m.drawImage(ctx, c, t, delta, md == BRK);
    }

    private int baseColor(LivingEntity t) {
        int rgb = themeColor.get() ? Theme.current().accent() : 0xFFFFFF;
        if (redOnHit.get() && t.hurtTime > 0) rgb = 0xFF3030;
        return rgb & 0xFFFFFF;
    }

    /** Image and Brackets: a picture over the target's center that spins around its middle. */
    private void drawImage(DrawContext ctx, MinecraftClient c, LivingEntity t, float delta, boolean brackets) {
        proj.begin(c, delta);
        Vec3d pos = t.getLerpedPos(delta).add(0, t.getHeight() * 0.5, 0);
        if (!proj.project(pos)) return;
        double depth = proj.out[2];

        // Size follows the target's apparent size on screen.
        double world = Math.max(t.getWidth(), t.getHeight() * 0.7) * 1.7 * size.get();
        double pixels = world / (depth * proj.tan) * (proj.screenHeight() / 2.0);
        if (pulse.get()) pixels *= 1.0 + 0.06 * Math.sin(System.nanoTime() / 2.5e8);
        pixels = Math.max(14, Math.min(pixels, proj.screenHeight() * 0.8));
        int half = (int) Math.round(pixels / 2.0);
        if (half < 1) return;

        double dir = reverse.get() ? -1 : 1;
        float angle = (float) Math.toRadians(((System.nanoTime() / 1.0e9) * 180.0 * speed.get() * dir) % 360.0);
        int color = 0xFF000000 | baseColor(t);
        int ts = brackets ? BRACKETS_TEX : IMAGE_TEX;

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) proj.out[0], (float) proj.out[1]);
        m.rotate(angle);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, brackets ? BRACKETS : IMAGE, -half, -half, 0f, 0f,
                half * 2, half * 2, ts, ts, ts, ts, color);
        m.popMatrix();
    }

    /** One glow sprite to draw: screen position, half-size, alpha and depth for sorting. */
    private record Dot(double x, double y, int half, int alpha, double depth) {}

    /** Ghost: glowing orbs fly around the target on a wavy orbit, each dragging a fading tail. */
    private void drawGhost(DrawContext ctx, MinecraftClient c, LivingEntity t, float delta) {
        proj.begin(c, delta);
        Vec3d center = t.getLerpedPos(delta).add(0, t.getHeight() * 0.5, 0);
        double orbit = t.getWidth() * 0.9 + 0.25;
        double half = t.getHeight() * 0.5;
        double now = System.nanoTime() / 1.0e9 * speed.get();
        int n = (int) orbs.get(), len = (int) tail.get();
        int rgb = baseColor(t);

        List<Dot> dots = new ArrayList<>(n * len);
        for (int i = 0; i < n; i++) {
            for (int k = 0; k < len; k++) {
                double ts = now * 2.4 - k * 0.045;      // tail = the same orbit a moment earlier
                double a = ts + i * (2 * Math.PI / n);
                double y = Math.sin(ts * 1.3 + i * 2.1) * half * 0.9;
                Vec3d w = center.add(Math.cos(a) * orbit, y, Math.sin(a) * orbit);
                if (!proj.project(w)) continue;

                double fade = 1.0 - (double) k / len;    // 1 at the head, 0 at the end of the tail
                double world = (0.16 + 0.22 * fade) * size.get();
                double px = world / (proj.out[2] * proj.tan) * (proj.screenHeight() / 2.0);
                int h = (int) Math.round(Math.max(3, Math.min(px, 60)));
                int alpha = (int) Math.round(255 * Math.pow(fade, 1.4));
                if (alpha < 4) continue;
                dots.add(new Dot(proj.out[0], proj.out[1], h, alpha, proj.out[2]));
            }
        }

        dots.sort((a, b) -> Double.compare(b.depth(), a.depth())); // far first
        for (Dot d : dots) {
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, GHOST,
                    (int) Math.round(d.x()) - d.half(), (int) Math.round(d.y()) - d.half(), 0f, 0f,
                    d.half() * 2, d.half() * 2, GHOST_TEX, GHOST_TEX, GHOST_TEX, GHOST_TEX, (d.alpha() << 24) | rgb);
        }
    }
}
