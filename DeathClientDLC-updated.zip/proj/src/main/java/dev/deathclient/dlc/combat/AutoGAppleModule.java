package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * Auto GApple (from the second client): eats a golden apple when your health (plus golden hearts) is at or under the
 * threshold. Smart = takes one from the hotbar (and switches back afterwards); off = only the one in the off hand.
 */
public class AutoGAppleModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 16, 3, 20, 0.5));
    public final BoolSetting smart = add(new BoolSetting("Smart", true));
    public final BoolSetting goldenHearts = add(new BoolSetting("Golden Hearts", true));
    public final BoolSetting returnSlot = add(new BoolSetting("Return Slot", true));

    private boolean eating;
    private int previousSlot = -1;

    public AutoGAppleModule() { super("Auto GApple", Category.COMBAT); }

    @Override
    protected void onEnable() { eating = false; previousSlot = -1; }

    @Override
    protected void onDisable() { stopEating(MinecraftClient.getInstance()); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        if (canEat(p)) {
            if (smart.get() && !p.getMainHandStack().isOf(Items.GOLDEN_APPLE)) swapToApple(p);
            if (!eating && !c.options.useKey.isPressed()) { c.options.useKey.setPressed(true); eating = true; }
        } else if (eating && !(p.isUsingItem() && p.getActiveItem().isOf(Items.GOLDEN_APPLE))) {
            stopEating(c);
        }
    }

    private boolean canEat(ClientPlayerEntity p) {
        if (p.isDead() || p.getItemCooldownManager().isCoolingDown(new ItemStack(Items.GOLDEN_APPLE))) return false;
        boolean has = smart.get() ? p.getOffHandStack().isOf(Items.GOLDEN_APPLE) || hotbarApple(p) != -1 : p.getOffHandStack().isOf(Items.GOLDEN_APPLE);
        if (!has) return false;
        float hp = p.getHealth() + (goldenHearts.get() ? p.getAbsorptionAmount() : 0f);
        return hp <= health.get();
    }

    private static int hotbarApple(ClientPlayerEntity p) { return Util.findHotbar(p, Items.GOLDEN_APPLE); }

    private void swapToApple(ClientPlayerEntity p) {
        int slot = hotbarApple(p), cur = p.getInventory().getSelectedSlot();
        if (slot == -1 || slot == cur) return;
        if (previousSlot == -1 && returnSlot.get()) previousSlot = cur;
        p.getInventory().setSelectedSlot(slot);
    }

    private void stopEating(MinecraftClient c) {
        if (!eating) return;
        c.options.useKey.setPressed(false);
        eating = false;
        if (c.player != null && previousSlot != -1 && returnSlot.get()) {
            c.player.getInventory().setSelectedSlot(previousSlot);
            previousSlot = -1;
        }
    }
}
