package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2f;

/**
 * Arrow Trails: a chain of chevron arrows (textures/gui/arrow_trail.png) is laid flat where you walk, each one pointing the
 * way you were going, then fading out. The arrows sit at the height of your feet (not on a ground found below you), so
 * they also work on blocks placed in mid-air (bridging over the void, scaffolds) and on slabs and stairs.
 *
 * Drawn as a screen overlay: three points of every arrow (centre, right edge, tip) are projected and the picture is
 * laid on them with a 2D affine transform, which is exact enough for an arrow this small.
 */
public class ArrowTrailsModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/arrow_trail.png");
    private static final int TEX = 256, HALF_PX = 64;      // the texture is drawn 128 px wide in local space
    private static final int MAX_ARROWS = 120;

    public final NumberSetting size = add(new NumberSetting("Size", 0.7, 0.3, 1.8, 0.1));
    public final NumberSetting spacing = add(new NumberSetting("Spacing (blocks)", 0.9, 0.4, 2.5, 0.1));
    public final NumberSetting lifetime = add(new NumberSetting("Lifetime (s)", 3.0, 0.5, 8.0, 0.5));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 90, 10, 100, 5));
    /** Off = the arrow only appears while you stand on something (a block in mid-air counts). On = also while you jump or fall. */
    public final BoolSetting inAir = add(new BoolSetting("While jumping", false));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));

    private record Arrow(double x, double y, double z, double dx, double dz, long start, float t) {}

    private final List<Arrow> arrows = new ArrayList<>();
    private final ScreenProjector proj = new ScreenProjector();
    private Vec3d last;
    private float counter;

    public ArrowTrailsModule() { super("Arrow Trails", Category.VISUALS); }

    @Override
    protected void onEnable() { last = null; }

    @Override
    protected void onDisable() { arrows.clear(); last = null; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Vec3d now = new Vec3d(p.getX(), p.getY(), p.getZ());
        if (last == null) { last = now; return; }
        if (!inAir.get() && !p.isOnGround()) { last = now; return; }   // stay in step with the feet, no gap-filling after a jump
        double dx = now.x - last.x, dz = now.z - last.z, d = Math.sqrt(dx * dx + dz * dz);
        if (d >= spacing.get() && d < 6.0) {                           // a teleport (large jump) doesn't draw a line of arrows
            arrows.add(new Arrow(now.x, now.y + 0.02, now.z, dx / d, dz / d, System.nanoTime(), counter));
            counter = (counter + 0.08f) % 1f;
            if (arrows.size() > MAX_ARROWS) arrows.remove(0);
            last = now;
        } else if (d >= 6.0) {
            last = now;
        }
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ArrowTrailsModule m = ModuleManager.get(ArrowTrailsModule.class);
        if (m == null || !m.isEnabled() || m.arrows.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        long now = System.nanoTime();
        double life = lifetime.get(), op = opacity.get() / 100.0, half = size.get() / 2.0;
        Theme th = Theme.current();
        arrows.removeIf(a -> (now - a.start()) / 1.0e9 > life);

        // far arrows first so the near ones are on top
        List<Arrow> list = new ArrayList<>(arrows);
        list.sort((a, b) -> Double.compare(dist2(c, b), dist2(c, a)));
        var mat = ctx.getMatrices();
        for (Arrow a : list) {
            double age = (now - a.start()) / 1.0e9, t = Math.min(1.0, age / life);
            double alpha = Math.min(1.0, age / 0.12) * Math.pow(1.0 - t, 0.8) * op;
            int al = (int) Math.round(Math.max(0, Math.min(1, alpha)) * 255);
            if (al < 4) continue;
            double s = half * (1.0 - 0.25 * t);

            Vec3d o = new Vec3d(a.x(), a.y(), a.z());
            double rx = -a.dz(), rz = a.dx();                              // right of the heading, on the ground
            if (!proj.project(o)) continue;
            double ox = proj.out[0], oy = proj.out[1];
            if (!proj.project(o.add(rx * s, 0, rz * s))) continue;
            double ex = proj.out[0] - ox, ey = proj.out[1] - oy;           // screen vector of "half a width to the right"
            if (!proj.project(o.add(a.dx() * s, 0, a.dz() * s))) continue;
            double fx = proj.out[0] - ox, fy = proj.out[1] - oy;           // screen vector of "half a length forward"
            if (Math.abs(ex) + Math.abs(ey) + Math.abs(fx) + Math.abs(fy) > 4000) continue;

            int rgb = themeColor.get() ? (th.at(a.t()) & 0xFFFFFF) : 0xFFFFFF;
            // local x = right, local y = down; forward (the arrow's tip, up in the picture) is -y
            mat.pushMatrix();
            mat.mul(new Matrix3x2f((float) (ex / HALF_PX), (float) (ey / HALF_PX),
                    (float) (-fx / HALF_PX), (float) (-fy / HALF_PX), (float) ox, (float) oy));
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, -HALF_PX, -HALF_PX, 0f, 0f, HALF_PX * 2, HALF_PX * 2,
                    TEX, TEX, TEX, TEX, (al << 24) | rgb);
            mat.popMatrix();
        }
    }

    private double dist2(MinecraftClient c, Arrow a) {
        double dx = a.x() - c.player.getX(), dy = a.y() - c.player.getY(), dz = a.z() - c.player.getZ();
        return dx * dx + dy * dy + dz * dz;
    }
}
