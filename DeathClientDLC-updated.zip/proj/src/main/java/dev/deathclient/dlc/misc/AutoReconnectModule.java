package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;

/**
 * AutoReconnect: when the server kicks you or the connection drops (the "Disconnected" screen), it joins the same
 * server again after Delay seconds, up to Attempts times in a row. Leaving the game yourself does not trigger it.
 */
public class AutoReconnectModule extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay (s)", 5, 1, 60, 1));
    public final NumberSetting attempts = add(new NumberSetting("Attempts", 5, 1, 30, 1));

    private ServerInfo last;
    private int ticks, tries;

    public AutoReconnectModule() {
        super("AutoReconnect", Category.MISC);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof DisconnectedScreen)) return;
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, dt) -> {
                if (!isEnabled() || last == null) return;
                String t = tries >= attempts.get() ? "AutoReconnect: attempts used up"
                        : "Reconnecting in " + Math.max(0, (int) Math.ceil(delay.get() - ticks / 20.0)) + " s  (" + (tries + 1) + "/" + (int) attempts.get() + ")";
                ctx.drawCenteredTextWithShadow(client.textRenderer, t, s.width / 2, 12, 0xFFFFFFFF);
            });
        });
    }

    @Override
    protected void onDisable() { ticks = 0; tries = 0; }

    private void tick(MinecraftClient c) {
        if (!isEnabled()) return;
        ServerInfo si = c.getCurrentServerEntry();
        if (si != null && c.world != null) { last = si; ticks = 0; tries = 0; return; }   // connected: remember the server
        if (!(c.currentScreen instanceof DisconnectedScreen) || last == null) { if (!(c.currentScreen instanceof net.minecraft.client.gui.screen.multiplayer.ConnectScreen)) ticks = 0; return; }
        if (tries >= attempts.get()) return;
        if (++ticks < delay.get() * 20) return;
        ticks = 0;
        tries++;
        ConnectScreen.connect(new MultiplayerScreen(new TitleScreen()), c, ServerAddress.parse(last.address), last, false, null);
    }
}
