package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Freelook: while it is on, the mouse turns only the camera. Your character keeps looking (and walking, and hitting)
 * where it was, nothing new is sent to the server. In first person it is a head turn, in third person (F5) the camera
 * orbits around you. Bind it to a key (.bind Freelook <key>) to switch it on and off while playing.
 */
public class FreelookModule extends Module {
    private static volatile FreelookModule instance;
    private float yaw, pitch;

    public FreelookModule() {
        super("Freelook", Category.RENDER);
        instance = this;
    }

    @Override
    protected void onEnable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) { yaw = p.getYaw(); pitch = p.getPitch(); }
    }

    /** True while Freelook drives the camera (Freecam has priority). */
    public static boolean active() {
        FreelookModule m = instance;
        return m != null && m.isEnabled() && MinecraftClient.getInstance().player != null && !FreecamModule.active();
    }

    /** Mouse turn (EntityLookMixin). Returns true if consumed, so the real player does not turn. */
    public static boolean look(double dx, double dy) {
        if (!active()) return false;
        FreelookModule m = instance;
        m.yaw += (float) dx * 0.15f;
        m.pitch = Math.max(-90f, Math.min(90f, m.pitch + (float) dy * 0.15f));
        return true;
    }

    private static boolean front() {
        return MinecraftClient.getInstance().options.getPerspective().isFrontView();
    }

    /** Angles the camera really uses (the front view looks back at you). */
    public static float viewYaw() { FreelookModule m = instance; return m == null ? 0f : front() ? m.yaw + 180f : m.yaw; }

    public static float viewPitch() { FreelookModule m = instance; return m == null ? 0f : front() ? -m.pitch : m.pitch; }

    public static float delta() {
        return MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
    }

    /** Camera position: your eye, pushed back 4 blocks in third person (shortened when a wall is in the way). */
    public static Vec3d camPos(float delta) {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        Vec3d eye = p.getLerpedPos(delta).add(0, p.getEyeHeight(p.getPose()), 0);
        if (c.options.getPerspective().isFirstPerson() || c.world == null) return eye;
        double yr = Math.toRadians(viewYaw()), pr = Math.toRadians(viewPitch());
        Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr));
        Vec3d want = eye.subtract(dir.multiply(4.0));
        var hit = c.world.raycast(new RaycastContext(eye, want, RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, p));
        if (hit.getType() == HitResult.Type.MISS) return want;
        double d = Math.max(0.0, hit.getPos().distanceTo(eye) - 0.25);
        return eye.subtract(dir.multiply(d));
    }
}
