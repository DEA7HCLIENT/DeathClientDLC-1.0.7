package dev.deathclient.dlc;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

/** No Friend Damage (from the second client): your own attacks on friends (see the Friends module) are cancelled. */
public class NoFriendDamageModule extends Module {
    private static NoFriendDamageModule instance;

    public NoFriendDamageModule() { super("No Friend Damage", Category.COMBAT); instance = this; }

    /** AttackEntityCallback. */
    static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
        NoFriendDamageModule m = instance;
        if (m != null && m.isEnabled() && world.isClient() && Friends.isFriend(entity)) return ActionResult.FAIL;
        return ActionResult.PASS;
    }
}
