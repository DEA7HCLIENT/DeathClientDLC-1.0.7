package dev.deathclient.dlc;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Hitboxes: makes other entities easier to hit by enlarging the box the crosshair is tested against, from 0 (the
 * default hitbox) up to 100 blocks. Direction: All sides, Sideways only, or Up only.
 *
 * Only the crosshair target is changed (EntityHitboxMixin and GameRendererHitboxMixin switch the bigger box on while
 * the game looks for the entity under the crosshair); movement, collisions, rendering and the server's own idea of
 * the hitbox stay as they are. A server still checks the distance of the hit itself, so a huge hitbox does not
 * make hits land from far away on a server that enforces reach.
 */
public class HitboxModule extends Module {
    /** Extra size in blocks added to the box; 0 = the default hitbox. */
    public final NumberSetting size = add(new NumberSetting("Size", 0.5, 0, 100, 0.1));
    /** Where the box grows. */
    public final NumberSetting direction = add(new NumberSetting("Direction", 1, 1, 3, 1).labels("All", "Sideways", "Up"));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    /** Draws the hitbox of nearby entities like F3+B does (the enlarged one in the theme colour), without the look line. */
    public final BoolSetting showBoxes = add(new BoolSetting("Show boxes", true));
    /** Also draws the normal hitbox (thin, white) inside the enlarged one. */
    public final BoolSetting showReal = add(new BoolSetting("Real box", true));
    /** Distance in blocks above each box; green while the target is within normal hit reach (3 blocks). */
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    /** The box of the player under your crosshair lights up: green = on the normal hitbox, orange = only on the enlarged part. */
    public final BoolSetting highlight = add(new BoolSetting("Highlight aimed", true));
    /** A line from the crosshair to the aimed player, drawn in the same colour. */
    public final BoolSetting lockLine = add(new BoolSetting("Lock line", true));
    /** After you hit a player, the crosshair turns towards the body or the head of that player for a short time. */
    public final NumberSetting aimAfterHit = add(new NumberSetting("Aim after hit", 1, 1, 3, 1).labels("Off", "Body", "Head"));
    /** Aim only after a hit made with the crosshair on that player (not hits sent by other modules). */
    public final BoolSetting aimCrosshairOnly = add(new BoolSetting("Aim: crosshair hits only", true));
    /** Aim only when that hit landed on the enlarged part, outside the normal hitbox (needs Size above 0). */
    public final BoolSetting aimEnlargedOnly = add(new BoolSetting("Aim: enlarged part only", false));
    /** Most degrees turned per tick while aiming. */
    public final NumberSetting aimSpeed = add(new NumberSetting("Aim speed", 8, 1, 30, 0.5));
    /** Share of the remaining angle covered per tick: low = soft, 1.0 = full speed all the way. */
    public final NumberSetting aimSmooth = add(new NumberSetting("Aim smoothing", 0.3, 0.05, 1.0, 0.05));
    /** How many ticks the aiming lasts after a hit (20 ticks = 1 s). */
    public final NumberSetting aimTicks = add(new NumberSetting("Aim duration", 10, 1, 40, 1));
    public final NumberSetting showRange = add(new NumberSetting("Show range", 24, 4, 128, 4));
    /** The boxes are drawn for the nearest targets only (like the other effects), so many players do not cost frames. */
    public final NumberSetting maxTargets = add(new NumberSetting("Max targets", 8, 1, 40, 1));

    /** True only while the game is searching for the entity under the crosshair. */
    public static volatile boolean scanning;

    private LivingEntity aimTarget;
    private int aimLeft;

    public HitboxModule() {
        super("Hitboxes", Category.COMBAT);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (isEnabled() && world.isClient() && player == mc.player
                    && (int) aimAfterHit.get() != 1 && entity instanceof LivingEntity le
                    && (!playersOnly.get() || le instanceof PlayerEntity)) {
                if (aimCrosshairOnly.get() && !(mc.crosshairTarget instanceof EntityHitResult h && h.getEntity() == entity)) return ActionResult.PASS;
                if (aimEnlargedOnly.get()) {
                    Vec3d eye = player.getEyePos();
                    boolean onReal = entity.getBoundingBox().raycast(eye, eye.add(player.getRotationVec(1.0f).multiply(12.0))).isPresent();
                    if (onReal) return ActionResult.PASS;
                }
                aimTarget = le;
                aimLeft = (int) aimTicks.get();
            }
            return ActionResult.PASS;
        });
    }

    @Override
    public void onTick(MinecraftClient c) {
        scanning = false;                                                     // safety: never stays on past a tick
        if (aimTarget == null) return;
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null || FreecamModule.active() || aimLeft-- <= 0
                || !aimTarget.isAlive() || aimTarget.isRemoved() || p.distanceTo(aimTarget) > 12) {
            aimTarget = null;
            return;
        }
        Vec3d point = (int) aimAfterHit.get() == 3 ? aimTarget.getEyePos() : aimTarget.getBoundingBox().getCenter();
        AimUtil.turn(c, p, point, aimSpeed.get(), aimSmooth.get());
    }

    @Override
    protected void onDisable() { scanning = false; aimTarget = null; }

    private final ScreenProjector proj = new ScreenProjector();

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        HitboxModule m = ModuleManager.get(HitboxModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        if (!m.showBoxes.get() && !m.showDistance.get()) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private record Item(Entity e, Box real, Box big, double dist) {}

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        Entity cam = c.getCameraEntity() != null ? c.getCameraEntity() : c.player;
        Vec3d from = cam.getLerpedPos(delta);
        double max = showRange.get();
        List<Item> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e == c.player || e == cam || e.isSpectator() || e.isRemoved() || !(e instanceof LivingEntity)) continue;
            if (playersOnly.get() && !(e instanceof PlayerEntity)) continue;
            Vec3d p = e.getLerpedPos(delta);
            double dist = p.distanceTo(from);
            if (dist > max) continue;
            Box real = e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());   // smooth between ticks
            list.add(new Item(e, real, expand(e, real), dist));
        }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(Item::dist));

        proj.begin(c, delta);
        int accent = 0xFF000000 | Theme.current().accent();
        Vec3d eye = from.add(0, cam.getEyeHeight(cam.getPose()), 0);
        Vec3d look = cam.getRotationVec(delta);
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        for (int i = 0, drawn = 0; i < list.size() && drawn < maxTargets.get(); i++) {
            Item it = list.get(i);
            if (!proj.project(it.big().getCenter())) continue;                   // behind the camera: skip
            double cx = proj.out[0], cy = proj.out[1];
            if (cx < -300 || cy < -300 || cx > sw + 300 || cy > sh + 300) continue;   // far off screen: skip
            drawn++;
            boolean aimed = c.crosshairTarget instanceof EntityHitResult h && h.getEntity() == it.e();
            int color = accent, th = 1;
            if (aimed && highlight.get()) {
                boolean onReal = it.real().raycast(eye, eye.add(look.multiply(12.0))).isPresent();
                color = onReal ? 0xFF55FF55 : 0xFFFFAA00;          // green: normal hitbox, orange: only the enlarged part
                th = 2;
                if (lockLine.get() && proj.project(it.real().getCenter())) {
                    EspModule.line(ctx, sw / 2, sh / 2, (int) Math.round(proj.out[0]), (int) Math.round(proj.out[1]), 1, color);
                }
            }
            if (showBoxes.get()) {
                drawBox(ctx, it.big(), color, th);
                if (showReal.get() && !it.big().equals(it.real())) drawBox(ctx, it.real(), 0x90FFFFFF, 1);
            }
            if (showDistance.get()) {
                Vec3d top = new Vec3d((it.big().minX + it.big().maxX) / 2, it.big().maxY + 0.1, (it.big().minZ + it.big().maxZ) / 2);
                if (proj.project(top)) {
                    String t = String.format("%.1fm", it.dist());
                    ctx.drawCenteredTextWithShadow(c.textRenderer, t, (int) proj.out[0], (int) proj.out[1] - 10,
                            it.dist() <= 3.0 ? 0xFF55FF55 : 0xFFFFFFFF);
                }
            }
        }
    }

    private void drawBox(DrawContext ctx, Box b, int color, int th) {
        double[] o = new double[4];
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                int j = i | bit;
                if (j == i) continue;                                  // each edge once
                if (proj.segment(corner(b, i), corner(b, j), o)) {
                    EspModule.line(ctx, (int) Math.round(o[0]), (int) Math.round(o[1]), (int) Math.round(o[2]), (int) Math.round(o[3]), th, color);
                }
            }
        }
    }

    /** Corner i of the box: bit 0 = x, bit 1 = y, bit 2 = z (1 = max side). */
    private static Vec3d corner(Box b, int i) {
        return new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
    }

    /** The box to test the crosshair against: {@code box} made bigger as set. */
    public static Box expand(Entity e, Box box) {
        HitboxModule m = ModuleManager.get(HitboxModule.class);
        if (m == null || !m.isEnabled()) return box;
        double s = m.size.get();
        if (s <= 0) return box;
        MinecraftClient c = MinecraftClient.getInstance();
        if (e == c.player || e == c.getCameraEntity() || !(e instanceof LivingEntity)) return box;
        if (m.playersOnly.get() && !(e instanceof PlayerEntity)) return box;
        return switch ((int) m.direction.get()) {
            case 2 -> box.expand(s, 0, s);          // sideways
            case 3 -> box.stretch(0, s, 0);         // up only
            default -> box.expand(s);               // all sides
        };
    }
}
