package dev.deathclient.dlc;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import java.util.Random;

/**
 * Auto Explosion (from the second client): place an obsidian block with obsidian in your hand and this puts an End
 * Crystal on it, then (3 ticks later) blows it up. Double Crystal places a second crystal and breaks that one too.
 * The hotbar slot is switched to the crystals and back afterwards. Rotation turns towards the spot / the crystal.
 */
public class AutoExplosionModule extends Module {
    private static final Random RANDOM = new Random();
    private static AutoExplosionModule instance;

    public final BoolSetting doubleCrystal = add(new BoolSetting("Double Crystal", false));
    public final NumberSetting rotation = add(AuraRotation.setting());

    private BlockPos obsidianPos;
    private int tick, prevSlot = -1;

    public AutoExplosionModule() { super("Auto Explosion", Category.COMBAT); instance = this; }

    /** UseBlockCallback: remember where obsidian was placed (the block next to the clicked face). */
    static ActionResult onUse(PlayerEntity player, World world, Hand hand, BlockHitResult hit) {
        AutoExplosionModule m = instance;
        if (m == null || !m.isEnabled() || !world.isClient() || hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (player.getMainHandStack().isOf(Items.OBSIDIAN)) {
            m.obsidianPos = hit.getBlockPos().offset(hit.getSide());
            m.prevSlot = -1;
            m.tick = 0;
        }
        return ActionResult.PASS;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (obsidianPos == null || p == null || c.world == null || c.interactionManager == null) return;
        int slot = Util.findHotbar(p, Items.END_CRYSTAL);
        if (slot == -1 || !c.world.getBlockState(obsidianPos).isOf(Blocks.OBSIDIAN) || !p.canInteractWithBlockAt(obsidianPos, 0.0)) { reset(p); return; }

        int rot = (int) rotation.get();
        if (tick == 1 || (doubleCrystal.get() && tick == 5)) placeCrystal(c, p, slot, rot);
        Box search = new Box(obsidianPos.up()).expand(0.5);
        for (EndCrystalEntity crystal : c.world.getEntitiesByClass(EndCrystalEntity.class, search, e -> true)) {
            if (tick >= 3 && p.canInteractWithEntity(crystal, 0.0)) {
                AuraRotation.face(c, p, point(p, crystal.getBoundingBox()), rot);
                c.interactionManager.attackEntity(p, crystal);
                p.swingHand(Hand.MAIN_HAND);
                AuraRotation.restore(c, p, rot);
                if (!doubleCrystal.get() || tick >= 7) { reset(p); return; }
                break;
            }
        }
        tick++;
        if (tick > (doubleCrystal.get() ? 8 : 4)) reset(p);
    }

    private void placeCrystal(MinecraftClient c, ClientPlayerEntity p, int slot, int rot) {
        int cur = p.getInventory().getSelectedSlot();
        if (cur != slot) {
            prevSlot = cur;
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            p.getInventory().setSelectedSlot(slot);
        } else if (prevSlot == -1) {
            prevSlot = cur;
        }
        Vec3d center = Vec3d.ofCenter(obsidianPos);
        Vec3d hitVec = new Box(obsidianPos).raycast(p.getEyePos(), center).orElse(center);
        Vec3d off = hitVec.subtract(center);
        BlockHitResult hit = new BlockHitResult(hitVec, Direction.getFacing(off.x, off.y, off.z), obsidianPos, false);
        AuraRotation.face(c, p, center, rot);
        c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, rot);
    }

    /** The nearest point of the crystal's box with a little noise, so the aim is never exactly the same. */
    private static Vec3d point(ClientPlayerEntity p, Box b) {
        Vec3d eye = p.getEyePos();
        return new Vec3d(net.minecraft.util.math.MathHelper.clamp(eye.x, b.minX, b.maxX) + rand(), net.minecraft.util.math.MathHelper.clamp(eye.y, b.minY, b.maxY) + rand(),
                net.minecraft.util.math.MathHelper.clamp(eye.z, b.minZ, b.maxZ) + rand());
    }

    private static double rand() { return (RANDOM.nextDouble() - 0.5) * 0.2; }

    private void reset(ClientPlayerEntity p) {
        if (prevSlot != -1 && p != null) {
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(prevSlot));
            p.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
        obsidianPos = null;
        tick = 0;
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        reset(c.player);
    }
}
