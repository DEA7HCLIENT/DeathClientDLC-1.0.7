package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * ESP: marks entities through walls. Mode: 2D (outline rectangle, optional fill, health bar and name),
 * five neon shapes with a marker above (Frame, Corners, Ring, Tech, Dots; white by default),
 * 3D Box (all 12 edges of the hitbox) or Circle (a ring on the ground around the feet).
 * Filters: Players, Mobs (hostile and other non-passive mobs), Animals (passive mobs and villagers), Invisibles
 * (invisible players) and Naked invisibles (invisible players with no armor, drawn in their own red colour).
 * Drawn as a screen overlay with ScreenProjector, so it needs no render-pipeline hooks.
 */
public class EspModule extends Module {
    private static final int MAX_TARGETS = 40;
    private static final int PLAYER = 0, MOB = 1, ANIMAL = 2, INVIS = 3, NAKED = 4, FRIEND = 5;
    private static final int[] COLORS = {0, 0xE08A3C, 0xA8D86B, 0xB06AFF, 0xFF4A4A, 0x4FD6D6};   // PLAYER uses the theme
    private static final int CIRCLE_SEGMENTS = 32;

    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 8, 1)
            .labels("2D", "3D Box", "Circle", "Frame", "Corners", "Ring", "Tech", "Dots"));
    /** The new shapes (Frame ... Dots) draw players in white; this switches them to the theme colour. */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    public final BoolSetting animals = add(new BoolSetting("Animals", false));
    public final BoolSetting invisibles = add(new BoolSetting("Invisibles", true));
    public final BoolSetting nakedInvisibles = add(new BoolSetting("Naked invisibles", true));
    public final NumberSetting range = add(new NumberSetting("Range", 64, 8, 160, 4));
    public final NumberSetting thickness = add(new NumberSetting("Thickness", 1, 1, 3, 1));
    /** 2D only. */
    public final BoolSetting fill = add(new BoolSetting("Fill", true));
    public final BoolSetting healthBar = add(new BoolSetting("Health bar", true));
    public final BoolSetting names = add(new BoolSetting("Names", true));

    private final ScreenProjector proj = new ScreenProjector();

    public EspModule() { super("ESP", Category.RENDER); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        EspModule m = ModuleManager.get(EspModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private record Target(Entity e, Box box, double dist, int kind) {}

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        Entity cam = c.getCameraEntity() != null ? c.getCameraEntity() : c.player;
        Vec3d from = cam.getLerpedPos(delta);
        double max = range.get();

        List<Target> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e == c.player || e == cam || e.isSpectator() || e.isRemoved()) continue;
            int kind = kind(e);
            if (kind < 0) continue;
            Vec3d p = e.getLerpedPos(delta);
            double dist = p.distanceTo(from);
            if (dist > max) continue;
            Box box = e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());   // smooth between ticks
            list.add(new Target(e, box, dist, kind));
        }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(Target::dist));

        proj.begin(c, delta);
        int theme = Theme.current().accent() & 0xFFFFFF;
        int th = (int) thickness.get(), m = (int) mode.get();
        for (int i = 0; i < Math.min(MAX_TARGETS, list.size()); i++) {
            Target t = list.get(i);
            int rgb = t.kind() == PLAYER ? theme : COLORS[t.kind()];
            switch (m) {
                case 2 -> box3d(ctx, t.box(), 0xFF000000 | rgb, th);
                case 3 -> circle(ctx, t.e(), t.box(), 0xFF000000 | rgb, th);
                case 4, 5, 6, 7, 8 -> styled(ctx, c, t, m, t.kind() == PLAYER && !themeColor.get() ? 0xFFFFFF : rgb, th);
                default -> box2d(ctx, c, t, rgb, th);
            }
        }
    }

    // ---- shapes ----

    /** Projects the 8 hitbox corners; bit 0 = x, bit 1 = y, bit 2 = z (1 = max side). Returns null per corner behind the camera. */
    private double[][] corners(Box b) {
        double[][] out = new double[8][];
        for (int i = 0; i < 8; i++) {
            Vec3d w = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (proj.project(w)) out[i] = new double[]{proj.out[0], proj.out[1]};
        }
        return out;
    }

    private void box3d(DrawContext ctx, Box b, int color, int th) {
        double[][] p = corners(b);
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                int j = i | bit;
                if (j == i || p[i] == null || p[j] == null) continue;     // each edge once, only if both ends are visible
                line(ctx, (int) Math.round(p[i][0]), (int) Math.round(p[i][1]),
                        (int) Math.round(p[j][0]), (int) Math.round(p[j][1]), th, color);
            }
        }
    }

    private void box2d(DrawContext ctx, MinecraftClient c, Target t, int rgb, int th) {
        double[][] p = corners(t.box());
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (double[] q : p) {
            if (q == null) return;                                        // partly behind the camera: skip
            minX = Math.min(minX, q[0]); maxX = Math.max(maxX, q[0]);
            minY = Math.min(minY, q[1]); maxY = Math.max(maxY, q[1]);
        }
        int x0 = (int) Math.round(minX), y0 = (int) Math.round(minY), x1 = (int) Math.round(maxX), y1 = (int) Math.round(maxY);
        if (x1 - x0 < 2 || y1 - y0 < 2 || x1 - x0 > 4000 || y1 - y0 > 4000) return;
        int color = 0xFF000000 | rgb;

        if (fill.get()) ctx.fill(x0, y0, x1, y1, 0x30000000 | rgb);
        ctx.fill(x0 - th, y0 - th, x1 + th, y0, color);                  // top
        ctx.fill(x0 - th, y1, x1 + th, y1 + th, color);                  // bottom
        ctx.fill(x0 - th, y0, x0, y1, color);                            // left
        ctx.fill(x1, y0, x1 + th, y1, color);                            // right

        if (healthBar.get() && t.e() instanceof LivingEntity le && le.getMaxHealth() > 0) {
            float hp = MathHelper.clamp(le.getHealth() / le.getMaxHealth(), 0f, 1f);
            int bx = x0 - th - 4, h = y1 - y0, filled = Math.round(h * hp);
            ctx.fill(bx - 1, y0 - 1, bx + 2, y1 + 1, 0xA0000000);        // background
            int hpColor = 0xFF000000 | ((int) (255 * (1 - hp)) << 16) | ((int) (255 * hp) << 8) | 0x20;
            ctx.fill(bx, y1 - filled, bx + 1, y1, hpColor);
        }
        if (names.get()) {
            String name = t.e().getName().getString();
            ctx.drawCenteredTextWithShadow(c.textRenderer, name, (x0 + x1) / 2, y0 - th - 10, 0xFFFFFFFF);
        }
    }

    // ---- the neon shapes (Frame, Corners, Ring, Tech, Dots): a bright line with a soft glow, a marker above ----

    /** A glowing straight line: a wide faint pass, a narrower one and the bright core. */
    private static void neon(DrawContext ctx, int x0, int y0, int x1, int y1, int th, int rgb) {
        boolean horiz = Math.abs(x1 - x0) >= Math.abs(y1 - y0);
        int[] grow = {4, 2, 0};
        int[] alpha = {0x18, 0x34, 0xFF};
        for (int i = 0; i < 3; i++) {
            int ox = horiz ? 0 : grow[i] / 2, oy = horiz ? grow[i] / 2 : 0;
            line(ctx, x0 - ox, y0 - oy, x1 - ox, y1 - oy, th + grow[i], (alpha[i] << 24) | rgb);
        }
    }

    /** A downward triangle over the target (a faint larger one under it as glow). */
    private static void marker(DrawContext ctx, int cx, int topY, int half, int rgb) {
        for (int pass = 0; pass < 2; pass++) {
            int g = pass == 0 ? 2 : 0, hh = half + g, hgt = (int) Math.round(half * 1.15) + g;
            int col = ((pass == 0 ? 0x34 : 0xFF) << 24) | rgb;
            for (int r = 0; r < hgt; r++) {
                int w = (int) Math.round(hh * (1.0 - r / (double) hgt));
                ctx.fill(cx - w, topY - g + r, cx + w + 1, topY - g + r + 1, col);
            }
        }
    }

    private void styled(DrawContext ctx, MinecraftClient c, Target t, int mode, int rgb, int th) {
        double[][] p = corners(t.box());
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (double[] q : p) {
            if (q == null) return;
            minX = Math.min(minX, q[0]); maxX = Math.max(maxX, q[0]);
            minY = Math.min(minY, q[1]); maxY = Math.max(maxY, q[1]);
        }
        int x0 = (int) Math.round(minX), y0 = (int) Math.round(minY), x1 = (int) Math.round(maxX), y1 = (int) Math.round(maxY);
        int w = x1 - x0, h = y1 - y0;
        if (w < 4 || h < 4 || w > 4000 || h > 4000) return;
        int cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
        if (fill.get()) ctx.fill(x0, y0, x1, y1, 0x1E000000 | rgb);

        int topY = y0;                                                  // where the marker sits above
        switch (mode) {
            case 4 -> {                                                 // Frame: a box with a gap in the middle of the top and bottom
                int gap = Math.max(8, w * 22 / 100);
                neon(ctx, x0, y0, cx - gap / 2, y0, th, rgb);  neon(ctx, cx + gap / 2, y0, x1, y0, th, rgb);
                neon(ctx, x0, y1, cx - gap / 2, y1, th, rgb);  neon(ctx, cx + gap / 2, y1, x1, y1, th, rgb);
                neon(ctx, x0, y0, x0, y1, th, rgb);            neon(ctx, x1, y0, x1, y1, th, rgb);
            }
            case 5 -> {                                                 // Corners: four brackets
                int lw = Math.max(6, w * 28 / 100), lh = Math.max(6, h * 20 / 100);
                neon(ctx, x0, y0, x0 + lw, y0, th, rgb);  neon(ctx, x0, y0, x0, y0 + lh, th, rgb);
                neon(ctx, x1, y0, x1 - lw, y0, th, rgb);  neon(ctx, x1, y0, x1, y0 + lh, th, rgb);
                neon(ctx, x0, y1, x0 + lw, y1, th, rgb);  neon(ctx, x0, y1, x0, y1 - lh, th, rgb);
                neon(ctx, x1, y1, x1 - lw, y1, th, rgb);  neon(ctx, x1, y1, x1, y1 - lh, th, rgb);
            }
            case 6 -> {                                                 // Ring: a circle around the whole body
                int r = (int) Math.round(Math.hypot(w, h) / 2 * 0.92);
                int n = 40;
                int px = cx + r, py = cy;
                for (int i = 1; i <= n; i++) {
                    double a = 2 * Math.PI * i / n;
                    int qx = cx + (int) Math.round(Math.cos(a) * r), qy = cy + (int) Math.round(Math.sin(a) * r);
                    neon(ctx, px, py, qx, qy, th, rgb);
                    px = qx; py = qy;
                }
                topY = cy - r;
            }
            case 7 -> {                                                 // Tech: bars with cut corners, segmented sides and blocks
                int cut = Math.max(4, Math.min(w, h) / 12), gap = Math.max(8, w * 18 / 100);
                neon(ctx, x0 + cut, y0, cx - gap / 2, y0, th, rgb);  neon(ctx, cx + gap / 2, y0, x1 - cut, y0, th, rgb);
                neon(ctx, x0 + cut, y1, x1 - cut, y1, th, rgb);
                neon(ctx, x0, y0 + cut, x0 + cut, y0, th, rgb);      neon(ctx, x1 - cut, y0, x1, y0 + cut, th, rgb);
                neon(ctx, x0, y1 - cut, x0 + cut, y1, th, rgb);      neon(ctx, x1 - cut, y1, x1, y1 - cut, th, rgb);
                int[][] seg = {{12, 30}, {38, 46}, {54, 100}};       // side dashes, in percent of the height
                for (int[] sg : seg) {
                    int ya = y0 + cut + (h - 2 * cut) * (sg[0] - 12) / 88, yb = y0 + cut + (h - 2 * cut) * (sg[1] - 12) / 88;
                    neon(ctx, x0, ya, x0, yb, th, rgb);  neon(ctx, x1, ya, x1, yb, th, rgb);
                    ctx.fill(x0 - 6, ya + 1, x0 - 3, yb - 1, 0xB0000000 | rgb);              // the blocks outside the sides
                    ctx.fill(x1 + 4, ya + 1, x1 + 7, yb - 1, 0xB0000000 | rgb);
                }
            }
            default -> {                                                // Dots: a slowly turning ring of dots around the body
                int rx = Math.max(6, (int) Math.round(w * 0.78)), ry = Math.max(8, (int) Math.round(h * 0.62));
                double spin = (System.nanoTime() / 1.0e9) * 0.5;
                int n = 36;
                for (int i = 0; i < n; i++) {
                    double a = spin + 2 * Math.PI * i / n;
                    int dx = cx + (int) Math.round(Math.cos(a) * rx), dy = cy + (int) Math.round(Math.sin(a) * ry);
                    int sz = i % 4 == 0 ? 3 : 2;
                    ctx.fill(dx - sz, dy - sz, dx + sz + 1, dy + sz + 1, 0x28000000 | rgb);   // glow
                    ctx.fill(dx - sz / 2, dy - sz / 2, dx - sz / 2 + sz, dy - sz / 2 + sz, 0xFF000000 | rgb);
                }
                topY = cy - ry;
            }
        }

        int half = Math.max(4, Math.min(10, w / 10));
        int mTop = topY - (int) Math.round(half * 1.15) - 5;
        marker(ctx, cx, mTop, half, rgb);

        if (healthBar.get() && t.e() instanceof LivingEntity le && le.getMaxHealth() > 0) {
            float hp = MathHelper.clamp(le.getHealth() / le.getMaxHealth(), 0f, 1f);
            int bx = x0 - th - 9, filled = Math.round(h * hp);
            ctx.fill(bx - 1, y0 - 1, bx + 2, y1 + 1, 0xA0000000);
            int hpColor = 0xFF000000 | ((int) (255 * (1 - hp)) << 16) | ((int) (255 * hp) << 8) | 0x20;
            ctx.fill(bx, y1 - filled, bx + 1, y1, hpColor);
        }
        if (names.get()) ctx.drawCenteredTextWithShadow(c.textRenderer, t.e().getName().getString(), cx, mTop - 11, 0xFFFFFFFF);
    }

    private void circle(DrawContext ctx, Entity e, Box b, int color, int th) {
        double cx = (b.minX + b.maxX) / 2, cz = (b.minZ + b.maxZ) / 2, y = b.minY + 0.02;
        double r = Math.max(b.maxX - b.minX, b.maxZ - b.minZ) / 2 + 0.3;
        double[] prev = null;
        double[] first = null;
        for (int i = 0; i <= CIRCLE_SEGMENTS; i++) {
            double a = 2 * Math.PI * (i % CIRCLE_SEGMENTS) / CIRCLE_SEGMENTS;
            double[] cur = proj.project(new Vec3d(cx + Math.cos(a) * r, y, cz + Math.sin(a) * r))
                    ? new double[]{proj.out[0], proj.out[1]} : null;
            if (prev != null && cur != null) {
                line(ctx, (int) Math.round(prev[0]), (int) Math.round(prev[1]),
                        (int) Math.round(cur[0]), (int) Math.round(cur[1]), th, color);
            }
            prev = cur;
        }
    }

    /**
     * Straight line from run-length fills: a mostly horizontal line is drawn as one horizontal run per row, a mostly
     * vertical one as one vertical run per column, so it costs only min(|dx|, |dy|) fills.
     */
    static void line(DrawContext ctx, int x0, int y0, int x1, int y1, int th, int color) {
        if (Math.abs(x0) > 6000 || Math.abs(x1) > 6000 || Math.abs(y0) > 6000 || Math.abs(y1) > 6000) return;
        if (Math.abs(x1 - x0) >= Math.abs(y1 - y0)) {
            if (x0 > x1) { int t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
            int dx = x1 - x0, rows = Math.abs(y1 - y0), sgn = y1 >= y0 ? 1 : -1;
            if (rows == 0) { ctx.fill(x0, y0, x1 + 1, y0 + th, color); return; }
            for (int i = 0; i <= rows; i++) {
                int xa = x0 + (int) Math.round(dx * Math.max(0, i - 0.5) / rows);
                int xb = x0 + (int) Math.round(dx * Math.min(rows, i + 0.5) / rows);
                int y = y0 + sgn * i;
                ctx.fill(xa, y, Math.max(xb, xa) + 1, y + th, color);
            }
        } else {
            if (y0 > y1) { int t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
            int dy = y1 - y0, cols = Math.abs(x1 - x0), sgn = x1 >= x0 ? 1 : -1;
            if (cols == 0) { ctx.fill(x0, y0, x0 + th, y1 + 1, color); return; }
            for (int i = 0; i <= cols; i++) {
                int ya = y0 + (int) Math.round(dy * Math.max(0, i - 0.5) / cols);
                int yb = y0 + (int) Math.round(dy * Math.min(cols, i + 0.5) / cols);
                int x = x0 + sgn * i;
                ctx.fill(x, ya, x + th, Math.max(yb, ya) + 1, color);
            }
        }
    }

    // ---- filters ----

    /** Which filter (and colour) an entity falls under, or -1 if it is not shown. */
    private int kind(Entity e) {
        if (e instanceof PlayerEntity pl) {
            if (pl.isInvisible()) {
                if (nakedInvisibles.get() && isNaked(pl)) return NAKED;
                return invisibles.get() ? INVIS : -1;
            }
            if (!players.get()) return -1;
            return Friends.isFriend(pl) ? FRIEND : PLAYER;
        }
        if (e instanceof PassiveEntity) return animals.get() ? ANIMAL : -1;
        if (e instanceof MobEntity) return mobs.get() ? MOB : -1;
        return -1;
    }

    private static boolean isNaked(PlayerEntity p) {
        return p.getEquippedStack(EquipmentSlot.HEAD).isEmpty() && p.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                && p.getEquippedStack(EquipmentSlot.LEGS).isEmpty() && p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }
}
