package dev.deathclient.dlc;

/**
 * See Invisible (from the second client): invisible players and mobs are drawn as translucent ghosts, the way a team mate
 * or a spectator sees them. Only how they are drawn changes (EntityMixin.isInvisibleTo); nothing is sent to the server.
 */
public class SeeInvisibleModule extends Module {
    private static SeeInvisibleModule instance;

    public SeeInvisibleModule() { super("See Invisible", Category.RENDER); instance = this; }

    public static boolean active() { return instance != null && instance.isEnabled(); }
}
