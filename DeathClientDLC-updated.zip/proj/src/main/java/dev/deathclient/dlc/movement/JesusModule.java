package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Jesus: walk across water. Each time your feet touch the water you are pushed back up, so you skim over the surface
 * instead of sinking. Hold sneak to go down. With "Lava" on it works on lava too (you still burn).
 */
public class JesusModule extends Module {
    public final NumberSetting lift = add(new NumberSetting("Lift", 0.12, 0.05, 0.4, 0.01));
    public final BoolSetting lava = add(new BoolSetting("Lava", false));

    public JesusModule() { super("Jesus", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || p.isSneaking() || p.getAbilities().flying) return;
        boolean liquid = p.isTouchingWater() || (lava.get() && p.isInLava());
        if (!liquid) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, Math.max(v.y, lift.get()), v.z);
    }
}
