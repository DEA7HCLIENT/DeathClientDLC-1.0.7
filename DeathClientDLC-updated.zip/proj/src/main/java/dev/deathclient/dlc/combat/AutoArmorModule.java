package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/**
 * AutoArmor: puts on the best armor from your inventory. The best piece is chosen by material (netherite, diamond,
 * iron, chainmail, copper, gold, turtle, leather). A worse piece you are wearing is taken off first and the better
 * one goes on a moment later. Works through the inventory slots, so no screen has to be open.
 */
public class AutoArmorModule extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 3, 1, 20, 1));
    public final BoolSetting onlyNoScreen = add(new BoolSetting("Only without a screen", true));

    private static final String[] PART = {"_helmet", "_chestplate", "_leggings", "_boots"};
    private static final String[] TIER = {"netherite_", "diamond_", "iron_", "chainmail_", "copper_", "golden_", "turtle_", "leather_"};
    private static final double[] SCORE = {6, 5, 4, 3, 2.5, 2, 1.5, 1};

    private int cooldown;

    public AutoArmorModule() { super("AutoArmor", Category.COMBAT); }

    /** Material score of an armor piece for the given part (0 = helmet ... 3 = boots); -1 if it is not that part. */
    private static double rank(ItemStack s, int part) {
        if (s.isEmpty()) return -1;
        String path = Registries.ITEM.getId(s.getItem()).getPath();
        if (!path.endsWith(PART[part])) return -1;
        for (int i = 0; i < TIER.length; i++) if (path.startsWith(TIER[i])) return SCORE[i];
        return 0.5;                                              // armor of an unknown material
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null) return;
        if (onlyNoScreen.get() && c.currentScreen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        var h = p.playerScreenHandler;
        for (int part = 0; part < 4; part++) {
            int armorSlot = 5 + part;                            // 5 helmet, 6 chest, 7 legs, 8 boots
            ItemStack worn = h.getSlot(armorSlot).getStack();
            double wornRank = rank(worn, part);
            int best = -1;
            double bestRank = Math.max(wornRank, 0);
            for (int i = 9; i <= 44; i++) {                      // main inventory and hotbar
                double r = rank(h.getSlot(i).getStack(), part);
                if (r > bestRank) { bestRank = r; best = i; }
            }
            if (best < 0) continue;
            int slot = worn.isEmpty() ? best : armorSlot;        // take the worse piece off first, then put the better one on
            c.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.QUICK_MOVE, p);
            cooldown = (int) delay.get();
            return;
        }
    }
}
