package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.Team;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Staff Viewer HUD (from the second client): lists the players of the tab list whose team prefix or tab-list name contains a staff
 * word (admin, moder, helper, owner, curator, staff, dev, support and the Russian forms). "Near" = loaded in your world,
 * "Online" = only in the tab list.
 */
public class StaffViewerHudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 160, 0, 1200, 1));

    private static final String[] WORDS = {"admin", "moder", "helper", "owner", "curator", "staff", "dev", "support",
            "админ", "модер", "хелпер", "куратор", "стаж", "владел", "разработ", "саппорт"};

    public StaffViewerHudModule() { super("Staff Viewer", Category.MISC, false); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        StaffViewerHudModule m = ModuleManager.get(StaffViewerHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        List<CooldownsHudModule.Row> rows = collect(c);
        if (rows.isEmpty() && c.currentScreen instanceof ChatScreen) rows.add(new CooldownsHudModule.Row("Preview Staff", "Status"));
        if (rows.isEmpty()) return;
        CooldownsHudModule.draw(ctx, c, "Staff Viewer", rows, (int) m.x.get(), (int) m.y.get(), (nx, ny) -> { m.x.set(nx); m.y.set(ny); });
    }

    private static List<CooldownsHudModule.Row> collect(MinecraftClient c) {
        List<CooldownsHudModule.Row> out = new ArrayList<>();
        var nh = c.getNetworkHandler();
        if (nh == null) return out;
        String self = c.player.getGameProfile().name();
        for (PlayerListEntry e : nh.getPlayerList()) {
            String name = e.getProfile().name();
            if (name.equals(self)) continue;
            Team t = c.world.getScoreboard().getScoreHolderTeam(name);
            String tag = (t == null ? "" : t.getPrefix().getString()) + (e.getDisplayName() == null ? "" : e.getDisplayName().getString());
            tag = tag.toLowerCase(Locale.ROOT);
            boolean staff = false;
            for (String w : WORDS) if (tag.contains(w)) { staff = true; break; }
            if (!staff) continue;
            boolean near = c.world.getPlayerByUuid(e.getProfile().id()) != null;
            out.add(new CooldownsHudModule.Row(name, near ? "Near" : "Online"));
        }
        return out;
    }
}
