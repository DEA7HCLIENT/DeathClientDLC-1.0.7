package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Pet: a little companion that floats beside you and follows you around. It is a picture (textures/gui/pet.png):
 * replace that file with any square PNG (a photo cut out on a transparent background works best) and it becomes
 * your own pet. It is drawn as a screen overlay at the projected world position, like Target ESP Image.
 * "Side" is the side of you it floats on, "Behind" how far back, "Height" how high above the feet,
 * "Follow" how quickly it catches up when you move (low = lazy and floaty), "Bob" the up-and-down hover.
 */
public class PetModule extends Module {
    /** Index = the "Pet" setting - 1. 0 is your own picture (pet.png), the rest are built in. */
    private static final Identifier[] TEXTURES = {
            Identifier.of("deathclientdlc", "textures/gui/pet.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_cat.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_dog.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_fox.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_dragon.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_slime.png"),
            Identifier.of("deathclientdlc", "textures/gui/pet_bat.png")};
    private static final int TEX = 256;

    /** Which pet floats beside you. Custom is textures/gui/pet.png, replace that file with your own picture. */
    public final NumberSetting pet = add(new NumberSetting("Pet", 1, 1, 7, 1).labels("Custom", "Cat", "Dog", "Fox", "Dragon", "Slime", "Bat"));
    public final NumberSetting size = add(new NumberSetting("Size", 0.7, 0.3, 2.0, 0.1));
    public final NumberSetting side = add(new NumberSetting("Side", 2, 1, 2, 1).labels("Left", "Right"));
    public final NumberSetting sideDistance = add(new NumberSetting("Side distance", 0.9, 0.3, 2.5, 0.1));
    public final NumberSetting behind = add(new NumberSetting("Behind", 0.4, -1.0, 3.0, 0.1));
    public final NumberSetting height = add(new NumberSetting("Height", 1.3, 0.2, 2.5, 0.1));
    public final NumberSetting follow = add(new NumberSetting("Follow", 0.15, 0.05, 0.5, 0.05));
    public final BoolSetting bob = add(new BoolSetting("Bob", true));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    private final ScreenProjector proj = new ScreenProjector();
    private Vec3d pos, prev;

    public PetModule() { super("Pet", Category.VISUALS); }

    @Override
    protected void onDisable() { pos = prev = null; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null) return;
        double yaw = Math.toRadians(p.getYaw());
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d back = new Vec3d(Math.sin(yaw), 0, -Math.cos(yaw));
        Vec3d s = (int) side.get() == 2 ? right : right.multiply(-1);
        Vec3d goal = p.getEntityPos().add(s.multiply(sideDistance.get())).add(back.multiply(behind.get())).add(0, height.get(), 0);
        if (pos == null || pos.squaredDistanceTo(goal) > 400) pos = goal;       // first tick, or after a teleport
        prev = pos;
        pos = pos.add(goal.subtract(pos).multiply(follow.get()));
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        PetModule m = ModuleManager.get(PetModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || m.pos == null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        Vec3d at = prev.add(pos.subtract(prev).multiply(delta));
        if (bob.get()) at = at.add(0, 0.08 * Math.sin(System.nanoTime() / 4.0e8), 0);
        proj.begin(c, delta);
        if (!proj.project(at)) return;
        double depth = proj.out[2];
        double pixels = size.get() / (depth * proj.tan) * (proj.screenHeight() / 2.0);
        pixels = Math.max(10, Math.min(pixels, proj.screenHeight() * 0.6));
        int half = (int) Math.round(pixels / 2.0);
        if (half < 1) return;
        int which = (int) pet.get() - 1;
        double t = System.nanoTime() / 3.0e8;
        int hw = half, hh = half;
        if (which == 5) {                                           // Slime: squashes and stretches
            double k = 0.07 * Math.sin(t * 1.3);
            hw = (int) Math.round(half * (1 + k)); hh = (int) Math.round(half * (1 - k));
        } else if (which == 6) {                                    // Bat: flaps up and down a little more
            at = at.add(0, 0.06 * Math.sin(t * 3.0), 0);
            if (!proj.project(at)) return;
        }
        int sx = (int) proj.out[0], sy = (int) proj.out[1];
        if (sx + hw < 0 || sy + hh < 0 || sx - hw > proj.screenWidth() || sy - hh > proj.screenHeight()) return;   // off screen: no draw call
        int color = themeColor.get() ? Theme.current().accent() | 0xFF000000 : 0xFFFFFFFF;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURES[Math.max(0, Math.min(TEXTURES.length - 1, which))], sx - hw, sy - hh,
                0f, 0f, hw * 2, hh * 2, TEX, TEX, TEX, TEX, color);
    }
}
