package dev.deathclient.dlc;

import net.minecraft.util.PlayerInput;

/**
 * Toggle Sneak: tap the sneak key once to keep sneaking, tap again to stop (no need to hold it).
 * The work is done in mixin.KeyboardInputMixin, which passes the input of every tick through {@link #apply}.
 */
public class ToggleSneakModule extends Module {
    private static volatile ToggleSneakModule instance;
    private boolean toggled, prev;

    public ToggleSneakModule() {
        super("Toggle Sneak", Category.MOVEMENT);
        instance = this;
    }

    @Override
    protected void onDisable() { toggled = false; prev = false; }

    /** Returns the input with the sneak flag replaced by the toggled state (unchanged while the module is off). */
    public static PlayerInput apply(PlayerInput in) {
        ToggleSneakModule m = instance;
        if (m == null || !m.isEnabled()) return in;
        boolean down = in.sneak();
        if (down && !m.prev) m.toggled = !m.toggled;
        m.prev = down;
        if (m.toggled == in.sneak()) return in;
        return new PlayerInput(in.forward(), in.backward(), in.left(), in.right(), in.jump(), m.toggled, in.sprint());
    }
}
