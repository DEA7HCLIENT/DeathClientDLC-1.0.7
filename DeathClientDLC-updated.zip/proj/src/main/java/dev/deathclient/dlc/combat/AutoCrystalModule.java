package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/**
 * Auto Crystal (from the second client): works on what your crosshair points at, no rotations of its own.
 * Aim at obsidian / bedrock and it places an End Crystal on it (fetching one from the inventory into the hotbar slot
 * when the hotbar has none, and swapping back); aim at a crystal and it breaks it.
 */
public class AutoCrystalModule extends Module {
    public final BoolSetting autoPlace = add(new BoolSetting("Auto Place", true));
    public final NumberSetting placeDelay = add(new NumberSetting("Place Delay", 0, 0, 5, 1));
    public final NumberSetting attackDelay = add(new NumberSetting("Attack Delay", 0, 0, 5, 1));
    public final NumberSetting attackRange = add(new NumberSetting("Attack Range", 6.0, 1.0, 6.0, 0.1));

    private int attackCd, placeCd;
    private int prevSlot = -1, restoreSlot = -1, restoreDelay;
    private int pendingInv = -1, pendingHot = -1, restoreInv = -1, restoreHot = -1, restoreInvDelay;

    public AutoCrystalModule() { super("Auto Crystal", Category.COMBAT); }

    @Override
    protected void onEnable() { resetAll(); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null) { resetAll(); return; }
        boolean restoring = tickRestoreInventory(c, p) | tickRestoreSlot(p);
        if (!restoring && autoPlace.get()) place(c, p);
        attack(c, p);
    }

    private void place(MinecraftClient c, ClientPlayerEntity p) {
        if (!(c.crosshairTarget instanceof BlockHitResult hit)) { cancelSwap(); return; }
        BlockPos pos = hit.getBlockPos();
        Block b = c.world.getBlockState(pos).getBlock();
        if (b != Blocks.OBSIDIAN && b != Blocks.BEDROCK) { cancelSwap(); return; }
        if (placeCd < (int) placeDelay.get()) { placeCd++; return; }
        if (hasCrystalOn(c, p, pos)) { cancelSwap(); return; }

        int slot = Util.findHotbar(p, Items.END_CRYSTAL);
        if (slot == -1) {                                                    // none in the hotbar: pull one from the inventory
            int inv = findInInventory(p);
            if (inv == -1) { cancelSwap(); return; }
            if (pendingInv == -1 && restoreInv == -1) {
                int sel = p.getInventory().getSelectedSlot();
                pendingInv = inv;
                pendingHot = sel;
                c.interactionManager.clickSlot(p.playerScreenHandler.syncId, inv, sel, SlotActionType.SWAP, p);
            }
            return;
        }
        int sel = p.getInventory().getSelectedSlot();
        if (sel != slot) {
            prevSlot = sel;
            p.getInventory().setSelectedSlot(slot);
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            return;
        }
        ActionResult r = c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) {
            p.swingHand(Hand.MAIN_HAND);
            if (prevSlot != -1) { restoreSlot = prevSlot; restoreDelay = 2; prevSlot = -1; }
            if (pendingInv != -1 && pendingHot != -1) {
                restoreInv = pendingInv; restoreHot = pendingHot; restoreInvDelay = 2;
                pendingInv = -1; pendingHot = -1;
            }
        }
        placeCd = 0;
    }

    private void attack(MinecraftClient c, ClientPlayerEntity p) {
        if (attackCd < (int) attackDelay.get()) { attackCd++; return; }
        if (!(c.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!(e instanceof EndCrystalEntity) || !e.isAlive()) return;
        double r = attackRange.get();
        if (p.squaredDistanceTo(e) > r * r) return;
        c.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
        attackCd = 0;
    }

    private boolean hasCrystalOn(MinecraftClient c, ClientPlayerEntity p, BlockPos base) {
        BlockPos cp = base.up();
        Box box = new Box(cp.getX(), cp.getY(), cp.getZ(), cp.getX() + 1.0, cp.getY() + 2.0, cp.getZ() + 1.0).expand(0.1);
        for (Entity e : c.world.getOtherEntities(p, box, x -> x instanceof EndCrystalEntity)) if (e.isAlive()) return true;
        return false;
    }

    private static int findInInventory(ClientPlayerEntity p) {
        for (int i = 9; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        return -1;
    }

    private boolean tickRestoreSlot(ClientPlayerEntity p) {
        if (restoreSlot == -1) return false;
        if (restoreDelay > 0) { restoreDelay--; return true; }
        int s = restoreSlot;
        restoreSlot = -1;
        if (p.getInventory().getSelectedSlot() != s) {
            p.getInventory().setSelectedSlot(s);
            p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(s));
        }
        return true;
    }

    private boolean tickRestoreInventory(MinecraftClient c, ClientPlayerEntity p) {
        if (restoreInv == -1 || restoreHot == -1) return false;
        if (restoreInvDelay > 0) { restoreInvDelay--; return true; }
        int inv = restoreInv, hot = restoreHot;
        restoreInv = -1;
        restoreHot = -1;
        c.interactionManager.clickSlot(p.playerScreenHandler.syncId, inv, hot, SlotActionType.SWAP, p);
        return true;
    }

    private void cancelSwap() {
        if (pendingInv != -1 && pendingHot != -1 && restoreInv == -1) {
            restoreInv = pendingInv; restoreHot = pendingHot; restoreInvDelay = 1;
            pendingInv = -1; pendingHot = -1;
        }
    }

    private void resetAll() {
        attackCd = 0; placeCd = 0;
        prevSlot = -1; restoreSlot = -1; restoreDelay = 0;
        pendingInv = -1; pendingHot = -1; restoreInv = -1; restoreHot = -1; restoreInvDelay = 0;
    }
}
