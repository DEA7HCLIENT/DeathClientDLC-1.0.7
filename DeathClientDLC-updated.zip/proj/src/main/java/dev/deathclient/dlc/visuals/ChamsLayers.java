package dev.deathclient.dlc;

import net.minecraft.client.render.RenderLayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Chams fill layer: the entity model drawn with a flat white texture (so the tint from ChamsModule becomes the colour),
 * translucent blending and the depth test OFF, so it is visible through walls.
 *
 * The 1.21.11 render API (RenderPipeline / RenderSetup) lives in the nested Builder class, which is only loaded inside
 * the try block of init(): if a class or method is missing in this build, the error is logged once and available() stays
 * false, so Chams falls back to the vanilla glow outline (see ChamsModule).
 */
public final class ChamsLayers {
    private static final Logger LOGGER = LoggerFactory.getLogger("DeathClientDLC/Chams");
    private static boolean tried;
    private static RenderLayer layer;

    private ChamsLayers() {}

    public static boolean available() { init(); return layer != null; }

    public static RenderLayer layer() { init(); return layer; }

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            layer = Builder.create();
            LOGGER.info("Chams fill layer created");
        } catch (Throwable t) {
            layer = null;
            LOGGER.warn("Chams fill layer is not available in this build, using the glow outline instead", t);
        }
    }

    private static final class Builder {
        static RenderLayer create() {
            com.mojang.blaze3d.pipeline.RenderPipeline pipeline = com.mojang.blaze3d.pipeline.RenderPipeline
                    .builder(net.minecraft.client.gl.RenderPipelines.ENTITY_SNIPPET)
                    .withLocation("pipeline/deathclientdlc_chams")
                    .withSampler("Sampler1")
                    .withBlend(com.mojang.blaze3d.pipeline.BlendFunction.TRANSLUCENT)
                    .withCull(false)
                    .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .build();
            net.minecraft.client.render.RenderSetup setup = net.minecraft.client.render.RenderSetup.builder(pipeline)
                    .texture("Sampler0", net.minecraft.util.Identifier.of("deathclientdlc", "textures/chams_white.png"))
                    .useLightmap()
                    .useOverlay()
                    .build();
            return RenderLayer.of("deathclientdlc_chams", setup);
        }
    }
}
