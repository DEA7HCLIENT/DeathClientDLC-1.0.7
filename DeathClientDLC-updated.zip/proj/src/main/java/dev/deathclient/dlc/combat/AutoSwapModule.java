package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import java.util.ArrayList;
import java.util.List;

/**
 * Auto Swap (from the second client): bind a key to it; each press puts the next of your chosen items into the off hand
 * (Totem, Head, GApple, Shield) from anywhere in the inventory, then the module switches itself off again.
 * Double = First Item and Second Item take turns; Triple = First, Second and Third in a cycle. If the off hand already
 * holds one of them, the next one of the list that you have is taken.
 */
public class AutoSwapModule extends Module {
    private static final int TOTEM = 1, HEAD = 2, GAPPLE = 3, SHIELD = 4;

    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 2, 1).labels("Double", "Triple"));
    public final NumberSetting first = add(new NumberSetting("First Item", TOTEM, 1, 4, 1).labels("Totem", "Head", "GApple", "Shield"));
    public final NumberSetting second = add(new NumberSetting("Second Item", GAPPLE, 1, 4, 1).labels("Totem", "Head", "GApple", "Shield"));
    public final NumberSetting third = add(new NumberSetting("Third Item", SHIELD, 1, 4, 1).labels("Totem", "Head", "GApple", "Shield"));

    public AutoSwapModule() { super("AutoSwap", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p != null && c.interactionManager != null && c.currentScreen == null) swap(c, p);
        toggle();
    }

    private void swap(MinecraftClient c, ClientPlayerEntity p) {
        List<Integer> items = new ArrayList<>();
        items.add((int) first.get());
        items.add((int) second.get());
        if ((int) mode.get() == 2) items.add((int) third.get());

        int cur = -1;                                               // which entry of the list the off hand holds now
        for (int i = 0; i < items.size(); i++) if (matches(items.get(i), p.getOffHandStack())) { cur = i; break; }
        for (int k = 1; k <= items.size(); k++) {
            int type = items.get(((cur < 0 ? -1 : cur) + k) % items.size());
            if (matches(type, p.getOffHandStack())) continue;       // the same kind is already there
            int slot = find(p, type);
            if (slot == -1) continue;
            p.setSprinting(false);
            c.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);   // 40 = off hand
            return;
        }
    }

    /** Screen slot (hotbar 36-44, inventory 9-35) holding that kind of item, or -1. */
    private static int find(ClientPlayerEntity p, int type) {
        for (int i = 0; i < 36; i++) {
            if (matches(type, p.getInventory().getStack(i))) return i < 9 ? i + 36 : i;
        }
        return -1;
    }

    private static boolean matches(int type, ItemStack s) {
        if (s.isEmpty()) return false;
        return switch (type) {
            case TOTEM -> s.isOf(Items.TOTEM_OF_UNDYING);
            case HEAD -> s.isOf(Items.PLAYER_HEAD);
            case GAPPLE -> s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
            default -> s.isOf(Items.SHIELD);
        };
    }
}
