package dev.deathclient.dlc;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** No Web (from the second client, Grim mode): inside a cobweb you move at 0.35 along your input, up at 0.65 with jump, down with sneak. */
public class NoWebModule extends Module {
    public NoWebModule() { super("No Web", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || !inWeb(c, p)) return;
        Vec3d d = Util.inputDir(c, p);
        double vy = c.options.jumpKey.isPressed() ? 0.65 : c.options.sneakKey.isPressed() ? -0.65 : 0.0;
        p.setVelocity(d.x * 0.35, vy, d.z * 0.35);
    }

    private static boolean inWeb(MinecraftClient c, ClientPlayerEntity p) {
        for (BlockPos pos : BlockPos.iterate(BlockPos.ofFloored(p.getBoundingBox().minX, p.getBoundingBox().minY, p.getBoundingBox().minZ),
                BlockPos.ofFloored(p.getBoundingBox().maxX, p.getBoundingBox().maxY, p.getBoundingBox().maxZ))) {
            if (c.world.getBlockState(pos).isOf(Blocks.COBWEB)) return true;
        }
        return false;
    }
}
