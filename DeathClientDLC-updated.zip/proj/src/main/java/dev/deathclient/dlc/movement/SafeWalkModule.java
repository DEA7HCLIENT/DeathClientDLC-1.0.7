package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * SafeWalk: you cannot walk off the edge of a block. At the edge the game is told you are sneaking (only that tick,
 * only while you are on the ground, moving and not jumping), so you stop at the edge like a sneaking player.
 * The work is done in mixin.KeyboardInputMixin, which passes the input of every tick through {@link #apply}.
 */
public class SafeWalkModule extends Module {
    private static volatile SafeWalkModule instance;

    public SafeWalkModule() {
        super("SafeWalk", Category.MOVEMENT);
        instance = this;
    }

    /** True when the player is on the ground, moving, and there is no block under the spot just ahead of the feet. */
    static boolean atEdge(MinecraftClient c, ClientPlayerEntity p) {
        if (c.world == null || !p.isOnGround()) return false;
        Vec3d d = Util.inputDir(c, p);
        if (d.lengthSquared() == 0) return false;
        Box b = p.getBoundingBox();
        Box slice = new Box(b.minX, b.minY - 0.5, b.minZ, b.maxX, b.minY - 0.01, b.maxZ).contract(0.1, 0, 0.1).offset(d.x * 0.35, 0, d.z * 0.35);
        return c.world.isSpaceEmpty(p, slice);
    }

    /** Returns the input with sneak switched on at an edge (unchanged otherwise or while the module is off). */
    public static PlayerInput apply(PlayerInput in) {
        SafeWalkModule m = instance;
        if (m == null || !m.isEnabled() || in.sneak() || in.jump()) return in;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || !atEdge(c, p)) return in;
        return new PlayerInput(in.forward(), in.backward(), in.left(), in.right(), in.jump(), true, in.sprint());
    }
}
