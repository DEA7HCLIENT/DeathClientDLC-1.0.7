package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Cooldowns HUD (from the second client): every item in the hotbar / off hand that is on cooldown (ender pearl, golden apple,
 * shield, chorus fruit ...) with the time left. The time is estimated from how fast the cooldown shrinks, so it is
 * a percentage for the first fraction of a second. Open the chat to drag the panel.
 */
public class CooldownsHudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 100, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;
    /** item id -> {last progress, smoothed rate per second, last sample time in seconds}. */
    private static final Map<String, float[]> TRACK = new HashMap<>();

    public CooldownsHudModule() { super("Cooldowns", Category.MISC, false); }

    record Row(String name, String value) {}

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CooldownsHudModule m = ModuleManager.get(CooldownsHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        List<Row> rows = collect(c);
        if (rows.isEmpty() && c.currentScreen instanceof ChatScreen) rows.add(new Row("Preview Cooldown", "**:**"));
        if (rows.isEmpty()) return;
        draw(ctx, c, "Cooldowns", rows, (int) m.x.get(), (int) m.y.get(), (nx, ny) -> { m.x.set(nx); m.y.set(ny); });
    }

    private static List<Row> collect(MinecraftClient c) {
        List<Row> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        float now = System.nanoTime() / 1.0e9f;
        for (int i = 0; i < 10; i++) {
            ItemStack st = i < 9 ? c.player.getInventory().getStack(i) : c.player.getOffHandStack();
            if (st.isEmpty()) continue;
            String id = Registries.ITEM.getId(st.getItem()).toString();
            if (!seen.add(id)) continue;
            float p = c.player.getItemCooldownManager().getCooldownProgress(st, 0f);
            if (p <= 0f) { TRACK.remove(id); continue; }
            float[] s = TRACK.computeIfAbsent(id, k -> new float[]{p, 0f, now});
            float el = now - s[2];
            if (el > 0.05f) {
                float rate = (s[0] - p) / el;
                s[1] = s[1] == 0f ? rate : s[1] + (rate - s[1]) * 0.2f;
                s[0] = p;
                s[2] = now;
            }
            String val = s[1] > 0.001f ? String.format(Locale.ROOT, "%.1fs", p / s[1]) : Math.round(p * 100f) + "%";
            out.add(new Row(st.getName().getString(), val));
        }
        return out;
    }

    /** The shared panel look of the the second client list HUDs: dark card, accent line under the title, name left / value right. */
    static void draw(DrawContext ctx, MinecraftClient c, String title, List<Row> rows, int x, int y,
                     java.util.function.BiConsumer<Integer, Integer> setPos) {
        var tr = c.textRenderer;
        int rowH = 12, pad = 6;
        int w = Fonts.width(tr, title) + 14;
        for (Row r : rows) w = Math.max(w, Fonts.width(tr, r.name()) + 14 + Fonts.width(tr, r.value()));
        w += pad * 2;
        int h = 16 + rows.size() * rowH + 3;
        HudEdit.track(x, y, w, h, setPos);
        Shapes.panel(ctx, x, y, w, h, BG);
        ctx.fill(x, y + 14, x + w, y + 15, Theme.current().accent());
        Fonts.draw(ctx, tr, title, x + pad, y + 3, WHITE);
        int ry = y + 18;
        for (Row r : rows) {
            Fonts.draw(ctx, tr, r.name(), x + pad, ry, WHITE);
            Fonts.draw(ctx, tr, r.value(), x + w - pad - Fonts.width(tr, r.value()), ry, MUTED);
            ry += rowH;
        }
    }
}
