package dev.deathclient.dlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.Identifier;

public class DeathClientDLC implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        License.restore();
        ClientLifecycleEvents.CLIENT_STARTED.register(WindowBranding::apply);
        // Replace the vanilla title screen (exact class check, so our own screen is never replaced).
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!Unhook.active() && screen.getClass() == TitleScreen.class) {
                StartupSound.play(client);
                // First time this launch: the start-up screen (icon on black), which opens the main menu itself.
                client.setScreen(!License.unlocked() ? new LoginScreen() : SplashScreen.done ? new MainMenuScreen() : new SplashScreen());
            }
        });

        Binds.load();
        Friends.load();
        Emotes.load();
        WaypointsModule.load();
        Config.restore();                       // settings + theme now, on/off flags on first world join
        ChatCommands.init();
        // Emote broadcasts are hidden from the chat (they would show up as an empty line).
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, time) -> !ClientUsers.onEmoteMessage(message));
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> !ClientUsers.onEmoteMessage(message));
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) -> ClientUsers.onMessage(message));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> ClientUsers.onMessage(message));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientUsers.clear());
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud"), Hud::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "keybinds"), KeybindsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "keystrokes"), KeystrokesModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "cooldowns_hud"), CooldownsHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "staff_viewer"), StaffViewerHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "effects_hud"), EffectsHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "notifications"), NotificationsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "info_hud"), InfoHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "cps_hud"), CpsHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "combo_counter"), ComboCounterModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "item_counter"), ItemCounterModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "waypoints"), WaypointsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "friend_list"), FriendListHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "swing_popup"), SwingAnimationModule::renderPopup);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "block_esp"), BlockEspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_esp"), TargetEspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "esp"), EspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hitbox_boxes"), HitboxModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "aim_fov"), AimAssistModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "arrows"), ArrowsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "jump_circle"), JumpCircleModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "particles"), ParticlesModule::render);
        AttackEntityCallback.EVENT.register(ParticlesModule::onAttack);
        AttackEntityCallback.EVENT.register(NoFriendDamageModule::onAttack);
        AttackEntityCallback.EVENT.register(ShiftTapModule::onAttack);
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register(AutoExplosionModule::onUse);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "china_hat"), ChinaHatModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "pet"), PetModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "ambience"), AmbienceModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "firefly"), FireFlyModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "arrow_trails"), ArrowTrailsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "wings"), WingsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "figure"), FigureModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "name_tags"), NameTagsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "freecam"), FreecamModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "damage_numbers"), DamageNumbersModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "glass_hand"), GlassHandModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_hud"), TargetHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "kill_effects"), KillEffectsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "crosshair"), CrosshairModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "damage_vignette"), DamageVignetteModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hit_marker"), HitMarkerModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "speed_lines"), SpeedLinesModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "compass_hud"), CompassHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "armor_hud"), ArmorHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "time_hud"), TimeHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "watermark"), WatermarkModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "saturation_viewer"), SaturationViewerModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "custom_hotbar"), CustomHotbarModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "custom_model"), CustomModelModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud_edit"), HudEdit::render);   // last: drag HUD in chat

        ClientTickEvents.START_CLIENT_TICK.register(FreecamModule::blockInteractions);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Binds.tick(client);                 // also opens/closes the ClickGUI on its bound key
            ModuleManager.tick(client);
            Emotes.tick(client);
            Config.autosaveTick();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.autosaveNow());
    }
}
