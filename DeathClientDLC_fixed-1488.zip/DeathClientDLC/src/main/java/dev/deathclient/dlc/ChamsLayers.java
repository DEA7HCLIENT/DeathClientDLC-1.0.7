package dev.deathclient.dlc;

import net.minecraft.client.render.RenderLayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Chams render layer. DISABLED for now: the 1.21.11 render-layer API names were not verified, so this returns null
 * and entities render normally. Re-enable by restoring the RenderPipeline/MultiPhase code once the names are checked.
 */
public final class ChamsLayers {
    private static final Logger LOGGER = LoggerFactory.getLogger("DeathClientDLC/Chams");

    private ChamsLayers() {}

    public static boolean available() { return false; }

    public static RenderLayer layer() { return null; }
}
