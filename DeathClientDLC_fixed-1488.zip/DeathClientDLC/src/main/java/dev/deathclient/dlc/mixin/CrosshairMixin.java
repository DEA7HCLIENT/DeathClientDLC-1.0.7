package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.CrosshairModule;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the game's own crosshair while Custom Crosshair runs with "Hide vanilla" on.
 * No arguments are read, so the hook does not depend on the method's signature.
 * require = 0: if the method is named differently in this build, nothing happens (the vanilla crosshair stays).
 */
@Mixin(InGameHud.class)
public abstract class CrosshairMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$hideCrosshair(CallbackInfo ci) {
        if (CrosshairModule.hidesVanilla()) ci.cancel();
    }
}
