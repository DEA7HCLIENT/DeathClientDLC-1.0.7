package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Air strafe: redirects current horizontal momentum to the input direction. */
public class StrafeModule extends Module {
    public final NumberSetting baseSpeed = add(new NumberSetting("Base speed", 0.35, 0.1, 2.0, 0.01));
    /** Multiplier on the redirected momentum; 1.0 keeps your speed, above 1.0 adds to it every tick. */
    public final NumberSetting boost = add(new NumberSetting("Boost", 1.0, 0.8, 1.5, 0.01));

    public StrafeModule() { super("Strafe", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.isOnGround()) return;
        Vec3d d = Util.inputDir(c, p);
        if (d.lengthSquared() == 0) return;
        Vec3d v = p.getVelocity();
        double speed = Math.max(Math.sqrt(v.x * v.x + v.z * v.z) * boost.get(), baseSpeed.get());
        p.setVelocity(d.x * speed, v.y, d.z * speed);
    }
}
