package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Hit Marker: a small X around the crosshair for a moment when the entity under it loses health.
 * Client feedback only: it reads your own screen, and it does not change what anyone else sees.
 */
public class HitMarkerModule extends Module {
    public final NumberSetting duration = add(new NumberSetting("Duration (ticks)", 8, 2, 20, 1));
    public final NumberSetting size = add(new NumberSetting("Size", 5, 2, 12, 1));
    public final NumberSetting thickness = add(new NumberSetting("Thickness", 2, 1, 4, 1));
    public final BoolSetting killColor = add(new BoolSetting("Red on kill", true));

    private LivingEntity watched;
    private float lastHealth;
    private int left;
    private boolean killed;

    public HitMarkerModule() { super("Hit Marker", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        LivingEntity target = null;
        if (c.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le) target = le;
        if (target != null && target == watched && target.getHealth() < lastHealth) {
            left = (int) duration.get();
            killed = target.getHealth() <= 0;
        }
        watched = target;
        lastHealth = target == null ? 0 : target.getHealth();
        if (left > 0) left--;
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        HitMarkerModule m = ModuleManager.get(HitMarkerModule.class);
        if (m == null || !m.isEnabled() || m.left <= 0 || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden || c.currentScreen != null) return;
        int cx = c.getWindow().getScaledWidth() / 2, cy = c.getWindow().getScaledHeight() / 2;
        int s = (int) m.size.get(), t = (int) m.thickness.get();
        double fade = m.left / m.duration.get();
        int a = (int) (255 * Math.max(0.25, fade));
        int rgb = (m.killed && m.killColor.get()) ? 0xFF3030 : 0xFFFFFF;
        int col = (a << 24) | rgb;
        // Two diagonals made of small squares, forming an X.
        for (int i = -s; i <= s; i++) {
            int px = cx + i, py1 = cy + i, py2 = cy - i;
            ctx.fill(px - t / 2 + 1, py1 - t / 2 + 1, px - t / 2 + t, py1 - t / 2 + t, col);
            ctx.fill(px - t / 2 + 1, py2 - t / 2 + 1, px - t / 2 + t, py2 - t / 2 + t, col);
        }
    }
}
