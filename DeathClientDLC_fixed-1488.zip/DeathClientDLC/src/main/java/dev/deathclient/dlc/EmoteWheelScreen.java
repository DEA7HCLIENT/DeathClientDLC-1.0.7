package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Emote wheel: opens on the wheel key (default B, see Binds). The emotes sit on a ring, the one under the cursor
 * (by direction from the centre) is highlighted. Pick one by clicking it, or hold the key, point and release.
 * The middle circle stops the current emote. Esc closes the wheel. Colours come from the static theme gradient.
 */
public class EmoteWheelScreen extends Screen {
    private static final int BTN_W = 62, BTN_H = 20, INNER = 26;
    private static final int BG = 0xE016161F, TEXT = 0xFFFFFFFF, MUTED = 0xFF8C8C99;
    /** Hovered slot: 0..N-1, CENTER (stop), or NONE. */
    private static final int NONE = -1, CENTER = -2;

    private boolean keyWasHeld = true;                  // the wheel opens while its key is held

    public EmoteWheelScreen() { super(Text.literal("Emotes")); }

    private int count() { return Emotes.NAMES.length; }

    private int cx() { return width / 2; }

    private int cy() { return height / 2; }

    private int ringRadius() { return Math.max(60, Math.min(112, Math.min(width, height) / 2 - 30)); }

    /** Slot 0 is at the top, then clockwise. */
    private double slotAngle(int i) { return -Math.PI / 2 + i * 2 * Math.PI / count(); }

    private int slotAt(double mx, double my) {
        double dx = mx - cx(), dy = my - cy();
        if (Math.sqrt(dx * dx + dy * dy) < INNER) return CENTER;
        double a = Math.atan2(dy, dx) + Math.PI / 2;           // 0 = straight up
        if (a < 0) a += 2 * Math.PI;
        return (int) Math.round(a / (2 * Math.PI / count())) % count();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        Ui.drawWorldDim(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int hover = slotAt(mx, my);

        // Hold the key, point at an emote, let go: plays it. A quick tap just leaves the wheel open for clicking.
        boolean held = Binds.wheelHeld();
        if (keyWasHeld && !held && hover >= 0) { choose(hover); return; }
        keyWasHeld = held;

        Theme th = Theme.current();
        int n = count(), r = ringRadius();
        for (int i = 0; i < n; i++) {
            int bx = (int) Math.round(cx() + Math.cos(slotAngle(i)) * r) - BTN_W / 2;
            int by = (int) Math.round(cy() + Math.sin(slotAngle(i)) * r) - BTN_H / 2;
            int col = th.at(n == 1 ? 0f : i / (float) (n - 1)) & 0xFFFFFF;
            boolean on = i == hover;
            ClickGuiScreen.rrect(ctx, bx - 1, by - 1, BTN_W + 2, BTN_H + 2, 0xFF000000 | col, 5);
            ClickGuiScreen.rrect(ctx, bx, by, BTN_W, BTN_H, on ? 0xFF000000 | col : BG, 4);
            String s = Emotes.LABELS[i];
            ctx.drawTextWithShadow(textRenderer, Fonts.gui(s), bx + (BTN_W - Fonts.guiWidth(textRenderer, s)) / 2,
                    by + (BTN_H - 8) / 2, on ? TEXT : 0xFFD8D8E2);
        }

        // Centre: shows what is under the cursor; click = stop the current emote.
        int accent = th.accent() & 0xFFFFFF;
        ClickGuiScreen.rrect(ctx, cx() - INNER - 1, cy() - INNER - 1, 2 * INNER + 2, 2 * INNER + 2, 0xFF000000 | accent, INNER + 1);
        ClickGuiScreen.rrect(ctx, cx() - INNER, cy() - INNER, 2 * INNER, 2 * INNER, hover == CENTER ? 0xFF2A2A38 : BG, INNER);
        String mid = hover == CENTER ? "Стоп" : hover >= 0 ? "▶" : "Эмоции";
        ctx.drawTextWithShadow(textRenderer, Fonts.gui(mid), cx() - Fonts.guiWidth(textRenderer, mid) / 2, cy() - 4,
                hover == CENTER || hover >= 0 ? TEXT : MUTED);
    }

    private void choose(int slot) {
        if (slot == CENTER) Emotes.stop();
        else if (slot >= 0) Emotes.play(Emotes.NAMES[slot]);
        close();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        int slot = slotAt(click.x(), click.y());
        if (slot == NONE) return true;
        choose(slot);
        return true;
    }

    @Override
    public boolean shouldPause() { return false; }
}
