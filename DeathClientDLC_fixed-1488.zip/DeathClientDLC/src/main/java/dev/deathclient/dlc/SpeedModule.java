package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class SpeedModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.5, 0.1, 2.0, 0.01));
    public final BoolSetting autoJump = add(new BoolSetting("Auto jump", false));

    public SpeedModule() { super("Speed", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Vec3d d = Util.inputDir(c, p);
        if (d.lengthSquared() == 0) return;
        p.setSprinting(true);
        Vec3d v = p.getVelocity();
        double vy = autoJump.get() && p.isOnGround() ? 0.42 : v.y;   // vanilla jump impulse
        p.setVelocity(d.x * speed.get(), vy, d.z * speed.get());
    }
}
