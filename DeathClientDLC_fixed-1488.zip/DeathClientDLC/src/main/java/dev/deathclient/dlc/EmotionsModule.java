package dev.deathclient.dlc;

/**
 * Emotions: your own model plays an emote (look at it in third person, which this module switches to by itself).
 * Emotes: 67, Hello, Custom and Cheer, Clap, Flex, Salute, Dab, Shrug, Airplane, Zombie, Boxing, Robot, Think, Facepalm, Dance. Custom is (your own two poses, A and B, that the
 * model moves between; every angle is in degrees: "arm" 0 = hanging, -90 = forward, -180 = straight up, "side" = outward).
 * Turn the module on to play, off to stop; bind it to a key for one-press emotes. Chat: .emote 67 | привет | custom |
 * save <name> (keeps the current Custom poses under that name) | <name> | del <name> | list | stop.
 * Other players who run this client see your ready-made emotes too (Share with clients) and you see theirs (Show others);
 * the emote travels as a hidden chat message, so it needs a server that keeps zero-width characters. Custom emotes stay local.
 */
public class EmotionsModule extends Module {
    public final NumberSetting emote = add(new NumberSetting("Emote", 1, 1, Emotes.NAMES.length, 1).labels(Emotes.LABELS));
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.2, 4.0, 0.1));
    public final BoolSetting thirdPerson = add(new BoolSetting("Third person", true));
    public final BoolSetting stopOnMove = add(new BoolSetting("Stop on move", true));
    /** Tell other client users which emote you play (a hidden chat message, see ClientUsers). Not sent for Custom emotes. */
    public final BoolSetting share = add(new BoolSetting("Share with clients", true));
    /** Play the emotes other client users share on their models. */
    public final BoolSetting showOthers = add(new BoolSetting("Show others", true));

    // Custom emote: pose A and pose B.
    public final NumberSetting aRArm = add(new NumberSetting("A R arm", -150, -180, 180, 5));
    public final NumberSetting aRSide = add(new NumberSetting("A R side", 15, -90, 90, 5));
    public final NumberSetting aLArm = add(new NumberSetting("A L arm", -150, -180, 180, 5));
    public final NumberSetting aLSide = add(new NumberSetting("A L side", 15, -90, 90, 5));
    public final NumberSetting aHeadPitch = add(new NumberSetting("A Head pitch", 10, -60, 60, 5));
    public final NumberSetting aHeadYaw = add(new NumberSetting("A Head yaw", 0, -90, 90, 5));
    public final NumberSetting bRArm = add(new NumberSetting("B R arm", -110, -180, 180, 5));
    public final NumberSetting bRSide = add(new NumberSetting("B R side", 40, -90, 90, 5));
    public final NumberSetting bLArm = add(new NumberSetting("B L arm", -110, -180, 180, 5));
    public final NumberSetting bLSide = add(new NumberSetting("B L side", 40, -90, 90, 5));
    public final NumberSetting bHeadPitch = add(new NumberSetting("B Head pitch", -10, -60, 60, 5));
    public final NumberSetting bHeadYaw = add(new NumberSetting("B Head yaw", 0, -90, 90, 5));

    public EmotionsModule() { super("Emotions", Category.VISUALS); }

    /** The twelve Custom values: pose A (R arm, R side, L arm, L side, head pitch, head yaw), then pose B. */
    double[] custom() {
        return new double[]{aRArm.get(), aRSide.get(), aLArm.get(), aLSide.get(), aHeadPitch.get(), aHeadYaw.get(),
                bRArm.get(), bRSide.get(), bLArm.get(), bLSide.get(), bHeadPitch.get(), bHeadYaw.get()};
    }

    @Override
    protected void onEnable() {
        Emotes.play(Emotes.NAMES[Math.max(0, Math.min(Emotes.NAMES.length - 1, (int) emote.get() - 1))]);
    }

    @Override
    protected void onDisable() { Emotes.stop(); }
}
