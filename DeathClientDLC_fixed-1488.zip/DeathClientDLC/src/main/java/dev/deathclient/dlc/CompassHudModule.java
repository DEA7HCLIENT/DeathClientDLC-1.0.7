package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Compass HUD: a heading bar at the top of the screen. Letters mark N, E, S, W; ticks every 15 degrees; the centre
 * line is where you look. The bearing is the number of degrees from north, clockwise.
 */
public class CompassHudModule extends Module {
    public final NumberSetting width = add(new NumberSetting("Width", 220, 120, 400, 10));
    public final BoolSetting degrees = add(new BoolSetting("Show degrees", true));
    public final BoolSetting theme = add(new BoolSetting("Theme color", true));

    private static final String[] NAMES = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private static final int BG = 0xB0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;

    public CompassHudModule() { super("Compass HUD", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CompassHudModule m = ModuleManager.get(CompassHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, p.getYaw(tickCounter.getTickProgress(false)));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float yaw) {
        int sw = c.getWindow().getScaledWidth();
        int w = (int) width.get();
        int x0 = sw / 2 - w / 2, y0 = 6, h = 22;
        int accent = (theme.get() ? Theme.current().accent() : 0xFFFFFF) | 0xFF000000;

        // Bearing in degrees from north: yaw 0 faces south in Minecraft, so north is yaw 180.
        double bearing = ((yaw + 180) % 360 + 360) % 360;

        ctx.fill(x0, y0, x0 + w, y0 + h, BG);
        ctx.fill(sw / 2, y0, sw / 2 + 1, y0 + h, accent);        // centre line

        int span = 90;                                           // degrees visible across the bar
        for (int d = -180; d <= 180; d += 15) {
            double a = bearing + d;
            double rel = ((a - bearing) % 360 + 540) % 360 - 180; // -180..180 relative to the centre
            if (Math.abs(rel) > span / 2.0) continue;
            int tickX = (int) Math.round(sw / 2.0 + rel / (span / 2.0) * (w / 2.0));
            int bearingNorm = (int) Math.round((((bearing + rel) % 360) + 360) % 360);
            boolean major = bearingNorm % 45 == 0;
            int th = major ? 8 : 4;
            ctx.fill(tickX, y0 + h - th, tickX + 1, y0 + h, MUTED);
            if (major) {
                String label = NAMES[(bearingNorm / 45) % 8];
                int lw = Fonts.width(c.textRenderer, label);
                Fonts.draw(ctx, c.textRenderer, label, tickX - lw / 2, y0 + 6, label.length() == 1 ? accent : WHITE);
            }
        }
        if (degrees.get()) {
            String deg = (int) Math.round(bearing) + "°";
            int dw = Fonts.width(c.textRenderer, deg);
            Fonts.draw(ctx, c.textRenderer, deg, sw / 2 - dw / 2, y0 + h + 3, WHITE);
        }
    }
}
