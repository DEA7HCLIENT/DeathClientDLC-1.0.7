package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Speed Lines: faint streaks that run from the screen edges toward the centre while you sprint or glide fast.
 * Drawn as short runs of ctx.fill on your screen only.
 */
public class SpeedLinesModule extends Module {
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 35, 5, 100, 5));
    public final NumberSetting count = add(new NumberSetting("Lines", 16, 4, 40, 2));
    public final NumberSetting minSpeed = add(new NumberSetting("Min speed", 0.25, 0.05, 1.0, 0.05));

    private int tick;

    public SpeedLinesModule() { super("Speed Lines", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) { tick++; }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        SpeedLinesModule m = ModuleManager.get(SpeedLinesModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        boolean fast = p.isSprinting() || p.isGliding();
        double speed = Math.hypot(p.getVelocity().x, p.getVelocity().z);
        if (!fast || speed < m.minSpeed.get()) return;
        m.draw(ctx, c, speed, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, double speed, float delta) {
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int cx = sw / 2, cy = sh / 2;
        int n = (int) count.get();
        int alpha = (int) (opacity.get() / 100.0 * 255 * Math.min(1.0, speed / 0.3));
        double phase = (tick + delta) * 0.6;
        for (int i = 0; i < n; i++) {
            // Each line starts on the edge of a ring around the centre and runs inward, with its own phase.
            double ang = i * 2 * Math.PI / n + Math.sin(i * 12.9898) * 0.1;
            double rOuter = Math.hypot(sw, sh) / 2;
            double len = 30 + 40 * (0.5 + 0.5 * Math.sin(phase + i));
            double start = rOuter * (0.75 + 0.25 * ((i * 37) % 10) / 10.0);
            int col = (alpha << 24) | 0xFFFFFF;
            for (int k = 0; k < len; k++) {
                double r = start - k * (start / len) * 0.9;
                if (r < 0) break;
                int x = (int) Math.round(cx + Math.cos(ang) * r), y = (int) Math.round(cy + Math.sin(ang) * r);
                if (x < 0 || y < 0 || x >= sw || y >= sh) continue;
                int a = (int) (alpha * (1 - k / len));
                ctx.fill(x, y, x + 1, y + 1, (a << 24) | 0xFFFFFF);
            }
        }
    }
}
