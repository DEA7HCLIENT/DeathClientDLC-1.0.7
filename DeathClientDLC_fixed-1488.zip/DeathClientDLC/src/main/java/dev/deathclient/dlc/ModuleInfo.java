package dev.deathclient.dlc;

import java.util.Map;

/** Short descriptions shown on the module cards in the ClickGUI. */
final class ModuleInfo {
    private static final Map<String, String> DESC = Map.ofEntries(
            Map.entry("KillAura", "Автоматически бьёт ближайших существ"),
            Map.entry("TPAura", "Телепортируется к цели для удара"),
            Map.entry("Mace Killer", "Бьёт булавой в падении (smash-атака) по ближайшей цели"),
            Map.entry("Elytra Mace", "Летит на элитрах к цели (7-50 блоков), пикирует и бьёт булавой"),
            Map.entry("Crystal Aura", "Автоматически ставит и бьёт кристаллы"),
            Map.entry("Anchor Aura", "Ставит и взрывает якорь у врага"),
            Map.entry("Arrows", "Стрелки вокруг прицела на игроков, мобов, сущностей и инвизов"),
            Map.entry("GUI Animation", "Анимация открытия и закрытия ClickGUI"),
            Map.entry("HUD Style", "Форма панелей HUD и кнопок главного меню: квадрат, закруглённый, стеклянные"),
            Map.entry("Target HUD", "Карточка цели: имя, здоровье, броня, дистанция. 8 стилей, в т.ч. стеклянные и со своей картинкой"),
            Map.entry("Custom Sky", "Свой цвет неба"),
            Map.entry("Custom Fog", "Свой цвет и дальность тумана"),
            Map.entry("Custom Font", "Шрифт клиента: готовые или свой .ttf / .otf (перетащи файл в меню или .font add)"),
            Map.entry("GUI Image", "Твоя картинка в правом нижнем углу ClickGUI (перетащи png/jpg в меню)"),
            Map.entry("TriggerBot", "Бьёт цель, на которую наведён прицел"),
            Map.entry("AutoCart", "Рельса и вагонетка с TNT туда, куда летит стрела"),
            Map.entry("Crystal Optimization", "Убирает задержку у кристаллов"),
            Map.entry("Velocity", "Уменьшает отбрасывание от ударов"),
            Map.entry("Speed", "Увеличивает скорость передвижения"),
            Map.entry("Strafe", "Улучшенное управление в воздухе"),
            Map.entry("Target Strafe", "Кружит вокруг цели при атаке"),
            Map.entry("Fly", "Полёт без режима творчества"),
            Map.entry("Kill Effects", "12 эффектов смерти рядом: чёрная дыра, призрак, цепи, огонь, молния, сердечки и др. (только у тебя на экране)"),
            Map.entry("NoClip", "Проход сквозь стены; в стене падаешь вниз"),
            Map.entry("NoClip Fly", "Полёт сквозь стены; в стене без клавиш вверх/вниз падаешь"),
            Map.entry("Spin", "Вращает персонажа вокруг оси"),
            Map.entry("ESP", "ESP: 2D, 3D Box или круг; игроки, мобы, животные, инвизки"),
            Map.entry("Glow ESP", "Подсвечивает существ сквозь стены"),
            Map.entry("Block ESP", "Рамки вокруг руд, сундуков и спавнеров"),
            Map.entry("Freecam", "Свободная камера отдельно от игрока"),
            Map.entry("Chams", "Цветная заливка моделей сквозь стены"),
            Map.entry("No Render", "Убирает лишнюю картинку: огонь, оверлеи, погоду, частицы, боссбар, скорборд и другое"),
            Map.entry("View Model", "Положение и размер рук (двигай в чате)"),
            Map.entry("Swing Animation", "Анимация взмаха: Default, Swipe, Down, Custom"),
            Map.entry("Visual Spin", "Вращение модели без смены угла"),
            Map.entry("Tracers", "Линии к игрокам"),
            Map.entry("Line Trails", "Линии-следы за движением"),
            Map.entry("Target ESP", "Эффект при наводке на цель"),
            Map.entry("Target ESP Image", "Картинка-метка на цели"),
            Map.entry("Target ESP Ghost", "Призрак вокруг цели"),
            Map.entry("Jump Circle", "Кольцо под ногами при прыжке, 5 режимов"),
            Map.entry("China Hat", "Китайская шляпа над головой"),
            Map.entry("Glass Hand", "Свечение руки и предмета под их цвет"),
            Map.entry("Emotions", "Эмоции модели: 67, Привет, Cheer, Clap, Dab, Dance и ещё 10, плюс свои (.emote). Колесо эмоций: клавиша B (.bind wheel <клавиша>)"),
            Map.entry("Trails", "Оставляет след за игроком"),
            Map.entry("Fullbright", "Максимальная яркость без факелов"),
            Map.entry("FOV", "Настройка угла обзора"),
            Map.entry("Hitboxes", "Увеличивает хитбоксы целей от обычных до 100: во все стороны, вширь или вверх"),
            Map.entry("Scaffold", "Строит мост под ногами: Safe, God, Telly, Fast Telly"),
            Map.entry("BedWars Helper", "Автоломание вражеской кровати и автозастройка своей"),
            Map.entry("Resource Pack", "Блокирует ресурспаки, которые присылает сервер"),
            Map.entry("Custom Theme", "Свои цвета для тем Custom 1-4 (оттенок, насыщенность, яркость)"),
            Map.entry("GUI Style", "Вид меню: Classic, Panels или CS"),
            Map.entry("Glass Menu", "Стеклянное меню: прозрачное окно и карточки"),
            Map.entry("Dynamic Island", "Остров с временем и названием"),
            Map.entry("Info HUD", "Панель: FPS, пинг, координаты и скорость"),
            Map.entry("Keybinds", "Список активных биндов на экране"),
            Map.entry("Client Badge", "Значок Марин рядом с ником тех, у кого есть клиент"),
            Map.entry("Friends", "Друзья: не бить, подсвечивать (.friend)"),
            Map.entry("Optimization", "Поднимает FPS, не рисует лишнее"),
            Map.entry("Compass HUD", "Полоса компаса сверху: стороны света и градусы"),
            Map.entry("Armor HUD", "Надетая броня с прочностью в процентах и полосой"),
            Map.entry("Time HUD", "Игровое время (ЧЧ:ММ) и погода: ясно, дождь или гроза"),
            Map.entry("Hit Marker", "Красный или белый X у прицела, когда попал по цели (видно только тебе)"),
            Map.entry("Speed Lines", "Тонкие линии от краёв к центру при быстром беге и полёте на элитрах"),
            Map.entry("Damage Vignette", "Красная вспышка по краям экрана при уроне и пульс при низком здоровье"),
            Map.entry("Crosshair", "Свой прицел: точка, крест, кольцо, крест с точкой или T; можно убрать стандартный"),
            Map.entry("Extra Optimization", "Выключает облака, тени сущностей, смешивание биомов и ставит быструю графику (старые значения вернутся)"));

    private ModuleInfo() {}

    static String desc(Module m) {
        String d = DESC.get(m.getName());
        if (d != null) return d;
        return m.isImplemented() ? "" : "В разработке";
    }
}
