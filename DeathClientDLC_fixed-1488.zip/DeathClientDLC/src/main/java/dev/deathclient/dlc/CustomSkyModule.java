package dev.deathclient.dlc;

/**
 * Custom Sky: the sky takes the color you choose (Hue / Saturation / Brightness, the theme color, or a Rainbow that
 * cycles), day and night. Client-side only. The sky color is read from ClientWorld.getSkyColor by ClientWorldSkyMixin,
 * which lives in the optional mixin config deathclientdlc.sky.mixins.json: if the method is named differently in your
 * Minecraft version the game still starts, and the module simply has no effect.
 */
public class CustomSkyModule extends Module {
    public final NumberSetting hue = add(new NumberSetting("Hue", 210, 0, 360, 5));
    public final NumberSetting saturation = add(new NumberSetting("Saturation", 70, 0, 100, 5));
    public final NumberSetting brightness = add(new NumberSetting("Brightness", 90, 0, 100, 5));
    public final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));
    /** 0 = solid color (the settings above), 1..N = a named palette that drifts through its colors. */
    public final NumberSetting preset = add(new NumberSetting("Preset", 0, 0, PRESET_NAMES.length - 1, 1)
            .labels(PRESET_NAMES));

    /** Named skies: the first entry is the solid mode, the rest are palettes (colors as 0xRRGGBB, drift speed in cycles/s). */
    static final String[] PRESET_NAMES = {
        "Solid", "Cosmos", "Aurora", "Sunset", "Nebula", "Midnight", "Ocean", "Ember", "Pastel", "Storm", "Cherry", "Matrix"
    };
    private static final int[][] PALETTES = {
        {},
        {0x1A0B3D, 0x3A1A6E, 0x0C0A24},                                 // Cosmos
        {0x0F7A5A, 0x1FB5A0, 0x5B2EA6, 0x1A8A4A},                       // Aurora
        {0xFF7B3A, 0xFF4F7B, 0x7A2E8C, 0x2A1450},                       // Sunset
        {0x3D0C57, 0x8B1F7A, 0x1E4CA3, 0x0B1636},                       // Nebula
        {0x05070F, 0x0E1A33, 0x1B2E55},                                 // Midnight
        {0x04243A, 0x0A5C7A, 0x2FA6A0},                                 // Ocean
        {0x2A0A05, 0x7A1D0A, 0xD9561B, 0xFFB347},                       // Ember
        {0xFFD6E8, 0xD6E6FF, 0xE3FFD6, 0xFFF3C4},                       // Pastel
        {0x1C2430, 0x3A4A5C, 0x2A2F38},                                 // Storm
        {0xFFB7C5, 0xFF8FAB, 0xF7C6D9, 0xCDB4DB},                       // Cherry
        {0x001A05, 0x00421A, 0x00C853},                                 // Matrix
    };
    private static final double[] SPEEDS = {0, 0.03, 0.05, 0.02, 0.025, 0.015, 0.03, 0.04, 0.02, 0.015, 0.03, 0.06};

    public CustomSkyModule() { super("Custom Sky", Category.RENDER); }

    /** Smoothly blends through a palette; position t is in cycles. */
    static int palette(int[] colors, double t) {
        int n = colors.length;
        double pos = (t % 1.0 + 1.0) % 1.0 * n;
        int i = (int) Math.floor(pos) % n, j = (i + 1) % n;
        double f = pos - Math.floor(pos);
        f = f * f * (3 - 2 * f);                                       // smoothstep between neighbours
        int a = colors[i], b = colors[j];
        int r = (int) ((a >> 16 & 0xFF) + ((b >> 16 & 0xFF) - (a >> 16 & 0xFF)) * f);
        int g = (int) ((a >> 8 & 0xFF) + ((b >> 8 & 0xFF) - (a >> 8 & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return r << 16 | g << 8 | bl;
    }

    /** The sky color (RGB), or -1 while the module is off. */
    public static int color() {
        CustomSkyModule m = ModuleManager.get(CustomSkyModule.class);
        if (m == null || !m.isEnabled()) return -1;
        int p = (int) Math.round(m.preset.get());
        if (p > 0 && p < PALETTES.length) {
            return palette(PALETTES[p], (System.currentTimeMillis() / 1000.0) * SPEEDS[p]);
        }
        return EnvColor.rgb(m.hue, m.saturation, m.brightness, m.rainbow, m.themeColor);
    }
}
