package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Custom Crosshair: a crosshair drawn in the centre of the screen. Styles: Dot, Cross, Ring, Cross + dot, T.
 * "Hide vanilla" turns off the game's own crosshair while this module is on (see CrosshairMixin).
 */
public class CrosshairModule extends Module {
    static final String[] STYLES = {"Dot", "Cross", "Ring", "Cross + dot", "T"};

    public final NumberSetting style = add(new NumberSetting("Style", 3, 0, STYLES.length - 1, 1).labels(STYLES));
    public final NumberSetting size = add(new NumberSetting("Size", 6, 2, 20, 1));
    public final NumberSetting gap = add(new NumberSetting("Gap", 3, 0, 10, 1));
    public final NumberSetting thickness = add(new NumberSetting("Thickness", 2, 1, 6, 1));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 100, 10, 100, 5));
    /** Off = white. On = the theme accent colour. */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));
    public final BoolSetting outline = add(new BoolSetting("Outline", true));
    public final BoolSetting hideVanilla = add(new BoolSetting("Hide vanilla", true));

    public CrosshairModule() { super("Crosshair", Category.VISUALS); }

    /** True while the module replaces the game's crosshair. Read by CrosshairMixin. */
    public static boolean hidesVanilla() {
        CrosshairModule m = ModuleManager.get(CrosshairModule.class);
        return m != null && m.isEnabled() && m.hideVanilla.get();
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CrosshairModule m = ModuleManager.get(CrosshairModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        int cx = c.getWindow().getScaledWidth() / 2, cy = c.getWindow().getScaledHeight() / 2;
        int a = (int) Math.round(opacity.get() / 100.0 * 255) << 24;
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;
        int col = a | rgb;
        int black = (a == 0 ? 0 : 0xA0000000);
        int s = (int) size.get(), g = (int) gap.get(), t = (int) thickness.get();
        int st = (int) Math.round(style.get());

        if (outline.get()) {
            // Draw the shape once in black, one pixel bigger on every side, then the coloured shape on top.
            draw(ctx, cx, cy, s, g, t, st, black, 1);
        }
        draw(ctx, cx, cy, s, g, t, st, col, 0);
    }

    /** grow = extra pixels on each side (used for the outline). */
    private static void draw(DrawContext ctx, int cx, int cy, int s, int g, int t, int st, int col, int grow) {
        int h = t / 2;
        switch (st) {
            case 0 -> dot(ctx, cx, cy, t + grow * 2, col, grow);
            case 1 -> cross(ctx, cx, cy, s, g, t, col, grow);
            case 2 -> ring(ctx, cx, cy, s + g, t, col, grow);
            case 3 -> { cross(ctx, cx, cy, s, g, t, col, grow); dot(ctx, cx, cy, t, col, grow); }
            default -> {                                           // T: no upper arm
                ctx.fill(cx - s - g - grow, cy - h - grow, cx - g + grow, cy - h + t + grow, col);
                ctx.fill(cx + g - grow, cy - h - grow, cx + s + g + grow, cy - h + t + grow, col);
                ctx.fill(cx - h - grow, cy + g - grow, cx - h + t + grow, cy + s + g + grow, col);
            }
        }
    }

    private static void dot(DrawContext ctx, int cx, int cy, int size, int col, int grow) {
        int h = size / 2;
        ctx.fill(cx - h - grow, cy - h - grow, cx - h + size + grow, cy - h + size + grow, col);
    }

    private static void cross(DrawContext ctx, int cx, int cy, int s, int g, int t, int col, int grow) {
        int h = t / 2;
        ctx.fill(cx - g - s - grow, cy - h - grow, cx - g + grow, cy - h + t + grow, col);   // left
        ctx.fill(cx + g - grow, cy - h - grow, cx + g + s + grow, cy - h + t + grow, col);   // right
        ctx.fill(cx - h - grow, cy - g - s - grow, cx - h + t + grow, cy - g + grow, col);   // top
        ctx.fill(cx - h - grow, cy + g - grow, cx - h + t + grow, cy + g + s + grow, col);   // bottom
    }

    private static void ring(DrawContext ctx, int cx, int cy, int r, int t, int col, int grow) {
        int n = Math.max(24, r * 4);
        for (int i = 0; i < n; i++) {
            double a = i * 2 * Math.PI / n;
            int x = (int) Math.round(cx + Math.cos(a) * r), y = (int) Math.round(cy + Math.sin(a) * r);
            ctx.fill(x - t / 2 - grow, y - t / 2 - grow, x - t / 2 + t + grow, y - t / 2 + t + grow, col);
        }
    }
}
