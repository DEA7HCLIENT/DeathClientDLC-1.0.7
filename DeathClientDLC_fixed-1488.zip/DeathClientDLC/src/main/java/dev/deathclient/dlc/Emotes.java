package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

/**
 * The emote that is playing on your own model, and the saved Custom emotes (config/deathclientdlc/emotes.properties).
 * The animation is a function of time that returns the angles (radians) of the head and both arms; the model mixin
 * (BipedEntityModelMixin) applies them after vanilla's own pose. NaN means "leave vanilla's angle".
 */
public final class Emotes {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/emotes.properties");
    private static final double TAU = Math.PI * 2;
    private static final Map<String, double[]> SAVED = new TreeMap<>();

    /** Angles in radians; head pitch/yaw/roll, right arm pitch/yaw/roll, left arm pitch/yaw/roll. */
    public record Pose(float hp, float hy, float hr, float rp, float ry, float rr, float lp, float ly, float lr) {}

    private interface Anim { Pose at(double cycles); }

    /** Emote order for the module's selector: the first three keep their numbers, the new ones follow. */
    public static final String[] NAMES = {"67", "hello", "custom", "cheer", "clap", "flex", "salute", "dab", "shrug",
            "airplane", "zombie", "boxing", "robot", "think", "facepalm", "dance"};
    public static final String[] LABELS = {"67", "Привет", "Custom", "Cheer", "Clap", "Flex", "Salute", "Dab", "Shrug",
            "Airplane", "Zombie", "Boxing", "Robot", "Think", "Facepalm", "Dance"};

    private static Anim anim;
    private static long start;
    private static Perspective prevPerspective;

    private Emotes() {}

    // ---- playing ----

    /** Starts an emote by name: 67, hello (привет), custom or a saved name. False if there is no such emote. */
    public static boolean play(String name) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return false;
        String n = name.trim().toLowerCase(Locale.ROOT);
        Anim a = builtin(n);
        if (a == null) a = switch (n) {
            case "custom" -> {
                EmotionsModule m = ModuleManager.get(EmotionsModule.class);
                yield t -> customPose(m == null ? new double[12] : m.custom(), t);
            }
            default -> {
                double[] v = SAVED.get(n);
                yield v == null ? null : (Anim) (t -> customPose(v, t));
            }
        };
        if (a == null) return false;
        anim = a;
        start = System.nanoTime();
        int shareCode = codeOf(canon(n));
        if (shareCode > 0) ClientUsers.sendEmote(shareCode);
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        if (m != null && m.thirdPerson.get() && prevPerspective == null) {
            prevPerspective = c.options.getPerspective();
            c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
        return true;
    }

    public static void stop() {
        if (anim != null) ClientUsers.emoteStopped();
        anim = null;
        MinecraftClient c = MinecraftClient.getInstance();
        if (prevPerspective != null && c.options != null) c.options.setPerspective(prevPerspective);
        prevPerspective = null;
    }

    public static boolean active() { return anim != null; }

    /** The pose for this frame, or null when nothing plays. */
    public static Pose pose() {
        Anim a = anim;
        if (a == null) return null;
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        double speed = m == null ? 1.0 : m.speed.get();
        return a.at((System.nanoTime() - start) / 1.0e9 * speed);
    }

    /** Every client tick: stops the emote when you move, and keeps the module's on/off in step with it. */
    static void tick(MinecraftClient c) {
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        ClientPlayerEntity p = c.player;
        if (anim != null && (p == null || !p.isAlive())) stop();
        if (anim != null && m != null && m.stopOnMove.get() && c.currentScreen == null
                && (Util.inputDir(c, p) != net.minecraft.util.math.Vec3d.ZERO
                    || c.options.jumpKey.isPressed() || c.options.sneakKey.isPressed())) stop();
        if (anim == null && m != null && m.isEnabled()) m.toggle();
    }

    // ---- the animations ----

    /** Canonical name of a ready-made emote (English and Russian aliases accepted), or null. */
    private static String canon(String n) {
        return switch (n) {
            case "67", "6-7", "six-seven" -> "67";
            case "hello", "hi", "wave", "привет" -> "hello";
            case "cheer", "ура", "победа" -> "cheer";
            case "clap", "хлопки", "аплодисменты" -> "clap";
            case "flex", "качок", "сила" -> "flex";
            case "salute", "честь", "салют" -> "salute";
            case "dab", "дэб" -> "dab";
            case "shrug", "пожатие", "хз" -> "shrug";
            case "airplane", "plane", "самолёт", "самолет" -> "airplane";
            case "zombie", "зомби" -> "zombie";
            case "boxing", "box", "бокс" -> "boxing";
            case "robot", "робот" -> "robot";
            case "think", "thinking", "думаю" -> "think";
            case "facepalm", "рукалицо" -> "facepalm";
            case "dance", "танец" -> "dance";
            default -> null;
        };
    }

    /** The ready-made emotes by name, or null. */
    private static Anim builtin(String n) {
        String c = canon(n);
        if (c == null) return null;
        return switch (c) {
            case "67" -> Emotes::sixSeven;
            case "hello" -> Emotes::hello;
            case "cheer" -> Emotes::cheer;
            case "clap" -> Emotes::clap;
            case "flex" -> Emotes::flex;
            case "salute" -> Emotes::salute;
            case "dab" -> Emotes::dab;
            case "shrug" -> Emotes::shrug;
            case "airplane" -> Emotes::airplane;
            case "zombie" -> Emotes::zombie;
            case "boxing" -> Emotes::boxing;
            case "robot" -> Emotes::robot;
            case "think" -> Emotes::think;
            case "facepalm" -> Emotes::facepalm;
            case "dance" -> Emotes::dance;
            default -> null;
        };
    }

    /** Number sent to other client users: index in NAMES + 1 (1..16); 0 means stop. 0 for names that cannot be shared. */
    private static int codeOf(String canon) {
        if (canon == null || canon.equals("custom")) return 0;
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(canon)) return i + 1;
        return 0;
    }

    // ---- emotes of other client users (see ClientUsers) ----

    private static final long REMOTE_SECONDS = 5;
    private record Remote(Anim anim, long start, long until) {}
    private static final Map<String, Remote> REMOTE = new java.util.concurrent.ConcurrentHashMap<>();

    /** Another client user started (code 1..16) or stopped (0) an emote. Plays for a few seconds on his model. */
    static void playRemote(String player, int code) {
        String key = player.toLowerCase(Locale.ROOT);
        if (code <= 0 || code > NAMES.length) { REMOTE.remove(key); return; }
        Anim a = builtin(NAMES[code - 1]);
        if (a == null) return;
        long now = System.nanoTime();
        REMOTE.put(key, new Remote(a, now, now + REMOTE_SECONDS * 1_000_000_000L));
    }

    static void clearRemote() { REMOTE.clear(); }

    /** Seconds an emote shared with others keeps playing on their screen. */
    static long remoteSeconds() { return REMOTE_SECONDS; }

    /** The pose for this entity's render state: yours, another client user's, or null. */
    public static Pose poseFor(net.minecraft.entity.LivingEntity e) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (e == c.player) return pose();
        if (!(e instanceof net.minecraft.entity.player.PlayerEntity)) return null;
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        if (m != null && !m.showOthers.get()) return null;
        String key = e.getName().getString().toLowerCase(Locale.ROOT);
        Remote r = REMOTE.get(key);
        if (r == null) return null;
        long now = System.nanoTime();
        if (now > r.until()) { REMOTE.remove(key); return null; }
        return r.anim().at((now - r.start()) / 1.0e9);
    }

    private static final float NA = Float.NaN;

    /** Both arms straight up, waving outward and in; the head tilts back. */
    private static Pose cheer(double t) {
        float s = (float) Math.sin(TAU * 2.0 * t);
        return new Pose(-0.25f, NA, 0.08f * s, -3.0f, NA, 0.35f + 0.2f * s, -3.0f, NA, -0.35f - 0.2f * s);
    }

    /** Arms forward, the hands sweep towards each other and apart. */
    private static Pose clap(double t) {
        float s = 0.5f + 0.5f * (float) Math.sin(TAU * 3.0 * t);
        return new Pose(0.1f, NA, NA, -1.45f, -0.7f * s, 0.05f, -1.45f, 0.7f * s, -0.05f);
    }

    /** Arms out to the sides, pulsing, head turning to each side. */
    private static Pose flex(double t) {
        float s = (float) Math.sin(TAU * 1.5 * t);
        return new Pose(0.05f, 0.35f * s, NA, 0.0f, NA, 1.45f + 0.15f * s, 0.0f, NA, -1.45f - 0.15f * s);
    }

    /** Right hand to the forehead, short nod. */
    private static Pose salute(double t) {
        float s = (float) Math.sin(TAU * 1.0 * t);
        return new Pose(0.05f * s, NA, NA, -2.65f, -0.45f, -0.15f, NA, NA, NA);
    }

    /** Head down and turned, one arm across the face and the other raised out to the side. */
    private static Pose dab(double t) {
        float s = (float) Math.sin(TAU * 1.0 * t);
        return new Pose(0.7f, -0.55f, NA, -1.5f, -0.9f, 0.1f, -2.6f, NA, -0.55f + 0.05f * s);
    }

    /** Arms out and slightly forward, the head tilting side to side. */
    private static Pose shrug(double t) {
        float s = (float) Math.sin(TAU * 1.2 * t);
        return new Pose(NA, NA, 0.18f * s, -0.6f, NA, 0.9f, -0.6f, NA, -0.9f);
    }

    /** Arms straight out, rocking from wing to wing. */
    private static Pose airplane(double t) {
        float s = (float) Math.sin(TAU * 1.0 * t);
        return new Pose(NA, NA, 0.25f * s, 0.0f, NA, 1.55f + 0.3f * s, 0.0f, NA, -1.55f + 0.3f * s);
    }

    /** Arms straight forward, a slow bob, the head hanging. */
    private static Pose zombie(double t) {
        float s = (float) Math.sin(TAU * 1.5 * t);
        return new Pose(0.35f + 0.05f * s, NA, 0.1f * s, -1.57f + 0.08f * s, NA, 0.05f, -1.57f - 0.08f * s, NA, -0.05f);
    }

    /** Fists alternate forward. */
    private static Pose boxing(double t) {
        float s = (float) Math.sin(TAU * 3.0 * t);
        return new Pose(NA, 0.15f * s, NA, -1.3f - 0.3f * s, -0.15f, 0.1f, -1.3f + 0.3f * s, 0.15f, -0.1f);
    }

    /** Stiff snaps between poses, no easing. */
    private static Pose robot(double t) {
        int step = (int) Math.floor(((t * 2.0) % 4.0 + 4.0) % 4.0);
        return switch (step) {
            case 0 -> new Pose(0.0f, 0.5f, NA, -1.57f, NA, 0.0f, 0.0f, NA, -0.1f);
            case 1 -> new Pose(0.0f, 0.5f, NA, -1.57f, NA, 0.0f, -1.57f, NA, 0.0f);
            case 2 -> new Pose(0.0f, -0.5f, NA, 0.0f, NA, 0.1f, -1.57f, NA, 0.0f);
            default -> new Pose(0.0f, -0.5f, NA, -1.57f, NA, 0.0f, -1.57f, NA, 0.0f);
        };
    }

    /** Hand at the chin, slow head tilt. */
    private static Pose think(double t) {
        float s = (float) Math.sin(TAU * 0.5 * t);
        return new Pose(0.2f, 0.25f * s, 0.1f * s, -2.0f, -0.6f, 0.0f, -1.1f, 0.9f, -0.1f);
    }

    /** Hand to the face, the head shaking slowly. */
    private static Pose facepalm(double t) {
        float s = (float) Math.sin(TAU * 1.0 * t);
        return new Pose(0.55f, 0.15f * s, NA, -2.45f, -0.45f, 0.0f, NA, NA, NA);
    }

    /** Arms swing up in turns, the head sways. */
    private static Pose dance(double t) {
        float s = (float) Math.sin(TAU * 1.8 * t);
        return new Pose(NA, 0.25f * s, 0.25f * s, -1.7f - 1.2f * s, NA, 0.3f, -1.7f + 1.2f * s, NA, -0.3f);
    }

    private static Pose sixSeven(double t) {
        float s = (float) Math.sin(TAU * 2.2 * t);                       // hands move up and down in turns
        return new Pose(0.12f * (float) Math.sin(TAU * 4.4 * t), Float.NaN, Float.NaN,
                -1.5f + 0.6f * s, Float.NaN, 0.08f,
                -1.5f - 0.6f * s, Float.NaN, -0.08f);
    }

    private static Pose hello(double t) {
        float wave = 0.3f + 0.45f * (float) Math.sin(TAU * 2.2 * t);     // right arm up, swinging sideways
        return new Pose(Float.NaN, -0.2f, Float.NaN, -2.9f, Float.NaN, wave, Float.NaN, Float.NaN, Float.NaN);
    }

    /** v = pose A (R arm, R side, L arm, L side, head pitch, head yaw) then pose B, in degrees; one A-B-A trip per cycle. */
    private static Pose customPose(double[] v, double t) {
        double s = 0.5 - 0.5 * Math.cos(TAU * t);
        double[] k = new double[6];
        for (int i = 0; i < 6; i++) k[i] = Math.toRadians(v[i] + (v[i + 6] - v[i]) * s);
        return new Pose((float) k[4], (float) k[5], Float.NaN, (float) k[0], Float.NaN, (float) k[1],
                (float) k[2], Float.NaN, (float) -k[3]);
    }

    // ---- saved custom emotes ----

    /** Keeps the current Custom poses under this name. */
    public static boolean save(String name) {
        EmotionsModule m = ModuleManager.get(EmotionsModule.class);
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (m == null || n.isEmpty() || n.equals("custom") || builtin(n) != null) return false;
        SAVED.put(n, m.custom());
        store();
        return true;
    }

    public static boolean delete(String name) {
        boolean r = SAVED.remove(name.trim().toLowerCase(Locale.ROOT)) != null;
        if (r) store();
        return r;
    }

    public static List<String> saved() { return new ArrayList<>(SAVED.keySet()); }

    public static void load() {
        SAVED.clear();
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (String key : props.stringPropertyNames()) {
            String[] parts = props.getProperty(key).split(",");
            if (parts.length != 12) continue;
            try {
                double[] v = new double[12];
                for (int i = 0; i < 12; i++) v[i] = Double.parseDouble(parts[i].trim());
                SAVED.put(key, v);
            } catch (NumberFormatException ignored) {}
        }
    }

    private static void store() {
        Properties props = new Properties();
        for (var e : SAVED.entrySet()) {
            StringBuilder sb = new StringBuilder();
            for (double d : e.getValue()) sb.append(sb.length() == 0 ? "" : ",").append(d);
            props.setProperty(e.getKey(), sb.toString());
        }
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) { props.store(out, "DeathClientDLC saved emotes"); }
        } catch (IOException ignored) {}
    }
}
