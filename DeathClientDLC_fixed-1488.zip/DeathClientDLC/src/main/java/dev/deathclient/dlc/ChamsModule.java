package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Chams: matching entities are drawn as a flat colour fill with the depth test off, so they show through walls.
 * The module only decides colours (argbFor); the draw itself is done by mixin.ChamsRendererMixin + ChamsLayers.
 */
public class ChamsModule extends Module {
    private static volatile ChamsModule instance;

    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 8));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", false));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 70, 10, 100, 5));
    public final NumberSetting red = add(new NumberSetting("Red", 255, 0, 255, 5));
    public final NumberSetting green = add(new NumberSetting("Green", 64, 0, 255, 5));
    public final NumberSetting blue = add(new NumberSetting("Blue", 64, 0, 255, 5));

    public ChamsModule() {
        super("Chams", Category.RENDER);
        instance = this;
    }

    /** ARGB tint for this entity, or -1 if it must be drawn normally. Called from the renderer on the render thread. */
    public static int argbFor(Entity e) {
        ChamsModule m = instance;
        if (m == null || !m.isEnabled() || !ChamsLayers.available()) return -1;

        MinecraftClient c = MinecraftClient.getInstance();
        if (c == null || !c.isOnThread()) return -1;
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || e == p) return -1;
        if (!(e instanceof LivingEntity le) || !le.isAlive() || le.isSpectator()) return -1;
        if (p.distanceTo(e) > m.range.get()) return -1;

        boolean ok = e instanceof PlayerEntity ? m.players.get()
                : e instanceof HostileEntity ? m.hostile.get() : m.passive.get();
        if (!ok) return -1;

        int a = (int) Math.round(m.opacity.get() * 2.55);
        return (a << 24) | ((int) m.red.get() << 16) | ((int) m.green.get() << 8) | (int) m.blue.get();
    }
}
