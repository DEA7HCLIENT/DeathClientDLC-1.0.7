package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Damage Vignette: red edges of the screen flash when you take damage and fade out over about half a second.
 * Optionally the edges also pulse softly while health is low. Drawn as edge bands of ctx.fill, like the rest of the overlay.
 */
public class DamageVignetteModule extends Module {
    public final NumberSetting strength = add(new NumberSetting("Strength", 60, 10, 100, 5));
    public final NumberSetting width = add(new NumberSetting("Width", 60, 10, 200, 5));
    public final NumberSetting lowHealth = add(new NumberSetting("Low health (hearts)", 4, 0, 10, 1));
    public final BoolSetting lowHealthPulse = add(new BoolSetting("Pulse at low health", true));

    private float lastHealth = -1;
    private int flashTicks;              // ticks left in the damage flash
    private int tick;

    public DamageVignetteModule() { super("Damage Vignette", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        tick++;
        ClientPlayerEntity p = c.player;
        if (p == null) { lastHealth = -1; return; }
        float hp = p.getHealth();
        if (lastHealth >= 0 && hp < lastHealth) flashTicks = 10;
        lastHealth = hp;
        if (flashTicks > 0) flashTicks--;
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        DamageVignetteModule m = ModuleManager.get(DamageVignetteModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.currentScreen != null) return;
        m.draw(ctx, c, p, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        double alpha = 0;
        // Damage flash: strongest right after the hit, fading over the 10 ticks.
        if (flashTicks > 0) alpha = Math.max(alpha, (flashTicks - delta) / 10.0);
        // Low health: a slow pulse, on only while health is below the threshold.
        double hearts = p.getHealth() / 2.0;
        if (lowHealthPulse.get() && hearts <= lowHealth.get() && p.getHealth() > 0) {
            double pulse = 0.5 + 0.5 * Math.sin((tick + delta) * 0.25);
            alpha = Math.max(alpha, 0.25 + 0.35 * pulse);
        }
        if (alpha <= 0.01) return;

        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int w = (int) width.get();
        int base = (int) Math.min(255, alpha * strength.get() / 100.0 * 255);
        // Four edges, each a stack of bands from the edge inwards: the outer band is the strongest.
        int steps = Math.max(4, w / 4);
        for (int i = 0; i < steps; i++) {
            double f = i / (double) steps;
            int a = (int) (base * (1 - f) * (1 - f));
            if (a <= 0) break;
            int col = (a << 24) | 0xC00000;
            int band = w / steps + 1;
            int d0 = i * w / steps;
            ctx.fill(d0, 0, d0 + band, sh, col);                       // left
            ctx.fill(sw - d0 - band, 0, sw - d0, sh, col);             // right
            ctx.fill(0, d0, sw, d0 + band, col);                       // top
            ctx.fill(0, sh - d0 - band, sw, sh - d0, col);             // bottom
        }
    }
}
