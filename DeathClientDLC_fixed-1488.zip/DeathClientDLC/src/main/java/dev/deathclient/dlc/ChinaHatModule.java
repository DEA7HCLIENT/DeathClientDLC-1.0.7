package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

/**
 * China Hat: a conical straw hat (a douli) above your head, drawn as shaded triangles on the screen. The brim is a
 * flat disc of projected points; the cone is a fan of triangles from the apex to the brim. Triangles are sorted by
 * depth so the near side covers the far side. Not particles and not a texture: just filled shapes placed with
 * ScreenProjector, like the rest of the overlay.
 */
public class ChinaHatModule extends Module {
    /** Radius of the brim in blocks. */
    public final NumberSetting radius = add(new NumberSetting("Radius", 0.6, 0.3, 1.2, 0.05));
    /** Height of the cone above the brim, in blocks. */
    public final NumberSetting coneHeight = add(new NumberSetting("Cone height", 0.35, 0.1, 0.8, 0.05));
    /** How far above the top of the head the brim floats. */
    public final NumberSetting height = add(new NumberSetting("Height", 0.1, 0.0, 1.0, 0.05));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 95, 10, 100, 5));
    /** Segments around the brim: more is rounder and a little heavier. */
    public final NumberSetting quality = add(new NumberSetting("Quality", 32, 12, 64, 4));
    /** Off = straw colour (warm white). On = the theme accent colour. */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    private final ScreenProjector proj = new ScreenProjector();

    public ChinaHatModule() { super("China Hat", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ChinaHatModule m = ModuleManager.get(ChinaHatModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tickCounter.getTickProgress(false));
    }

    private static final class Tri {
        final double[] a, b, c;
        final double depth;
        final int color;
        Tri(double[] a, double[] b, double[] c, int color) {
            this.a = a; this.b = b; this.c = c; this.color = color;
            this.depth = (a[2] + b[2] + c[2]) / 3.0;
        }
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        proj.begin(c, delta);
        Vec3d base = p.getLerpedPos(delta);
        double R = radius.get(), H = coneHeight.get();
        int seg = (int) quality.get();

        // Ground basis of the camera: r0 = right (horizontal), f0 = forward (horizontal).
        double[] r0 = {proj.rightX(), 0, proj.rightZ()};
        double[] n = {0, 1, 0};                                   // head's "up"; tilted while gliding
        double[] headCentre;

        if (p.isGliding()) {
            // Elytra: the body leans toward the flight direction, and its height shrinks (getHeight() is 0.6 here).
            // The hat follows the head: a pivot at the body centre, the head rotated by the lean angle.
            Vec3d v = p.getVelocity();
            double hs = Math.hypot(v.x, v.z);
            double fx, fz;                                                // flight direction on the ground
            if (hs > 0.01) { fx = v.x / hs; fz = v.z / hs; }
            else { fx = r0[2]; fz = -r0[0]; }                             // hovering: the facing direction
            double tilt = Math.max(-Math.PI / 3, Math.min(Math.PI / 2, Math.atan2(-v.y, Math.max(hs, 1e-4))));
            n = new double[]{fx * Math.sin(tilt), Math.cos(tilt), fz * Math.sin(tilt)};
            double len = Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]);
            n = new double[]{n[0] / len, n[1] / len, n[2] / len};
            double pivotY = base.y + 0.9;
            headCentre = new double[]{base.x + n[0] * 0.9, pivotY + n[1] * 0.9, base.z + n[2] * 0.9};
        } else {
            headCentre = new double[]{base.x, base.y + p.getHeight(), base.z};
        }

        // Brim centre: above the head along its up direction.
        double hgt = height.get();
        double[] C = {headCentre[0] + n[0] * hgt, headCentre[1] + n[1] * hgt, headCentre[2] + n[2] * hgt};

        // Brim plane basis, perpendicular to n: w = n x r0, r = w x n.
        double[] w = norm(cross(n, r0));
        double[] r = norm(cross(w, n));

        double[] apexP = {C[0] + n[0] * H, C[1] + n[1] * H, C[2] + n[2] * H};
        double[] apex = project(apexP);

        int alphaByte = ((int) Math.round(opacity.get() / 100.0 * 255)) << 24;
        int base0 = (themeColor.get() ? Theme.current().accent() : 0xF2E3B0) & 0xFFFFFF;

        // Hat = a crown cone over a brim ring, with a thin brim edge. No flat disc in the middle.
        double T = 0.05;                                          // brim thickness, blocks
        double innerR = R * 0.45;
        double[][] top = new double[seg][], inner = new double[seg][], bot = new double[seg][];
        for (int i = 0; i < seg; i++) {
            double th = i * 2 * Math.PI / seg;
            double cR = Math.cos(th), sR = Math.sin(th);
            top[i] = project(ringPoint(C, n, r, w, cR * R, sR * R, 0));
            bot[i] = project(ringPoint(C, n, r, w, cR * R, sR * R, -T));
            inner[i] = project(ringPoint(C, n, r, w, cR * innerR, sR * innerR, 0));
        }

        List<Tri> tris = new ArrayList<>();
        for (int i = 0; i < seg; i++) {
            int j = (i + 1) % seg;
            double th = (i + 0.5) * 2 * Math.PI / seg;
            double shade = 0.62 + 0.38 * (0.5 + 0.5 * Math.cos(th - 0.8));   // light from the upper left
            // Cone: from the apex down to the inner brim ring, with light bands.
            if (apex != null && inner[i] != null && inner[j] != null)
                tris.add(new Tri(apex, inner[i], inner[j], alphaByte | shadeRgb(base0, shade)));
            // Brim top ring: two triangles between the inner and outer ring.
            if (inner[i] != null && inner[j] != null && top[i] != null && top[j] != null) {
                tris.add(new Tri(inner[i], top[i], top[j], alphaByte | shadeRgb(base0, shade * 0.88)));
                tris.add(new Tri(inner[i], top[j], inner[j], alphaByte | shadeRgb(base0, shade * 0.88)));
            }
            // Brim edge: a darker band, so the brim reads as a brim and not as a flat disc.
            if (top[i] != null && top[j] != null && bot[i] != null && bot[j] != null) {
                tris.add(new Tri(top[i], top[j], bot[j], alphaByte | shadeRgb(base0, 0.5)));
                tris.add(new Tri(top[i], bot[j], bot[i], alphaByte | shadeRgb(base0, 0.5)));
            }
        }
        tris.sort((x, y) -> Double.compare(y.depth, x.depth));                // far first, near last
        for (Tri t : tris) fillTriangle(ctx, t.a, t.b, t.c, t.color);
    }

    /** A point on the brim plane: C + a*r + b*w, then lifted by 'lift' along the hat's up direction n. */
    private static double[] ringPoint(double[] C, double[] n, double[] r, double[] w, double a, double b, double lift) {
        return new double[]{
            C[0] + a * r[0] + b * w[0] + lift * n[0],
            C[1] + a * r[1] + b * w[1] + lift * n[1],
            C[2] + a * r[2] + b * w[2] + lift * n[2]};
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    private static double[] norm(double[] v) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return l < 1e-9 ? new double[]{1, 0, 0} : new double[]{v[0] / l, v[1] / l, v[2] / l};
    }

    private double[] project(double[] q) {
        if (!proj.project(new Vec3d(q[0], q[1], q[2]))) return null;
        return new double[]{proj.out[0], proj.out[1], proj.out[2]};
    }

    private static int shadeRgb(int rgb, double s) {
        int r = (int) Math.min(255, ((rgb >> 16) & 0xFF) * s);
        int g = (int) Math.min(255, ((rgb >> 8) & 0xFF) * s);
        int b = (int) Math.min(255, (rgb & 0xFF) * s);
        return r << 16 | g << 8 | b;
    }

    /** Scanline fill of one triangle, one row at a time, with ctx.fill. */
    static void fillTriangle(DrawContext ctx, double[] a, double[] b, double[] c, int color) {
        double minY = Math.min(a[1], Math.min(b[1], c[1]));
        double maxY = Math.max(a[1], Math.max(b[1], c[1]));
        int y0 = (int) Math.ceil(minY - 0.5), y1 = (int) Math.floor(maxY - 0.5);
        if (y1 < y0 || y1 - y0 > 2000) return;
        double[][] e = {a, b, b, c, c, a};
        for (int y = y0; y <= y1; y++) {
            double sy = y + 0.5;
            double xMin = Double.MAX_VALUE, xMax = -Double.MAX_VALUE;
            int hits = 0;
            for (int k = 0; k < 6; k += 2) {
                double[] p = e[k], q = e[k + 1];
                if ((p[1] <= sy && q[1] > sy) || (q[1] <= sy && p[1] > sy)) {
                    double x = p[0] + (sy - p[1]) * (q[0] - p[0]) / (q[1] - p[1]);
                    xMin = Math.min(xMin, x);
                    xMax = Math.max(xMax, x);
                    hits++;
                }
            }
            if (hits < 2) continue;
            int xa = (int) Math.round(xMin), xb = (int) Math.round(xMax);
            if (xb > xa) ctx.fill(xa, y, xb, y + 1, color);
        }
    }
}
