package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ChamsLayers;
import dev.deathclient.dlc.ChamsModule;
import dev.deathclient.dlc.ChamsState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Chams: tags the render state in updateRenderState, then swaps the layer (no depth test) and the tint. require = 0 like the other renderer hooks. */
@Mixin(LivingEntityRenderer.class)
public abstract class ChamsRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"), require = 0)
    private void deathclientdlc$chamsTag(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (state instanceof ChamsState cs) cs.deathclientdlc$setChams(ChamsModule.argbFor(entity));
    }

    @Inject(method = "getRenderLayer", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$chamsLayer(LivingEntityRenderState state, boolean showBody, boolean translucent, boolean showOutline,
                                           CallbackInfoReturnable<RenderLayer> cir) {
        if (cir.getReturnValue() == null || !(state instanceof ChamsState cs) || cs.deathclientdlc$getChams() == -1) return;
        RenderLayer l = ChamsLayers.layer();
        if (l != null) cir.setReturnValue(l);
    }

    @Inject(method = "getMixColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$chamsTint(LivingEntityRenderState state, CallbackInfoReturnable<Integer> cir) {
        if (state instanceof ChamsState cs && cs.deathclientdlc$getChams() != -1) cir.setReturnValue(cs.deathclientdlc$getChams());
    }
}
