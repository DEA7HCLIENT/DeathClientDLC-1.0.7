package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.FreecamModule;
import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Freecam: moves the camera entity right before the world is rendered, so the view follows the mouse and keys
 * without a frame of delay. No arguments are read, so the hook does not depend on the method's signature.
 * require = 0: if renderWorld is named differently in this build the hook is skipped and Freecam falls back to the
 * HUD callback (works, but one frame late).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "renderWorld", at = @At("HEAD"), require = 0)
    private void deathclientdlc$freecamFrame(CallbackInfo ci) {
        FreecamModule.worldFrame();
    }

    /** No Render: hurt tilt of the view when you take damage. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noHurtCam(CallbackInfo ci) {
        if (NoRenderModule.hurtCam()) ci.cancel();
    }

    /** No Render: view bobbing while walking. */
    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noViewBob(CallbackInfo ci) {
        if (NoRenderModule.viewBob()) ci.cancel();
    }
}
