package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import java.util.ArrayList;
import java.util.List;

/**
 * Info HUD: a small panel with FPS, ping, coordinates (with facing), speed, and optional rows: memory use, world time,
 * server or world, dimension, the block under the crosshair and the number of players around you.
 * The strip under the title is the theme colour, a gradient for the two- and three-colour themes.
 * Drag it with the left mouse button while the chat is open (HudEdit).
 */
public class InfoHudModule extends Module {
    public final BoolSetting showFps = add(new BoolSetting("FPS", true));
    public final BoolSetting showPing = add(new BoolSetting("Ping", true));
    public final BoolSetting showCoords = add(new BoolSetting("Coords", true));
    public final BoolSetting showSpeed = add(new BoolSetting("Speed", true));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 110, 0, 1200, 1));
    public final BoolSetting showMemory = add(new BoolSetting("Memory", false));
    public final BoolSetting showTime = add(new BoolSetting("World time", false));
    public final BoolSetting showServer = add(new BoolSetting("Server", false));
    public final BoolSetting showDimension = add(new BoolSetting("Dimension", false));
    public final BoolSetting showLooking = add(new BoolSetting("Looking at", false));
    public final BoolSetting showPlayers = add(new BoolSetting("Players nearby", false));
    /** Background opacity, percent. */
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 82, 0, 100, 1));

    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;

    // Frame-time and speed sampling (smoothed), all updated from the HUD callback.
    private static long lastFrame, lastSample;
    private static double fps = 60, speed, lastX, lastZ;
    private static boolean haveSample;

    public InfoHudModule() { super("Info HUD", Category.MISC, true); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        InfoHudModule m = ModuleManager.get(InfoHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        long now = System.nanoTime();

        // FPS: exponential average of the frame time.
        if (lastFrame != 0) {
            double dt = (now - lastFrame) / 1.0e9;
            if (dt > 0 && dt < 1) fps += (1.0 / dt - fps) * 0.05;
        }
        lastFrame = now;

        // Speed: horizontal distance over at least 100 ms, smoothed.
        double px = c.player.getX(), pz = c.player.getZ();
        if (!haveSample) { lastX = px; lastZ = pz; lastSample = now; haveSample = true; }
        else if (now - lastSample >= 100_000_000L) {
            double dt = (now - lastSample) / 1.0e9;
            double v = Math.hypot(px - lastX, pz - lastZ) / dt;
            if (v > 200) v = speed;                                   // teleport / world change: ignore the jump
            speed += (v - speed) * 0.3;
            lastX = px; lastZ = pz; lastSample = now;
        }

        List<String[]> rows = new ArrayList<>();                      // {label, value, colour as hex}
        if (m.showFps.get()) rows.add(new String[]{"FPS", String.valueOf((int) Math.round(fps)), null});
        if (m.showPing.get()) {
            int ping = -1;
            var nh = c.getNetworkHandler();
            if (nh != null) {
                var e = nh.getPlayerListEntry(c.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
            String col = ping < 0 ? null : ping < 80 ? "55FF55" : ping < 150 ? "FFD455" : "FF5555";
            rows.add(new String[]{"Ping", ping < 0 ? "-" : ping + " ms", col});
        }
        if (m.showCoords.get()) {
            String face = c.player.getHorizontalFacing().name().substring(0, 1);
            rows.add(new String[]{"XYZ", Math.round(px) + " " + Math.round(c.player.getY()) + " " + Math.round(pz) + "  " + face, null});
        }
        if (m.showSpeed.get()) rows.add(new String[]{"Speed", String.format("%.1f b/s", speed), null});
        if (m.showMemory.get()) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) >> 20, max = rt.maxMemory() >> 20;
            rows.add(new String[]{"Memory", used + " / " + max + " MB", null});
        }
        if (m.showTime.get() && c.world != null) {
            long t = c.world.getTimeOfDay() % 24000;
            int hh = (int) ((t / 1000 + 6) % 24), mm = (int) ((t % 1000) * 60 / 1000);
            rows.add(new String[]{"Time", String.format("%02d:%02d", hh, mm), null});
        }
        if (m.showServer.get()) {
            var entry = c.getCurrentServerEntry();
            String srv = entry != null ? entry.address : "Singleplayer";
            rows.add(new String[]{"Server", trim(srv, 18), null});
        }
        if (m.showDimension.get() && c.world != null) {
            rows.add(new String[]{"Dimension", trim(c.world.getRegistryKey().getValue().getPath(), 18), null});
        }
        if (m.showLooking.get() && c.crosshairTarget instanceof net.minecraft.util.hit.BlockHitResult bhr && c.world != null) {
            String block = c.world.getBlockState(bhr.getBlockPos()).getBlock().getName().getString();
            rows.add(new String[]{"Looking at", trim(block, 18), null});
        }
        if (m.showPlayers.get() && c.world != null) {
            rows.add(new String[]{"Players", String.valueOf(Math.max(0, c.world.getPlayers().size() - 1)), null});
        }
        if (rows.isEmpty()) return;

        var tr = c.textRenderer;
        String title = "Info";
        int pad = 6, rowH = 12;
        int w = Fonts.width(tr, title);
        for (String[] r : rows) w = Math.max(w, Fonts.width(tr, r[0]) + 12 + Fonts.width(tr, r[1]));
        w += pad * 2;
        int h = 16 + rows.size() * rowH + 3;
        int x = (int) m.posX.get(), y = (int) m.posY.get();

        HudEdit.track(x, y, w, h, (nx, ny) -> { m.posX.set(nx); m.posY.set(ny); });
        int alpha = (int) Math.round(m.opacity.get() * 255 / 100.0);
        ClickGuiScreen.rect(ctx, x, y, w, h, (alpha << 24) | 0x101010, true, true);
        stripe(ctx, x, y + 14, w);
        Fonts.draw(ctx, tr, title, x + pad, y + 3, WHITE);

        int ry = y + 18;
        for (String[] r : rows) {
            Fonts.draw(ctx, tr, r[0], x + pad, ry, MUTED);
            int col = r[2] == null ? WHITE : 0xFF000000 | Integer.parseInt(r[2], 16);
            Fonts.draw(ctx, tr, r[1], x + w - pad - Fonts.width(tr, r[1]), ry, col);
            ry += rowH;
        }
    }

    private static String trim(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    /** 1 px line in the theme colour; gradient themes are drawn left to right in 2 px slices. */
    private static void stripe(DrawContext ctx, int x, int y, int w) {
        Theme t = Theme.current();
        if (!t.gradient()) { ctx.fill(x, y, x + w, y + 1, t.accent()); return; }
        for (int i = 0; i < w; i += 2) {
            ctx.fill(x + i, y, x + Math.min(w, i + 2), y + 1, t.at((i + 1f) / w));
        }
    }
}
