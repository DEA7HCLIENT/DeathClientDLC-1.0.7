package dev.deathclient.dlc;

/**
 * No Render: switches off visual effects that get in the way. Every option is separate, all are off by default
 * except the three original ones (Fire, FOV effects, Potion effects).
 * <ul>
 *   <li>Fire: the burning overlay on the screen edges.</li>
 *   <li>FOV effects: the field of view no longer changes with speed, sprinting, slowness, bow draw or spyglass.</li>
 *   <li>Potion effects: nausea wobble, blindness and darkness are not shown (the effects still work on the server).</li>
 *   <li>Vanilla swing: the game's own hand swing is not drawn (Swing Animation still works).</li>
 *   <li>Hurt cam: the view no longer tilts when you take damage.</li>
 *   <li>View bob: the view no longer bobs while you walk.</li>
 *   <li>Crosshair: the vanilla crosshair is hidden (the cursor position stays the same).</li>
 *   <li>Vignette: the dark screen edges that come from low light are hidden.</li>
 * </ul>
 * The hooks are in the mixins: InGameOverlayRendererMixin, AbstractClientPlayerEntityMixin, ClientPlayerEntityMixin,
 * LivingEntityMixin, HeldItemRendererMixin, GameRendererMixin and InGameHudMixin.
 */
public class NoRenderModule extends Module {
    public final BoolSetting fire = add(new BoolSetting("Fire", true));
    public final BoolSetting fov = add(new BoolSetting("FOV effects", true));
    public final BoolSetting effects = add(new BoolSetting("Potion effects", true));
    public final BoolSetting vanillaSwing = add(new BoolSetting("Vanilla swing", false));
    public final BoolSetting hurtCam = add(new BoolSetting("Hurt cam", false));
    public final BoolSetting viewBob = add(new BoolSetting("View bob", false));
    public final BoolSetting crosshair = add(new BoolSetting("Crosshair", false));
    public final BoolSetting vignette = add(new BoolSetting("Vignette", false));

    public NoRenderModule() { super("No Render", Category.RENDER); }

    /** The module if it is on, else null. Every hook goes through this, so turning the module off restores everything. */
    private static NoRenderModule on() {
        NoRenderModule m = ModuleManager.get(NoRenderModule.class);
        return m != null && m.isEnabled() ? m : null;
    }

    public static boolean fire() { NoRenderModule m = on(); return m != null && m.fire.get(); }
    public static boolean fov() { NoRenderModule m = on(); return m != null && m.fov.get(); }
    public static boolean effects() { NoRenderModule m = on(); return m != null && m.effects.get(); }
    public static boolean vanillaSwing() { NoRenderModule m = on(); return m != null && m.vanillaSwing.get(); }
    public static boolean hurtCam() { NoRenderModule m = on(); return m != null && m.hurtCam.get(); }
    public static boolean viewBob() { NoRenderModule m = on(); return m != null && m.viewBob.get(); }
    public static boolean crosshair() { NoRenderModule m = on(); return m != null && m.crosshair.get(); }
    public static boolean vignette() { NoRenderModule m = on(); return m != null && m.vignette.get(); }
}
