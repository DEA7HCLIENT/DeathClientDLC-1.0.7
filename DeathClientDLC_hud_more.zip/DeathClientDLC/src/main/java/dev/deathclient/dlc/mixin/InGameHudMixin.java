package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render: the vanilla crosshair and the vignette (dark screen edges). require = 0: if a method has another name
 * in this build, that hook is skipped and nothing breaks.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noCrosshair(CallbackInfo ci) {
        if (NoRenderModule.crosshair()) ci.cancel();
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noVignette(CallbackInfo ci) {
        if (NoRenderModule.vignette()) ci.cancel();
    }
}
