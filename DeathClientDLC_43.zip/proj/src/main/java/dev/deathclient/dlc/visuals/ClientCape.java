package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * The DC cape. Everybody who has this client (you, and the players ClientUsers recognises) wears it, and sees it on the others;
 * there is no module and no switch. It is drawn on the screen over the back of the player (like the wings of Cosmetics), as 16
 * vertical strips of textures/gui/cape_back.png (the back panel of textures/cape/dc_cape.png), so it covers a normal cape the
 * player may wear. It hangs 1 block from the shoulders, swings back when the player runs and sways a little.
 * Limits of this way of drawing: it is only shown when you do not look at the player's front, not in first person, and it
 * is skipped when the elytra is worn (like the vanilla cape) or when you cannot see the player.
 */
public final class ClientCape {
    private static final Identifier TEX = Identifier.of("deathclientdlc", "textures/gui/cape_back.png");
    private static final int TW = 160, TH = 256, COLS = 16, COL_W = TW / COLS;
    private static final ScreenProjector PROJ = new ScreenProjector();

    private ClientCape() {}

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.world == null || c.player == null || c.options.hudHidden || c.currentScreen != null || Hud.hidden) return;
        float delta = tickCounter.getTickProgress(false);
        PROJ.begin(c, delta);
        Entity cam = c.getCameraEntity() != null ? c.getCameraEntity() : c.player;
        boolean freecam = cam != c.player;
        double camYaw = Math.toRadians(cam.getYaw() + (!freecam && c.options.getPerspective().isFrontView() ? 180 : 0));
        double cfx = -Math.sin(camYaw), cfz = Math.cos(camYaw);
        for (PlayerEntity p : c.world.getPlayers()) {
            if (p == c.player && !freecam && c.options.getPerspective().isFirstPerson()) continue;
            if (!ClientUsers.isUser(p) || p.isInvisible() || p.isSpectator()) continue;
            if (p != c.player && !c.player.canSee(p)) continue;        // never show a cape through a wall
            draw(ctx, c, p, delta, cfx, cfz);
        }
    }

    private static double[] pt(double x, double y, double z) {
        if (!PROJ.project(new Vec3d(x, y, z))) return null;
        return new double[]{PROJ.out[0], PROJ.out[1]};
    }

    private static void draw(DrawContext ctx, MinecraftClient c, PlayerEntity p, float delta, double cfx, double cfz) {
        if (p.isGliding() || p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        Vec3d base = p.getLerpedPos(delta);
        double yaw = Math.toRadians(p.getBodyYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -Math.cos(yaw), rz = -Math.sin(yaw);   // forward and right of the player
        if (fx * cfx + fz * cfz < -0.2) return;              // you look at his front: the cape is behind the body, it would be drawn over it

        double t = System.nanoTime() / 1.0e9;
        Vec3d v = p.getVelocity();
        double along = v.x * fx + v.z * fz, side = v.x * rx + v.z * rz;
        double swing = Math.max(-0.1, Math.min(0.55, along * 3.0)) + 0.03 + Math.sin(t * 2.0 + p.getId()) * 0.02;
        double sway = Math.max(-0.2, Math.min(0.2, -side * 1.0));
        double hw = 0.3125, len = 1.0, off = 0.19;
        double topY = base.y + p.getHeight() * (p.isSneaking() ? 0.80 : 0.77);
        double tx = base.x - fx * off, tz = base.z - fz * off;

        for (int i = 0; i < COLS; i++) {
            double a = i / (double) COLS, b = (i + 1) / (double) COLS;
            double[] t0 = pt(tx + rx * (-hw + 2 * hw * a), topY, tz + rz * (-hw + 2 * hw * a));
            double[] t1 = pt(tx + rx * (-hw + 2 * hw * b), topY, tz + rz * (-hw + 2 * hw * b));
            double[] b0 = pt(tx + rx * (-hw + 2 * hw * a) - fx * swing + rx * sway, topY - len + swing * 0.25, tz + rz * (-hw + 2 * hw * a) - fz * swing + rz * sway);
            double[] b1 = pt(tx + rx * (-hw + 2 * hw * b) - fx * swing + rx * sway, topY - len + swing * 0.25, tz + rz * (-hw + 2 * hw * b) - fz * swing + rz * sway);
            if (t0 == null || t1 == null || b0 == null || b1 == null) continue;
            double xl = Math.min(Math.min(t0[0], b0[0]), Math.min(t1[0], b1[0]));
            double xr = Math.max(Math.max(t0[0], b0[0]), Math.max(t1[0], b1[0]));
            double yt = (t0[1] + t1[1]) / 2.0, yb = (b0[1] + b1[1]) / 2.0;
            int x0 = (int) Math.floor(xl), x1 = (int) Math.ceil(xr) + 1;            // one pixel of overlap so no gaps show between strips
            int y0 = (int) Math.round(yt), y1 = (int) Math.round(yb);
            if (x1 <= x0 || y1 <= y0 || x1 - x0 > 2000 || y1 - y0 > 3000) continue;
            int shade = (int) Math.round(255 * (0.82 + 0.18 * Math.sin(Math.PI * (a + b) / 2.0)));      // a little darker at the sides, like a curved cloth
            int color = 0xFF000000 | (shade << 16) | (shade << 8) | shade;
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEX, x0, y0, (float) (i * COL_W), 0f, x1 - x0, y1 - y0, COL_W, TH, TW, TH, color);
        }
    }
}
