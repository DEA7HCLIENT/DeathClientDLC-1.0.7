package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * "Monday" aim profile (ported from the supplied monday.rotation.Rotation class).
 * Picks a visible point on the target's hitbox from a fixed table of points, on the side of the target that faces
 * us, with weighted body zones, holds each point for a few ticks, and turns toward it with a capped, jittered,
 * mouse-grid-quantized step. {@link #update} returns the next yaw / pitch; it does not send anything itself.
 */
final class MondayRotation {
    record Rot(float yaw, float pitch) {}

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final double EDGE = 0.88;
    private static final double PREDICT = 0.6;

    private static final float MAX_YAW = 5.0f;
    private static final float MAX_PITCH = 15.0f;
    private static final float MIN_STEP = 0.35f;
    private static final double F_MIN = 0.35;
    private static final double F_MAX = 0.75;
    private static final float CAP_RAND = 0.1f;

    private static final float JIT_YAW = 0.12f;
    private static final float JIT_PITCH = 0.08f;

    private static final int HOLD_MIN = 2;
    private static final int HOLD_MAX = 5;
    private static final int PICK_NEAR = 3;
    private static final double PITCH_W = 0.5;
    // zone weights: legs, lower body, body / arms, head / neck
    private static final double[] ZONE_W = {10.0, 20.0, 40.0, 30.0};
    private static final double FACE_ANG = 45.0;
    private static final double FACE_HYST = 10.0;

    // {yFrac, right, forward}
    private static final double[][] P = {
        {0.922, 0.529, 0.758},
        {0.924, -0.57, 0.758},
        {0.839, -0.059, 0.758},
        {0.663, 0.79, 0.379},
        {0.672, -0.962, 0.379},
        {0.581, -0.109, 0.379},
        {0.705, -0.018, 0.379},
        {0.467, 0.04, 0.379},
        {0.669, -1.0, 0.128},
        {0.669, -1.0, -0.281},
        {0.951, -0.758, 0.354},
        {0.936, -0.758, -0.484},
        {0.855, -0.758, 0.024},
        {0.952, -0.423, -0.758},
        {0.813, 0.062, -0.758},
        {0.929, 0.528, -0.758},
        {0.678, -0.801, -0.379},
        {0.537, -0.87, -0.379},
        {0.686, 0.895, -0.379},
        {0.572, 0.787, -0.379},
        {0.6, 0.067, -0.379},
        {0.694, -0.05, -0.379},
        {0.455, 0.02, -0.379},
        {0.474, 1.0, 0.005},
        {0.672, 1.0, 0.059},
        {0.596, 1.0, 0.081},
        {0.938, 0.758, 0.538},
        {0.913, 0.758, -0.369},
        {0.83, 0.758, 0.059},
        {0.6, 0.356, 0.379},
        {0.635, -0.451, 0.379},
        {0.504, -1.0, -0.155},
        {0.497, -1.0, 0.09},
        {0.587, -1.0, -0.039},
        {0.539, 1.0, -0.174},
        {0.523, 1.0, 0.15},
        {0.531, -0.229, -0.379},
        {0.482, 0.295, -0.379},
        {0.621, -0.25, -0.379},
        {0.639, 0.428, -0.379},
        {0.805, -0.513, -0.758},
        {0.952, 0.139, -0.758},
        {0.821, 0.465, -0.758},
        {0.815, -0.415, 0.758},
        {0.807, 0.599, 0.758},
        {0.914, 0.07, 0.758},
        {0.572, 0.767, 0.379},
        {0.463, 0.832, 0.379},
        {0.451, -0.898, 0.379},
        {0.551, -0.855, 0.379},
        {0.44, -0.377, 0.379},
        {0.524, -0.443, 0.379},
        {0.52, 0.176, 0.379}
    };

    // Side of the target each point in P sits on: 0 front, 1 right, 2 back, 3 left.
    private static final int[] Z = {
        0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 0,
        0, 3, 3, 3, 1, 1, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
    };

    private LivingEntity last;
    private int id = -1, hold;
    private final ArrayDeque<Integer> bag = new ArrayDeque<>();
    private int face;

    void reset() {
        last = null;
        id = -1;
        hold = 0;
        bag.clear();
        face = 0;
    }

    // Picks one of the PICK_NEAR points closest to the crosshair (the current point is skipped).
    // A body zone is rolled by weight first, then the nearest points inside that zone are used.
    private int next(LivingEntity t, Vec3d eye, Vec3d vel, double range, boolean[] ok, float yaw, float pitch) {
        double[] dist = new double[P.length];
        List<Integer> all = new ArrayList<>();
        for (int i = 0; i < P.length; i++) {
            if (!ok[i]) continue;
            Vec3d p = at(t, i, vel);
            if (i == id || !visible(eye, p, range)) continue;
            float[] a = ang(eye, p);
            dist[i] = Math.hypot(MathHelper.wrapDegrees(a[0] - yaw), (a[1] - pitch) * PITCH_W);
            all.add(i);
        }
        if (all.isEmpty()) return id >= 0 && visible(eye, at(t, id, vel), range) ? id : -1;
        boolean[] has = new boolean[4];
        double total = 0;
        for (int i : all) has[zone(i)] = true;
        for (int z = 0; z < 4; z++) if (has[z]) total += ZONE_W[z];
        if (total > 0) {
            double roll = ThreadLocalRandom.current().nextDouble() * total;
            int pick = -1;
            for (int z = 0; z < 4; z++) {
                if (!has[z] || ZONE_W[z] <= 0) continue;
                pick = z;
                if (roll < ZONE_W[z]) break;
                roll -= ZONE_W[z];
            }
            final int zz = pick;
            all.removeIf(i -> zone(i) != zz);
        }
        all.sort(Comparator.comparingDouble(i -> dist[i]));
        return all.get(ThreadLocalRandom.current().nextInt(Math.min(PICK_NEAR, all.size())));
    }

    private static int zone(int i) {
        double y = P[i][0];
        return y < 0.4 ? 0 : y < 0.58 ? 1 : y < 0.8 ? 2 : 3;
    }

    /** Next (yaw, pitch) toward the target, starting from the given angles; {@code range} limits how far an aim point may be. */
    Rot update(LivingEntity target, float yaw, float pitch, double range) {
        if (mc.player == null || mc.world == null || target == null) {
            reset();
            return new Rot(yaw, pitch);
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (target != last) {
            reset();
            last = target;
        }

        Vec3d eye = mc.player.getEyePos();
        Vec3d vel = new Vec3d(target.getX() - target.prevX, 0, target.getZ() - target.prevZ).multiply(PREDICT);

        face = faceOf(target, eye);
        boolean[] ok = poolOf(face);
        if (id >= 0 && (!ok[id] || !visible(eye, at(target, id, vel), range))) id = -1;

        if (id < 0 || hold <= 0) {
            id = next(target, eye, vel, range, ok, yaw, pitch);
            hold = r.nextInt(HOLD_MIN, HOLD_MAX + 1);
        }
        if (id < 0) return new Rot(yaw, pitch);
        hold--;

        float[] aim = ang(eye, at(target, id, vel));
        float dy = MathHelper.wrapDegrees(aim[0] - yaw);
        float dp = aim[1] - pitch;

        double dist = Math.hypot(dy, dp);
        double f = F_MIN + (F_MAX - F_MIN) * Math.min(dist / 90.0, 1.0);

        float sy = step(dy, f, MAX_YAW, r);
        float sp = step(dp, f, MAX_PITCH, r);
        sy += rand(r, JIT_YAW);
        sp += rand(r, JIT_PITCH);

        float q = Rotations.gcd(mc);
        sy = Rotations.snap(sy, q);
        sp = Rotations.snap(sp, q);

        return new Rot(yaw + sy, MathHelper.clamp(pitch + sp, -90f, 90f));
    }

    // Which side of the target faces us: 0 front, 1 right, 2 back, 3 left. Hysteresis at the zone borders keeps the choice from flickering.
    private int faceOf(LivingEntity t, Vec3d eye) {
        double dx = eye.x - t.getX(), dz = eye.z - t.getZ();
        double len = Math.hypot(dx, dz);
        if (len < 1.0E-4) return face;
        double yaw = Math.toRadians(t.bodyYaw);
        double fwd = (-Math.sin(yaw) * dx + Math.cos(yaw) * dz) / len;
        double rgt = (-Math.cos(yaw) * dx - Math.sin(yaw) * dz) / len;
        double a = Math.toDegrees(Math.atan2(rgt, fwd));
        if (inFace(face, a, FACE_HYST)) return face;
        for (int z = 0; z < 4; z++) if (inFace(z, a, 0.0)) return z;
        return face;
    }

    private static boolean inFace(int z, double a, double m) {
        double abs = Math.abs(a);
        return switch (z) {
            case 0 -> abs < FACE_ANG + m;
            case 2 -> abs > 180.0 - FACE_ANG - m;
            case 1 -> a > FACE_ANG - m && a < 180.0 - FACE_ANG + m;
            default -> a < -(FACE_ANG - m) && a > -(180.0 - FACE_ANG + m);
        };
    }

    // Points of the wanted side. With none on that side the front ones are used, and with none there either, all of them.
    private static boolean[] poolOf(int z) {
        boolean[] ok = new boolean[P.length];
        boolean any = false;
        for (int i = 0; i < P.length; i++) if (Z[i] == z) { ok[i] = true; any = true; }
        if (!any) for (int i = 0; i < P.length; i++) if (Z[i] == 0) { ok[i] = true; any = true; }
        if (!any) Arrays.fill(ok, true);
        return ok;
    }

    private static float rand(ThreadLocalRandom r, double range) {
        return (float) ((r.nextDouble() * 2 - 1) * range);
    }

    private static float step(float d, double f, float cap, ThreadLocalRandom r) {
        float limit = cap * (1f + CAP_RAND * rand(r, 1.0));
        float s = MathHelper.clamp((float) (d * f), -limit, limit);
        if (Math.abs(d) <= MIN_STEP) return d;
        return Math.abs(s) < MIN_STEP ? Math.copySign(MIN_STEP, d) : s;
    }

    private Vec3d at(LivingEntity t, int i, Vec3d vel) {
        Box b = t.getBoundingBox();
        double half = b.getLengthX() * 0.5 * EDGE;
        double yaw = Math.toRadians(t.bodyYaw);
        double x = b.getCenter().x + (-Math.cos(yaw) * P[i][1] - Math.sin(yaw) * P[i][2]) * half;
        double z = b.getCenter().z + (-Math.sin(yaw) * P[i][1] + Math.cos(yaw) * P[i][2]) * half;
        return new Vec3d(x, b.minY + b.getLengthY() * P[i][0], z).add(vel);
    }

    private static boolean visible(Vec3d from, Vec3d to, double range) {
        if (from.distanceTo(to) > range) return false;
        RaycastContext ctx = new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player);
        return mc.world.raycast(ctx).getType() == HitResult.Type.MISS;
    }

    private static float[] ang(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        float yaw = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        float pitch = MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))), -90f, 90f);
        return new float[]{yaw, pitch};
    }
}
