package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.block.SlabBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.List;

/**
 * XBow: a TNT minecart trap on the nearest player, step by step.
 * <ol>
 *   <li>lays a rail on the floor next to the target (out of your own blast range, "Min self distance"),</li>
 *   <li>puts a TNT minecart on the rail,</li>
 *   <li>if Slab safe is on and there is a slab on the hotbar: puts the slab on the floor between you and the rail,
 *       a half-block that takes part of the blast,</li>
 *   <li>lights the minecart (flint and steel, or a fire charge, used on it).</li>
 * </ol>
 * It needs a rail (any kind), a TNT minecart and flint and steel (or a fire charge) on the hotbar.
 *
 * Rotation: Snap turns to the point at once (one look packet right before each step, then your real view again) and
 * Smooth turns the aim step by step, at most "Rotation speed" degrees per tick (up to 180, where it is nearly a snap),
 * and acts when it is aimed. Your own camera stays where it is unless "Turn camera" is on.
 */
public class XBowModule extends Module {
    private static final int SNAP = 1, SMOOTH = 2;
    private static final int FIND = 0, RAIL = 1, CART = 2, SLAB = 3, FIRE = 4, COOL = 5;
    private static final Item[] RAILS = {Items.RAIL, Items.POWERED_RAIL, Items.DETECTOR_RAIL, Items.ACTIVATOR_RAIL};

    public final NumberSetting targetRange = add(new NumberSetting("Target range", 10, 3, 20, 1));
    public final NumberSetting reach = add(new NumberSetting("Reach", 4.5, 2, 6, 0.5));
    /** The rail is never laid closer than this to you, so the blast stays away from you. */
    public final NumberSetting minSelfDist = add(new NumberSetting("Min self distance", 2.5, 0, 6, 0.5));
    public final NumberSetting rotation = add(new NumberSetting("Rotation", SNAP, 1, 2, 1).labels("Snap", "Smooth"));
    /** Smooth: degrees per tick the aim may turn. 180 = about a snap. */
    public final NumberSetting speed = add(new NumberSetting("Rotation speed", 180, 10, 180, 5));
    public final BoolSetting turnCamera = add(new BoolSetting("Turn camera", false));
    /** Ticks between the steps. */
    public final NumberSetting delay = add(new NumberSetting("Delay", 2, 1, 10, 1));
    /** Ticks to wait after a finished trap before the next one. */
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 20, 0, 100, 5));
    public final BoolSetting slabSafe = add(new BoolSetting("Slab safe", false));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    /** Switch the module off after one trap. */
    public final BoolSetting once = add(new BoolSetting("Once", false));

    private PlayerEntity target;
    private BlockPos rail;
    private int stage = FIND, wait, life, tries;
    private boolean srvActive;
    private float srvYaw, srvPitch;

    public XBowModule() { super("XBow", Category.COMBAT); }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) endAim(c, c.player);
        target = null;
        rail = null;
        stage = FIND;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null || c.currentScreen != null) return;
        if (wait > 0) { wait--; return; }
        if (stage != FIND && stage != COOL && --life <= 0) { fail(c, p, "XBow: время вышло"); return; }
        switch (stage) {
            case FIND -> find(c, p);
            case RAIL -> layRail(c, p);
            case CART -> placeCart(c, p);
            case SLAB -> placeSlab(c, p);
            case FIRE -> ignite(c, p);
            default -> stage = FIND;                                        // COOL is over
        }
    }

    // ------------------------------------------------------------------ planning

    private void find(MinecraftClient c, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestD = targetRange.get();
        for (PlayerEntity e : c.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator() || Friends.isFriend(e) || AntiBotModule.isBot(e)) continue;
            double d = p.distanceTo(e);
            if (d < bestD) { bestD = d; best = e; }
        }
        if (best == null) return;
        BlockPos spot = railSpot(c, p, best);
        if (spot == null) return;                                           // nowhere to put the rail yet: look again
        target = best;
        rail = spot;
        stage = RAIL;
        life = 200;
        tries = 0;
    }

    /** A free cell with a solid floor next to the target: close to it, within your reach, and not too close to you. */
    private BlockPos railSpot(MinecraftClient c, ClientPlayerEntity p, PlayerEntity t) {
        BlockPos base = t.getBlockPos();
        Vec3d eye = p.getEyePos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = -1; dy <= 1; dy++) {
            BlockPos pos = base.add(dx, dy, dz);
            BlockPos floor = pos.down();
            BlockState st = c.world.getBlockState(pos);
            boolean free = st.isIn(BlockTags.RAILS) || ((st.isAir() || st.isReplaceable()) && c.world.getFluidState(pos).isEmpty());
            if (!free || !c.world.getBlockState(floor).isSideSolidFullSquare(c.world, floor, Direction.UP)) continue;
            Vec3d aim = new Vec3d(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5);
            if (eye.distanceTo(aim) > reach.get() || p.getPos().distanceTo(Vec3d.ofBottomCenter(pos)) < minSelfDist.get()) continue;
            double d = Vec3d.ofBottomCenter(pos).distanceTo(t.getPos());
            if (d < bestD) { bestD = d; best = pos; }
        }
        return best;
    }

    // ------------------------------------------------------------------ the steps

    private void layRail(MinecraftClient c, ClientPlayerEntity p) {
        if (isRail(c, rail)) { next(CART); return; }
        int slot = railSlot(p);
        if (slot < 0) { fail(c, p, "XBow: нет рельс на хотбаре"); return; }
        BlockPos floor = rail.down();
        Vec3d aim = new Vec3d(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(aim, Direction.UP, floor, false);
        if (act(c, p, slot, aim, () -> c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit))) next(CART);
    }

    private void placeCart(MinecraftClient c, ClientPlayerEntity p) {
        if (!isRail(c, rail)) {                                             // the rail did not appear: lay it again
            if (++tries > 3) fail(c, p, "XBow: не удалось поставить рельсу"); else stage = RAIL;
            return;
        }
        if (findCart(c) != null) { next(slabSafe.get() ? SLAB : FIRE); return; }
        int slot = Util.findHotbar(p, Items.TNT_MINECART);
        if (slot < 0) { fail(c, p, "XBow: нет вагонетки с TNT на хотбаре"); return; }
        Vec3d aim = new Vec3d(rail.getX() + 0.5, rail.getY() + 0.125, rail.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(aim, Direction.UP, rail, false);
        if (act(c, p, slot, aim, () -> c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit))) next(slabSafe.get() ? SLAB : FIRE);
    }

    /** Slab safe: a slab on the floor between you and the rail. Skipped quietly if there is no slab or no room. */
    private void placeSlab(MinecraftClient c, ClientPlayerEntity p) {
        int slot = slabSlot(p);
        BlockPos spot = slabSpot(c, p);
        if (slot < 0 || spot == null) { stage = FIRE; return; }
        BlockPos floor = spot.down();
        Vec3d aim = new Vec3d(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(aim, Direction.UP, floor, false);
        if (act(c, p, slot, aim, () -> c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit))) next(FIRE);
    }

    private BlockPos slabSpot(MinecraftClient c, ClientPlayerEntity p) {
        Vec3d to = Vec3d.ofBottomCenter(rail).subtract(p.getPos());
        double len = Math.hypot(to.x, to.z);
        if (len < 1e-3) return null;
        BlockPos spot = BlockPos.ofFloored(p.getX() + to.x / len, p.getY(), p.getZ() + to.z / len);
        if (spot.equals(p.getBlockPos()) || spot.equals(rail)) return null;
        BlockState st = c.world.getBlockState(spot);
        boolean free = (st.isAir() || st.isReplaceable()) && c.world.getFluidState(spot).isEmpty();
        return free && c.world.getBlockState(spot.down()).isSideSolidFullSquare(c.world, spot.down(), Direction.UP) ? spot : null;
    }

    private void ignite(MinecraftClient c, ClientPlayerEntity p) {
        TntMinecartEntity cart = findCart(c);
        if (cart == null) {                                                 // the cart is not there (yet)
            if (++tries > 8) { stage = CART; tries = 0; }                   // put it again (the life timer ends it all)
            return;
        }
        int slot = Util.findHotbar(p, Items.FLINT_AND_STEEL);
        if (slot < 0) slot = Util.findHotbar(p, Items.FIRE_CHARGE);
        if (slot < 0) { fail(c, p, "XBow: нет огнива на хотбаре"); return; }
        Vec3d aim = cart.getBoundingBox().getCenter();
        if (act(c, p, slot, aim, () -> c.interactionManager.interactEntity(p, cart, Hand.MAIN_HAND))) {
            endAim(c, p);
            target = null;
            rail = null;
            stage = COOL;
            wait = (int) cooldown.get();
            if (once.get()) toggle();
        }
    }

    private void next(int to) {
        stage = to;
        wait = (int) delay.get() - 1;
        tries = 0;
    }

    private TntMinecartEntity findCart(MinecraftClient c) {
        List<TntMinecartEntity> list = c.world.getEntitiesByClass(TntMinecartEntity.class,
                new Box(rail).expand(1.5), e -> e.isAlive());
        return list.isEmpty() ? null : list.get(0);
    }

    private static boolean isRail(MinecraftClient c, BlockPos pos) {
        return c.world.getBlockState(pos).isIn(BlockTags.RAILS);
    }

    private static int railSlot(ClientPlayerEntity p) {
        for (Item rail : RAILS) {
            int s = Util.findHotbar(p, rail);
            if (s >= 0) return s;
        }
        return -1;
    }

    private static int slabSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).getItem() instanceof BlockItem bi && bi.getBlock() instanceof SlabBlock) return i;
        }
        return -1;
    }

    private void fail(MinecraftClient c, ClientPlayerEntity p, String msg) {
        endAim(c, p);
        target = null;
        rail = null;
        stage = COOL;
        wait = (int) cooldown.get();
        p.sendMessage(Text.literal(msg), true);
    }

    // ------------------------------------------------------------------ rotation and use

    /**
     * Aims at the point and runs the use when aimed: false = not yet (too far, or Smooth is still turning). The slot
     * is switched for the use and given back.
     */
    private boolean act(MinecraftClient c, ClientPlayerEntity p, int slot, Vec3d aim, Runnable use) {
        if (p.getEyePos().distanceTo(aim) > reach.get()) return false;     // too far: wait (the life timer runs)
        if (!aimAt(c, p, aim)) return false;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        use.run();
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        if ((int) rotation.get() == SNAP) endAim(c, p);                    // Snap: right back to the real view
        return true;
    }

    private boolean aimAt(MinecraftClient c, ClientPlayerEntity p, Vec3d point) {
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float gcd = Rotations.gcd(c);
        if ((int) rotation.get() == SNAP) {
            float yaw = p.getYaw() + Rotations.snap(MathHelper.wrapDegrees(want[0] - p.getYaw()), gcd);
            float pitch = MathHelper.clamp(p.getPitch() + Rotations.snap(want[1] - p.getPitch(), gcd), -90f, 90f);
            show(c, p, yaw, pitch);
            return true;
        }
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw), dp = want[1] - srvPitch;
        float m = Math.max(Math.abs(dy), Math.abs(dp));
        float k = m > speed.get() ? (float) speed.get() / m : 1f;           // at most "speed" degrees on the longer axis
        srvYaw += Rotations.snap(dy * k, gcd);
        srvPitch = MathHelper.clamp(srvPitch + Rotations.snap(dp * k, gcd), -90f, 90f);
        show(c, p, srvYaw, srvPitch);
        return Math.abs(MathHelper.wrapDegrees(want[0] - srvYaw)) <= 3f && Math.abs(want[1] - srvPitch) <= 3f;
    }

    /** The aim for this tick: to the server (and your model's head), and to your camera if Turn camera is on. */
    private void show(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (turnCamera.get()) {
            p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yaw - p.getYaw()));
            p.setPitch(pitch);
        }
        sendLook(c, p, yaw, pitch);
        ServerRotation.set(yaw, pitch, 400);
    }

    /** Tells the server your real view again (nothing to do when the camera was turned: it is the view). */
    private void endAim(MinecraftClient c, ClientPlayerEntity p) {
        if (srvActive || !turnCamera.get()) sendLook(c, p, p.getYaw(), p.getPitch());
        srvActive = false;
    }

    private static void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }
}
