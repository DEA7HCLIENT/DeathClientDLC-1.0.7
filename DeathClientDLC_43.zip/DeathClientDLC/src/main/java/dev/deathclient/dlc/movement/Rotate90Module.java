package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Rotate 90: turns your view by 90 degrees to the right or to the left, at a speed you choose (50 to 360 degrees
 * per second), and switches itself off when the turn is done. Put it on a key (bind) and every press is one quarter
 * turn: at 360 the turn takes a quarter of a second, at 50 about two seconds.
 * "Snap to 90" first rounds your direction to the nearest multiple of 90 degrees, so repeated turns always end on the
 * four straight directions even if you started a little off.
 * It turns the real view (the camera and what the server sees); the game draws it smoothly between ticks.
 */
public class Rotate90Module extends Module {
    /** Degrees per second. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 180, 50, 360, 10));
    public final NumberSetting direction = add(new NumberSetting("Direction", 1, 1, 2, 1).labels("Right", "Left"));
    public final BoolSetting snapToGrid = add(new BoolSetting("Snap to 90", false));

    private boolean started;
    private float target;

    public Rotate90Module() { super("Rotate 90", Category.MOVEMENT); }

    @Override
    protected void onDisable() { started = false; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null) return;
        if (!started) {                                                    // the first tick after it was switched on
            float base = p.getYaw();
            if (snapToGrid.get()) base = Math.round(base / 90f) * 90f;
            target = base + ((int) direction.get() == 1 ? 90f : -90f);     // a bigger yaw is a turn to the right
            started = true;
        }
        float diff = target - p.getYaw();
        float step = (float) (speed.get() / 20.0);                         // a tick is 1/20 second
        if (Math.abs(diff) <= step) {
            p.setYaw(target);
            toggle();                                                      // done: switch itself off
        } else {
            p.setYaw(p.getYaw() + Math.copySign(step, diff));
        }
    }
}
