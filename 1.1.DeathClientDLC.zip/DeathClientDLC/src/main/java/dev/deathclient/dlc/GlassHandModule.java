package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

/**
 * Glass Hand: a frosted-glass glow around your first-person hand and / or held item, in the color of the
 * hand (skin tone) or of the item. The glow is drawn inside the hand's own matrix (HeldItemRendererMixin),
 * so it follows the hand, the held item, the View Model offsets and scale, and the equip animation.
 * Colors: Auto = skin tone for the hand and the item's own color for the item; Theme; Rainbow; Custom (H / S / B).
 * Offset X / Offset Y are in the same GUI-pixel units as the rest of the HUD (200 px = 1 block in view space).
 */
public class GlassHandModule extends Module {
    private static final String[] ITEM_KEYS = {
            "netherite", "diamond", "emerald", "golden", "gold", "iron", "chainmail", "copper", "amethyst", "lapis",
            "redstone", "end_crystal", "ender", "totem", "tnt", "apple", "blaze", "fire", "slime", "obsidian",
            "wooden", "stone", "bow", "shield", "elytra", "trident", "mace", "turtle"};
    private static final int[] ITEM_COLORS = {
            0x6B5F6E, 0x4AEDD9, 0x17DD62, 0xFCEE4B, 0xFCEE4B, 0xD8D8D8, 0xA8A8B8, 0xE77C56, 0xB066E8, 0x345EC3,
            0xFF2B2B, 0xFF5FD0, 0x2FB59F, 0xFFD83A, 0xFF4B3B, 0xFF3B3B, 0xFF9A1F, 0xFF9A1F, 0x7BE35A, 0x3A2A5A,
            0x9C7A45, 0x8F8F8F, 0xB08A55, 0x9AA0AA, 0xB9B4D0, 0x2FB5A8, 0xC9C3D6, 0x5DBB63};
    private static final int[] SKIN_TONES = {0xF0C8A0, 0xD9A47B, 0xB07A55, 0x7A4B33};
    private static final int LAYERS = 10;
    private static final int SEGMENTS = 32;
    /** GUI pixels per block in view space, same as ViewModelModule. */
    private static final double K = 200;

    // Anchor points in camera (view) space, right-hand side; the View Model matrix is already applied.
    // Hand: the palm/forearm area. Item: the spot where a held item sits. Tuned by eye, adjust with the sliders.
    private static final float HAND_X = 0.35f, HAND_Y = -0.42f, HAND_Z = -0.66f;
    private static final float HAND_RX = 0.30f, HAND_RY = 0.42f;
    private static final float ITEM_X = 0.42f, ITEM_Y = -0.22f, ITEM_Z = -0.60f;
    private static final float ITEM_R = 0.18f;

    public final NumberSetting target = add(new NumberSetting("Glow target", 3, 1, 3, 1).labels("Hand", "Item", "Both"));
    public final NumberSetting color = add(new NumberSetting("Color", 1, 1, 4, 1).labels("Auto", "Theme", "Rainbow", "Custom"));
    public final NumberSetting handTone = add(new NumberSetting("Hand tone", 1, 1, 4, 1).labels("Light", "Medium", "Tan", "Dark"));
    public final NumberSetting hue = add(new NumberSetting("Custom hue", 200, 0, 360, 5));
    public final NumberSetting sat = add(new NumberSetting("Custom saturation", 0.8, 0, 1, 0.05));
    public final NumberSetting bri = add(new NumberSetting("Custom brightness", 1, 0.2, 1, 0.05));
    public final NumberSetting size = add(new NumberSetting("Glow size", 14, 4, 40, 1));
    public final NumberSetting strength = add(new NumberSetting("Glow strength %", 45, 5, 100, 5));
    public final NumberSetting frost = add(new NumberSetting("Glass frost %", 18, 0, 60, 2));
    public final BoolSetting pulse = add(new BoolSetting("Pulse", false));
    public final NumberSetting offX = add(new NumberSetting("Offset X", 0, -150, 150, 1));
    public final NumberSetting offY = add(new NumberSetting("Offset Y", 0, -150, 150, 1));

    public GlassHandModule() { super("Glass Hand", Category.VISUALS); }

    /**
     * Called by HeldItemRendererMixin at the start of renderFirstPersonItem, after the View Model matrix is set.
     * The matrix is the hand's camera-space matrix, so the glow is bound to the hand and the item.
     */
    public static void renderHand(Hand hand, MatrixStack matrices, ItemStack stack, VertexConsumerProvider vcp) {
        if (Hud.hidden) return;
        GlassHandModule g = ModuleManager.get(GlassHandModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (g == null || !g.isEnabled() || c.player == null || c.options.hudHidden
                || c.player.isSpectator() || !c.options.getPerspective().isFirstPerson()) return;
        boolean main = hand == Hand.MAIN_HAND;
        if (!main && stack.isEmpty()) return;                // vanilla draws the off hand only with an item

        int tgt = (int) g.target.get();
        boolean mainRight = c.options.getMainArm().getValue() == Arm.RIGHT;
        float side = (main == mainRight) ? 1f : -1f;
        float pulse = g.pulse.get() ? 0.75f + 0.25f * MathHelper.sin(System.currentTimeMillis() / 250f) : 1f;
        float dx = (float) (g.offX.get() / K), dy = (float) (-g.offY.get() / K);

        Matrix4f mat = matrices.peek().getPositionMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getDebugFilledBox());
        float grow = (float) (g.size.get() / K);
        float str = (float) (g.strength.get() / 100.0) * pulse;
        float fa = (float) (g.frost.get() / 100.0) * pulse;

        if (tgt != 2) {
            int rgb = g.colorFor(false, stack) & 0xFFFFFF;
            g.glow(vc, mat, side * HAND_X + dx, HAND_Y + dy, HAND_Z,
                    HAND_RX + grow, HAND_RY + grow, rgb, str, fa);
        }
        if (tgt != 1 && !stack.isEmpty()) {
            int rgb = g.colorFor(true, stack) & 0xFFFFFF;
            g.glow(vc, mat, side * ITEM_X + dx, ITEM_Y + dy, ITEM_Z,
                    ITEM_R + grow, ITEM_R + grow, rgb, str, fa);
        }
    }

    /** Soft glow from stacked radial fades, plus a faint frosted core. All quads are in the hand's matrix. */
    private void glow(VertexConsumer vc, Matrix4f mat, float cx, float cy, float z,
                      float rx, float ry, int rgb, float str, float frostA) {
        for (int i = 0; i < LAYERS; i++) {
            float t = 1f - i / (float) LAYERS;                  // 1 = outermost
            int a = Math.min(255, Math.round(str * 255f * 0.22f * (1.2f - t)));
            if (a <= 0) continue;
            ellipse(vc, mat, cx, cy, z, rx * (0.4f + 0.6f * t), ry * (0.4f + 0.6f * t), rgb, a);
        }
        int fa = Math.min(255, Math.round(frostA * 255f));
        if (fa > 0) {
            ellipse(vc, mat, cx, cy, z - 0.001f, rx * 0.7f, ry * 0.7f, 0xFFFFFF, fa);
        }
    }

    /** Triangle fan drawn as quads (center, edge, edge, center): center alpha fades to 0 at the rim. */
    private static void ellipse(VertexConsumer vc, Matrix4f mat, float cx, float cy, float z,
                                float rx, float ry, int rgb, int centerA) {
        int inner = (centerA << 24) | rgb;
        int outer = rgb;                                        // alpha 0
        for (int i = 0; i < SEGMENTS; i++) {
            double a0 = 2 * Math.PI * i / SEGMENTS, a1 = 2 * Math.PI * (i + 1) / SEGMENTS;
            float x0 = cx + (float) Math.cos(a0) * rx, y0 = cy + (float) Math.sin(a0) * ry;
            float x1 = cx + (float) Math.cos(a1) * rx, y1 = cy + (float) Math.sin(a1) * ry;
            vc.vertex(mat, cx, cy, z).color(inner);
            vc.vertex(mat, x0, y0, z).color(outer);
            vc.vertex(mat, x1, y1, z).color(outer);
            vc.vertex(mat, cx, cy, z).color(inner);
        }
    }

    // ---- colors ----

    private int colorFor(boolean forItem, ItemStack stack) {
        return switch ((int) color.get()) {
            case 1 -> forItem ? itemColor(stack) : SKIN_TONES[(int) handTone.get() - 1];
            case 2 -> Theme.current().accent() & 0xFFFFFF;
            case 3 -> hsv((System.currentTimeMillis() % 4000L) / 4000f, 0.8f, 1f);
            default -> hsv((float) hue.get() / 360f, (float) sat.get(), (float) bri.get());
        };
    }

    /** The item's own color: dyed color, known material names, block map color, else a stable color per item id. */
    private static int itemColor(ItemStack stack) {
        var dyed = stack.get(DataComponentTypes.DYED_COLOR);
        if (dyed != null) return dyed.rgb() & 0xFFFFFF;
        String id = Registries.ITEM.getId(stack.getItem()).getPath();
        for (int i = 0; i < ITEM_KEYS.length; i++) if (id.contains(ITEM_KEYS[i])) return ITEM_COLORS[i];
        if (stack.getItem() instanceof BlockItem bi) {
            Block b = bi.getBlock();
            return b.getDefaultMapColor().color & 0xFFFFFF;
        }
        return hsv(Math.abs(id.hashCode() % 360) / 360f, 0.6f, 1f);
    }

    /** h, s, v in 0..1 -> 0xRRGGBB. */
    private static int hsv(float h, float s, float v) {
        float h6 = (h - (float) Math.floor(h)) * 6f;
        int i = (int) h6;
        float f = h6 - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
