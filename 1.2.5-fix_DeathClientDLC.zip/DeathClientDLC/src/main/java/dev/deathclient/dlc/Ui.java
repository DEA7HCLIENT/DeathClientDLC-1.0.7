package dev.deathclient.dlc;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Shared background and title drawing for the main menu and the ClickGUI. */
final class Ui {
    private static final Identifier BACKGROUND = Identifier.of("deathclientdlc", "textures/gui/background.png");
    private static final Identifier TITLE = Identifier.of("deathclientdlc", "textures/gui/title.png");
    private static final int BG_W = 848, BG_H = 428;
    private static final int TITLE_W = 1100, TITLE_H = 230;
    /** Title width in GUI pixels; height follows the texture ratio. */
    static final int TITLE_GUI_W = 200;
    static final int TITLE_TOP = 14;

    private Ui() {}

    /** Cover-fit the image to the screen, anchored right so the character stays visible. */
    static void drawBackground(DrawContext ctx, int width, int height) {
        double scale = Math.max((double) width / BG_W, (double) height / BG_H);
        int rw = (int) Math.min(BG_W, Math.ceil(width / scale));
        int rh = (int) Math.min(BG_H, Math.ceil(height / scale));
        float u = BG_W - rw;
        float v = (BG_H - rh) / 2f;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BACKGROUND, 0, 0, u, v, width, height, rw, rh, BG_W, BG_H);
    }

    static void drawTitle(DrawContext ctx, int width) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TITLE, (width - TITLE_GUI_W) / 2, TITLE_TOP,
                0f, 0f, TITLE_GUI_W, titleHeight(), TITLE_W, TITLE_H, TITLE_W, TITLE_H,
                Theme.current().accent() | 0xFF000000);   // the texture is white: it takes the theme colour
    }

    static int titleHeight() { return TITLE_GUI_W * TITLE_H / TITLE_W; }

    // Dim over the world instead of vanilla blur: vanilla blur can run only once per frame and crashes when several screens draw it.
    static void drawWorldDim(DrawContext ctx, int width, int height) {
        ctx.fill(0, 0, width, height, 0xB0000000);
    }
}
