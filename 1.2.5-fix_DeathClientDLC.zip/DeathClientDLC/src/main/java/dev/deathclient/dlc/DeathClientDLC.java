package dev.deathclient.dlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.util.Identifier;

public class DeathClientDLC implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Replace the vanilla title screen (exact class check, so our own screen is never replaced).
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen.getClass() == TitleScreen.class) {
                StartupSound.play(client);
                // First time this launch: the start-up screen (icon on black), which opens the main menu itself.
                client.setScreen(SplashScreen.done ? new MainMenuScreen() : new SplashScreen());
            }
        });

        Binds.load();
        Friends.load();
        Emotes.load();
        Config.restore();                       // settings + theme now, on/off flags on first world join
        ChatCommands.init();
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) -> ClientUsers.onMessage(message));
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> ClientUsers.onMessage(message));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientUsers.clear());
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud"), Hud::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "keybinds"), KeybindsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "info_hud"), InfoHudModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "block_esp"), BlockEspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_esp"), TargetEspImageModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "target_esp_ghost"), TargetEspGhostModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "esp"), EspModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "arrows"), ArrowsModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "jump_circle"), JumpCircleModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "china_hat"), ChinaHatModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "glass_hand"), GlassHandModule::render);
        HudElementRegistry.addLast(Identifier.of("deathclientdlc", "hud_edit"), HudEdit::render);   // last: drag HUD in chat

        ClientTickEvents.START_CLIENT_TICK.register(FreecamModule::blockInteractions);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Binds.tick(client);                 // also opens/closes the ClickGUI on its bound key
            ModuleManager.tick(client);
            Emotes.tick(client);
            Config.autosaveTick();
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.autosaveNow());
    }
}
