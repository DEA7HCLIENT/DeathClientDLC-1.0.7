package dev.deathclient.dlc;

import java.util.Map;

/** Short descriptions shown on the module cards in the ClickGUI. */
final class ModuleInfo {
    private static final Map<String, String> DESC = Map.ofEntries(
            Map.entry("KillAura", "Автоматически бьёт ближайших существ"),
            Map.entry("TPAura", "Телепортируется к цели для удара"),
            Map.entry("AutoTotem", "Держит тотем бессмертия в левой руке (можно только при низком HP)"),
            Map.entry("Auto Gapple", "Ест золотое яблоко из хотбара при низком HP"),
            Map.entry("Auto Armor", "Надевает лучшую броню из инвентаря"),
            Map.entry("Surround", "Ставит обсидиан вокруг ног и чинит разрушенные стороны"),
            Map.entry("Criticals", "Каждый удар на земле становится критическим (пакеты)"),
            Map.entry("Auto Pot", "Кидает под ноги зелья: лечение, сила, скорость, огнестойкость"),
            Map.entry("Auto Web", "Ставит паутину на ноги ближайшему игроку"),
            Map.entry("Anti Bot", "Боты и NPC пропускаются всеми боевыми модулями"),
            Map.entry("Auto Log", "Выходит с сервера при низком HP или когда рядом игрок"),
            Map.entry("Auto Weapon", "Берёт лучший меч (или топор против щита) перед ударом"),
            Map.entry("Aim Assist", "Мягко подтягивает прицел к ближайшей цели"),
            Map.entry("No Fall", "Убирает урон от падения"),
            Map.entry("Sprint", "Автоспринт при движении вперёд"),
            Map.entry("Target HUD", "Панель с именем и здоровьем цели"),
            Map.entry("Hit Effects", "Частицы при каждом ударе"),
            Map.entry("Auto Respawn", "Сам нажимает возрождение"),
            Map.entry("Anti AFK", "Мелкие действия, чтобы не кикнуло за AFK"),
            Map.entry("Item ESP", "Подсвечивает выброшенные предметы сквозь стены"),
            Map.entry("Tracers", "Линии от центра экрана к игрокам"),
            Map.entry("Free Lock", "Камера захватывает цель и следит за ней, двигаться можно свободно"),
            Map.entry("TP Back", "Телепорт за спину игрока (на кого смотришь или ближайшего)"),
            Map.entry("Mace Killer", "Бьёт булавой в падении (smash-атака) по ближайшей цели"),
            Map.entry("Elytra Mace", "Летит на элитрах к цели (7-50 блоков), пикирует и бьёт булавой"),
            Map.entry("Crystal Aura", "Автоматически ставит и бьёт кристаллы"),
            Map.entry("Anchor Aura", "Ставит и взрывает якорь у врага"),
            Map.entry("Arrows", "Стрелки вокруг прицела на игроков, мобов, сущностей и инвизов"),
            Map.entry("GUI Animation", "Анимация открытия и закрытия ClickGUI"),
            Map.entry("TriggerBot", "Бьёт цель, на которую наведён прицел"),
            Map.entry("AutoCart", "Рельса и вагонетка с TNT туда, куда летит стрела"),
            Map.entry("Crystal Optimization", "Убирает задержку у кристаллов"),
            Map.entry("Velocity", "Уменьшает отбрасывание от ударов"),
            Map.entry("Speed", "Увеличивает скорость передвижения"),
            Map.entry("Strafe", "Улучшенное управление в воздухе"),
            Map.entry("Target Strafe", "Кружит вокруг цели при атаке"),
            Map.entry("Fly", "Полёт без режима творчества"),
            Map.entry("NoClip", "Проход сквозь блоки"),
            Map.entry("NoClip Fly", "Полёт сквозь стены"),
            Map.entry("Spin", "Вращает персонажа вокруг оси"),
            Map.entry("ESP", "ESP: 2D, 3D Box или круг; игроки, мобы, животные, инвизки"),
            Map.entry("Glow ESP", "Подсвечивает существ сквозь стены"),
            Map.entry("Block ESP", "Рамки вокруг руд, сундуков и спавнеров"),
            Map.entry("Freecam", "Свободная камера отдельно от игрока"),
            Map.entry("Chams", "Цветная заливка моделей сквозь стены"),
            Map.entry("No Render", "Убирает огонь на экране, эффекты FOV и эффекты зелий"),
            Map.entry("View Model", "Положение и размер рук (двигай в чате)"),
            Map.entry("Swing Animation", "Анимация взмаха: Default, Swipe, Down, Custom"),
            Map.entry("Visual Spin", "Вращение модели без смены угла"),
            Map.entry("Line Trails", "Линии-следы за движением"),
            Map.entry("Target ESP", "Эффект при наводке на цель"),
            Map.entry("Target ESP Image", "Картинка-метка на цели"),
            Map.entry("Target ESP Ghost", "Призрак вокруг цели"),
            Map.entry("Jump Circle", "Кольцо под ногами при прыжке, 5 режимов"),
            Map.entry("China Hat", "Китайская шляпа над головой"),
            Map.entry("Glass Hand", "Свечение руки и предмета под их цвет"),
            Map.entry("Cosmetics", "Крылья, плащ, шляпы, нимб и аура из частиц на твоей модели"),
            Map.entry("Emotions", "Эмоции модели: 67, Привет и свои (.emote)"),
            Map.entry("Trails", "Оставляет след за игроком"),
            Map.entry("Fullbright", "Максимальная яркость без факелов"),
            Map.entry("FOV", "Настройка угла обзора"),
            Map.entry("Resource Pack", "Блокирует ресурспаки, которые присылает сервер"),
            Map.entry("Custom Theme", "Свои цвета для тем Custom 1-4 (оттенок, насыщенность, яркость)"),
            Map.entry("GUI Style", "Вид меню: Classic, Panels или CS"),
            Map.entry("Glass Menu", "Стеклянное меню: прозрачное окно и карточки"),
            Map.entry("Dynamic Island", "Остров с временем и названием"),
            Map.entry("Info HUD", "Панель: FPS, пинг, координаты и скорость"),
            Map.entry("Keybinds", "Список активных биндов на экране"),
            Map.entry("Client Badge", "Значок Марин рядом с ником тех, у кого есть клиент"),
            Map.entry("Friends", "Друзья: не бить, подсвечивать (.friend)"),
            Map.entry("Optimization", "Поднимает FPS, не рисует лишнее"));

    private ModuleInfo() {}

    static String desc(Module m) {
        String d = DESC.get(m.getName());
        if (d != null) return d;
        return m.isImplemented() ? "" : "В разработке";
    }
}
