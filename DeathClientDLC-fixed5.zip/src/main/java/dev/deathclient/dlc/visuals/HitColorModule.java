package dev.deathclient.dlc;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/**
 * Hit Color: while an entity is in its hurt flash (hurtTime > 0), its body is tinted.
 * Colour comes from the theme accent or from a custom hue; saturation and opacity are set here.
 * The draw itself is done by mixin.HitColorRendererMixin, which reads argbFor() each frame.
 * Armor: setting exists, but the armor layer is not hooked yet, so it has no effect for now.
 */
public class HitColorModule extends Module {
    private static volatile HitColorModule instance;

    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));
    public final NumberSetting hue = add(new NumberSetting("Hue", 0, 0, 360, 5));
    public final NumberSetting saturation = add(new NumberSetting("Saturation", 100, 0, 100, 5));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 60, 0, 100, 5));
    public final BoolSetting body = add(new BoolSetting("Body", true));
    public final BoolSetting armor = add(new BoolSetting("Armor", true));

    public HitColorModule() {
        super("Hit Color", Category.VISUALS);
        instance = this;
    }

    /** ARGB tint for this entity this frame, or -1 when it is not in its hit flash. Called on the render thread. */
    public static int argbFor(Entity e) {
        HitColorModule m = instance;
        if (m == null || !m.isEnabled() || !m.body.get()) return -1;
        if (!(e instanceof LivingEntity le) || !le.isAlive() || le.hurtTime <= 0) return -1;

        int rgb = m.themeColor.get()
                ? m.theme()
                : hsvToRgb(m.hue.get(), m.saturation.get() / 100.0, 1.0);
        int a = (int) Math.round(m.opacity.get() * 2.55);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private int theme() { return Theme.current().accent() & 0xFFFFFF; }

    static int hsvToRgb(double h, double s, double v) {
        double c = v * s;
        double hp = (h % 360) / 60.0;
        double x = c * (1 - Math.abs(hp % 2 - 1));
        double r = 0, g = 0, b = 0;
        if (hp < 1) { r = c; g = x; }
        else if (hp < 2) { r = x; g = c; }
        else if (hp < 3) { g = c; b = x; }
        else if (hp < 4) { g = x; b = c; }
        else if (hp < 5) { r = x; b = c; }
        else { r = c; b = x; }
        double m = v - c;
        int ri = (int) Math.round((r + m) * 255), gi = (int) Math.round((g + m) * 255), bi = (int) Math.round((b + m) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }
}
