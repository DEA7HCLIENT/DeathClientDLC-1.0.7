package dev.deathclient.dlc;

/** Carried by LivingEntityRenderState (added by mixin.HitColorRenderStateMixin): ARGB hit tint for this frame, or -1 when off. */
public interface HitColorState {
    void deathclientdlc$setHit(int argb);

    int deathclientdlc$getHit();
}
