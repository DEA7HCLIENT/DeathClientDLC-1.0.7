package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ChamsState;
import dev.deathclient.dlc.HitColorModule;
import dev.deathclient.dlc.HitColorState;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hit Color: tags the render state in updateRenderState, then tints the body. Chams keeps priority. require = 0 like the other renderer hooks. */
@Mixin(LivingEntityRenderer.class)
public abstract class HitColorRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"), require = 0)
    private void deathclientdlc$hitTag(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (state instanceof HitColorState hs) hs.deathclientdlc$setHit(HitColorModule.argbFor(entity));
    }

    @Inject(method = "getMixColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void deathclientdlc$hitTint(LivingEntityRenderState state, CallbackInfoReturnable<Integer> cir) {
        if (!(state instanceof HitColorState hs) || hs.deathclientdlc$getHit() == -1) return;
        if (state instanceof ChamsState cs && cs.deathclientdlc$getChams() != -1) return;
        cir.setReturnValue(hs.deathclientdlc$getHit());
    }
}
