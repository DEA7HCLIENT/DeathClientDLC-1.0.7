package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.HitColorState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(LivingEntityRenderState.class)
public abstract class HitColorRenderStateMixin implements HitColorState {
    @Unique private int deathclientdlc$hit = -1;

    @Override public void deathclientdlc$setHit(int argb) { this.deathclientdlc$hit = argb; }

    @Override public int deathclientdlc$getHit() { return this.deathclientdlc$hit; }
}
