package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.tag.ItemTags;

/**
 * Auto Block: holds right-click for you whenever an enemy is close and you're holding a sword, the way 1.8
 * players held right-click by hand. What that actually does is entirely up to the server: vanilla 1.8 itself
 * does nothing with it, a server plugin that adds sword-blocking will react to it, and on a modern server it
 * behaves like a shield if the sword's right-click action is set to block. It does nothing on its own.
 */
public class AutoBlockModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 4, 1, 10, 0.5));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public AutoBlockModule() { super("Auto Block", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.currentScreen != null) return;
        if (!p.getMainHandStack().isIn(ItemTags.SWORDS)) { p.stopUsingItem(); return; }

        boolean near = false;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof net.minecraft.entity.player.PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (p.distanceTo(le) <= range.get()) { near = true; break; }
        }
        if (near) {
            if (!p.isUsingItem()) p.setCurrentHand(net.minecraft.util.Hand.MAIN_HAND);
        } else {
            p.stopUsingItem();
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.stopUsingItem();
    }
}
