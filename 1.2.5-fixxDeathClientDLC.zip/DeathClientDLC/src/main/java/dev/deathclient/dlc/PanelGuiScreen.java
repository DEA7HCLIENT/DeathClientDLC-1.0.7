package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI style "Panels": every category is its own window with a header, side by side; drag a header to move it.
 * LMB module: toggle. RMB module: unfold its settings. MMB module: bind. RMB header: fold the panel.
 * The last panel lists the colour themes.
 */
public class PanelGuiScreen extends Screen {
    private static final int PW = 112, HEAD = 16, ROW = 14, SET = 13, PAD = 5;
    private static final int BG = 0xE0101016, HEAD_BG = 0xF01A1A24, ROW_HOVER = 0x22FFFFFF;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF8C8C99, SOFT = 0xFFC4C4CE;

    /** One panel; position and fold state are kept between openings. */
    private static final class Panel {
        final String title;
        final Category cat;                 // null = themes panel
        int x, y;
        boolean folded;
        Panel(String title, Category cat) { this.title = title; this.cat = cat; }
    }

    private static final List<Panel> PANELS = new ArrayList<>();
    private static boolean placed;

    /** Themes panel: at most this many rows are shown, the rest scrolls (mouse wheel). */
    private static final int THEME_ROWS = 12;
    private static double themeScroll;

    private Panel dragPanel;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;
    private int dragX, dragW;               // slider track while dragging

    public PanelGuiScreen() { super(Text.literal("Death Client")); }

    @Override
    protected void init() {
        if (PANELS.isEmpty()) {
            for (Category c : Category.values()) if (!ModuleManager.of(c).isEmpty()) PANELS.add(new Panel(c.label, c));
            PANELS.add(new Panel("Themes", null));
        }
        if (!placed) {
            int total = PANELS.size() * (PW + 6) - 6;
            int x = Math.max(4, (width - total) / 2);
            for (Panel p : PANELS) { p.x = x; p.y = 20; x += PW + 6; }
            placed = true;
        }
        for (Panel p : PANELS) {
            p.x = Math.max(0, Math.min(p.x, Math.max(0, width - PW)));
            p.y = Math.max(0, Math.min(p.y, Math.max(0, height - HEAD)));
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (client != null && GuiStyleModule.style() != GuiStyleModule.PANELS) client.setScreen(GuiStyleModule.create());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) Ui.drawWorldDim(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
        GuiImage.draw(ctx, width, height);                       // GUI Image module: picture in the bottom-right corner
    }

    // Dropping a png / jpg on the open ClickGUI sets the GUI Image (the method name differs between mappings).
    public void filesDragged(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    public void onFilesDropped(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    // ------------------------------------------------------------------ layout

    /** How many theme rows fit: up to THEME_ROWS, fewer on a small screen. */
    private int themeRows() {
        return Math.min(Math.min(THEME_ROWS, Theme.values().length), Math.max(4, (height - HEAD - 30) / ROW));
    }

    private double themeMaxScroll() { return Math.max(0, (Theme.values().length - themeRows()) * ROW); }

    private static boolean unfolded(Module m) { return m.expanded && !m.getSettings().isEmpty(); }

    private int bodyHeight(Panel p) {
        if (p.folded) return 0;
        if (p.cat == null) return themeRows() * ROW + 3;
        int h = 3;
        for (Module m : ModuleManager.of(p.cat)) {
            h += ROW;
            if (unfolded(m)) h += m.getSettings().size() * SET + 2;
        }
        return h;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Theme theme = Theme.current();
        int acc = theme.accent();
        // Glass Menu: translucent tinted panels with a bright rim and a light band under the header.
        GlassMenuModule gm = ModuleManager.get(GlassMenuModule.class);
        boolean glass = gm != null && gm.isEnabled();
        int glassBody = 0, glassHead = 0;
        if (glass) {
            int a = (int) (gm.opacity.get() * 2.55);
            int tint = ClickGuiScreen.mix(0xFF0B0D14, acc, (float) (gm.tint.get() / 100.0) * 0.5f) & 0xFFFFFF;
            glassBody = (a << 24) | tint;
            glassHead = (Math.min(255, a + 40) << 24) | (ClickGuiScreen.mix(0xFF000000 | tint, WHITE, 0.10f) & 0xFFFFFF);
        }
        for (Panel p : PANELS) {
            int h = HEAD + bodyHeight(p);
            if (glass) {
                ClickGuiScreen.rrect(ctx, p.x, p.y, PW, h, glassBody, 4);
                ClickGuiScreen.rrect(ctx, p.x, p.y, PW, HEAD, glassHead, 4);
                if (gm.shine.get() && h > HEAD + 2) {
                    ctx.fillGradient(p.x + 1, p.y + HEAD, p.x + PW - 1, p.y + HEAD + Math.min(h - HEAD - 1, 36), 0x24FFFFFF, 0x00FFFFFF);
                }
                if (gm.border.get()) ClickGuiScreen.outline(ctx, p.x, p.y, PW, h, 0x70FFFFFF, 4);
            } else {
                ClickGuiScreen.rrect(ctx, p.x - 1, p.y - 1, PW + 2, h + 2, 0x33FFFFFF, 5);
                ClickGuiScreen.rrect(ctx, p.x, p.y, PW, h, BG, 4);
                ClickGuiScreen.rrect(ctx, p.x, p.y, PW, HEAD, HEAD_BG, 4);
            }
            stripe(ctx, theme, p.x, p.y + HEAD - 1, PW);
            text(ctx, p.title, p.x + PAD + 1, p.y + 4, WHITE);
            text(ctx, p.folded ? "+" : "-", p.x + PW - 11, p.y + 4, MUTED);
            if (p.folded) continue;

            int y = p.y + HEAD + 2;
            if (p.cat == null) {
                themeScroll = Math.max(0, Math.min(themeScroll, themeMaxScroll()));
                int listH = themeRows() * ROW;
                ctx.enableScissor(p.x, y, p.x + PW, y + listH);
                int ty = y - (int) themeScroll;
                for (Theme t : Theme.values()) {
                    if (ty + ROW > y && ty < y + listH) {
                        boolean hover = ClickGuiScreen.in(mx, my, p.x + 2, Math.max(ty, y), PW - 6, ROW) && my >= y && my < y + listH;
                        boolean active = t == theme;
                        if (hover) ctx.fill(p.x + 2, ty, p.x + PW - 4, ty + ROW, ROW_HOVER);
                        int sx = p.x + PAD, sw = 14;
                        for (int i = 0; i < sw; i++) ctx.fill(sx + i, ty + 3, sx + i + 1, ty + ROW - 3, 0xFF000000 | (t.at(i / (float) (sw - 1)) & 0xFFFFFF));
                        text(ctx, t.label, p.x + PAD + 19, ty + 3, active ? WHITE : SOFT);
                        if (active) ctx.fill(p.x + 2, ty + 2, p.x + 4, ty + ROW - 2, 0xFF000000 | acc);
                    }
                    ty += ROW;
                }
                ctx.disableScissor();
                double max = themeMaxScroll();
                if (max > 0) {                                           // scroll bar on the right edge
                    int total = Theme.values().length * ROW;
                    int barH = Math.max(10, (int) (listH * (double) listH / total));
                    int barY = y + (int) ((listH - barH) * (themeScroll / max));
                    ctx.fill(p.x + PW - 3, y, p.x + PW - 2, y + listH, 0x22FFFFFF);
                    ctx.fill(p.x + PW - 3, barY, p.x + PW - 2, barY + barH, 0xFF000000 | acc);
                }
                continue;
            }
            for (Module m : ModuleManager.of(p.cat)) {
                boolean on = m.isEnabled();
                boolean hover = ClickGuiScreen.in(mx, my, p.x + 2, y, PW - 4, ROW);
                if (on) ctx.fill(p.x + 2, y, p.x + PW - 2, y + ROW, 0x30000000 | (acc & 0xFFFFFF));
                else if (hover) ctx.fill(p.x + 2, y, p.x + PW - 2, y + ROW, ROW_HOVER);
                if (on) ctx.fill(p.x + 2, y + 1, p.x + 4, y + ROW - 1, 0xFF000000 | acc);
                text(ctx, m.getName(), p.x + PAD + 2, y + 3, on ? WHITE : SOFT);
                String tag = Binds.listening() == m ? "..." : m.getKey() != -1 ? "[" + Binds.name(m.getKey()) + "]" : (m.getSettings().isEmpty() ? "" : (m.expanded ? "v" : ">"));
                if (!tag.isEmpty()) text(ctx, tag, p.x + PW - 5 - textRenderer.getWidth(tag), y + 3, MUTED);
                y += ROW;
                if (unfolded(m)) {
                    for (Setting s : m.getSettings()) {
                        drawSetting(ctx, s, p.x + 4, y, PW - 8, mx, my, acc);
                        y += SET;
                    }
                    y += 2;
                }
            }
        }
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y, int w, int mx, int my, int acc) {
        if (ClickGuiScreen.in(mx, my, x, y, w, SET)) ctx.fill(x, y, x + w, y + SET, 0x14FFFFFF);
        if (s instanceof BoolSetting b) {
            text(ctx, b.name, x + 3, y + 2, SOFT);
            int bx = x + w - 11;
            ClickGuiScreen.rrect(ctx, bx, y + 2, 8, 8, b.get() ? 0xFF000000 | acc : 0xFF2C2C38, 2);
        } else if (s instanceof NumberSetting n) {
            double t = (n.get() - n.min) / (n.max - n.min);
            ctx.fill(x, y, x + (int) (w * t), y + SET, 0x30000000 | (acc & 0xFFFFFF));
            String v = n.label() != null ? n.label() : String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
            text(ctx, n.name, x + 3, y + 2, SOFT);
            text(ctx, v, x + w - 3 - textRenderer.getWidth(v), y + 2, MUTED);
        }
    }

    private static void stripe(DrawContext ctx, Theme t, int x, int y, int w) {
        if (!t.gradient()) { ctx.fill(x, y, x + w, y + 1, 0xFF000000 | t.accent()); return; }
        for (int i = 0; i < w; i += 2) ctx.fill(x + i, y, Math.min(x + w, x + i + 2), y + 1, 0xFF000000 | (t.at((i + 1f) / w) & 0xFFFFFF));
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        // The topmost panel is the last one drawn; test from the end.
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            int h = HEAD + bodyHeight(p);
            if (!ClickGuiScreen.in(mx, my, p.x, p.y, PW, h)) continue;
            PANELS.remove(i);                                  // bring to front
            PANELS.add(p);
            if (my < p.y + HEAD) {
                if (btn == 0) { dragPanel = p; dragDX = mx - p.x; dragDY = my - p.y; }
                else if (btn == 1) p.folded = !p.folded;
                return true;
            }
            clickBody(p, mx, my, btn);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private void clickBody(Panel p, double mx, double my, int btn) {
        int y = p.y + HEAD + 2;
        if (p.cat == null) {
            int listH = themeRows() * ROW;
            if (btn != 0 || my < y || my >= y + listH) return;
            int idx = (int) ((my - y + themeScroll) / ROW);
            Theme[] all = Theme.values();
            if (mx < p.x + PW - 4 && idx >= 0 && idx < all.length) Theme.set(all[idx]);
            return;
        }
        for (Module m : ModuleManager.of(p.cat)) {
            if (ClickGuiScreen.in(mx, my, p.x + 2, y, PW - 4, ROW)) {
                if (btn == 0) m.toggle();
                else if (btn == 1) { if (!m.getSettings().isEmpty()) m.expanded = !m.expanded; }
                else if (btn == 2) Binds.listen(m);
                return;
            }
            y += ROW;
            if (unfolded(m)) {
                for (Setting s : m.getSettings()) {
                    if (btn == 0 && ClickGuiScreen.in(mx, my, p.x + 4, y, PW - 8, SET)) {
                        if (s instanceof BoolSetting b) b.toggle();
                        else if (s instanceof NumberSetting n) { dragSetting = n; dragX = p.x + 4; dragW = PW - 8; slide(mx); }
                        return;
                    }
                    y += SET;
                }
                y += 2;
            }
        }
    }

    private void slide(double mx) {
        double t = Math.max(0, Math.min(1, (mx - dragX) / dragW));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragPanel != null) {
            dragPanel.x = Math.max(0, Math.min((int) (click.x() - dragDX), Math.max(0, width - PW)));
            dragPanel.y = Math.max(0, Math.min((int) (click.y() - dragDY), Math.max(0, height - HEAD)));
            return true;
        }
        if (dragSetting != null) { slide(click.x()); return true; }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragPanel = null;
        dragSetting = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (Panel p : PANELS) {
            if (p.cat != null || p.folded) continue;
            if (ClickGuiScreen.in(mouseX, mouseY, p.x, p.y, PW, HEAD + bodyHeight(p))) {
                themeScroll = Math.max(0, Math.min(themeScroll - verticalAmount * ROW * 2, themeMaxScroll()));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() { return false; }
}
