package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

/**
 * Target HUD: a small card with the player you are aiming at (name, health bar, health and distance, and the
 * head). It takes the target from the crosshair. When the crosshair leaves the target, the card keeps showing
 * the last one for "Hold" seconds, so you can read it after a fight. It is draggable with the rest of the HUD
 * (open the chat to move it).
 */
public class TargetHudModule extends Module {
    private static final int W = 128, H = 38, PAD = 6;
    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;

    public final NumberSetting posX = add(new NumberSetting("X", 0, -1000, 1000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 120, 0, 1200, 1));
    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.05));
    public final NumberSetting hold = add(new NumberSetting("Hold", 2.0, 0.0, 10.0, 0.5));
    public final BoolSetting showHead = add(new BoolSetting("Head", true));
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", false));

    private LivingEntity target;
    private long lastSeen;
    /** Health bar animates toward the real value. */
    private float shownHp = -1;

    public TargetHudModule() { super("Target HUD", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null || c.world == null) return;
        if (c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le
                && le != c.player && le.isAlive() && (!playersOnly.get() || le instanceof PlayerEntity)) {
            if (le != target) shownHp = -1;
            target = le;
            lastSeen = System.currentTimeMillis();
        }
        if (target != null && (!target.isAlive() || target.isRemoved()
                || System.currentTimeMillis() - lastSeen > hold.get() * 1000)) {
            target = null;
            shownHp = -1;
        }
    }

    @Override
    protected void onDisable() { target = null; shownHp = -1; }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetHudModule m = ModuleManager.get(TargetHudModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || m.target == null || c.player == null) return;
        if (Hud.hidden || c.options.hudHidden) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        LivingEntity t = target;
        float s = (float) scale.get();
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int x = (int) (sw / 2.0 + posX.get());
        int y = (int) posY.get();
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(s, s);

        // card
        ClickGuiScreen.rect(ctx, 0, 0, W, H, BG, true, true);
        int accent = Theme.current().accent();
        ClickGuiScreen.rect(ctx, 0, H - 2, W, 2, accent, false, true);

        int left = PAD;
        if (showHead.get() && t instanceof PlayerEntity) {
            drawBadge(ctx, c, t.getName().getString(), left, PAD);
            left += 26;
        }
        var tr = c.textRenderer;
        String name = t.getName().getString();
        if (name.length() > 14) name = name.substring(0, 13) + "…";
        Fonts.draw(ctx, tr, name, left, PAD, WHITE);

        float max = Math.max(1f, t.getMaxHealth());
        float real = MathHelper.clamp(t.getHealth() + t.getAbsorptionAmount(), 0, max + t.getAbsorptionAmount());
        shownHp = shownHp < 0 ? real : shownHp + (real - shownHp) * 0.25f;
        int barX = left, barY = PAD + 14, barW = W - barX - PAD, barH = 4;
        ctx.fill(barX, barY, barX + barW, barY + barH, 0xFF303030);
        float frac = MathHelper.clamp(shownHp / max, 0f, 1f);
        ctx.fill(barX, barY, barX + Math.round(barW * frac), barY + barH, hpColor(frac));

        String hp = String.format("%.1f", t.getHealth());
        String line2 = showDistance.get()
                ? hp + "   " + String.format("%.1f", t.distanceTo(c.player)) + "m"
                : hp;
        Fonts.draw(ctx, tr, line2, barX, PAD + 22, MUTED);

        m.popMatrix();

        // drag it with the HUD editor, like the other HUD cards
        int bx = x, by = y;
        int bw = (int) (W * s), bh = (int) (H * s);
        HudEdit.track(bx, by, bw, bh, (nx, ny) -> {
            posX.set(nx - sw / 2.0);
            posY.set(ny);
        });
    }

    /** A 20x20 badge with the first letter of the name, coloured from the name. */
    private static void drawBadge(DrawContext ctx, MinecraftClient c, String name, int x, int y) {
        int hue = (name.hashCode() & 0x7FFFFFFF) % 360;
        int rgb = java.awt.Color.HSBtoRGB(hue / 360f, 0.55f, 0.85f) & 0xFFFFFF;
        ctx.fill(x, y, x + 20, y + 20, 0xFF000000 | rgb);
        ctx.fill(x, y, x + 20, y + 1, 0x60FFFFFF);
        String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        ctx.drawCenteredTextWithShadow(c.textRenderer, letter, x + 10, y + 6, 0xFFFFFFFF);
    }

    /** Green when healthy, through yellow to red when low. */
    private static int hpColor(float frac) {
        int r = frac > 0.5f ? (int) (255 * (1 - frac) * 2) : 255;
        int g = frac > 0.5f ? 255 : (int) (255 * frac * 2);
        return 0xFF000000 | (r << 16) | (g << 8) | 0x30;
    }
}
