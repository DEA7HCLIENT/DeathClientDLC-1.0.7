package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Target filter shared by the block / crystal auras. Three groups can be turned on or off:
 * Players (other players), Mobs (hostile and neutral mobs, e.g. zombies, creepers), and Entities (everything else
 * alive: animals, villagers, armor stands, golems and so on). Friends are never targeted.
 */
final class AuraTargets {
    private AuraTargets() {}

    /** Nearest living entity within range that passes the group filters, or null. */
    static LivingEntity nearest(MinecraftClient c, ClientPlayerEntity p, double range,
                                boolean players, boolean mobs, boolean entities) {
        LivingEntity best = null;
        double bestD = range;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (!allowed(le, players, mobs, entities) || Friends.skip(le)) continue;
            double d = p.distanceTo(le);
            if (d <= bestD) { bestD = d; best = le; }
        }
        return best;
    }

    static boolean allowed(LivingEntity le, boolean players, boolean mobs, boolean entities) {
        if (le instanceof PlayerEntity) return players;
        if (le instanceof PassiveEntity) return entities;      // animals, villagers
        if (le instanceof MobEntity) return mobs;              // hostile and neutral mobs
        return entities;                                        // armor stands and other living entities
    }
}
