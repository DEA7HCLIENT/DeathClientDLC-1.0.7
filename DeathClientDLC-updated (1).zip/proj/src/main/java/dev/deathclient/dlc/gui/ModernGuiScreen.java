package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/**
 * The "Modern" ClickGUI style, ported from the second client's ModernClickGui: a dark window with a side nav (categories, Configs,
 * Themes, Keybinds), cards in two columns and a settings panel that opens next to the cards. Modern draws it with its
 * own GPU rounded-rect shaders; here it is drawn with the same primitives as the other GUI styles.
 * <p>
 * LMB card: toggle. RMB card or "...": settings panel. MMB card: bind. Drag the top strip to move the window.
 */
public class ModernGuiScreen extends Screen {
    private static final int SW = 132, HEAD = 40, GAP = 8, CARD_H = 44, PW = 214, ROW = 22, SLIDER = 32;
    // Colours of the the second client window.
    private static final int WIN = 0xFF080D16, SIDE = 0xFF0A111C, BORDER = 0xFF1E2D43, SEP = 0xFF17243A,
            TOG_OFF = 0xFF36506D, KNOB = 0xFFF5FAFF, DIM = 0xFF8394AA, ACC_TXT = 0xFF79B4FF,
            CARD_OFF = 0xFF0D1522, CARD_LINE = 0xFF263B57, WHITE = 0xFFFFFFFF, PANEL = 0xFF090E18;

    private enum Tab { MODULES, CONFIGS, THEMES, KEYBINDS }

    private static int winX, winY;
    private static boolean placed;
    private static Tab tab = Tab.MODULES;
    private static Category cat = Category.COMBAT;

    private int W = 600, H = 420;
    private final List<Category> cats = new ArrayList<>();
    private List<String> cfgs = List.of();
    private double scroll, maxScroll, panelScroll, panelMax;
    private Module panel;
    private boolean draggingWin;
    private double dragDX, dragDY;
    private NumberSetting dragNum;
    private int dragTrackX, dragTrackW;

    private interface Act { void on(int button, double mx); }
    private record Hit(int x, int y, int w, int h, int clipT, int clipB, Act act) {}
    private final List<Hit> hits = new ArrayList<>();
    /** Index of the first hit that belongs to the settings panel (it sits on top of the cards). */
    private int panelHitStart;

    public ModernGuiScreen() { super(Text.literal("Death Client")); }

    @Override
    protected void init() {
        cats.clear();
        for (Category c : Category.values()) if (!ModuleManager.of(c).isEmpty()) cats.add(c);
        if (!cats.contains(cat) && !cats.isEmpty()) cat = cats.get(0);
        W = Math.max(420, Math.min(600, width - 24));
        H = Math.max(300, Math.min(420, height - 24));
        if (!placed) { winX = (width - W) / 2; winY = (height - H) / 2; placed = true; }
        winX = Math.max(0, Math.min(winX, Math.max(0, width - W)));
        winY = Math.max(0, Math.min(winY, Math.max(0, height - H)));
        cfgs = Config.list();
    }

    // ------------------------------------------------------------------ drawing helpers

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private static void rr(DrawContext c, int x, int y, int w, int h, int color, int r) { ClickGuiScreen.rrect(c, x, y, w, h, color, r); }

    private static int acc() { return Theme.current().accent() | 0xFF000000; }

    /** Rounded rect in the theme colour; gradient themes run left to right over the whole window. */
    private void accRect(DrawContext c, int x, int y, int w, int h, int r, int alpha) {
        Theme t = Theme.current();
        int a = alpha << 24;
        if (!t.gradient()) { rr(c, x, y, w, h, a | (t.accent() & 0xFFFFFF), r); return; }
        rr(c, x, y, w, h, a | (t.at((x - winX + w / 2f) / W) & 0xFFFFFF), r);
        for (int i = r; i < w - r; i += 2) {
            c.fill(x + i, y, Math.min(x + i + 2, x + w - r), y + h, a | (t.at((x - winX + i) / (float) W) & 0xFFFFFF));
        }
    }

    private void text(DrawContext c, String s, int x, int y, int color) { Fonts.draw(c, textRenderer, s, x, y, color); }

    private int tw(String s) { return Fonts.width(textRenderer, s); }

    private void sw(DrawContext c, int x, int y, boolean on) {
        rr(c, x, y, 26, 14, on ? acc() : TOG_OFF, 7);
        rr(c, on ? x + 14 : x + 2, y + 2, 10, 10, KNOB, 5);
    }

    private void hit(int x, int y, int w, int h, int ct, int cb, Act a) { hits.add(new Hit(x, y, w, h, ct, cb, a)); }

    // ------------------------------------------------------------------ frame

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) Ui.drawWorldDim(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        hits.clear();
        rr(ctx, winX - 1, winY - 1, W + 2, H + 2, BORDER, 9);
        rr(ctx, winX, winY, W, H, WIN, 8);
        rr(ctx, winX, winY, SW, H, SIDE, 8);
        ctx.fill(winX + SW - 8, winY, winX + SW, winY + H, SIDE);
        ctx.fill(winX + SW, winY + 8, winX + SW + 1, winY + H - 8, SEP);
        accRect(ctx, winX + 10, winY, W - 20, 2, 1, 0xFF);

        drawNav(ctx, mx, my);
        int bx = winX + SW + 12, bw = W - SW - 24, top = winY + HEAD, bottom = winY + H - 10;
        String title = tab == Tab.MODULES ? cat.label : switch (tab) { case CONFIGS -> "Configs"; case THEMES -> "Themes"; default -> "Keybinds"; };
        text(ctx, title, bx, winY + 14, WHITE);
        ctx.fill(bx, winY + HEAD - 6, bx + bw, winY + HEAD - 5, SEP);

        ctx.enableScissor(bx - 2, top, bx + bw + 2, bottom);
        int contentH = switch (tab) {
            case MODULES -> drawModules(ctx, mx, my, bx, top, bw, bottom);
            case CONFIGS -> drawConfigs(ctx, mx, my, bx, top, bw, bottom);
            case THEMES -> drawThemes(ctx, mx, my, bx, top, bw, bottom);
            case KEYBINDS -> drawKeybinds(ctx, mx, my, bx, top, bw, bottom);
        };
        ctx.disableScissor();
        maxScroll = Math.max(0, contentH - (bottom - top));
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        panelHitStart = hits.size();
        if (panel != null && tab == Tab.MODULES) drawPanel(ctx, mx, my);
    }

    private void drawNav(DrawContext ctx, int mx, int my) {
        Ui.drawLogo(ctx, winX + 10, winY + 8, 22, acc());                 // same logo as the other GUI styles
        text(ctx, "Death Client", winX + 36, winY + 16, WHITE);
        int y = winY + 44;
        for (Category c : cats) { nav(ctx, mx, my, y, c.label, tab == Tab.MODULES && cat == c, () -> { tab = Tab.MODULES; cat = c; reset(); }); y += 28; }
        y += 10;
        nav(ctx, mx, my, y, "Configs", tab == Tab.CONFIGS, () -> { tab = Tab.CONFIGS; cfgs = Config.list(); reset(); }); y += 28;
        nav(ctx, mx, my, y, "Themes", tab == Tab.THEMES, () -> { tab = Tab.THEMES; reset(); }); y += 28;
        nav(ctx, mx, my, y, "Keybinds", tab == Tab.KEYBINDS, () -> { tab = Tab.KEYBINDS; reset(); });
        text(ctx, "Theme: " + Theme.current().label, winX + 12, winY + H - 16, DIM);
    }

    private void nav(DrawContext ctx, int mx, int my, int y, String label, boolean active, Runnable go) {
        int x = winX + 8, w = SW - 16;
        boolean hov = in(mx, my, x, y, w, 24);
        if (active) accRect(ctx, x, y, w, 24, 6, 0xFF);
        else if (hov) rr(ctx, x, y, w, 24, ClickGuiScreen.mix(SIDE, acc(), 0.14f), 6);
        text(ctx, label, x + 12, y + 8, active ? WHITE : (hov ? WHITE : DIM));
        hit(x, y, w, 24, 0, height, (b, m) -> go.run());
    }

    private void reset() { scroll = 0; panel = null; panelScroll = 0; }

    // ------------------------------------------------------------------ modules

    private int drawModules(DrawContext ctx, int mx, int my, int bx, int top, int bw, int bottom) {
        List<Module> list = ModuleManager.of(cat);
        int cw = (bw - GAP) / 2;
        int y0 = top + 4 - (int) scroll;
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int x = bx + (i % 2) * (cw + GAP), y = y0 + (i / 2) * (CARD_H + GAP);
            if (y + CARD_H < top || y > bottom) continue;
            boolean hov = in(mx, my, x, y, cw, CARD_H) && my >= top && my < bottom && !overPanel(mx, my);
            boolean on = m.isEnabled();
            rr(ctx, x, y, cw, CARD_H, on ? ClickGuiScreen.mix(CARD_LINE, acc(), 0.7f) : CARD_LINE, 7);
            rr(ctx, x + 1, y + 1, cw - 2, CARD_H - 2, on ? ClickGuiScreen.mix(CARD_OFF, acc(), hov ? 0.26f : 0.18f) : (hov ? 0xFF111C2D : CARD_OFF), 6);
            text(ctx, m.getName(), x + 12, y + 10, m.isImplemented() ? WHITE : DIM);
            text(ctx, m.getKey() == -1 ? "no bind" : "[" + Binds.name(m.getKey()) + "]", x + 12, y + 25, on ? ACC_TXT : DIM);
            sw(ctx, x + cw - 38, y + 15, on);
            final Module mod = m;
            if (!m.getSettings().isEmpty()) {
                text(ctx, "...", x + cw - 58, y + 13, panel == m ? ACC_TXT : DIM);
                hit(x + cw - 64, y, 22, CARD_H, top, bottom, (b, c) -> { if (b == 0) openPanel(mod); });
            }
            hit(x, y, cw, CARD_H, top, bottom, (b, c) -> {
                if (b == 0) mod.toggle();
                else if (b == 1) openPanel(mod);
                else if (b == 2) Binds.listen(mod);
            });
        }
        return (list.size() + 1) / 2 * (CARD_H + GAP) + 8;
    }

    private void openPanel(Module m) { panel = panel == m ? null : m; panelScroll = 0; }

    private int panelX() { return winX + W - PW - 12; }

    private int panelY() { return winY + HEAD + 2; }

    private int panelH() { return Math.min(H - HEAD - 14, (int) Math.min(panelMax + 34, H)); }

    private boolean overPanel(double mx, double my) {
        return panel != null && tab == Tab.MODULES && in(mx, my, panelX(), panelY(), PW, panelH());
    }

    private void drawPanel(DrawContext ctx, int mx, int my) {
        int x = panelX(), y = panelY(), h = Math.max(60, panelH());
        rr(ctx, x - 1, y - 1, PW + 2, h + 2, CARD_LINE, 8);
        rr(ctx, x, y, PW, h, PANEL, 7);
        accRect(ctx, x + 8, y, PW - 16, 2, 1, 0xFF);
        text(ctx, panel.getName(), x + 12, y + 10, WHITE);
        text(ctx, "x", x + PW - 16, y + 10, DIM);
        hit(x + PW - 24, y, 24, 26, 0, height, (b, m) -> panel = null);
        ctx.fill(x + 10, y + 26, x + PW - 10, y + 27, SEP);

        int ct = y + 28, cb = y + h - 4;
        ctx.enableScissor(x, ct, x + PW, cb);
        int ry = ct + 4 - (int) panelScroll;
        for (Setting s : panel.getSettings()) {
            if (s instanceof BoolSetting b) {
                text(ctx, b.name, x + 12, ry + 7, WHITE);
                sw(ctx, x + PW - 38, ry + 4, b.get());
                hit(x, ry, PW, ROW, ct, cb, (bt, m) -> b.toggle());
                ry += ROW;
            } else if (s instanceof NumberSetting n) {
                String lab = n.label();
                if (lab != null) {                                           // mode selector: click the left half back, the right half forward
                    text(ctx, n.name, x + 12, ry + 7, DIM);
                    String v = "< " + lab + " >";
                    text(ctx, v, x + PW - 12 - tw(v), ry + 7, ACC_TXT);
                    hit(x, ry, PW, ROW, ct, cb, (bt, m) -> {
                        boolean back = m < x + PW / 2.0 || bt == 1;
                        double v2 = n.get() + (back ? -n.step : n.step);
                        n.set(v2 > n.max ? n.min : v2 < n.min ? n.max : v2);
                    });
                    ry += ROW;
                } else {
                    String v = n.step >= 1 ? String.valueOf((int) Math.round(n.get())) : String.format(java.util.Locale.ROOT, "%.2f", n.get());
                    text(ctx, n.name, x + 12, ry + 4, WHITE);
                    text(ctx, v, x + PW - 12 - tw(v), ry + 4, ACC_TXT);
                    int tx = x + 12, tw = PW - 24, ty = ry + 20;
                    float f = (float) ((n.get() - n.min) / (n.max - n.min));
                    rr(ctx, tx, ty, tw, 4, TOG_OFF, 2);
                    accRect(ctx, tx, ty, Math.max(4, (int) (tw * f)), 4, 2, 0xFF);
                    rr(ctx, tx + (int) ((tw - 8) * f), ty - 2, 8, 8, KNOB, 4);
                    hit(x, ry + 12, PW, 18, ct, cb, (bt, m) -> { dragNum = n; dragTrackX = tx; dragTrackW = tw; slide(m); });
                    ry += SLIDER;
                }
            } else if (s instanceof ButtonSetting bs) {
                rr(ctx, x + 10, ry + 2, PW - 20, ROW - 4, in(mx, my, x + 10, ry + 2, PW - 20, ROW - 4) ? 0xFF16233A : CARD_OFF, 5);
                text(ctx, bs.name, x + PW / 2 - tw(bs.name) / 2, ry + 7, WHITE);
                hit(x + 10, ry + 2, PW - 20, ROW - 4, ct, cb, (bt, m) -> bs.run());
                ry += ROW;
            }
        }
        String bind = Binds.listening() == panel ? "press a key..." : (panel.getKey() == -1 ? "none" : "[" + Binds.name(panel.getKey()) + "]");
        text(ctx, "Bind", x + 12, ry + 7, DIM);
        text(ctx, bind, x + PW - 12 - tw(bind), ry + 7, ACC_TXT);
        final Module pm = panel;
        hit(x, ry, PW, ROW, ct, cb, (bt, m) -> { if (bt == 0) Binds.listen(pm); else { pm.setKey(-1); Binds.save(); } });
        ry += ROW;
        ctx.disableScissor();
        panelMax = ry + panelScroll - ct + 4;
        panelScroll = Math.max(0, Math.min(panelScroll, Math.max(0, panelMax - (cb - ct))));
    }

    private void slide(double mx) {
        if (dragNum == null) return;
        double f = Math.max(0, Math.min(1, (mx - dragTrackX) / dragTrackW));
        dragNum.set(dragNum.min + f * (dragNum.max - dragNum.min));
    }

    // ------------------------------------------------------------------ configs / themes / keybinds

    private int drawConfigs(DrawContext ctx, int mx, int my, int bx, int top, int bw, int bottom) {
        int base = top + 4 - (int) scroll;
        btn(ctx, mx, my, bx, base, 110, "Save current", top, bottom, () -> { Config.save(Config.currentName()); cfgs = Config.list(); });
        btn(ctx, mx, my, bx + 118, base, 90, "New config", top, bottom, () -> {
            int n = 1;
            while (cfgs.contains("cfg" + n)) n++;
            Config.save("cfg" + n);
            cfgs = Config.list();
        });
        int ry = base + 32;
        for (String name : new ArrayList<>(cfgs)) {
            boolean cur = name.equals(Config.currentName()), hov = in(mx, my, bx, ry, bw, 26) && my >= top && my < bottom;
            rr(ctx, bx, ry, bw, 26, cur ? ClickGuiScreen.mix(CARD_LINE, acc(), 0.7f) : CARD_LINE, 6);
            rr(ctx, bx + 1, ry + 1, bw - 2, 24, cur ? ClickGuiScreen.mix(CARD_OFF, acc(), 0.18f) : (hov ? 0xFF111C2D : CARD_OFF), 5);
            text(ctx, name, bx + 12, ry + 9, WHITE);
            text(ctx, "delete", bx + bw - 12 - tw("delete"), ry + 9, DIM);
            final String n = name;
            hit(bx + bw - 60, ry, 60, 26, top, bottom, (b, m) -> { Config.delete(n); cfgs = Config.list(); });
            hit(bx, ry, bw, 26, top, bottom, (b, m) -> { if (b == 0) Config.load(n); else { Config.delete(n); cfgs = Config.list(); } });
            ry += 30;
        }
        return ry + (int) scroll - top + 4;
    }

    private void btn(DrawContext ctx, int mx, int my, int x, int y, int w, String label, int ct, int cb, Runnable r) {
        rr(ctx, x, y, w, 24, in(mx, my, x, y, w, 24) ? ClickGuiScreen.mix(CARD_OFF, acc(), 0.3f) : CARD_OFF, 6);
        text(ctx, label, x + w / 2 - tw(label) / 2, y + 8, WHITE);
        hit(x, y, w, 24, ct, cb, (b, m) -> r.run());
    }

    private int drawThemes(DrawContext ctx, int mx, int my, int bx, int top, int bw, int bottom) {
        Theme[] all = Theme.values();
        int cols = 3, cw = (bw - GAP * (cols - 1)) / cols, ch = 46;
        int y0 = top + 4 - (int) scroll;
        for (int i = 0; i < all.length; i++) {
            Theme t = all[i];
            int x = bx + (i % cols) * (cw + GAP), y = y0 + (i / cols) * (ch + GAP);
            if (y + ch < top || y > bottom) continue;
            boolean cur = t == Theme.current(), hov = in(mx, my, x, y, cw, ch) && my >= top && my < bottom;
            rr(ctx, x, y, cw, ch, cur ? acc() : CARD_LINE, 7);
            rr(ctx, x + 1, y + 1, cw - 2, ch - 2, hov ? 0xFF111C2D : CARD_OFF, 6);
            int sx = x + 8, sw = cw - 16;                                    // colour strip: the gradient of the theme
            for (int k = 0; k < sw; k += 2) ctx.fill(sx + k, y + 8, Math.min(sx + k + 2, sx + sw), y + 18, 0xFF000000 | (t.at(k / (float) sw) & 0xFFFFFF));
            text(ctx, t.label, x + 8, y + 27, cur ? WHITE : DIM);
            hit(x, y, cw, ch, top, bottom, (b, m) -> Theme.set(t));
        }
        return (all.length + cols - 1) / cols * (ch + GAP) + 8;
    }

    private int drawKeybinds(DrawContext ctx, int mx, int my, int bx, int top, int bw, int bottom) {
        int ry = top + 4 - (int) scroll;
        boolean lm = Binds.listeningMenu();
        String mk = lm ? "press a key..." : "[" + Binds.name(Binds.menuKey()) + "]";
        row(ctx, mx, my, bx, ry, bw, "Menu key", mk, true, top, bottom, (b, m) -> Binds.listenMenu());
        ry += 28;
        for (Module m : ModuleManager.shown()) {
            boolean listening = Binds.listening() == m;
            String k = listening ? "press a key..." : (m.getKey() == -1 ? "none" : "[" + Binds.name(m.getKey()) + "]");
            if (ry + 24 >= top && ry <= bottom) {
                row(ctx, mx, my, bx, ry, bw, m.getName(), k, m.getKey() != -1 || listening, top, bottom, (b, x) -> {
                    if (b == 0) Binds.listen(m);
                    else if (b == 1) { m.setKey(-1); Binds.save(); }
                });
            }
            ry += 28;
        }
        return ry + (int) scroll - top + 4;
    }

    private void row(DrawContext ctx, int mx, int my, int x, int y, int w, String name, String key, boolean bound, int ct, int cb, Act act) {
        boolean hov = in(mx, my, x, y, w, 24) && my >= ct && my < cb;
        rr(ctx, x, y, w, 24, CARD_LINE, 6);
        rr(ctx, x + 1, y + 1, w - 2, 22, hov ? 0xFF111C2D : CARD_OFF, 5);
        text(ctx, name, x + 12, y + 8, WHITE);
        text(ctx, key, x + w - 12 - tw(key), y + 8, bound ? ACC_TXT : DIM);
        hit(x, y, w, 24, ct, cb, act);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (!in(mx, my, winX, winY, W, H)) { panel = null; return super.mouseClicked(click, doubled); }
        boolean onPanel = overPanel(mx, my);
        for (int i = hits.size() - 1; i >= (onPanel ? panelHitStart : 0); i--) {      // the panel is drawn last, so it is hit first
            Hit h = hits.get(i);
            if (!in(mx, my, h.x, h.y, h.w, h.h) || my < h.clipT || my >= h.clipB) continue;
            h.act.on(btn, mx);
            return true;
        }
        if (onPanel) return true;
        if (btn == 0 && my < winY + HEAD - 6) { draggingWin = true; dragDX = mx - winX; dragDY = my - winY; return true; }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragNum != null) { slide(click.x()); return true; }
        if (draggingWin) {
            winX = Math.max(0, Math.min((int) (click.x() - dragDX), Math.max(0, width - W)));
            winY = Math.max(0, Math.min((int) (click.y() - dragDY), Math.max(0, height - H)));
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragNum = null;
        draggingWin = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (overPanel(mouseX, mouseY)) {
            panelScroll = Math.max(0, Math.min(panelScroll - verticalAmount * 14, Math.max(0, panelMax - (panelH() - 32))));
            return true;
        }
        if (in(mouseX, mouseY, winX, winY, W, H)) {
            scroll = Math.max(0, Math.min(scroll - verticalAmount * 14, maxScroll));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void tick() {
        super.tick();
        if (client != null && GuiStyleModule.style() != GuiStyleModule.MODERN) client.setScreen(GuiStyleModule.create());   // style changed in the settings
    }

    @Override
    public boolean shouldPause() { return false; }
}
