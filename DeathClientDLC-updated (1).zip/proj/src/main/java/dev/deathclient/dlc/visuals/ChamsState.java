package dev.deathclient.dlc;

/** Carried by LivingEntityRenderState (added by mixin.ChamsRenderStateMixin): ARGB chams tint for this frame, or -1 when off. */
public interface ChamsState {
    void deathclientdlc$setChams(int argb);

    int deathclientdlc$getChams();

    /** Glow ESP glint tint (ARGB) for this frame, or -1 when off. */
    void deathclientdlc$setGlint(int argb);

    int deathclientdlc$getGlint();
}
