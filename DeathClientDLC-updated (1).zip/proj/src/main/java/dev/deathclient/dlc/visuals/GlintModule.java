package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Glint: replaces the enchantment shimmer with a picture (white lightning on black, textures/misc/glint_lightning.png),
 * tinted in your colour. Only things that already have a glint get it: enchanted tools and armour, the enchanted
 * golden apple, enchanted books, and the same shimmer on armour of players and mobs. Unenchanted items stay as they are.
 * <p>
 * The game draws the glint with a texture that is added to the picture of the item, so black adds nothing and the white
 * lines light up in the chosen colour. The three vanilla glint textures (items, entities / armour, and the old name) are
 * replaced while the module is on and put back from the game's own files when it is off.
 */
public class GlintModule extends Module {
    private static final String[] TEXTURES = {
            "textures/misc/enchanted_glint_item.png",       // items, held and in the inventory
            "textures/misc/enchanted_glint_entity.png",     // armour and entities
            "textures/misc/enchanted_item_glint.png"};      // the name before 1.21.4; unused ids are harmless
    private static final String BASE = "/assets/deathclientdlc/textures/misc/glint_lightning.png";

    public final BoolSetting themeColor = add(new BoolSetting("Цвет темы", false));
    public final ButtonSetting palette = add(new ButtonSetting("Палитра цвета", () -> ColorPickerScreen.open("Glint", ColorPickerScreen.rgb(this.red, this.green, this.blue))));
    public final NumberSetting red = add(new NumberSetting("Red", 150, 0, 255, 5));
    public final NumberSetting green = add(new NumberSetting("Green", 190, 0, 255, 5));
    public final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));
    public final NumberSetting brightness = add(new NumberSetting("Brightness", 100, 20, 300, 10));

    private BufferedImage base;
    private String appliedKey = "";
    private int ticks;
    private final Map<Identifier, AbstractTexture> mine = new HashMap<>();

    public GlintModule() { super("Glint", Category.VISUALS); }

    @Override
    protected void onEnable() { apply(); }

    @Override
    protected void onDisable() { restore(); }

    /** Looks about twice a second for a changed colour, or for a resource reload (F3 + T) that put the game's glint back. */
    @Override
    public void onTick(MinecraftClient c) {
        if (++ticks < 10) return;
        ticks = 0;
        if (!key().equals(appliedKey) || replaced(c)) apply();
    }

    private int color() { return themeColor.get() ? Theme.current().accent() & 0xFFFFFF : ((int) red.get() << 16) | ((int) green.get() << 8) | (int) blue.get(); }

    private String key() { return color() + "/" + (int) brightness.get(); }

    private boolean replaced(MinecraftClient c) {
        TextureManager tm = c.getTextureManager();
        for (Map.Entry<Identifier, AbstractTexture> e : mine.entrySet()) if (tm.getTexture(e.getKey()) != e.getValue()) return true;
        return false;
    }

    private void apply() {
        MinecraftClient c = MinecraftClient.getInstance();
        try {
            if (base == null) {
                try (InputStream in = GlintModule.class.getResourceAsStream(BASE)) { base = ImageIO.read(in); }
            }
            int rgb = color();
            float br = (float) (brightness.get() / 100.0);
            int w = base.getWidth(), h = base.getHeight();
            BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            float cr = ((rgb >> 16) & 255) / 255f * br, cg = ((rgb >> 8) & 255) / 255f * br, cb = (rgb & 255) / 255f * br;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int g = base.getRGB(x, y) & 255;                        // the picture is grey: its brightness
                    int r = Math.min(255, Math.round(g * cr)), gg = Math.min(255, Math.round(g * cg)), b = Math.min(255, Math.round(g * cb));
                    out.setRGB(x, y, 0xFF000000 | (r << 16) | (gg << 8) | b);
                }
            }
            ByteArrayOutputStream png = new ByteArrayOutputStream();
            ImageIO.write(out, "png", png);
            TextureManager tm = c.getTextureManager();
            for (String path : TEXTURES) {
                Identifier id = Identifier.of("minecraft", path);
                AbstractTexture tex = MenuCustom.makeTexture(NativeImage.read(new ByteArrayInputStream(png.toByteArray())));
                tm.registerTexture(id, tex);
                mine.put(id, tex);
            }
            appliedKey = key();
        } catch (Exception ignored) {
            appliedKey = key();                                             // do not retry every half second
        }
    }

    /** Back to the game's own glint: the vanilla pictures are read from the resources and registered again. */
    private void restore() {
        MinecraftClient c = MinecraftClient.getInstance();
        TextureManager tm = c.getTextureManager();
        for (String path : TEXTURES) {
            Identifier id = Identifier.of("minecraft", path);
            try {
                Optional<Resource> res = c.getResourceManager().getResource(id);
                if (res.isPresent()) {
                    try (InputStream in = res.get().getInputStream()) {
                        tm.registerTexture(id, MenuCustom.makeTexture(NativeImage.read(in)));
                    }
                } else {
                    tm.destroyTexture(id);
                }
            } catch (Exception ignored) {}
        }
        mine.clear();
        appliedKey = "";
    }
}
