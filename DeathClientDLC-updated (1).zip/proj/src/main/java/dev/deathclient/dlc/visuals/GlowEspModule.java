package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Glow ESP through vanilla's outline renderer (see mixin.EntityMixin). No custom drawing code: the game
 * renders the outline itself, through walls, in the color returned by colorFor().
 */
public class GlowEspModule extends Module {
    // ---- configuration: colors are 0xRRGGBB ----
    static final int COLOR_PLAYER  = 0xFF4040;
    static final int COLOR_HOSTILE = 0xFF9933;
    static final int COLOR_PASSIVE = 0x55FF55;
    static final int COLOR_ITEM    = 0x55AAFF;
    static final int COLOR_FRIEND  = 0x55FFFF;

    private static volatile GlowEspModule instance;

    public final NumberSetting range = add(new NumberSetting("Range", 32, 8, 64, 4));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting items = add(new BoolSetting("Items", false));
    /** The two looks are independent: the vanilla outline, and the lightning fill (the Glint picture) over living entities, through walls. Both, either one, or none. */
    public final BoolSetting outline = add(new BoolSetting("Контур", true));
    public final BoolSetting fill = add(new BoolSetting("Заливка", true));
    public final NumberSetting glintOpacity = add(new NumberSetting("Прозрачность заливки", 70, 10, 100, 5));
    /** Own colour instead of the colour per kind (players red, hostile orange, ...); friends keep theirs. */
    public final BoolSetting customColor = add(new BoolSetting("Свой цвет", false));
    public final ButtonSetting palette = add(new ButtonSetting("Палитра цвета", () -> ColorPickerScreen.open("Glow ESP", ColorPickerScreen.rgb(this.red, this.green, this.blue))));
    public final NumberSetting red = add(new NumberSetting("Red", 160, 0, 255, 5));
    public final NumberSetting green = add(new NumberSetting("Green", 120, 0, 255, 5));
    public final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));

    public GlowEspModule() {
        super("Glow ESP", Category.RENDER);
        instance = this;
    }

    /** Outline color for this entity, or -1 if it must not glow. Called by the mixin every frame. Chams (outline way) uses the same outline. */
    public static int colorFor(Entity e) {
        int own = ownColor(e);
        GlowEspModule m = instance;
        if (own != -1 && m != null && m.outline.get()) return own;                 // the outline only when it is switched on
        return ChamsModule.glowRgbFor(e);
    }

    /** ARGB tint of the glint fill for this living entity, or -1 (module off, Заливка off, not glowing, not a living entity). Pulses slowly. */
    public static int glintArgbFor(Entity e) {
        GlowEspModule m = instance;
        if (m == null || !m.isEnabled() || !m.fill.get() || !(e instanceof LivingEntity)) return -1;
        int rgb = ownColor(e);
        if (rgb == -1) return -1;
        double pulse = 0.78 + 0.22 * Math.sin(System.currentTimeMillis() / 320.0);
        int a = (int) Math.round(m.glintOpacity.get() * 2.55 * pulse);
        return (Math.max(10, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    private int tone(int kindColor) {
        return customColor.get() ? ((int) red.get() << 16) | ((int) green.get() << 8) | (int) blue.get() : kindColor;
    }

    private static int ownColor(Entity e) {
        GlowEspModule m = instance;
        if (m == null || !m.isEnabled()) return -1;

        MinecraftClient c = MinecraftClient.getInstance();
        // The integrated server shares the Entity class; only the render thread may touch the client world.
        if (c == null || !c.isOnThread()) return -1;
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || e == p) return -1;
        if (c.world.getEntityById(e.getId()) != e) return -1;   // client-side copies only

        if (e instanceof LivingEntity le && (!le.isAlive() || le.isSpectator())) return -1;
        if (p.distanceTo(e) > m.range.get()) return -1;

        if (e instanceof PlayerEntity) {
            FriendsModule fm = ModuleManager.get(FriendsModule.class);
            if (fm != null && fm.highlight.get() && Friends.isFriend(e)) return COLOR_FRIEND;
            return m.players.get() ? m.tone(COLOR_PLAYER) : -1;
        }
        if (e instanceof HostileEntity) return m.hostile.get() ? m.tone(COLOR_HOSTILE) : -1;
        if (e instanceof LivingEntity) return m.passive.get() ? m.tone(COLOR_PASSIVE) : -1;
        if (e instanceof ItemEntity) return m.items.get() ? m.tone(COLOR_ITEM) : -1;
        return -1;
    }
}
