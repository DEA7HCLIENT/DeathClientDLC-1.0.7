package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Visual Client: with one key press the client becomes a visuals-only one. Every gameplay module (all of Combat and
 * Movement plus the gameplay helpers of Misc) is switched off and cannot be switched on, and it is hidden everywhere in
 * the client: the menus (the Combat / Movement tabs are gone), the keybind list, the module lists and the chat commands
 * (.toggle, .bind, ...). Visuals, HUD and menu modules keep working. Press the key again to leave: with "Restore on
 * exit" the modules that were on come back. Like Unhook, the saved on/off state is not overwritten while this is on.
 * <p>
 * Bind it first (Keybinds tab, or middle click on its card): with "Hide itself" on, its own card is hidden too, so the
 * key is the only way out; it only hides itself when a key is bound, so you cannot lock yourself out.
 * This only changes what this client shows; it does not touch the game window, the process or the mod files.
 */
public class VisualClientModule extends Module {
    /** Misc modules that act on the game (the rest of Misc is HUD / menu / looks and stays usable). */
    private static final Set<String> MISC_GAMEPLAY = Set.of("AutoLeave", "AutoReconnect", "AutoRespawn", "AutoTool",
            "ChestStealer", "Nuker", "MiddleClickFriend", "BedWars Helper");

    private static VisualClientModule instance;
    public final BoolSetting restore = add(new BoolSetting("Restore on exit", true));
    public final BoolSetting hideSelf = add(new BoolSetting("Hide itself", true));
    private final List<Module> saved = new ArrayList<>();

    public VisualClientModule() { super("Visual Client", Category.MISC); instance = this; }

    static boolean active() { return instance != null && instance.isEnabled(); }

    /** True while the mode is on: the lists should use {@link #hides}. */
    static boolean hiding() { return active(); }

    /** True for the modules that Visual Client switches off. */
    static boolean gameplay(Module m) {
        if (m == instance) return false;
        return switch (m.getCategory()) {
            case COMBAT, MOVEMENT -> true;
            case MISC -> MISC_GAMEPLAY.contains(m.getName());
            default -> false;
        };
    }

    /** True if the module must not be shown anywhere while the mode is on. */
    static boolean hides(Module m) {
        if (!active()) return false;
        if (m == instance) return instance.hideSelf.get() && instance.getKey() != -1;
        return gameplay(m);
    }

    /** Asked by Module.toggle(): true while Visual Client is on and the module is one it keeps off. */
    static boolean blocks(Module m) { return active() && gameplay(m); }

    @Override
    protected void onEnable() {
        MinecraftClient c = MinecraftClient.getInstance();
        Config.autosaveNow(true);                          // store the full state first; saves are skipped while the mode is on
        saved.clear();
        for (Module m : ModuleManager.all()) {
            if (gameplay(m) && m.isEnabled()) { saved.add(m); m.toggle(); }
        }
        if (GuiStyleModule.isClickGui(c.currentScreen)) c.setScreen(null);   // the open menu still lists the old modules
    }

    @Override
    protected void onDisable() {
        if (restore.get()) {
            for (Module m : saved) if (!m.isEnabled()) m.toggle();
        }
        saved.clear();
    }

    /** Something may have switched a module on in the meantime (a config being loaded): keep them off. */
    @Override
    public void onTick(MinecraftClient c) {
        for (Module m : ModuleManager.all()) {
            if (gameplay(m) && m.isEnabled()) m.toggle();
        }
    }
}
