package dev.deathclient.dlc;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Start-up screen, shown once per launch: black background, the logo (textures/gui/splash_icon.png) fades in and
 * breathes slowly, under it the client name and a pulsing "Press to enter". It waits until you click (or press Enter /
 * Space / Esc); then the main menu is shown at once and the black start-up screen slides up off the top of the screen
 * while the logo shrinks and flies up with it ({@link #renderIntro}, drawn on top of the main menu by MainMenuScreen).
 */
public class SplashScreen extends Screen {
    /** Set when the splash has been started, so it is only ever shown once per launch. */
    static boolean done;

    private static final Identifier ICON = Identifier.of("deathclientdlc", "textures/gui/splash_icon.png");
    private static final int TEX = 512;
    private static final long FADE_IN = 900;                                  // ms
    private static final long MENU_FADE = 1100;                              // ms, the black screen sliding up
    private static long menuFadeStart;

    private long start = -1;
    private boolean wentOn;

    public SplashScreen() {
        super(Text.literal("Death Client"));
        done = true;
    }

    private static int logoBase(int width, int height) { return (int) (Math.min(width, height) * 0.46f); }

    private static float logoCx(int width) { return width / 2f; }

    private static float logoCy(int height) { return height / 2f - height * 0.06f; }

    /**
     * Drawn over the main menu for about a second after the start-up screen: the black screen slides up and off the top
     * (its lower edge moves up, nothing fades), the logo shrinks and flies up to the top edge on that curtain, and the
     * name under it fades out at the start. Both start exactly where the start-up screen ended, so there is no jump.
     */
    static void renderIntro(DrawContext ctx, TextRenderer tr, int width, int height) {
        if (menuFadeStart == 0) return;
        long t = System.currentTimeMillis() - menuFadeStart;
        if (t >= MENU_FADE) { menuFadeStart = 0; return; }
        float p = t / (float) MENU_FADE;
        float e = p < 0.5f ? 4f * p * p * p : 1f - (float) Math.pow(-2f * p + 2f, 3) / 2f;      // ease in-out cubic

        int edge = Math.round(height * (1f - e));                                                   // bottom edge of the curtain
        if (edge > 0) ctx.fill(0, 0, width, edge, 0xFF000000);

        int base = logoBase(width, height);
        float cx = logoCx(width), cy = logoCy(height);
        float scale = 1f - 0.9f * e;                                                                 // shrinks to a tenth
        float y = cy + (-base * 0.08f - cy) * e;                                                     // up past the top edge
        float fadeOut = 1f - smooth((p - 0.78f) / 0.22f);                                            // gone as it leaves
        int a = Math.round(255f * fadeOut);
        if (a > 2) {
            var m = ctx.getMatrices();
            m.pushMatrix();
            m.translate(cx, y);
            m.scale(scale, scale);
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, -base / 2, -base / 2, 0f, 0f, base, base,
                    TEX, TEX, TEX, TEX, (a << 24) | 0xFFFFFF);
            m.popMatrix();
        }
        int ta = Math.round(255f * (1f - smooth(p / 0.35f)));
        drawCentered(ctx, tr, "Death Client", cx, y + base / 2f * scale + 6f, 1.6f, ta, 0xFFFFFF);
    }

    private static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xFF000000);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        long now = System.currentTimeMillis();
        if (start < 0) start = now;
        long t = now - start;

        float in = smooth(t / (float) FADE_IN);
        float vis = in;
        if (vis <= 0.01f) return;

        float breathe = 1f + 0.012f * (float) Math.sin(t / 900.0);
        float scale = (0.94f + 0.06f * in) * breathe;
        int base = logoBase(width, height);
        float cx = logoCx(width), cy = logoCy(height);

        var m = ctx.getMatrices();
        int a = Math.round(255f * vis);
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, -base / 2, -base / 2, 0f, 0f, base, base,
                TEX, TEX, TEX, TEX, (a << 24) | 0xFFFFFF);
        m.popMatrix();

        // Client name and the prompt under the logo (text with a nearly zero alpha would be drawn opaque, so skip those).
        float textY = cy + base / 2f * scale + 6f;
        drawCentered(ctx, textRenderer, "Death Client", cx, textY, 1.6f, a, 0xFFFFFF);
        int pa = Math.round(255f * vis * (0.45f + 0.45f * (float) Math.sin(t / 450.0 + 1.0)));
        drawCentered(ctx, textRenderer, "Press to enter", cx, textY + 22f, 1.0f, pa, 0xC8CCD8);
    }

    private static void drawCentered(DrawContext ctx, TextRenderer textRenderer, String s, float cx, float y, float size, int alpha, int rgb) {
        if (s.isEmpty() || alpha < 12) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, y);
        m.scale(size, size);
        ctx.drawTextWithShadow(textRenderer, Fonts.gui(s), -Fonts.guiWidth(textRenderer, s) / 2, 0, (Math.min(255, alpha) << 24) | rgb);
        m.popMatrix();
    }

    @Override
    public void tick() {
        super.tick();
        if (client == null || wentOn) return;
        if (start >= 0 && System.currentTimeMillis() - start > 300) {         // keys count only after it has been on screen a moment
            long win = client.getWindow().getHandle();
            if (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS
                    || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS) goOn();
        }
    }

    private void goOn() {
        if (wentOn || client == null) return;
        wentOn = true;
        menuFadeStart = System.currentTimeMillis();
        client.setScreen(new MainMenuScreen());
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        goOn();
        return true;
    }

    @Override
    public void close() { goOn(); }

    @Override
    public boolean shouldPause() { return false; }
}
