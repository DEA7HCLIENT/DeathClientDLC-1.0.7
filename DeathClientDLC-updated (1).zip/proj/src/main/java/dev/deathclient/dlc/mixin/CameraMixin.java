package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.FreecamModule;
import dev.deathclient.dlc.FreelookModule;
import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Freecam. HEAD: steps the camera right before the game reads it. TAIL: after the game has positioned the camera
 * from the camera entity, the position and rotation are overwritten with Freecam's own state, so the picture never
 * depends on the dummy entity's interpolation (stale previous angles made the view lag or not turn).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update", at = @At("HEAD"), require = 0)
    private void deathclientdlc$freecamBeforeCamera(CallbackInfo ci) {
        FreecamModule.worldFrame();
    }

    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void deathclientdlc$freecamApply(CallbackInfo ci) {
        if (FreecamModule.active()) {
            setRotation(FreecamModule.yaw(), FreecamModule.pitch());
            Vec3d e = FreecamModule.eyePos();
            setPos(e.x, e.y, e.z);
        } else if (FreelookModule.active()) {
            setRotation(FreelookModule.viewYaw(), FreelookModule.viewPitch());
            Vec3d e = FreelookModule.camPos(FreelookModule.delta());
            setPos(e.x, e.y, e.z);
        }
    }

    /** No Render, "Camera through blocks": the third-person camera keeps its full distance instead of being pulled in by blocks behind you. */
    @Inject(method = "clipToSpace", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$cameraThroughBlocks(float desiredCameraDistance, CallbackInfoReturnable<Float> cir) {
        if (NoRenderModule.cameraClip()) cir.setReturnValue(desiredCameraDistance);
    }
}
