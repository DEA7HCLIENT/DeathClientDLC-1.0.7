package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ChamsState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(LivingEntityRenderState.class)
public abstract class ChamsRenderStateMixin implements ChamsState {
    @Unique private int deathclientdlc$chams = -1;
    @Unique private int deathclientdlc$glint = -1;

    @Override public void deathclientdlc$setChams(int argb) { this.deathclientdlc$chams = argb; }

    @Override public int deathclientdlc$getChams() { return this.deathclientdlc$chams; }

    @Override public void deathclientdlc$setGlint(int argb) { this.deathclientdlc$glint = argb; }

    @Override public int deathclientdlc$getGlint() { return this.deathclientdlc$glint; }
}
