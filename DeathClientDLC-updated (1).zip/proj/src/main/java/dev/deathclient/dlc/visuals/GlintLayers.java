package dev.deathclient.dlc;

import net.minecraft.client.render.RenderLayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Glow ESP glint layer: the entity model drawn with the lightning picture (textures/glow_glint.png: white lightning, the
 * rest a faint wash), tinted by the Glow ESP colour, translucent blending and the depth test OFF, so it shows through walls.
 *
 * The 1.21.11 render API (RenderPipeline / RenderSetup) lives in the nested Builder class, which is only loaded inside
 * the try block of init(): if a class or method is missing in this build, the error is logged once and available() stays
 * false, so Glow ESP keeps drawing only the vanilla outline.
 */
public final class GlintLayers {
    private static final Logger LOGGER = LoggerFactory.getLogger("DeathClientDLC/GlowGlint");
    private static boolean tried;
    private static RenderLayer layer;

    private GlintLayers() {}

    public static boolean available() { init(); return layer != null; }

    public static RenderLayer layer() { init(); return layer; }

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            layer = Builder.create();
            LOGGER.info("Glow ESP glint layer created");
        } catch (Throwable t) {
            layer = null;
            LOGGER.warn("Glow ESP glint layer is not available in this build, only the outline is drawn", t);
        }
    }

    private static final class Builder {
        static RenderLayer create() {
            com.mojang.blaze3d.pipeline.RenderPipeline pipeline = com.mojang.blaze3d.pipeline.RenderPipeline
                    .builder(net.minecraft.client.gl.RenderPipelines.ENTITY_SNIPPET)
                    .withLocation("pipeline/deathclientdlc_glow_glint")
                    .withSampler("Sampler1")
                    .withBlend(com.mojang.blaze3d.pipeline.BlendFunction.TRANSLUCENT)
                    .withCull(false)
                    .withDepthTestFunction(com.mojang.blaze3d.platform.DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .build();
            net.minecraft.client.render.RenderSetup setup = net.minecraft.client.render.RenderSetup.builder(pipeline)
                    .texture("Sampler0", net.minecraft.util.Identifier.of("deathclientdlc", "textures/glow_glint.png"))
                    .useLightmap()
                    .useOverlay()
                    .build();
            return RenderLayer.of("deathclientdlc_glow_glint", setup);
        }
    }
}
