package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Small quick-toggle panel for the 1.8-style modules only, opened with its own key (Num+ by default). */
public class LegacyMenuScreen extends Screen {
    private static final String[] NAMES = {"No Cooldown", "Sprint Reset", "W-Tap", "Auto Block"};
    private static final int ROW_H = 22, W = 160, PAD = 8;

    public LegacyMenuScreen() { super(Text.literal("1.8")); }

    @Override public boolean shouldCloseOnEsc() { return true; }

    private List<Module> mods() {
        List<Module> list = new ArrayList<>();
        for (String n : NAMES) for (Module m : ModuleManager.shown()) if (m.getName().equals(n)) list.add(m);
        return list;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        List<Module> mods = mods();
        int h = PAD * 2 + 18 + mods.size() * (ROW_H + 4);
        int x = (width - W) / 2, y = (height - h) / 2;
        int acc = Theme.current().accent() | 0xFF000000;

        ctx.fill(x, y, x + W, y + h, 0xF0101016);
        ctx.fill(x, y, x + W, y + 1, acc);
        ctx.fill(x, y + h - 1, x + W, y + h, acc);
        ctx.fill(x, y, x + 1, y + h, acc);
        ctx.fill(x + W - 1, y, x + W, y + h, acc);
        ctx.drawText(textRenderer, "1.8 Functions", x + PAD, y + PAD, 0xFFFFFFFF, false);

        int ry = y + PAD + 18;
        for (Module m : mods) {
            boolean on = m.isEnabled();
            boolean hover = mx >= x + PAD && mx <= x + W - PAD && my >= ry && my <= ry + ROW_H;
            ctx.fill(x + PAD, ry, x + W - PAD, ry + ROW_H, on ? acc : (hover ? 0x30FFFFFF : 0x20FFFFFF));
            ctx.drawText(textRenderer, m.getName(), x + PAD + 6, ry + 7, 0xFFFFFFFF, false);
            ry += ROW_H + 4;
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    @Override
    public boolean mouseClicked(net.minecraft.client.gui.Click click, boolean doubled) {
        List<Module> mods = mods();
        int h = PAD * 2 + 18 + mods.size() * (ROW_H + 4);
        int x = (width - W) / 2, y = (height - h) / 2;
        int ry = y + PAD + 18;
        for (Module m : mods) {
            if (click.x() >= x + PAD && click.x() <= x + W - PAD && click.y() >= ry && click.y() <= ry + ROW_H) {
                m.toggle();
                return true;
            }
            ry += ROW_H + 4;
        }
        return super.mouseClicked(click, doubled);
    }
}
