package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

/**
 * Watermark: a small box in the corner with the client's logo and name, and a second line with your nickname,
 * FPS and ping. The logo is white with transparency (textures/gui/logo_art.png), so the theme colour tints it;
 * the underline under the box is the theme gradient. Drag it while the chat is open (HUD editor).
 */
public class WatermarkModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 600, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 6, 0, 400, 1));
    public final BoolSetting info = add(new BoolSetting("Nick, FPS, ping", true));
    public final BoolSetting theme = add(new BoolSetting("Theme color", true));

    private static final Identifier ART = Identifier.of("deathclientdlc", "textures/gui/logo_art.png");
    private static final int ART_PX = 96;
    private static final int BG = 0xC0101010, MUTED = 0xFF9A9AA6;

    public WatermarkModule() { super("Watermark", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        WatermarkModule m = ModuleManager.get(WatermarkModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        var tr = c.textRenderer;
        Theme th = Theme.current();
        int accent = (theme.get() ? th.accent() : 0xFFFFFF) | 0xFF000000;
        // On clear glass the plain theme colour is hard to read: lighten the title.
        int titleCol = LiquidGlass.on() ? (ClickGuiScreen.mix(accent, 0xFFFFFFFF, 0.5f) | 0xFF000000) : accent;

        String title = "Death Client";
        String line2 = null;
        if (info.get()) {
            StringBuilder sb = new StringBuilder(c.player.getName().getString());
            sb.append("  ·  ").append(c.getCurrentFps()).append(" fps");
            PlayerListEntry e = c.getNetworkHandler() == null ? null : c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());
            if (e != null) sb.append("  ·  ").append(e.getLatency()).append(" ms");
            line2 = sb.toString();
        }

        int logo = 22, pad = 4, gap = 5;
        int textW = Fonts.width(tr, title);
        if (line2 != null) textW = Math.max(textW, Fonts.width(tr, line2));
        int w = pad + logo + gap + textW + 8;
        int h = logo + pad * 2;
        int x0 = (int) x.get(), y0 = (int) y.get();

        HudEdit.track(x0, y0, w, h, (nx, ny) -> { x.set(nx); y.set(ny); });
        Shapes.panel(ctx, x0, y0, w, h, BG);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ART, x0 + pad, y0 + pad, 0f, 0f, logo, logo, ART_PX, ART_PX, ART_PX, ART_PX, accent);

        int tx = x0 + pad + logo + gap;
        if (line2 != null) {
            Fonts.draw(ctx, tr, title, tx, y0 + 6, titleCol);
            Fonts.draw(ctx, tr, line2, tx, y0 + 17, MUTED);
        } else {
            Fonts.draw(ctx, tr, title, tx, y0 + (h - 8) / 2, titleCol);
        }

        // Underline: the theme gradient (a fixed colour when "Theme color" is off).
        for (int i = 0; i < w; i++) {
            int col = theme.get() ? (th.at(w <= 1 ? 0f : i / (float) (w - 1)) | 0xFF000000) : 0xFFFFFFFF;
            ctx.fill(x0 + i, y0 + h - 1, x0 + i + 1, y0 + h, col);
        }
    }
}
