package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** AirStuck: you hang in the air. Your movement is zeroed and no movement packets leave (hook: mixin.BlinkMixin). */
public class AirStuckModule extends Module {
    public AirStuckModule() { super("AirStuck", Category.MOVEMENT); }

    /** Called for every packet you send: true = dropped. */
    static boolean drop(Packet<?> packet) {
        AirStuckModule m = ModuleManager.get(AirStuckModule.class);
        return m != null && m.isEnabled() && packet instanceof PlayerMoveC2SPacket;
    }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player != null) c.player.setVelocity(0, 0, 0);
    }
}
