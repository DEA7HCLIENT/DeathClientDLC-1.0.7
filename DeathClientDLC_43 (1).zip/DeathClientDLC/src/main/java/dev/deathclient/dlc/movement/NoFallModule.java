package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** NoFall: once you have fallen far enough, tells the server you are on the ground, so the landing does no damage. */
public class NoFallModule extends Module {
    public final NumberSetting distance = add(new NumberSetting("Fall distance", 2.5, 1.0, 10.0, 0.5));

    public NoFallModule() { super("NoFall", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || p.isOnGround() || p.isTouchingWater() || p.getAbilities().allowFlying) return;
        if (p.fallDistance > distance.get())
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(p.getX(), p.getY(), p.getZ(), true, false));
    }
}
