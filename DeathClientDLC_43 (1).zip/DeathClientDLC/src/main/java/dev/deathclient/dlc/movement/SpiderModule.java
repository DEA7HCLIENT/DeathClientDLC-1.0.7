package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Spider: while you push against a wall you climb it. */
public class SpiderModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.2, 0.05, 0.6, 0.01));

    public SpiderModule() { super("Spider", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.horizontalCollision || p.isSneaking()) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, speed.get(), v.z);
    }
}
