package dev.deathclient.dlc;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Start-up screen, shown once per launch: black background, the logo (textures/gui/splash_icon.png) fades in and
 * breathes slowly, under it the client name and a pulsing "Press to enter". It waits until you click (or press Enter /
 * Space / Esc); then the logo grows and fades out and the main menu comes up out of black (introFade, used by MainMenuScreen).
 */
public class SplashScreen extends Screen {
    /** Set when the splash has been started, so it is only ever shown once per launch. */
    static boolean done;

    private static final Identifier ICON = Identifier.of("deathclientdlc", "textures/gui/splash_icon.png");
    private static final int TEX = 512;
    private static final long FADE_IN = 900, LEAVE = 550;                   // ms
    private static final long MENU_FADE = 1000;                              // ms, the main menu coming out of black
    private static long menuFadeStart;

    private long start = -1, leaveStart = -1;
    private boolean wentOn;

    public SplashScreen() {
        super(Text.literal("Death Client"));
        done = true;
    }

    /** 1 -> 0 over the first second of the main menu; 0 when it is not fading in. Black overlay strength. */
    static float introFade() {
        if (menuFadeStart == 0) return 0f;
        long t = System.currentTimeMillis() - menuFadeStart;
        if (t >= MENU_FADE) { menuFadeStart = 0; return 0f; }
        float a = 1f - t / (float) MENU_FADE;
        return a * a;
    }

    private static float smooth(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x * x * (3f - 2f * x);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xFF000000);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        long now = System.currentTimeMillis();
        if (start < 0) start = now;
        long t = now - start;

        float in = smooth(t / (float) FADE_IN);
        float lv = leaveStart < 0 ? 0f : smooth((now - leaveStart) / (float) LEAVE);
        float vis = in * (1f - lv);
        if (vis <= 0.01f) return;

        float breathe = 1f + 0.012f * (float) Math.sin(t / 900.0);
        float scale = (0.94f + 0.06f * in) * breathe * (1f + 0.35f * lv);
        int base = (int) (Math.min(width, height) * 0.46f);
        float cx = width / 2f, cy = height / 2f - height * 0.06f;

        var m = ctx.getMatrices();
        int a = Math.round(255f * vis);
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ICON, -base / 2, -base / 2, 0f, 0f, base, base,
                TEX, TEX, TEX, TEX, (a << 24) | 0xFFFFFF);
        m.popMatrix();

        // Client name and the prompt under the logo (text with a nearly zero alpha would be drawn opaque, so skip those).
        float textY = cy + base / 2f * scale + 6f;
        drawCentered(ctx, "Death Client", cx, textY, 1.6f, a, 0xFFFFFF);
        int pa = Math.round(255f * vis * (0.45f + 0.45f * (float) Math.sin(t / 450.0 + 1.0)));
        drawCentered(ctx, leaveStart < 0 ? "Press to enter" : "", cx, textY + 22f, 1.0f, pa, 0xC8CCD8);
    }

    private void drawCentered(DrawContext ctx, String s, float cx, float y, float size, int alpha, int rgb) {
        if (s.isEmpty() || alpha < 12) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, y);
        m.scale(size, size);
        ctx.drawTextWithShadow(textRenderer, Fonts.gui(s), -Fonts.guiWidth(textRenderer, s) / 2, 0, (Math.min(255, alpha) << 24) | rgb);
        m.popMatrix();
    }

    @Override
    public void tick() {
        super.tick();
        if (client == null) return;
        if (leaveStart < 0) {
            if (start >= 0 && System.currentTimeMillis() - start > 300) {         // keys count only after it has been on screen a moment
                long win = client.getWindow().getHandle();
                if (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS
                        || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_SPACE) == GLFW.GLFW_PRESS) leave();
            }
        } else if (System.currentTimeMillis() - leaveStart >= LEAVE) {
            goOn();
        }
    }

    private void leave() {
        if (leaveStart < 0) leaveStart = System.currentTimeMillis();
    }

    private void goOn() {
        if (wentOn || client == null) return;
        wentOn = true;
        menuFadeStart = System.currentTimeMillis();
        client.setScreen(new MainMenuScreen());
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        leave();
        return true;
    }

    @Override
    public void close() { leave(); }

    @Override
    public boolean shouldPause() { return false; }
}
