package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.ArrayList;
import java.util.List;

/** Active potion effects as a separate HUD list (icon, name + level, time left). Independent of the Dynamic Island. */
public class EffectsHudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 60, 0, 1200, 1));
    public final BoolSetting icons = add(new BoolSetting("Icons", true));

    private static final String[] ROMAN = {"", " I", " II", " III", " IV", " V"};
    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFFB9B2C8;

    public EffectsHudModule() { super("Effects HUD", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        EffectsHudModule m = ModuleManager.get(EffectsHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        var tr = c.textRenderer;
        List<StatusEffectInstance> list = new ArrayList<>(c.player.getStatusEffects());
        int ic = icons.get() ? 18 : 0, rowH = 24, gap = 3, pad = 6;
        String[] names = new String[list.size()], times = new String[list.size()];
        int w = 90;
        for (int i = 0; i < list.size(); i++) {
            StatusEffectInstance e = list.get(i);
            int amp = Math.max(0, Math.min(e.getAmplifier() + 1, ROMAN.length - 1));
            names[i] = Text.translatable(e.getEffectType().value().getTranslationKey()).getString() + ROMAN[amp];
            int sec = Math.max(0, e.getDuration() / 20);
            times[i] = e.isInfinite() ? "∞" : (sec / 60) + ":" + String.format("%02d", sec % 60);
            w = Math.max(w, pad + ic + (ic > 0 ? 6 : 0) + Math.max(Fonts.width(tr, names[i]), Fonts.width(tr, times[i])) + pad);
        }
        int x0 = (int) x.get(), y0 = (int) y.get();
        int total = Math.max(1, list.size()) * (rowH + gap) - gap;
        final int fw = w;
        HudEdit.track(x0, y0, w, total, (nx, ny) -> { x.set(nx); y.set(ny); });
        int accent = Theme.current().accent() | 0xFF000000;
        for (int i = 0; i < list.size(); i++) {
            int ry = y0 + i * (rowH + gap);
            Shapes.panel(ctx, x0, ry, fw, rowH, BG);
            ClickGuiScreen.outline(ctx, x0, ry, fw, rowH, (0x90 << 24) | (accent & 0xFFFFFF), Shapes.corner(Shapes.shape()));
            int tx = x0 + pad;
            if (ic > 0) {
                var key = list.get(i).getEffectType().getKey();
                if (key.isPresent()) {
                    Identifier tex = key.get().getValue().withPrefixedPath("mob_effect/");
                    ctx.drawGuiTexture(RenderPipelines.GUI_TEXTURED, tex, tx, ry + (rowH - ic) / 2, ic, ic);
                }
                tx += ic + 6;
            }
            Fonts.draw(ctx, tr, names[i], tx, ry + 4, WHITE);
            Fonts.draw(ctx, tr, times[i], tx, ry + 14, MUTED);
        }
    }
}
