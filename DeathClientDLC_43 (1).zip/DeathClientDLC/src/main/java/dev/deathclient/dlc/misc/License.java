package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;

/** Access gate. Only a salted PBKDF2 hash of the key is stored (never the key itself). Remembered on this PC after the first correct entry. */
public final class License {
    private static final String SALT = "97ef85538efc516d52b10694abfd49d3";
    private static final String HASH = "a1def4a9aca826fc329d607e160ecf4f599187ffdf8e9ce9d6a757a4773ec339";
    private static final int ITER = 120000;
    private static volatile boolean unlocked;

    private License() {}

    public static boolean unlocked() { return unlocked; }

    /** Checks the entered key; unlocks for this launch when it matches. */
    public static boolean tryUnlock(String key) {
        if (key == null || key.isEmpty()) return false;
        try {
            byte[] salt = hex(SALT);
            var spec = new PBEKeySpec(key.toCharArray(), salt, ITER, 256);
            byte[] got = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            if (MessageDigest.isEqual(got, hex(HASH))) { unlocked = true; remember(); return true; }
        } catch (Exception ignored) {}
        return false;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc").resolve("license.dat");
    }

    /** Token bound to this machine, so a copied file does not unlock another PC. */
    private static String token() throws Exception {
        String id = System.getProperty("user.name") + "|" + System.getProperty("os.name") + "|" + System.getProperty("user.home");
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] t = md.digest((HASH + "|" + id).getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : t) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static void remember() {
        try {
            Files.createDirectories(file().getParent());
            Files.writeString(file(), token());
        } catch (Exception ignored) {}
    }

    /** Called at start-up: unlocks silently when this PC has already entered the key. */
    public static void restore() {
        try {
            if (Files.exists(file()) && Files.readString(file()).trim().equals(token())) unlocked = true;
        } catch (Exception ignored) {}
    }

    private static byte[] hex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return b;
    }
}
