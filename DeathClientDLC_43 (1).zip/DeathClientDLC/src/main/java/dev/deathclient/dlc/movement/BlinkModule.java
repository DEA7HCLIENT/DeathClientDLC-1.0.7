package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import java.util.ArrayList;
import java.util.List;

/**
 * Blink: your movement packets are held back while it is on, so on the server you stay where you were. Switch it off and
 * everything is sent at once. It also switches itself off when the held packets reach "Max packets".
 * The hook is mixin.BlinkMixin.
 */
public class BlinkModule extends Module {
    public final NumberSetting max = add(new NumberSetting("Max packets", 200, 20, 1000, 10));
    private static final List<Packet<?>> QUEUE = new ArrayList<>();
    private static boolean flushing;

    public BlinkModule() { super("Blink", Category.MOVEMENT); }

    /** Called for every packet you send: true = held back. */
    static boolean hold(Packet<?> packet) {
        BlinkModule m = ModuleManager.get(BlinkModule.class);
        if (m == null || !m.isEnabled() || flushing || !(packet instanceof PlayerMoveC2SPacket)) return false;
        QUEUE.add(packet);
        return true;
    }

    @Override
    public void onTick(MinecraftClient c) {
        if (QUEUE.size() >= max.get()) toggle();
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        flushing = true;
        try {
            if (c.getNetworkHandler() != null) for (Packet<?> pk : QUEUE) c.getNetworkHandler().sendPacket(pk);
        } finally {
            QUEUE.clear();
            flushing = false;
        }
    }
}
