package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Single-window ClickGUI: sidebar with categories (+ Configs / Themes), search bar and a two-column
 * grid of module cards. Enabled modules are filled with the theme accent.
 * LMB card: toggle. RMB card or gear: settings. MMB card or chain icon: bind. Click the search field and type.
 */
public class ClickGuiScreen extends Screen {
    // WW/WH scale to the screen (recomputed in init()); the rest are fixed, bigger card-style metrics.
    private static int WW = 760, WH = 560;
    private static final int SW = 190, CARD_H = 92, THEME_H = 54, GAP = 14, SET_H = 26, ROW = 30, KB_H = 18;
    /** Corner radius in GUI pixels (shared with the main menu and HUD). */
    private static final int R = 6;
    /** Module-card chrome: icon chip, "..." settings button and the on/off switch. */
    private static final int CHIP = 26, PAD = 12, MENU_BTN = 18, SW_W = 30, SW_H = 16;

    private static final int WIN_BG = 0xF2101016, CARD_BG = 0xFF16161F, CARD_HOVER = 0xFF1F1F2A, CARD_LINE = 0xFF23232F;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF8C8C99, SOFT = 0xFFB8B8C4;

    private enum Tab { CATEGORY, CONFIGS, THEMES, KEYBINDS }

    // Kept between openings.
    private static int winX, winY;
    private static boolean placed;
    private static Category selCat = Category.COMBAT;
    private static Tab tab = Tab.CATEGORY;

    /** Opacity multiplier of everything the GUI draws (the Fade animation); 1 outside the GUI's own render. */
    private static float fadeA = 1f;

    private static int fa(int argb) {
        if (fadeA >= 1f) return argb;
        return ((int) ((argb >>> 24) * fadeA) << 24) | (argb & 0xFFFFFF);
    }

    // Open / close animation (GuiAnimationModule).
    private final long animStart = System.nanoTime();
    private boolean closing;
    private long closeStart;

    private final List<Category> cats = new ArrayList<>();
    private List<String> cfgs = List.of();
    private Module openModule;
    private double scroll;
    private String query = "";
    private boolean searchFocused;
    /** The module whose info panel is open (the "I" button), or null. */
    private Module infoMod;

    private boolean draggingWin;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;
    private NumberSetting wheelHue, wheelSat, briSetting;
    private int wheelDragCx, wheelDragCy, briTrackX, briTrackW;

    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private long repeatAt;

    public ClickGuiScreen() {
        super(Text.literal("Death Client"));
    }

    @Override
    protected void init() {
        cats.clear();
        for (Category c : Category.values()) if (!ModuleManager.of(c).isEmpty()) cats.add(c);
        if (!cats.contains(selCat) && !cats.isEmpty()) selCat = cats.get(0);
        WW = clamp(width - 80, 700, 1040);
        WH = clamp(height - 80, 460, 760);
        if (!placed) {
            winX = (width - WW) / 2;
            winY = (height - WH) / 2;
            placed = true;
        }
        winX = clamp(winX, 0, Math.max(0, width - WW));
        winY = clamp(winY, 0, Math.max(0, height - WH));
        refreshCfgs();
    }

    // ------------------------------------------------------------------ helpers

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(r * r - dy * dy));
    }

    /** Filled rect with optional rounded top and/or bottom corners (one scanline per corner row). */
    static void rect(DrawContext ctx, int x, int y, int w, int h, int color, boolean top, boolean bottom) {
        color = fa(color);
        int r = Math.min(R, h / 2);
        int t = top ? r : 0, b = bottom ? r : 0;
        for (int i = 0; i < t; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
        for (int i = 0; i < b; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + t, x + w, y + h - b, color);
    }

    /** Fully rounded rectangle with its own corner radius. */
    static void rrect(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        color = fa(color);
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------------ glass menu / theme gradient helpers

    /** Set at the start of every frame: Glass Menu is on. */
    private boolean glass;

    private int cardBg()      { return glass ? 0x26FFFFFF : CARD_BG; }
    private int cardHover()   { return glass ? 0x3CFFFFFF : CARD_HOVER; }
    private int cardLine()    { return glass ? 0x4DFFFFFF : CARD_LINE; }
    private int field()       { return glass ? 0x22FFFFFF : 0xFF171720; }
    private int fieldFocus()  { return glass ? 0x3AFFFFFF : 0xFF22222E; }
    private int track()       { return glass ? 0x66000000 : 0xFF2C2C38; }

    /** One-pixel rounded outline (the glass edge); the inside is left untouched. */
    static void outline(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        color = fa(color);
        r = Math.min(r, Math.min(w, h) / 2);
        int i0 = inset(r, 0);
        ctx.fill(x + i0, y, x + w - i0, y + 1, color);
        ctx.fill(x + i0, y + h - 1, x + w - i0, y + h, color);
        ctx.fill(x, y + r, x + 1, y + h - r, color);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 1; i < r; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + in + 1, y + i + 1, color);
            ctx.fill(x + w - in - 1, y + i, x + w - in, y + i + 1, color);
            ctx.fill(x + in, y + h - 1 - i, x + in + 1, y + h - i, color);
            ctx.fill(x + w - in - 1, y + h - 1 - i, x + w - in, y + h - i, color);
        }
    }

    /** Card with a border. Glass: translucent fill + outline drawn on top; normal: border rect under the fill. */
    private void cardBox(DrawContext ctx, int x, int y, int w, int h, int line, int fill, int r) {
        if (glass) {
            if ((fill >>> 24) != 0) rrect(ctx, x, y, w, h, fill, r);
            outline(ctx, x, y, w, h, line, r);
        } else {
            rrect(ctx, x - 1, y - 1, w + 2, h + 2, line, r);
            if ((fill >>> 24) != 0) rrect(ctx, x, y, w, h, fill, r);
        }
    }

    /** Rounded rect in the theme colour; a gradient theme is laid out left to right across the whole window. */
    private void accentRect(DrawContext ctx, int x, int y, int w, int h, int r) {
        Theme t = Theme.current();
        int a = glass ? 0xC8 : 0xFF;
        if (!t.gradient()) { rrect(ctx, x, y, w, h, (a << 24) | (t.accent() & 0xFFFFFF), r); return; }
        gradRect(ctx, x, y, w, h, r, t, (x - winX) / (float) WW, (x + w - winX) / (float) WW, a);
    }

    /** Rounded rect filled with the theme gradient from position u0 to u1 (0..1), in 1-4 px wide slices. */
    private static void gradRect(DrawContext ctx, int x, int y, int w, int h, int r, Theme t, float u0, float u1, int alpha) {
        if (!t.gradient()) { rrect(ctx, x, y, w, h, (alpha << 24) | (t.accent() & 0xFFFFFF), r); return; }
        r = Math.min(r, Math.min(w, h) / 2);
        for (int c = 0; c < w; ) {
            boolean edge = c < r || c >= w - r;
            int step = edge ? 1 : Math.max(1, Math.min(4, (w - r) - c));
            int v = edge ? inset(r, Math.min(c, w - 1 - c)) : 0;
            float u = u0 + (u1 - u0) * ((c + step / 2f) / w);
            ctx.fill(x + c, y + v, x + c + step, y + h - v, fa((alpha << 24) | (t.at(u) & 0xFFFFFF)));
            c += step;
        }
    }

    private static int accent() { return Theme.current().accent(); }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        color = fa(color);
        if ((color >>> 24) < 4) return;                       // the game draws near-zero alpha text as opaque
        ctx.drawTextWithShadow(textRenderer, Fonts.gui(s), x, y, color);
    }

    // Tiny pixel icons.
    private static final String[] ICON_COMBAT = {"...#...", ".#.#.#.", "..###..", "#######", "..###..", ".#.#.#.", "...#..."};
    private static final String[] ICON_MOVE = {"#..#...", "##.##..", ".##.##.", "..##.##", ".##.##.", "##.##..", "#..#..."};
    private static final String[] ICON_EYE = {"..###..", ".#...#.", "#..#..#", ".#...#.", "..###.."};
    private static final String[] ICON_STAR = {"...#...", "..###..", ".#####.", "#######", ".#####.", "..###..", "...#..."};
    private static final String[] ICON_BOX = {"#######", "#.....#", "#.###.#", "#.###.#", "#.###.#", "#.....#", "#######"};
    private static final String[] ICON_FOLDER = {"###....", "#######", "#.....#", "#.....#", "#.....#", "#######"};
    private static final String[] ICON_DROP = {"...#...", "..###..", ".#####.", "#######", "#######", ".#####.", "..###.."};
    private static final String[] ICON_EXIT = {"####...", "#..#...", "#..#.#.", "#..####", "#..#.#.", "#..#...", "####..."};
    private static final String[] ICON_SEARCH = {".###...", "#...#..", "#...#..", "#...#..", ".###...", ".....#.", "......#"};
    private static final String[] ICON_GEAR = {"..#.#..", ".#####.", "###.###", ".#...#.", "###.###", ".#####.", "..#.#.."};
    private static final String[] ICON_LINK = {".###.###.", "#..#.#..#", "#.#####.#", "#..#.#..#", ".###.###."};
    private static final String[] ICON_BACK = {"...#", "..##", ".###", "####", ".###", "..##", "...#"};
    private static final String[] ICON_KEY = {".###...", "#...#..", "#...#..", ".###...", "..#....", "..##...", "..#.#.."};
    private static final String[] ICON_USER = {"..###..", "..###..", "...#...", ".#####.", "#.###.#", "..#.#..", "..#.#.."};

    private static String[] iconFor(Category c) {
        return switch (c) {
            case COMBAT -> ICON_COMBAT;
            case MOVEMENT -> ICON_MOVE;
            case RENDER -> ICON_EYE;
            case VISUALS -> ICON_STAR;
            default -> ICON_BOX;
        };
    }

    private static void icon(DrawContext ctx, String[] rows, int x, int y, int color) {
        for (int j = 0; j < rows.length; j++) {
            String row = rows[j];
            for (int i = 0; i < row.length(); i++) {
                if (row.charAt(i) == '#') ctx.fill(x + i, y + j, x + i + 1, y + j + 1, fa(color));
            }
        }
    }

    private static void check(DrawContext ctx, int x, int y, int color) {
        int[][] px = {{0, 2}, {1, 3}, {2, 4}, {3, 3}, {4, 2}, {5, 1}, {6, 0}};
        for (int[] q : px) ctx.fill(x + q[0], y + q[1], x + q[0] + 1, y + q[1] + 2, fa(color));
    }

    /** Up to two lines of text that fit maxW, the last one cut with "..." if needed. */
    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        String[] words = s.split(" ");
        StringBuilder cur = new StringBuilder();
        int i = 0;
        for (; i < words.length && out.size() < 2; i++) {
            String t = cur.length() == 0 ? words[i] : cur + " " + words[i];
            if (Fonts.guiWidth(textRenderer, t) <= maxW || cur.length() == 0) {
                cur = new StringBuilder(t);
            } else {
                out.add(cur.toString());
                cur = new StringBuilder(words[i]);
                if (out.size() == 2) break;
            }
        }
        if (out.size() < 2 && cur.length() > 0) { out.add(cur.toString()); i = words.length; }
        if (i < words.length && !out.isEmpty()) {
            String last = out.get(out.size() - 1);
            while (last.length() > 1 && Fonts.guiWidth(textRenderer, last + "...") > maxW) last = last.substring(0, last.length() - 1);
            out.set(out.size() - 1, last + "...");
        }
        return out;
    }

    // ------------------------------------------------------------------ geometry

    private int cx() { return winX + SW + 14; }
    private int cw() { return WW - SW - 28; }
    private static final int HEAD_H = 36;
    private int headY() { return winY + 12; }
    private int listTop() { return headY() + HEAD_H + 12; }
    private int listBottom() { return winY + WH - 16; }
    private int cardW() { return (cw() - GAP) / 2; }
    private int navY(int i) { return winY + 76 + i * (ROW + 4); }
    private int configsY() { return navY(cats.size()) + 22; }
    private int themesY() { return configsY() + ROW + 4; }
    private int keybindsY() { return themesY() + ROW + 4; }
    private int accountsY() { return keybindsY() + ROW + 4; }
    private int statusY() { return winY + WH - 58; }
    private int searchBtnX() { return cx() + cw() - 30; }

    private boolean inList(double mx, double my, int top) {
        return in(mx, my, cx(), top, cw(), listBottom() - top);
    }

    private List<Module> visible() {
        if (!query.isEmpty()) {
            String q = query.toLowerCase(Locale.ROOT).replace(" ", "");
            List<Module> out = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                if (m.getName().toLowerCase(Locale.ROOT).replace(" ", "").contains(q)) out.add(m);
            }
            return out;
        }
        return ModuleManager.of(selCat);
    }

    private void refreshCfgs() { cfgs = Config.list(); }

    /** Top of the scrolling area for the current view. */
    private int viewTop() {
        if (openModule != null || tab == Tab.CONFIGS || tab == Tab.KEYBINDS) return listTop() + 24;
        return listTop();
    }

    private int contentHeight() {
        if (openModule != null) return openModule.getSettings().size() * (SET_H + 4);
        if (tab == Tab.CONFIGS) return cfgs.size() * (ROW + 6);
        if (tab == Tab.KEYBINDS) return ModuleManager.all().size() * (KB_H + 4);
        int n = tab == Tab.THEMES ? Theme.values().length : visible().size();
        int rows = (n + 1) / 2;
        int h = tab == Tab.THEMES ? THEME_H : CARD_H;
        return rows == 0 ? 0 : rows * (h + GAP) - GAP;
    }

    private double maxScroll() { return Math.max(0, contentHeight() - (listBottom() - viewTop())); }

    // ------------------------------------------------------------------ typing (polled, layout-independent)

    private void pollTyping() {
        if (client == null) return;
        long win = client.getWindow().getHandle();
        boolean active = searchFocused && Binds.listening() == null;
        long now = System.currentTimeMillis();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_Z; k++) {
            boolean ok = k == GLFW.GLFW_KEY_SPACE || (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) || (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z);
            if (!ok) continue;
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (active && down && !prevKey[k] && query.length() < 20) {
                char ch = k >= GLFW.GLFW_KEY_A ? (char) ('a' + (k - GLFW.GLFW_KEY_A)) : (char) k;
                typed(String.valueOf(ch));
            }
            prevKey[k] = down;
        }
        int bs = GLFW.GLFW_KEY_BACKSPACE;
        boolean down = GLFW.glfwGetKey(win, bs) == GLFW.GLFW_PRESS;
        if (active && down) {
            if (!prevKey[bs]) { backspace(); repeatAt = now + 350; }
            else if (now >= repeatAt) { backspace(); repeatAt = now + 45; }
        }
        prevKey[bs] = down;
    }

    private void typed(String s) {
        query += s;
        tab = Tab.CATEGORY;
        openModule = null;
        scroll = 0;
    }

    private void backspace() {
        if (query.isEmpty()) return;
        query = query.substring(0, query.length() - 1);
        scroll = 0;
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) Ui.drawWorldDim(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
        GuiImage.draw(ctx, width, height);                       // GUI Image module: picture in the bottom-right corner
        GuiImage.drawAddButton(ctx, width, height);
    }

    // Dropping a png / jpg on the open ClickGUI sets the GUI Image (the method name differs between mappings).
    public void filesDragged(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    public void onFilesDropped(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        double p = animProgress();
        if (closing && p <= 0) return;                         // finished: tick() closes the screen
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (p >= 1 || am == null || !am.isEnabled()) { renderGui(ctx, mx, my); return; }

        GuiAnimationModule.Pose pose = am.pose(p, winX, winY, WW, WH, width, height);
        float cx = winX + WW / 2f, cy = winY + WH / 2f;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) pose.dx(), (float) pose.dy());
        m.translate(cx, cy);
        m.scale((float) pose.scale(), (float) pose.scale());
        m.translate(-cx, -cy);
        fadeA = (float) pose.alpha();
        try {
            renderGui(ctx, mx, my);
        } finally {
            fadeA = 1f;
            m.popMatrix();
        }
    }

    /** How much of the window is shown, 0..1: grows while opening, shrinks while closing. 1 when there is no animation. */
    private double animProgress() {
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (am == null || !am.isEnabled()) return closing ? 0 : 1;
        double t = Math.min(1.0, (System.nanoTime() - (closing ? closeStart : animStart)) / 1.0e6 / am.durationMs());
        return closing ? 1 - t : t;
    }

    private boolean animating() { return closing || animProgress() < 1; }

    @Override
    public void close() {
        if (closing) return;
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (am != null && am.isEnabled() && am.closeAnimation.get()) {
            closing = true;                                    // the real close happens in tick() once it has played
            closeStart = System.nanoTime();
        } else {
            super.close();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!closing && client != null && GuiStyleModule.style() != GuiStyleModule.CLASSIC) {   // style changed in the settings
            client.setScreen(GuiStyleModule.create());
            return;
        }
        if (closing && animProgress() <= 0) super.close();
    }

    private void renderGui(DrawContext ctx, int mx, int my) {
        pollTyping();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));

        GlassMenuModule gm = ModuleManager.get(GlassMenuModule.class);
        glass = gm != null && gm.isEnabled();
        if (LiquidGlass.on()) {
            glass = true;                                        // the cards inside use their glass look too
            LiquidGlass.card(ctx, winX, winY, WW, WH, 10, 1f);
        } else if (glass) {
            // Smoked glass: translucent tinted pane, bright rim, soft light band along the top edge.
            int a = (int) (gm.opacity.get() * 2.55);
            int body = mix(0xFF0B0D14, accent(), (float) (gm.tint.get() / 100.0) * 0.5f);
            rrect(ctx, winX, winY, WW, WH, (a << 24) | (body & 0xFFFFFF), 6);
            if (gm.shine.get()) {
                ctx.fillGradient(winX + 2, winY + 6, winX + WW - 2, winY + 6 + WH * 2 / 5, fa(0x30FFFFFF), fa(0x00FFFFFF));
            }
            if (gm.border.get()) {
                outline(ctx, winX, winY, WW, WH, 0x70FFFFFF, 6);
                outline(ctx, winX + 1, winY + 1, WW - 2, WH - 2, 0x14FFFFFF, 5);
            }
        } else {
            rrect(ctx, winX - 1, winY - 1, WW + 2, WH + 2, 0x33FFFFFF, 7);
            rrect(ctx, winX, winY, WW, WH, WIN_BG, 6);
        }
        ctx.fill(winX + SW, winY + 8, winX + SW + 1, winY + WH - 8, fa(0x22FFFFFF));

        renderSidebar(ctx, mx, my);
        renderTopBar(ctx, mx, my);

        if (openModule != null) renderSettings(ctx, mx, my);
        else if (tab == Tab.CONFIGS) renderConfigs(ctx, mx, my);
        else if (tab == Tab.THEMES) renderThemes(ctx, mx, my);
        else if (tab == Tab.KEYBINDS) renderKeybinds(ctx, mx, my);
        else renderModules(ctx, mx, my);

        text(ctx, tab == Tab.KEYBINDS && openModule == null ? "ЛКМ назначить   ПКМ сбросить" : "ЛКМ вкл   ПКМ настройки   СКМ бинд", cx(), winY + WH - 12, 0xFF5E5E6B);
        if (infoMod != null && openModule == null && tab == Tab.CATEGORY) renderInfo(ctx);
    }

    /** Where the state icon sits: right after the module name. */
    private int stateX(Module m, int x) { return x + 7 + Fonts.guiWidth(textRenderer, m.getName()) + 4; }

    /** Where the info button sits: right after the state icon. */
    private int infoX(Module m, int x) { return stateX(m, x) + 9 + 4; }

    /** The info panel: name, state, bind and the full description, drawn over the module list. */
    private void renderInfo(DrawContext ctx) {
        Module m = infoMod;
        int x = cx(), y = listTop(), w = cw(), h = listBottom() - listTop();
        int acc = accent();
        rrect(ctx, x, y, w, h, 0xF2101016, 6);
        outline(ctx, x, y, w, h, acc | 0xFF000000, 6);
        text(ctx, m.getName(), x + 10, y + 10, WHITE);
        String state = m.isEnabled() ? "Включён" : "Выключен";
        text(ctx, state, x + 10, y + 24, m.isEnabled() ? acc | 0xFF000000 : MUTED);
        String bind = "Бинд: " + (m.getKey() == -1 ? "не назначен" : Binds.name(m.getKey()));
        text(ctx, bind, x + 10 + Fonts.guiWidth(textRenderer, state) + 14, y + 24, MUTED);
        String d = ModuleInfo.desc(m);
        List<String> lines = wrapAll(d.isEmpty() ? "Описания нет" : d, w - 20);
        for (int i = 0; i < lines.size() && y + 46 + i * 11 < y + h - 18; i++) {
            text(ctx, lines.get(i), x + 10, y + 46 + i * 11, SOFT);
        }
        text(ctx, "Нажми, чтобы закрыть", x + 10, y + h - 14, 0xFF5E5E6B);
    }

    /** Word wrap with no line limit (the info panel shows the whole description). */
    private List<String> wrapAll(String s, int maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (cur.length() > 0 && Fonts.guiWidth(textRenderer, t) > maxW) {
                out.add(cur.toString());
                cur = new StringBuilder(word);
            } else {
                cur = new StringBuilder(t);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void navRow(DrawContext ctx, int mx, int my, int y, String[] ic, String label, boolean selected) {
        int x = winX + 10, w = SW - 20;
        boolean hover = in(mx, my, x, y, w, ROW);
        if (selected) accentRect(ctx, x, y, w, ROW, 6);
        else if (hover) rrect(ctx, x, y, w, ROW, 0x18FFFFFF, 6);
        icon(ctx, ic, x + 10, y + ROW / 2 - 3, selected ? WHITE : SOFT);
        text(ctx, label, x + 24, y + ROW / 2 - 3, selected ? WHITE : SOFT);
    }

    private void groupLabel(DrawContext ctx, int y, String s) { text(ctx, s, winX + 12, y, MUTED); }

    private void renderSidebar(DrawContext ctx, int mx, int my) {
        Ui.drawLogo(ctx, winX + 14, winY + 14, 26, fa(Theme.current().accent() | 0xFF000000));
        text(ctx, "Deathclient", winX + 48, winY + 21, WHITE);

        groupLabel(ctx, winY + 60, "Main");
        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            navRow(ctx, mx, my, navY(i), iconFor(c), c.label, tab == Tab.CATEGORY && query.isEmpty() && c == selCat);
        }
        groupLabel(ctx, navY(cats.size()) + 10, "Other");
        navRow(ctx, mx, my, configsY(), ICON_FOLDER, "Config", tab == Tab.CONFIGS);
        navRow(ctx, mx, my, keybindsY(), ICON_KEY, "Keybinds", tab == Tab.KEYBINDS);
        navRow(ctx, mx, my, themesY(), ICON_DROP, "Themes", tab == Tab.THEMES);
        navRow(ctx, mx, my, accountsY(), ICON_USER, "Accounts", false);

        // Bottom status panel: client name + connection state, click opens Accounts.
        int sx = winX + 10, sy = statusY(), sw = SW - 20, sh = 44;
        boolean hover = in(mx, my, sx, sy, sw, sh);
        cardBox(ctx, sx, sy, sw, sh, cardLine(), hover ? cardHover() : cardBg(), 7);
        Ui.drawLogo(ctx, sx + 8, sy + 8, 26, fa(Theme.current().accent() | 0xFF000000));
        text(ctx, "Deathclient", sx + 42, sy + 10, WHITE);
        boolean online = client != null && client.player != null;
        text(ctx, online ? "Connected" : "Offline", sx + 42, sy + 22, online ? (accent() | 0xFF000000) : MUTED);
        icon(ctx, ICON_GEAR, sx + sw - 20, sy + sh / 2 - 3, SOFT);
    }

    private void renderTopBar(DrawContext ctx, int mx, int my) {
        int hx = cx(), hy = headY(), hw = cw();
        cardBox(ctx, hx, hy, hw, HEAD_H, cardLine(), cardBg(), 7);

        String title, desc;
        if (!query.isEmpty()) { title = "Search"; desc = "\"" + query + "\""; }
        else if (tab == Tab.CONFIGS) { title = "Config"; desc = "Save, load and manage your setups."; }
        else if (tab == Tab.THEMES) { title = "Themes"; desc = "Pick the accent colour of the client."; }
        else if (tab == Tab.KEYBINDS) { title = "Keybinds"; desc = "Bind any module to a key."; }
        else { title = selCat.label; desc = catDesc(selCat); }

        int tx = hx + PAD;
        text(ctx, title, tx, hy + HEAD_H / 2 - 4, WHITE);
        tx += Fonts.guiWidth(textRenderer, title) + 10;
        text(ctx, "/", tx, hy + HEAD_H / 2 - 4, accent() | 0xFF000000);
        tx += 10;
        text(ctx, desc, tx, hy + HEAD_H / 2 - 4, SOFT);

        int bx = searchBtnX(), by = hy + (HEAD_H - 20) / 2;
        boolean focused = searchFocused;
        rrect(ctx, bx, by, 20, 20, focused ? fieldFocus() : (in(mx, my, bx, by, 20, 20) ? cardHover() : field()), 5);
        icon(ctx, ICON_SEARCH, bx + 6, by + 6, focused || !query.isEmpty() ? (accent() | 0xFF000000) : MUTED);
        if (focused) {
            // The query lives in the header title itself above ("Search" / "query"); this is just a blinking caret cue.
            boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
            if (blink) ctx.fill(bx + 9, by + 14, bx + 11, by + 16, fa(WHITE));
        }
    }

    private static String catDesc(Category c) {
        return switch (c) {
            case COMBAT -> "Enhance your PvP performance with advanced combat modules.";
            case MOVEMENT -> "Move faster, further and in ways vanilla never allowed.";
            case RENDER -> "Change what you see and how the world is drawn.";
            case VISUALS -> "Cosmetic flair for your client and your screen.";
            default -> "Everything else that doesn't fit elsewhere.";
        };
    }

    private int menuX(int x) { return x + cardW() - PAD - MENU_BTN - 6 - SW_W; }
    private int toggleX(int x) { return x + cardW() - PAD - SW_W; }

    private void toggleSwitch(DrawContext ctx, int x, int y, boolean on) {
        int acc = accent();
        rrect(ctx, x, y, SW_W, SW_H, on ? acc : track(), SW_H / 2);
        rrect(ctx, on ? x + SW_W - SW_H + 2 : x + 2, y + 2, SW_H - 4, SW_H - 4, WHITE, (SW_H - 4) / 2);
    }

    private void dotsMenu(DrawContext ctx, int x, int y, int size, int color) {
        int cyy = y + size / 2;
        for (int i = -1; i <= 1; i++) ctx.fill(x + size / 2 + i * 5 - 1, cyy - 1, x + size / 2 + i * 5 + 1, cyy + 1, fa(color));
    }

    private void renderModules(DrawContext ctx, int mx, int my) {
        List<Module> mods = visible();
        int cw = cardW(), acc = accent();
        ctx.enableScissor(cx(), listTop(), cx() + cw(), listBottom());
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            if (y + CARD_H < listTop() || y > listBottom()) continue;
            boolean hover = inList(mx, my, listTop()) && in(mx, my, x, y, cw, CARD_H);
            boolean on = m.isEnabled();

            cardBox(ctx, x, y, cw, CARD_H, on ? (acc | 0xFF000000) : cardLine(), hover ? cardHover() : cardBg(), 8);

            // Icon chip (category icon), top-left.
            rrect(ctx, x + PAD, y + PAD, CHIP, CHIP, mix(acc, 0xFF000000, 0.55f) | 0xFF000000, 7);
            outline(ctx, x + PAD, y + PAD, CHIP, CHIP, (0x80 << 24) | (acc & 0xFFFFFF), 7);
            icon(ctx, iconFor(selCatOf(m)), x + PAD + CHIP / 2 - 3, y + PAD + CHIP / 2 - 3, acc | 0xFF000000);

            text(ctx, m.getName(), x + PAD + CHIP + 10, y + PAD + 2, WHITE);

            boolean menuHover = in(mx, my, menuX(x), y + PAD, MENU_BTN, MENU_BTN);
            rrect(ctx, menuX(x), y + PAD, MENU_BTN, MENU_BTN, menuHover ? cardHover() : 0x00000000, 5);
            dotsMenu(ctx, menuX(x), y + PAD, MENU_BTN, SOFT);

            toggleSwitch(ctx, toggleX(x), y + PAD + (MENU_BTN - SW_H) / 2, on);

            List<String> lines = wrap(ModuleInfo.desc(m), cw - 2 * PAD);
            for (int l = 0; l < lines.size(); l++) {
                text(ctx, lines.get(l), x + PAD, y + PAD + CHIP + 8 + l * 11, SOFT);
            }

            if (m.getKey() != -1) {
                String k = "[" + Binds.name(m.getKey()) + "]";
                text(ctx, k, x + cw - PAD - Fonts.guiWidth(textRenderer, k), y + CARD_H - 13, MUTED);
            }
        }
        ctx.disableScissor();
        if (mods.isEmpty()) text(ctx, query.isEmpty() ? "Здесь пока пусто" : "Ничего не найдено", cx() + 4, listTop() + 6, MUTED);
    }

    /** The category a module belongs to, for its card icon (falls back to the selected tab). */
    private Category selCatOf(Module m) {
        for (Category c : Category.values()) if (ModuleManager.of(c).contains(m)) return c;
        return selCat;
    }

    /** The wheel's on-screen geometry for the i-th colour of the open Custom Theme module. */
    private int wheelCx(int i) { return cx() + 44; }
    private int wheelCy(int i) { return viewTop() + 30 + i * WHEEL_BLOCK - (int) scroll; }
    private static final int WHEEL_R = 34, WHEEL_BLOCK = 118;

    private void renderCustomThemeSettings(DrawContext ctx, int mx, int my) {
        Module m = openModule;
        List<Setting> all = m.getSettings();                 // Hue,Sat,Bri x4, in order
        int acc = accent();
        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        for (int i = 0; i * 3 + 2 < all.size(); i++) {
            NumberSetting hue = (NumberSetting) all.get(i * 3), sat = (NumberSetting) all.get(i * 3 + 1), bri = (NumberSetting) all.get(i * 3 + 2);
            int cxp = wheelCx(i), cyp = wheelCy(i);
            if (cyp - WHEEL_R > listBottom() || cyp + WHEEL_R + 30 < vt) continue;

            text(ctx, "Цвет " + (i + 1), cx(), cyp - WHEEL_R - 12, WHITE);
            ColorWheel.id();                                  // make sure the texture exists before we draw it
            int wr = WHEEL_R * 2;
            ctx.drawTexture(net.minecraft.client.gl.RenderPipelines.GUI_TEXTURED, ColorWheel.id(),
                    cxp - WHEEL_R, cyp - WHEEL_R, 0f, 0f, wr, wr, ColorWheel.size(), ColorWheel.size(), ColorWheel.size(), ColorWheel.size(), 0xFFFFFFFF);
            double ang = Math.toRadians(hue.get());
            double rr = sat.get() * WHEEL_R;
            int kx = cxp + (int) Math.round(Math.cos(ang) * rr), ky = cyp - (int) Math.round(Math.sin(ang) * rr);
            int knobCol = ColorWheel.hsb(hue.get(), sat.get(), 1.0) | 0xFF000000;
            rrect(ctx, kx - 5, ky - 5, 10, 10, WHITE, 5);
            rrect(ctx, kx - 3, ky - 3, 6, 6, knobCol, 3);

            int sx = cxp + WHEEL_R + 14, sw = cx() + cw() - sx - 6, sy = cyp - 6;
            String briLabel = "Яркость";
            text(ctx, briLabel, sx, cyp - WHEEL_R - 12, WHITE);
            int preview = ColorWheel.hsb(hue.get(), sat.get(), bri.get()) | 0xFF000000;
            rrect(ctx, sx, cyp - WHEEL_R, 18, 18, preview, 4);
            outline(ctx, sx, cyp - WHEEL_R, 18, 18, 0x80000000, 4);
            int trackX = sx, trackW = Math.max(20, sw), ty = sy;
            double low = ColorWheel.hsb(hue.get(), sat.get(), 0.0);
            rrect(ctx, trackX, ty, trackW, 6, mix(0xFF000000, preview, 0.15f), 3);
            rrect(ctx, trackX, ty, trackW, 6, preview, 3);
            int fillW = (int) (trackW * bri.get());
            outline(ctx, trackX, ty, trackW, 6, 0x60000000, 3);
            int kx2 = trackX + fillW;
            rrect(ctx, kx2 - 3, ty - 3, 6, 12, WHITE, 3);
        }
        ctx.disableScissor();
    }

    private void renderSettings(DrawContext ctx, int mx, int my) {
        Module m = openModule;
        if (m instanceof CustomThemeModule) {
            int top0 = listTop();
            rrect(ctx, cx(), top0, 20, 18, in(mx, my, cx(), top0, 20, 18) ? cardHover() : cardBg(), 5);
            icon(ctx, ICON_BACK, cx() + 8, top0 + 5, WHITE);
            text(ctx, m.getName(), cx() + 27, top0 + 5, WHITE);
            renderCustomThemeSettings(ctx, mx, my);
            return;
        }
        int acc = accent();
        int top = listTop();
        rrect(ctx, cx(), top, 20, 18, in(mx, my, cx(), top, 20, 18) ? cardHover() : cardBg(), 5);
        icon(ctx, ICON_BACK, cx() + 8, top + 5, WHITE);
        text(ctx, m.getName(), cx() + 27, top + 5, WHITE);
        String bind = Binds.listening() == m ? "Нажми любую кнопку..." : "Бинд: " + Binds.name(m.getKey());
        text(ctx, bind, cx() + cw() - 4 - Fonts.guiWidth(textRenderer, bind), top + 5, MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (Setting s : m.getSettings()) {
            if (y + SET_H >= vt && y <= listBottom()) {
                rrect(ctx, cx(), y, cw(), SET_H, cardBg(), 5);
                if (s instanceof BoolSetting b) {
                    text(ctx, b.name, cx() + 8, y + 9, WHITE);
                    int tx = cx() + cw() - 8 - 22, ty = y + 8;
                    rrect(ctx, tx, ty, 22, 11, b.get() ? acc : track(), 5);
                    rrect(ctx, b.get() ? tx + 12 : tx + 1, ty + 1, 9, 9, WHITE, 4);
                } else if (s instanceof ButtonSetting bs) {
                    rrect(ctx, cx() + 6, y + 4, cw() - 12, SET_H - 8, acc, 4);
                    String bt = bs.name;
                    text(ctx, bt, cx() + cw() / 2 - Fonts.guiWidth(textRenderer, bt) / 2, y + 9, WHITE);
                } else if (s instanceof NumberSetting n) {
                    text(ctx, n.name, cx() + 8, y + 4, WHITE);
                    String v = n.label() != null ? n.label() : String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
                    text(ctx, v, cx() + cw() - 8 - Fonts.guiWidth(textRenderer, v), y + 4, MUTED);
                    int trackX = cx() + 8, trackW = cw() - 16, ty = y + SET_H - 8;
                    int fillW = (int) (trackW * (n.get() - n.min) / (n.max - n.min));
                    rrect(ctx, trackX, ty, trackW, 3, track(), 1);
                    rrect(ctx, trackX, ty, Math.max(2, fillW), 3, acc, 1);
                    rrect(ctx, trackX + fillW - 3, ty - 2, 6, 7, WHITE, 2);
                }
            }
            y += SET_H + 4;
        }
        ctx.disableScissor();
        if (m.getSettings().isEmpty()) text(ctx, "У этого модуля нет настроек", cx() + 4, vt + 6, MUTED);
    }

    private void renderConfigs(DrawContext ctx, int mx, int my) {
        int top = listTop(), acc = accent();
        rrect(ctx, cx(), top, 86, 18, in(mx, my, cx(), top, 86, 18) ? acc : cardBg(), 5);
        text(ctx, "Сохранить", cx() + 43 - Fonts.guiWidth(textRenderer, "Сохранить") / 2, top + 5, WHITE);
        rrect(ctx, cx() + 92, top, 60, 18, in(mx, my, cx() + 92, top, 60, 18) ? acc : cardBg(), 5);
        text(ctx, "Новый", cx() + 122 - Fonts.guiWidth(textRenderer, "Новый") / 2, top + 5, WHITE);
        String cur = "Текущий: " + Config.currentName();
        text(ctx, cur, cx() + cw() - 4 - Fonts.guiWidth(textRenderer, cur), top + 5, MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (String name : cfgs) {
            boolean active = name.equals(Config.currentName());
            boolean hover = inList(mx, my, vt) && in(mx, my, cx(), y, cw(), ROW + 2);
            rrect(ctx, cx(), y, cw(), ROW + 2, active ? mix(acc, 0xFF000000, 0.45f) : (hover ? cardHover() : cardBg()), 5);
            text(ctx, name, cx() + 8, y + 6, WHITE);
            if (active) check(ctx, cx() + cw() - 16, y + 5, WHITE);
            y += ROW + 6;
        }
        ctx.disableScissor();
        if (cfgs.isEmpty()) text(ctx, "Конфигов нет. Нажми «Сохранить».", cx() + 4, vt + 6, MUTED);
        else text(ctx, "ЛКМ загрузить   ПКМ удалить", cx() + cw() - 4 - Fonts.guiWidth(textRenderer, "ЛКМ загрузить   ПКМ удалить"), winY + WH - 12, 0xFF5E5E6B);
    }

    private void renderThemes(DrawContext ctx, int mx, int my) {
        Theme[] themes = Theme.values();
        int cw = cardW();
        ctx.enableScissor(cx(), listTop(), cx() + cw(), listBottom());
        for (int i = 0; i < themes.length; i++) {
            Theme t = themes[i];
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (THEME_H + GAP) - (int) scroll;
            boolean active = t == Theme.current();
            boolean hover = inList(mx, my, listTop()) && in(mx, my, x, y, cw, THEME_H);
            cardBox(ctx, x, y, cw, THEME_H, active ? t.accent() : cardLine(), hover ? cardHover() : cardBg(), 7);
            gradRect(ctx, x + 8, y + 8, THEME_H - 16, THEME_H - 16, 6, t, 0f, 1f, 255);
            text(ctx, t.label, x + THEME_H - 2, y + THEME_H / 2 - 4, WHITE);
            if (active) check(ctx, x + cw - 16, y + THEME_H / 2 - 3, WHITE);
        }
        ctx.disableScissor();
    }

    // ------------------------------------------------------------------ input

    private void openSettings(Module m) {
        if (m.getSettings().isEmpty()) return;
        openModule = m;
        scroll = 0;
    }

    private void selectTab(Tab t) {
        tab = t;
        openModule = null;
        query = "";
        scroll = 0;
        searchFocused = false;
        if (t == Tab.CONFIGS) refreshCfgs();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (animating()) return true;                          // no clicks while the window is moving

        if (!in(mx, my, winX, winY, WW, WH)) {
            searchFocused = false;
            if (btn == 0 && GuiImage.clickAddButton(mx, my, width, height)) return true;
            if (btn == 0 && GuiImage.press(mx, my, width, height)) return true;
            return super.mouseClicked(click, doubled);
        }

        // Drag the window by the logo area.
        if (btn == 0 && in(mx, my, winX, winY, SW, 36)) {
            draggingWin = true;
            dragDX = mx - winX;
            dragDY = my - winY;
            return true;
        }

        // Sidebar.
        if (btn == 0) {
            int x = winX + 10, w = SW - 20;
            for (int i = 0; i < cats.size(); i++) {
                if (in(mx, my, x, navY(i), w, ROW)) {
                    selCat = cats.get(i);
                    selectTab(Tab.CATEGORY);
                    return true;
                }
            }
            if (in(mx, my, x, configsY(), w, ROW)) { selectTab(Tab.CONFIGS); return true; }
            if (in(mx, my, x, themesY(), w, ROW)) { selectTab(Tab.THEMES); return true; }
            if (in(mx, my, x, keybindsY(), w, ROW)) { selectTab(Tab.KEYBINDS); return true; }
            if (in(mx, my, x, accountsY(), w, ROW)) { client.setScreen(new AccountsScreen(this)); return true; }
        }

        // Header search button.
        int bx = searchBtnX(), by = headY() + (HEAD_H - 20) / 2;
        if (btn == 0 && in(mx, my, bx, by, 20, 20)) { searchFocused = !searchFocused; return true; }
        searchFocused = false;

        // Bottom status panel -> Accounts.
        if (btn == 0 && in(mx, my, winX + 10, statusY(), SW - 20, 44)) { client.setScreen(new AccountsScreen(this)); return true; }

        if (openModule != null) return clickSettings(mx, my, btn);
        if (tab == Tab.CONFIGS) return clickConfigs(mx, my, btn);
        if (tab == Tab.THEMES) return clickThemes(mx, my, btn);
        if (tab == Tab.KEYBINDS) return clickKeybinds(mx, my, btn);
        return clickModules(mx, my, btn);
    }

    private boolean clickModules(double mx, double my, int btn) {
        if (infoMod != null) {                                   // a click closes the info panel
            infoMod = null;
            return true;
        }
        if (!inList(mx, my, listTop())) return true;
        List<Module> mods = visible();
        int cw = cardW();
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            if (!in(mx, my, x, y, cw, CARD_H)) continue;
            if (btn == 0 && in(mx, my, menuX(x), y + PAD, MENU_BTN, MENU_BTN)) { openSettings(m); return true; }
            if (btn == 0 && in(mx, my, toggleX(x), y + PAD, SW_W, MENU_BTN)) { m.toggle(); return true; }
            if (btn == 0) m.toggle();
            else if (btn == 1) openSettings(m);
            else if (btn == 2) Binds.listen(m);
            return true;
        }
        return true;
    }

    private boolean clickCustomThemeSettings(double mx, double my, int btn) {
        Module m = openModule;
        List<Setting> all = m.getSettings();
        for (int i = 0; i * 3 + 2 < all.size(); i++) {
            NumberSetting hue = (NumberSetting) all.get(i * 3), sat = (NumberSetting) all.get(i * 3 + 1), bri = (NumberSetting) all.get(i * 3 + 2);
            int cxp = wheelCx(i), cyp = wheelCy(i);
            double dx = mx - cxp, dy = my - cyp;
            if (btn == 0 && Math.sqrt(dx * dx + dy * dy) <= WHEEL_R + 4) {
                wheelHue = hue; wheelSat = sat;
                wheelDragCx = cxp; wheelDragCy = cyp;
                double[] hs = ColorWheel.pick(dx, dy, WHEEL_R);
                hue.set(hs[0]); sat.set(hs[1]);
                return true;
            }
            int sx = cxp + WHEEL_R + 14, sy = cyp - 6, sw = cx() + cw() - sx - 6, trackW = Math.max(20, sw);
            if (btn == 0 && in(mx, my, sx, sy - 4, trackW, 14)) {
                briSetting = bri;
                briTrackX = sx; briTrackW = trackW;
                bri.set(Math.max(0, Math.min(1, (mx - sx) / (double) trackW)));
                return true;
            }
        }
        return true;
    }

    private boolean clickSettings(double mx, double my, int btn) {
        Module m = openModule;
        int top = listTop();
        if (m instanceof CustomThemeModule) {
            if (btn == 0 && in(mx, my, cx(), top, 20, 18)) { openModule = null; scroll = 0; return true; }
            return clickCustomThemeSettings(mx, my, btn);
        }
        if (btn == 0 && in(mx, my, cx(), top, 20, 18)) { openModule = null; scroll = 0; return true; }
        String bind = Binds.listening() == m ? "Нажми любую кнопку..." : "Бинд: " + Binds.name(m.getKey());
        int bw = Fonts.guiWidth(textRenderer, bind);
        if (btn == 0 && in(mx, my, cx() + cw() - 4 - bw - 2, top, bw + 6, 18)) { Binds.listen(m); return true; }

        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (Setting s : m.getSettings()) {
            if (btn == 0 && in(mx, my, cx(), y, cw(), SET_H)) {
                if (s instanceof BoolSetting b) b.toggle();
                else if (s instanceof ButtonSetting bs) bs.run();
                else if (s instanceof NumberSetting n) { dragSetting = n; updateSlider(mx); }
                return true;
            }
            y += SET_H + 4;
        }
        return true;
    }

    private boolean clickConfigs(double mx, double my, int btn) {
        int top = listTop();
        if (btn == 0 && in(mx, my, cx(), top, 86, 18)) {
            Config.save(Config.currentName());
            refreshCfgs();
            return true;
        }
        if (btn == 0 && in(mx, my, cx() + 92, top, 60, 18)) {
            int n = 1;
            while (cfgs.contains("cfg" + n)) n++;
            Config.save("cfg" + n);
            refreshCfgs();
            return true;
        }
        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (String name : new ArrayList<>(cfgs)) {
            if (in(mx, my, cx(), y, cw(), ROW + 2)) {
                if (btn == 0) Config.load(name);
                else if (btn == 1) { Config.delete(name); refreshCfgs(); }
                return true;
            }
            y += ROW + 6;
        }
        return true;
    }

    private boolean clickThemes(double mx, double my, int btn) {
        if (btn != 0 || !inList(mx, my, listTop())) return true;
        Theme[] themes = Theme.values();
        int cw = cardW();
        for (int i = 0; i < themes.length; i++) {
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (THEME_H + GAP) - (int) scroll;
            if (in(mx, my, x, y, cw, THEME_H)) { Theme.set(themes[i]); return true; }
        }
        return true;
    }

    private void renderKeybinds(DrawContext ctx, int mx, int my) {
        int top = listTop(), acc = accent();
        boolean lm = Binds.listeningMenu();
        boolean hover = in(mx, my, cx(), top, cw(), 18);
        rrect(ctx, cx(), top, cw(), 18, lm ? acc : (hover ? cardHover() : cardBg()), 5);
        text(ctx, "Клавиша меню", cx() + 8, top + 5, WHITE);
        String mk = lm ? "Нажми любую кнопку..." : "[" + Binds.name(Binds.menuKey()) + "]";
        text(ctx, mk, cx() + cw() - 8 - Fonts.guiWidth(textRenderer, mk), top + 5, lm ? WHITE : MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (Module m : ModuleManager.all()) {
            if (y + KB_H >= vt && y <= listBottom()) {
                boolean listening = Binds.listening() == m;
                boolean h = inList(mx, my, vt) && in(mx, my, cx(), y, cw(), KB_H);
                rrect(ctx, cx(), y, cw(), KB_H, listening ? acc : (h ? cardHover() : cardBg()), 5);
                text(ctx, m.getName(), cx() + 8, y + 5, WHITE);
                String k = listening ? "Нажми любую кнопку..." : (m.getKey() == -1 ? "none" : "[" + Binds.name(m.getKey()) + "]");
                int col = listening ? WHITE : (m.getKey() == -1 ? 0xFF5E5E6B : mix(acc, WHITE, 0.6f));
                text(ctx, k, cx() + cw() - 8 - Fonts.guiWidth(textRenderer, k), y + 5, col);
            }
            y += KB_H + 4;
        }
        ctx.disableScissor();
    }

    private boolean clickKeybinds(double mx, double my, int btn) {
        int top = listTop();
        if (btn == 0 && in(mx, my, cx(), top, cw(), 18)) { Binds.listenMenu(); return true; }
        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (Module m : ModuleManager.all()) {
            if (in(mx, my, cx(), y, cw(), KB_H)) {
                if (btn == 0) Binds.listen(m);
                else if (btn == 1) { m.setKey(-1); Binds.save(); }
                return true;
            }
            y += KB_H + 4;
        }
        return true;
    }

    private void updateSlider(double mx) {
        double t = Math.max(0, Math.min(1, (mx - (cx() + 8)) / (cw() - 16)));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (GuiImage.drag(click.x(), click.y(), width, height)) return true;
        if (draggingWin) {
            winX = clamp((int) (click.x() - dragDX), 0, Math.max(0, width - WW));
            winY = clamp((int) (click.y() - dragDY), 0, Math.max(0, height - WH));
            return true;
        }
        if (dragSetting != null) {
            updateSlider(click.x());
            return true;
        }
        if (wheelHue != null) {
            double dx = click.x() - wheelDragCx, dy = click.y() - wheelDragCy;
            double[] hs = ColorWheel.pick(dx, dy, WHEEL_R);
            wheelHue.set(hs[0]);
            wheelSat.set(hs[1]);
            return true;
        }
        if (briSetting != null) {
            briSetting.set(Math.max(0, Math.min(1, (click.x() - briTrackX) / (double) briTrackW)));
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        GuiImage.release();
        draggingWin = false;
        dragSetting = null;
        wheelHue = null;
        wheelSat = null;
        briSetting = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (in(mouseX, mouseY, winX + SW, winY, WW - SW, WH)) {
            scroll = Math.max(0, Math.min(scroll - verticalAmount * 14, maxScroll()));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() { return false; }
}
