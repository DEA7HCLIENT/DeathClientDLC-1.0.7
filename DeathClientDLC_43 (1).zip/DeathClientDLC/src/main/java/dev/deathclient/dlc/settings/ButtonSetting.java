package dev.deathclient.dlc;

/** A button in a module's settings: a click runs the action (for example, open a folder). */
public class ButtonSetting extends Setting {
    private final Runnable action;

    public ButtonSetting(String name, Runnable action) {
        super(name);
        this.action = action;
    }

    public void run() { action.run(); }
}
