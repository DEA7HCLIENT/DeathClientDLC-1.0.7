package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/**
 * ElytraHelper: bind a key to it. A press puts the elytra on (your chestplate goes into the slot the elytra came from),
 * starts the glide when you are in the air and, with "Firework" on, uses a rocket from the hotbar. Then it switches itself off.
 */
public class ElytraHelperModule extends Module {
    public final BoolSetting firework = add(new BoolSetting("Firework", true));

    public ElytraHelperModule() { super("ElytraHelper", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p != null && c.interactionManager != null) run(c, p);
        toggle();
    }

    private void run(MinecraftClient c, ClientPlayerEntity p) {
        if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            for (int i = 0; i < 36; i++) {
                if (!p.getInventory().getStack(i).isOf(Items.ELYTRA)) continue;
                int slot = i < 9 ? 36 + i : i, sync = p.playerScreenHandler.syncId;
                c.interactionManager.clickSlot(sync, slot, 0, SlotActionType.PICKUP, p);   // pick the elytra up
                c.interactionManager.clickSlot(sync, 6, 0, SlotActionType.PICKUP, p);      // chest slot: swap with the chestplate
                c.interactionManager.clickSlot(sync, slot, 0, SlotActionType.PICKUP, p);   // the chestplate goes where the elytra was
                break;
            }
        }
        if (!p.isOnGround() && !p.isGliding())
            p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        if (firework.get()) {
            int slot = Util.findHotbar(p, Items.FIREWORK_ROCKET);
            if (slot >= 0) {
                int prev = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                c.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.getInventory().setSelectedSlot(prev);
            }
        }
    }
}
