package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.lwjgl.glfw.GLFW;

/**
 * Keystrokes: W / A S D, LMB RMB and SPACE keys on the screen. A pressed key lights up in the theme colour
 * (with a short fade). Drag it while the chat is open (HUD editor).
 */
public class KeystrokesModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 120, 0, 1200, 1));
    public final BoolSetting mouse = add(new BoolSetting("Mouse buttons", true));
    public final BoolSetting space = add(new BoolSetting("Space", true));

    private static final int BG = 0xC0120C1E, WHITE = 0xFFFFFFFF, MUTED = 0xFFB9B2C8;
    private static final float[] ANIM = new float[7];     // W A S D LMB RMB SPACE
    private static long last;

    public KeystrokesModule() { super("Keystrokes", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        KeystrokesModule m = ModuleManager.get(KeystrokesModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        var tr = c.textRenderer;
        boolean free = c.currentScreen == null;
        long window = c.getWindow().getHandle();
        boolean[] down = {
                free && c.options.forwardKey.isPressed(), free && c.options.leftKey.isPressed(),
                free && c.options.backKey.isPressed(), free && c.options.rightKey.isPressed(),
                free && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS,
                free && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS,
                free && c.options.jumpKey.isPressed()};
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        float k = 1f - (float) Math.exp(-dt * 22f);
        for (int i = 0; i < ANIM.length; i++) ANIM[i] += ((down[i] ? 1f : 0f) - ANIM[i]) * k;

        int s = 26, g = 3, r = 5;
        int w = s * 3 + g * 2;
        int h = s * 2 + g + (mouse.get() ? g + 22 : 0) + (space.get() ? g + 18 : 0);
        int x0 = (int) x.get(), y0 = (int) y.get();
        HudEdit.track(x0, y0, w, h, (nx, ny) -> { x.set(nx); y.set(ny); });

        int yy = y0;
        key(ctx, tr, "W", x0 + s + g, yy, s, s, r, ANIM[0]);
        yy += s + g;
        key(ctx, tr, "A", x0, yy, s, s, r, ANIM[1]);
        key(ctx, tr, "S", x0 + s + g, yy, s, s, r, ANIM[2]);
        key(ctx, tr, "D", x0 + (s + g) * 2, yy, s, s, r, ANIM[3]);
        yy += s + g;
        if (mouse.get()) {
            int bw = (w - g) / 2;
            key(ctx, tr, "LMB", x0, yy, bw, 22, r, ANIM[4]);
            key(ctx, tr, "RMB", x0 + bw + g, yy, w - bw - g, 22, r, ANIM[5]);
            yy += 22 + g;
        }
        if (space.get()) key(ctx, tr, "SPACE", x0, yy, w, 18, r, ANIM[6]);
    }

    private static void key(DrawContext ctx, net.minecraft.client.font.TextRenderer tr, String label,
                            int x, int y, int w, int h, int r, float a) {
        int accent = Theme.current().accent() | 0xFF000000;
        int fill = ClickGuiScreen.mix(BG | 0xFF000000, accent, 0.15f + 0.55f * a);
        fill = (Math.round(0xC0 + 0x30 * a) << 24) | (fill & 0xFFFFFF);
        ClickGuiScreen.rrect(ctx, x, y, w, h, fill, r);
        int edge = ClickGuiScreen.mix(ClickGuiScreen.mix(accent, 0xFF000000, 0.35f), accent, a);
        ClickGuiScreen.outline(ctx, x, y, w, h, (0xFF << 24) | (edge & 0xFFFFFF), r);
        int col = ClickGuiScreen.mix(MUTED, WHITE, a) | 0xFF000000;
        Fonts.draw(ctx, tr, label, x + (w - Fonts.width(tr, label)) / 2, y + (h - 8) / 2, col);
    }
}
