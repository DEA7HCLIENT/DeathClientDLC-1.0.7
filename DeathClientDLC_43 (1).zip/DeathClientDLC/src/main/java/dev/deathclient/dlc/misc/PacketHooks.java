package dev.deathclient.dlc;

import net.minecraft.network.packet.Packet;

/** One entry point for the outgoing-packet hook, so the mixin does not need to know about the modules (public: the mixin is in another package). */
public final class PacketHooks {
    private PacketHooks() {}

    /** True if a module (Blink, AirStuck) takes this packet, so it must not be sent now. */
    public static boolean consume(Packet<?> packet) {
        return AirStuckModule.drop(packet) || BlinkModule.hold(packet);
    }
}
