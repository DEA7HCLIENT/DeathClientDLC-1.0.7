package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoClipModule;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Singleplayer NoClip: the integrated server rolls the player back when they stand inside a block. While NoClip is
 * on in a singleplayer world, that check says "not colliding", so the position is accepted. require = 0: if the method
 * name differs in this version, nothing happens (the game still runs).
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerNoClipMixin {
    @Inject(method = "isPlayerNotCollidingWithBlocks", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noClipPosition(CallbackInfoReturnable<Boolean> cir) {
        if (NoClipModule.serverNoClip()) cir.setReturnValue(true);
    }
}
