package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** ElytraBooster: while you glide and hold forward you keep speeding up along your view direction, up to a limit. */
public class ElytraBoosterModule extends Module {
    public final NumberSetting boost = add(new NumberSetting("Boost", 0.04, 0.01, 0.3, 0.01));
    public final NumberSetting max = add(new NumberSetting("Max speed", 2.5, 1.0, 6.0, 0.1));

    public ElytraBoosterModule() { super("ElytraBooster", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isGliding() || !c.options.forwardKey.isPressed()) return;
        Vec3d v = p.getVelocity();
        if (v.length() >= max.get()) return;
        p.setVelocity(v.add(p.getRotationVec(1.0f).multiply(boost.get())));
    }
}
