package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** ElytraMotion: you steer the glide yourself. Forward = along the view at a fixed speed, jump / sneak = up / down, nothing = hover. */
public class ElytraMotionModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.2, 0.2, 4.0, 0.05));
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.5, 0.1, 2.0, 0.05));

    public ElytraMotionModule() { super("ElytraMotion", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isGliding()) return;
        Vec3d look = p.getRotationVec(1.0f);
        int up = (c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0);
        Vec3d v = c.options.forwardKey.isPressed() ? look.multiply(speed.get()) : Vec3d.ZERO;
        p.setVelocity(v.x, up != 0 ? up * vertical.get() : v.y, v.z);
    }
}
