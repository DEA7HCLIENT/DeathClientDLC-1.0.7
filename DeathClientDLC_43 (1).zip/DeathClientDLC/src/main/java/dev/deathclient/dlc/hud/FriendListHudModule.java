package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Friend List: a HUD panel with your friends (the ones added with ".friend add <name>") and whether each of them is on
 * the server you are playing on right now.
 * <ul>
 *   <li>green dot: the friend is on the server (they are in the player list); on the right the distance if they are
 *       near enough to be loaded, otherwise their ping (or "online");</li>
 *   <li>grey dot: offline (not on this server).</li>
 * </ul>
 * Friends on the server come first. Drag the panel with the mouse while the chat is open.
 */
public class FriendListHudModule extends Module {
    public final BoolSetting showOffline = add(new BoolSetting("Show offline", true));
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    public final BoolSetting showPing = add(new BoolSetting("Ping", true));
    public final NumberSetting maxRows = add(new NumberSetting("Max rows", 10, 1, 25, 1));
    public final NumberSetting posX = add(new NumberSetting("X", 6, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 170, 0, 1200, 1));

    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94, ON = 0xFF4CD964, OFF = 0xFF6B6B76;

    public FriendListHudModule() { super("Friend List", Category.MISC); }

    /** One friend: name, whether they are on the server, how far they are (-1 = not loaded) and their ping. */
    private record Row(String name, boolean online, double dist, int ping) {}

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        FriendListHudModule m = ModuleManager.get(FriendListHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        List<String> friends = Friends.list();
        ClientPlayNetworkHandler nh = c.getNetworkHandler();

        List<Row> rows = new ArrayList<>();
        int online = 0;
        for (String f : friends) {
            PlayerListEntry entry = nh == null ? null : nh.getPlayerListEntry(f);
            PlayerEntity near = null;                                      // a friend close enough to be loaded
            for (PlayerEntity e : c.world.getPlayers()) {
                if (e != c.player && e.getName().getString().equalsIgnoreCase(f)) { near = e; break; }
            }
            boolean on = entry != null || near != null;
            if (on) online++;
            rows.add(new Row(near != null ? near.getName().getString() : f, on,
                    near != null ? c.player.distanceTo(near) : -1.0, entry != null ? entry.getLatency() : -1));
        }
        rows.sort(Comparator.comparing((Row r) -> !r.online()).thenComparing(r -> r.name().toLowerCase()));
        if (!showOffline.get()) rows.removeIf(r -> !r.online());
        int hidden = Math.max(0, rows.size() - (int) maxRows.get());
        if (hidden > 0) rows = new ArrayList<>(rows.subList(0, (int) maxRows.get()));

        var tr = c.textRenderer;
        int pad = 6, rowH = 12;
        String title = "Friends", count = online + "/" + friends.size();
        String empty = friends.isEmpty() ? ".friend add <ник>" : "никого нет на сервере";

        // Width: the widest of the title line and the rows (dot + name + the right-hand text).
        int w = Fonts.width(tr, title) + 14 + Fonts.width(tr, count);
        List<String> rights = new ArrayList<>();
        for (Row r : rows) {
            String right = rightText(r);
            rights.add(right);
            w = Math.max(w, 10 + Fonts.width(tr, r.name()) + 12 + Fonts.width(tr, right));
        }
        if (rows.isEmpty()) w = Math.max(w, Fonts.width(tr, empty));
        if (hidden > 0) w = Math.max(w, Fonts.width(tr, "+" + hidden + "..."));
        w += pad * 2;
        int lines = Math.max(1, rows.size()) + (hidden > 0 ? 1 : 0);
        int h = 16 + lines * rowH + 3;
        int x = (int) posX.get(), y = (int) posY.get();

        HudEdit.track(x, y, w, h, (nx, ny) -> { posX.set(nx); posY.set(ny); });
        Shapes.panel(ctx, x, y, w, h, BG);
        stripe(ctx, x, y + 14, w);
        Fonts.draw(ctx, tr, title, x + pad, y + 3, WHITE);
        Fonts.draw(ctx, tr, count, x + w - pad - Fonts.width(tr, count), y + 3, online > 0 ? ON : MUTED);

        int ry = y + 18;
        if (rows.isEmpty()) {
            Fonts.draw(ctx, tr, empty, x + pad, ry, MUTED);
            return;
        }
        int acc = 0xFF000000 | (Theme.current().accent() & 0xFFFFFF);
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            ctx.fill(x + pad, ry + 3, x + pad + 5, ry + 8, r.online() ? ON : OFF);                 // the dot
            Fonts.draw(ctx, tr, r.name(), x + pad + 10, ry, r.online() ? WHITE : MUTED);
            String right = rights.get(i);
            int col = !r.online() ? OFF : (r.dist() >= 0 && showDistance.get()) ? acc : (r.ping() >= 0 && showPing.get()) ? MUTED : ON;
            Fonts.draw(ctx, tr, right, x + w - pad - Fonts.width(tr, right), ry, col);
            ry += rowH;
        }
        if (hidden > 0) Fonts.draw(ctx, tr, "+" + hidden + "...", x + pad, ry, MUTED);
    }

    private String rightText(Row r) {
        if (!r.online()) return "offline";
        if (r.dist() >= 0 && showDistance.get()) return Math.round(r.dist()) + "m";
        if (r.ping() >= 0 && showPing.get()) return r.ping() + " ms";
        return "online";
    }

    /** 1 px line in the theme colour; gradient themes are drawn left to right in 2 px slices. */
    private static void stripe(DrawContext ctx, int x, int y, int w) {
        Theme t = Theme.current();
        if (!t.gradient()) { ctx.fill(x, y, x + w, y + 1, t.accent()); return; }
        for (int i = 0; i < w; i += 2) {
            ctx.fill(x + i, y, x + Math.min(w, i + 2), y + 1, t.at((i + 1f) / w));
        }
    }
}
