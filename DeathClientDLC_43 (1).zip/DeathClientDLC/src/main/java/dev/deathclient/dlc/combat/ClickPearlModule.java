package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * ClickPearl: bind a key to it (Keybinds / .bind) and every press throws an ender pearl from the hotbar,
 * then the module switches itself off again, ready for the next press.
 */
public class ClickPearlModule extends Module {
    public ClickPearlModule() { super("ClickPearl", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p != null && c.interactionManager != null) {
            int slot = Util.findHotbar(p, Items.ENDER_PEARL);
            if (slot >= 0) {
                int prev = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                c.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.getInventory().setSelectedSlot(prev);
            }
        }
        toggle();                                   // one throw per press
    }
}
