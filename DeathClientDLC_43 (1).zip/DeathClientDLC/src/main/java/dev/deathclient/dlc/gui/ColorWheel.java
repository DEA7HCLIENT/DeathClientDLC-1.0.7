package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * The hue/saturation wheel used by the Custom Theme settings (angle = hue 0-360, distance from the centre =
 * saturation 0-1, brightness fixed at 1 so the picker itself always reads true colours; a separate slider sets
 * brightness). Rendered once into a PNG in memory and loaded the same way GuiImage/MenuCustom load their pictures,
 * so it only costs one texture upload, not per-pixel GUI draw calls every frame.
 */
final class ColorWheel {
    private static final int SIZE = 96;
    private static final Identifier ID = Identifier.of("deathclientdlc", "color_wheel");
    private static boolean ready;

    private ColorWheel() {}

    static Identifier id() {
        ensure();
        return ID;
    }

    static int size() { return SIZE; }

    private static void ensure() {
        if (ready) return;
        ready = true;
        try {
            BufferedImage img = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
            double cx = (SIZE - 1) / 2.0, cy = (SIZE - 1) / 2.0, r = SIZE / 2.0;
            for (int y = 0; y < SIZE; y++) {
                for (int x = 0; x < SIZE; x++) {
                    double dx = x - cx, dy = y - cy;
                    double d = Math.sqrt(dx * dx + dy * dy);
                    if (d > r) { img.setRGB(x, y, 0); continue; }
                    double hue = (Math.toDegrees(Math.atan2(-dy, dx)) + 360) % 360;
                    double sat = Math.min(1.0, d / r);
                    int rgb = hsb(hue, sat, 1.0);
                    int a = d > r - 1.2 ? (int) (255 * Math.max(0, r - d) / 1.2) : 255;   // 1px antialiased edge
                    img.setRGB(x, y, (a << 24) | (rgb & 0xFFFFFF));
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(img, "png", out);
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(out.toByteArray()));
            AbstractTexture tex = MenuCustom.makeTexture(ni);
            MinecraftClient.getInstance().getTextureManager().registerTexture(ID, tex);
        } catch (Exception ignored) {
            ready = false;                                       // try again next frame
        }
    }

    /** 0xRRGGBB for the given hue (0-360), saturation and brightness (0-1). */
    static int hsb(double hue, double sat, double bri) {
        double h = (hue % 360) / 60.0, s = sat, v = bri;
        int sector = (int) Math.floor(h);
        double f = h - sector, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (sector) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) Math.round(r * 255) << 16) | ((int) Math.round(g * 255) << 8) | (int) Math.round(b * 255);
    }

    /** Hue (0-360) and saturation (0-1) for a point at (dx, dy) relative to the wheel's centre, radius r. */
    static double[] pick(double dx, double dy, double r) {
        double hue = (Math.toDegrees(Math.atan2(-dy, dx)) + 360) % 360;
        double sat = Math.min(1.0, Math.sqrt(dx * dx + dy * dy) / r);
        return new double[]{hue, sat};
    }
}
