package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;

/** AutoRespawn: presses "Respawn" for you the moment the death screen shows up. */
public class AutoRespawnModule extends Module {
    public AutoRespawnModule() { super("AutoRespawn", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player != null && c.currentScreen instanceof DeathScreen) c.player.requestRespawn();
    }
}
