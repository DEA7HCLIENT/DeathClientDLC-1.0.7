package dev.deathclient.dlc;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Key entry shown before the splash / main menu until the right key is typed. Esc does not close it.
 * Stands in for the vanilla title screen: the "D" artwork where the Minecraft logo would be, and
 * "DeathClient" as the big logo text under it.
 */
public class LoginScreen extends Screen {
    private static final Identifier D_ART = Identifier.of("deathclientdlc", "textures/gui/death_d.png");

    private final StringBuilder input = new StringBuilder();
    private long errorUntil;
    private long start = System.currentTimeMillis();

    public LoginScreen() { super(Text.literal("DeathClient")); }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xFF050309);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        int accent = Theme.current().accent() | 0xFF000000;

        // "D" artwork, slowly breathing, where the Minecraft logo would sit.
        float t = (System.currentTimeMillis() - start) / 1000f;
        float breathe = 1f + 0.015f * (float) Math.sin(t * 1.3f);
        int art = Math.round(84 * breathe);
        int ax = (width - art) / 2, ay = height / 2 - 118;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, D_ART, ax, ay, 0f, 0f, art, art, 128, 128, 128, 128, 0xFFFFFFFF);

        // "DeathClient" logo text under the art.
        String title = "DeathClient";
        var f = textRenderer;
        int scale = 3;
        int tw = f.getWidth(title) * scale;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((width - tw) / 2f, ay + art + 10);
        m.scale(scale, scale);
        ctx.drawText(f, title, 1, 1, 0x40000000, false);
        ctx.drawText(f, title, 0, 0, accent & 0xFFFFFF | 0xFF000000, false);
        m.popMatrix();

        int w = 200, h = 22, x = (width - w) / 2, y = height / 2 + 36;
        String hint = "Введи ключ и нажми Enter";
        ctx.drawText(f, hint, (width - f.getWidth(hint)) / 2, y - 14, 0xFFB9B2C8, false);
        boolean err = System.currentTimeMillis() < errorUntil;
        ClickGuiScreen.rrect(ctx, x, y, w, h, 0xFF120C1E, 5);
        ClickGuiScreen.outline(ctx, x, y, w, h, err ? 0xFFFF4D4D : accent, 5);
        String dots = "•".repeat(input.length());
        boolean caret = (System.currentTimeMillis() / 500) % 2 == 0;
        ctx.drawText(f, dots + (caret ? "_" : ""), x + 8, y + (h - 8) / 2, 0xFFFFFFFF, false);
        if (err) {
            String msg = "Неверный ключ";
            ctx.drawText(f, msg, (width - f.getWidth(msg)) / 2, y + h + 8, 0xFFFF4D4D, false);
        }
    }

    @Override
    public boolean keyPressed(KeyInput k) {
        int key = k.key();
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (input.length() > 0) input.setLength(input.length() - 1);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            if (License.tryUnlock(input.toString())) {
                client.setScreen(SplashScreen.done ? new MainMenuScreen() : new SplashScreen());
            } else {
                input.setLength(0);
                errorUntil = System.currentTimeMillis() + 1500;
            }
            return true;
        }
        return super.keyPressed(k);
    }

    @Override
    public boolean charTyped(CharInput c) {
        if (input.length() < 64) input.append(c.asString());
        return true;
    }
}
