package dev.deathclient.dlc;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;

/** The "ДОБАВИТЬ ФОТО" button: shown in the bottom-right corner of every screen where a picture can be loaded. */
final class PhotoButton {
    private static final int W = 150, H = 20;

    private PhotoButton() {}

    /** Opens the folder in the file manager; the picture is picked there, then dropped on the screen. */
    static void open(Path folder) {
        try {
            Files.createDirectories(folder);
            Util.getOperatingSystem().open(folder.toFile());
        } catch (Exception ignored) {}
    }

    static void draw(DrawContext ctx, int sw, int sh) {
        int x = sw - W - 8, y = sh - H - 8;
        ClickGuiScreen.rrect(ctx, x, y, W, H, 0xE0101016, 5);
        ClickGuiScreen.rrect(ctx, x, y + H - 2, W, 2, Theme.current().accent() | 0xFF000000, 1);
        var tr = MinecraftClient.getInstance().textRenderer;
        String t = "ДОБАВИТЬ ФОТО";
        Fonts.draw(ctx, tr, t, x + (W - Fonts.width(tr, t)) / 2, y + 6, 0xFFFFFFFF);
    }

    /** A click on the button opens the folder and returns true. */
    static boolean click(double mx, double my, int sw, int sh, Path folder) {
        int x = sw - W - 8, y = sh - H - 8;
        if (mx < x || mx >= x + W || my < y || my >= y + H) return false;
        open(folder);
        return true;
    }
}
