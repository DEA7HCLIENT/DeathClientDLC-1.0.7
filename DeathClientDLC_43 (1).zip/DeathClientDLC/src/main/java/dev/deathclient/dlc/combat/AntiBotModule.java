package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import java.util.ArrayList;
import java.util.List;

/**
 * AntiBot: finds fake players (NPCs and bots that are not in the tab list, optionally also odd names / non-random UUIDs).
 * With "Remove" on they disappear from your world; the aiming and Interrupt modules skip them either way.
 */
public class AntiBotModule extends Module {
    public final BoolSetting remove = add(new BoolSetting("Remove", true));
    public final BoolSetting strictName = add(new BoolSetting("Strict name check", false));
    public final BoolSetting uuidCheck = add(new BoolSetting("UUID check", false));

    public AntiBotModule() { super("AntiBot", Category.COMBAT); }

    /** True if this entity is a bot by the current settings (always false while the module is off). */
    static boolean isBot(Entity e) {
        AntiBotModule m = ModuleManager.get(AntiBotModule.class);
        if (m == null || !m.isEnabled() || !(e instanceof PlayerEntity pe)) return false;
        MinecraftClient c = MinecraftClient.getInstance();
        if (e == c.player) return false;
        ClientPlayNetworkHandler h = c.getNetworkHandler();
        if (h == null) return false;
        if (h.getPlayerListEntry(pe.getUuid()) == null) return true;                       // not in the tab list
        if (m.uuidCheck.get() && pe.getUuid().version() != 4) return true;                  // real accounts have random (v4) UUIDs
        return m.strictName.get() && !pe.getName().getString().matches("[A-Za-z0-9_]{1,16}");
    }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.world == null || c.player == null || !remove.get()) return;
        List<Integer> ids = new ArrayList<>();
        for (PlayerEntity pe : c.world.getPlayers()) if (pe.age > 10 && isBot(pe)) ids.add(pe.getId());
        for (int id : ids) c.world.removeEntity(id, Entity.RemovalReason.DISCARDED);
    }
}
