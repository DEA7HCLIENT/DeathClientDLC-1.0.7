package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/** ElytraTarget: while you glide, the camera stays on the nearest player so you can fly at him and keep him in sight. */
public class ElytraTargetModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 60, 10, 150, 5));
    public final NumberSetting speed = add(new NumberSetting("Speed", 15, 1, 60, 1));

    public ElytraTargetModule() { super("ElytraTarget", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isGliding() || c.currentScreen != null) return;
        LivingEntity t = AimUtil.pick(c, p, range.get(), 360, true);
        if (t != null) AimUtil.turn(c, p, t.getBoundingBox().getCenter(), speed.get());
    }
}
