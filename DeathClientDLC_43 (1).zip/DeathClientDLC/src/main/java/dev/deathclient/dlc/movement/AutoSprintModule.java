package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** AutoSprint: sprints on its own while you walk forward (not when sneaking, hungry or against a wall). */
public class AutoSprintModule extends Module {
    public AutoSprintModule() { super("AutoSprint", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || p.isSneaking() || p.horizontalCollision || p.getHungerManager().getFoodLevel() <= 6) return;
        if (c.options.forwardKey.isPressed()) p.setSprinting(true);
    }
}
