package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** InterruptHealing: hits a player in reach who is drinking a potion or eating a golden apple, with your weapon fully charged. */
public class InterruptHealingModule extends Module {
    public final NumberSetting reach = add(new NumberSetting("Reach", 3.0, 2.0, 6.0, 0.1));

    public InterruptHealingModule() { super("InterruptHealing", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null || c.currentScreen != null) return;
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;
        for (PlayerEntity pe : c.world.getPlayers()) {
            if (pe == p || !pe.isAlive() || !pe.isUsingItem() || p.distanceTo(pe) > reach.get()) continue;
            if (Friends.skip(pe) || AntiBotModule.isBot(pe)) continue;
            Item it = pe.getActiveItem().getItem();
            if (it != Items.POTION && it != Items.GOLDEN_APPLE && it != Items.ENCHANTED_GOLDEN_APPLE) continue;
            c.interactionManager.attackEntity(p, pe);
            p.swingHand(Hand.MAIN_HAND);
            return;
        }
    }
}
