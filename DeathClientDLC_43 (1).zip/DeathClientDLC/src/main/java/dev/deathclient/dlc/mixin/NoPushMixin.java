package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.NoPushModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** NoPush: your own player is not pushed away from other entities. require = 0: skipped if the method is named differently. */
@Mixin(Entity.class)
public abstract class NoPushMixin {
    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noPush(Entity other, CallbackInfo ci) {
        NoPushModule m = ModuleManager.get(NoPushModule.class);
        if (m != null && m.isEnabled() && (Object) this == MinecraftClient.getInstance().player) ci.cancel();
    }
}
