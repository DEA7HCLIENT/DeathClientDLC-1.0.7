package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Kill Aura: automatically attacks every valid target in reach, no clicking and no aiming needed.
 * This class only picks targets and attacks; everything about aiming lives in {@link KillAuraRotation}
 * (modes None, Silent, Smooth, Neuro, VodkaCraft, HvH, Bezier, Spring, Focus, Snap, Grim, Matrix, Monday;
 * see there for what each does).
 * <ul>
 *   <li>Aim point (Bezier / Spring / Focus / Snap): Center, Chest, Head, Nearest or Wander.</li>
 *   <li>Reach is measured to the target's hitbox, the way the server measures it.</li>
 *   <li>Normal mode waits for the weapon cooldown; HvH mode hits every tick.</li>
 * </ul>
 */
public class KillAuraModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    public final NumberSetting rotation = add(new NumberSetting("Rotation", KillAuraRotation.SILENT, 1, KillAuraRotation.LABELS.length, 1)
            .labels(KillAuraRotation.LABELS));
    /** Where Bezier / Spring / Focus / Snap aim inside the hitbox. */
    public final NumberSetting aimPoint = add(new NumberSetting("Aim point", 4, 1, 5, 1)
            .labels("Center", "Chest", "Head", "Nearest", "Wander"));
    /** Bezier / Spring / Focus: hit only while the look ray really crosses the target's hitbox. */
    public final BoolSetting hitCheck = add(new BoolSetting("Hit check", true));
    /** Max degrees per tick for Smooth / Neuro / VodkaCraft. */
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));
    /**
     * Off (default): your camera never moves. Every rotation mode aims on the server side only (the server and
     * other players see the aim). On: your own camera turns too, as the Smooth / Neuro / Bezier / Spring modes always did.
     */
    public final BoolSetting visualCamera = add(new BoolSetting("Visual camera", false));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    private final KillAuraRotation rot = new KillAuraRotation(this);
    private LivingEntity aimTarget;

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    /** The entity KillAura is aiming at right now (null when there is none). */
    LivingEntity currentTarget() { return aimTarget; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if ((!inGui.get() && c.currentScreen != null) || !p.isAlive() || p.isSpectator()) {
            rot.release(c, p);
            return;
        }

        int mode = (int) rotation.get();
        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            if (Util.reach(p, le) <= rangeFor(mode)) list.add(le);
        }
        if (list.isEmpty()) {
            rot.release(c, p);
            aimTarget = null;
            return;
        }

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(e -> Util.reach(p, e)));

        LivingEntity primary = list.get(0);
        if (primary != aimTarget) {
            aimTarget = primary;
            rot.onNewTarget();
        }

        boolean aligned = rot.update(c, p, primary, mode);

        float need = rot.minCooldown(mode, hvh.get() ? 0f : (float) cooldown.get());
        if (rot.hitBlocked(p, primary, mode)) return;
        if (!aligned || p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        if (KillAuraRotation.singleTarget(mode)) count = 1;          // one aim point at a time
        for (int i = 0; i < count; i++) {
            LivingEntity t = list.get(i);
            rot.beforeHit(c, p, t, mode, i);
            c.interactionManager.attackEntity(p, t);
        }
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        rot.afterHits(c, p, mode, count);
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        rot.release(c, c.player);
        aimTarget = null;
    }

    /** Reach used to pick targets: Grim / Matrix stay under 2.95 (Grim measures 3.0 to the hitbox and allows little slack). */
    private double rangeFor(int mode) {
        return KillAuraRotation.strictReach(mode) ? Math.min(range.get(), 2.95) : range.get();
    }
}
