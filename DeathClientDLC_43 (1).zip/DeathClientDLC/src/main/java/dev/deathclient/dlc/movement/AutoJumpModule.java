package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** AutoJump: jumps again the moment you land while you are moving. */
public class AutoJumpModule extends Module {
    public AutoJumpModule() { super("AutoJump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isOnGround() || p.isSneaking() || p.isTouchingWater()) return;
        if (Util.inputDir(c, p).lengthSquared() == 0) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, 0.42, v.z);                 // vanilla jump impulse
    }
}
