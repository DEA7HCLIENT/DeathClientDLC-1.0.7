package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.NoSlowModule;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * NoSlow: in tickMovement the "is using an item" checks are answered with false while the module is on, so using an
 * item neither slows the movement input nor stops sprinting. require = 0: if the call is not found, nothing happens.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class NoSlowMixin {
    @Redirect(method = "tickMovement", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"), require = 0)
    private boolean deathclientdlc$noSlow(ClientPlayerEntity self) {
        NoSlowModule m = ModuleManager.get(NoSlowModule.class);
        return (m == null || !m.isEnabled()) && self.isUsingItem();
    }
}
