package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** AutoTool: while you break a block the fastest tool in the hotbar is selected; afterwards your old slot comes back. */
public class AutoToolModule extends Module {
    public final BoolSetting restore = add(new BoolSetting("Restore slot", true));
    private int saved = -1;

    public AutoToolModule() { super("AutoTool", Category.MISC); }

    @Override
    protected void onDisable() { saved = -1; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        boolean breaking = c.options.attackKey.isPressed() && c.crosshairTarget instanceof BlockHitResult bhr
                && bhr.getType() == HitResult.Type.BLOCK;
        if (!breaking) {
            if (saved != -1 && restore.get()) p.getInventory().setSelectedSlot(saved);
            saved = -1;
            return;
        }
        BlockState state = c.world.getBlockState(((BlockHitResult) c.crosshairTarget).getBlockPos());
        int cur = p.getInventory().getSelectedSlot();
        int best = cur;
        float bestSpeed = p.getInventory().getStack(cur).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            float sp = s.getMiningSpeedMultiplier(state);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        if (best != cur) {
            if (saved == -1) saved = cur;
            p.getInventory().setSelectedSlot(best);
        }
    }
}
