package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** AutoTotem: when your health is low (or always, if "Always" is on) a totem is moved from the inventory to the left hand. */
public class AutoTotemModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 10, 2, 20, 1));
    public final BoolSetting always = add(new BoolSetting("Always", false));
    public final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 3, 0, 20, 1));
    private int cooldown;

    public AutoTotemModule() { super("AutoTotem", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (!always.get() && p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
        for (int i = 0; i < 36; i++) {
            if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slot = i < 9 ? 36 + i : i;                       // inventory index -> screen handler slot
            c.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);   // 40 = off hand
            cooldown = (int) delay.get();
            return;
        }
    }
}
