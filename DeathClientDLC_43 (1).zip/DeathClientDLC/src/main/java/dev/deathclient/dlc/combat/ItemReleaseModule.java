package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** ItemRelease: with a bow in your hand it draws it and lets go by itself once it is charged to the set number of ticks. */
public class ItemReleaseModule extends Module {
    public final NumberSetting charge = add(new NumberSetting("Charge (ticks)", 20, 3, 20, 1));

    public ItemReleaseModule() { super("ItemRelease", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null || c.currentScreen != null || !p.getMainHandStack().isOf(Items.BOW)) return;
        if (!p.isUsingItem()) c.interactionManager.interactItem(p, Hand.MAIN_HAND);
        else if (p.getItemUseTime() >= charge.get()) c.interactionManager.stopUsingItem(p);
    }
}
