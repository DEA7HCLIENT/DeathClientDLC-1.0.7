package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import java.awt.Color;

/**
 * Colour palette: a colour wheel (textures/gui/color_wheel.png) with a brightness bar, a preview and the hex code.
 * Click or drag on the wheel to pick the colour and its strength (centre = white), drag the bar for brightness.
 * Every change is applied to the module at once; Esc or "Готово" returns to where you came from (the menu).
 * Modules open it from a "Палитра" button in their settings: ColorPickerScreen.open(name, rgb(...) or hsb(...)).
 */
public class ColorPickerScreen extends Screen {
    /** What the palette edits. */
    public interface Target {
        /** Current colour: hue 0..360, saturation 0..1, brightness 0..1. */
        float[] hsb();
        void apply(float hue, float sat, float bri);
    }

    /** Three 0..255 sliders (Red / Green / Blue). */
    public static Target rgb(NumberSetting r, NumberSetting g, NumberSetting b) {
        return new Target() {
            public float[] hsb() {
                float[] v = Color.RGBtoHSB((int) r.get(), (int) g.get(), (int) b.get(), null);
                return new float[]{v[0] * 360f, v[1], v[2]};
            }
            public void apply(float h, float s, float v) {
                int c = Color.HSBtoRGB(h / 360f, s, v);
                r.set((c >> 16) & 255); g.set((c >> 8) & 255); b.set(c & 255);
            }
        };
    }

    /** Hue 0..360 and saturation / brightness 0..100 sliders (Custom Theme). */
    public static Target hsb(NumberSetting h, NumberSetting s, NumberSetting v) {
        return new Target() {
            public float[] hsb() { return new float[]{(float) h.get(), (float) (s.get() / 100.0), (float) (v.get() / 100.0)}; }
            public void apply(float hh, float ss, float vv) {
                h.set(Math.round(hh)); s.set(Math.round(ss * 100f)); v.set(Math.round(vv * 100f));
            }
        };
    }

    public static void open(String title, Target target) {
        MinecraftClient c = MinecraftClient.getInstance();
        c.setScreen(new ColorPickerScreen(c.currentScreen, title, target));
    }

    /** Hue (degrees) of the wheel image every 5 degrees, counter-clockwise from the right; measured from the image. */
    private static final float[] HUE = {0, 3, 6, 9, 12, 15, 18, 21, 24, 26, 29, 32, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 64, 71, 78, 85, 92, 99, 106, 113, 120, 125, 131, 137, 142, 148, 154, 159, 165, 171, 176, 182, 187, 193, 198, 203, 208, 213, 219, 224, 229, 234, 240, 245, 251, 256, 262, 267, 273, 278, 284, 289, 295, 300, 310, 320, 330, 340, 350};
    private static final Identifier WHEEL = Identifier.of("deathclientdlc", "textures/gui/color_wheel.png");
    private static final int TEX = 256, SIZE = 150, CARD_W = 232, CARD_H = 222;
    private static final int CARD = 0xF0121218, MUTED = 0xFF9A9AA6, WHITE = 0xFFFFFFFF;

    private final Screen parent;
    private final String heading;
    private final Target target;
    private float h, s, v;
    private int drag;                                   // 0 none, 1 wheel, 2 brightness bar

    private ColorPickerScreen(Screen parent, String title, Target target) {
        super(Text.literal("Палитра"));
        this.parent = parent;
        this.heading = title;
        this.target = target;
        float[] c = target.hsb();
        h = c[0]; s = c[1]; v = c[2];
    }

    // ---- the wheel's hue scale (not linear: it is measured from the image) ----

    private static float hueAt(double deg) {
        double a = ((deg % 360) + 360) % 360 / 5.0;
        int i = (int) Math.floor(a);
        double f = a - i;
        float h0 = HUE[i % 72], h1 = i + 1 >= 72 ? 360f : HUE[i + 1];
        return (float) (h0 + (h1 - h0) * f) % 360f;
    }

    private static double angleOf(float hue) {
        for (int i = 0; i < 72; i++) {
            float h0 = HUE[i], h1 = i + 1 >= 72 ? 360f : HUE[i + 1];
            if (hue >= h0 && hue < h1) return 5.0 * (i + (h1 == h0 ? 0 : (hue - h0) / (h1 - h0)));
        }
        return 0;
    }

    // ---- layout ----

    private int cardX() { return (width - CARD_W) / 2; }
    private int cardY() { return (height - CARD_H) / 2; }
    private int wx() { return cardX() + 16; }
    private int wy() { return cardY() + 34; }
    private int barX() { return wx() + SIZE + 18; }
    private int rgbNow() { return Color.HSBtoRGB(h / 360f, s, v) & 0xFFFFFF; }

    private boolean inDone(double mx, double my) {
        return mx >= cardX() + CARD_W - 86 && mx < cardX() + CARD_W - 16 && my >= cardY() + CARD_H - 32 && my < cardY() + CARD_H - 12;
    }

    // ---- picking ----

    private void pickWheel(double mx, double my) {
        double dx = mx - (wx() + SIZE / 2.0), dy = my - (wy() + SIZE / 2.0);
        double d = Math.sqrt(dx * dx + dy * dy), r = SIZE / 2.0;
        s = (float) Math.min(1.0, d / r);
        if (d > 0.5) h = hueAt(Math.toDegrees(Math.atan2(-dy, dx)));
        target.apply(h, s, v);
    }

    private void pickBar(double my) {
        v = (float) Math.max(0.0, Math.min(1.0, 1.0 - (my - wy()) / SIZE));
        target.apply(h, s, v);
    }

    // ---- drawing ----

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        Ui.drawWorldDim(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        long win = client.getWindow().getHandle();
        if (drag != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS) drag = 0;
        if (drag == 1) pickWheel(mx, my); else if (drag == 2) pickBar(my);

        var tr = textRenderer;
        int x0 = cardX(), y0 = cardY(), acc = Theme.current().accent() | 0xFF000000;
        ClickGuiScreen.rrect(ctx, x0, y0, CARD_W, CARD_H, CARD, 10);
        ClickGuiScreen.outline(ctx, x0, y0, CARD_W, CARD_H, 0x55FFFFFF, 10);
        Fonts.draw(ctx, tr, "Палитра", x0 + 16, y0 + 10, WHITE);
        Fonts.draw(ctx, tr, heading, x0 + CARD_W - 16 - Fonts.width(tr, heading), y0 + 10, MUTED);

        // the wheel, as dark as the chosen brightness
        int g = Math.round(255f * v);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, WHEEL, wx(), wy(), 0f, 0f, SIZE, SIZE, TEX, TEX, TEX, TEX,
                0xFF000000 | (g << 16) | (g << 8) | g);
        double ang = Math.toRadians(angleOf(h)), rr = s * SIZE / 2.0;
        int mxp = (int) Math.round(wx() + SIZE / 2.0 + Math.cos(ang) * rr), myp = (int) Math.round(wy() + SIZE / 2.0 - Math.sin(ang) * rr);
        ClickGuiScreen.rrect(ctx, mxp - 5, myp - 5, 10, 10, 0xFFFFFFFF, 5);
        ClickGuiScreen.rrect(ctx, mxp - 4, myp - 4, 8, 8, 0xFF000000 | rgbNow(), 4);

        // brightness bar: the colour at full brightness down to black
        int full = Color.HSBtoRGB(h / 360f, s, 1f) | 0xFF000000;
        ctx.fillGradient(barX(), wy(), barX() + 16, wy() + SIZE, full, 0xFF000000);
        ClickGuiScreen.outline(ctx, barX() - 1, wy() - 1, 18, SIZE + 2, 0x55FFFFFF, 2);
        int ky = wy() + Math.round((1f - v) * SIZE);
        ClickGuiScreen.rrect(ctx, barX() - 3, ky - 2, 22, 4, WHITE, 2);

        // preview and codes
        int py = wy() + SIZE + 14;
        ClickGuiScreen.rrect(ctx, x0 + 16, py, 90, 24, 0xFF000000 | rgbNow(), 6);
        ClickGuiScreen.outline(ctx, x0 + 16, py, 90, 24, 0x66FFFFFF, 6);
        int rgb = rgbNow();
        Fonts.draw(ctx, tr, String.format("#%06X", rgb), x0 + 114, py + 1, WHITE);
        Fonts.draw(ctx, tr, ((rgb >> 16) & 255) + ", " + ((rgb >> 8) & 255) + ", " + (rgb & 255), x0 + 114, py + 13, MUTED);

        // Done
        boolean hov = inDone(mx, my);
        ClickGuiScreen.rrect(ctx, x0 + CARD_W - 86, y0 + CARD_H - 32, 70, 20, hov ? acc : 0xFF2A2A36, 5);
        Fonts.draw(ctx, tr, "Готово", x0 + CARD_W - 86 + (70 - Fonts.width(tr, "Готово")) / 2, y0 + CARD_H - 26, WHITE);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x(), my = click.y();
        double dx = mx - (wx() + SIZE / 2.0), dy = my - (wy() + SIZE / 2.0);
        if (dx * dx + dy * dy <= (SIZE / 2.0 + 3) * (SIZE / 2.0 + 3)) { drag = 1; pickWheel(mx, my); return true; }
        if (mx >= barX() - 4 && mx < barX() + 20 && my >= wy() - 4 && my < wy() + SIZE + 4) { drag = 2; pickBar(my); return true; }
        if (inDone(mx, my)) { close(); return true; }
        return true;
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public boolean shouldPause() { return false; }
}
