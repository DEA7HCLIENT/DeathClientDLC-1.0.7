package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** DragonFly: while you glide the horizontal speed follows your view at the set value, the climb comes from where you look. */
public class DragonFlyModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.5, 0.3, 4.0, 0.05));

    public DragonFlyModule() { super("DragonFly", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isGliding() || !c.options.forwardKey.isPressed()) return;
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        if (flat.lengthSquared() < 1.0e-4) return;
        flat = flat.normalize().multiply(speed.get());
        p.setVelocity(flat.x, p.getVelocity().y + look.y * 0.05, flat.z);
    }
}
