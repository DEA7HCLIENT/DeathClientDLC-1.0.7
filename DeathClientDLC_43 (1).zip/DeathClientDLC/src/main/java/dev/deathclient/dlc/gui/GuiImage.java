package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * The picture of the GUI Image module. There are 24 slots (config/deathclientdlc/gui_images/1.png ... 24.png); the
 * Picture setting of the module chooses which one is drawn. Slots 1-4 start with the four pictures that come with the mod
 * (inside the jar); a file in the config folder, or a picture dropped on the ClickGUI, replaces the built-in one. Dropping a png / jpg on the ClickGUI puts it into the
 * chosen slot. Old single picture (gui_image.png) is still used as slot 1 until slot 1 is replaced.
 */
final class GuiImage {
    static final int SLOTS = 24;
    /** Slots 1-4 hold the pictures that come with the mod until you put your own there. */
    static final int BUILT_IN = 4;
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc").resolve("gui_images");
    private static final Path LEGACY = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc").resolve("gui_image.png");

    private static final boolean[] loaded = new boolean[SLOTS + 1];
    private static final boolean[] has = new boolean[SLOTS + 1];
    private static final int[] w = new int[SLOTS + 1], h = new int[SLOTS + 1];
    private static boolean dragging;
    private static int grabX, grabY;

    private GuiImage() {}

    /** The slot the module is showing now (1..24). */
    static int current() {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (m == null) return 1;
        return Math.max(1, Math.min(SLOTS, (int) Math.round(m.picture.get())));
    }

    private static Path file(int n) {
        Path p = DIR.resolve(n + ".png");
        if (n == 1 && !Files.exists(p) && Files.exists(LEGACY)) return LEGACY;
        return p;
    }

    private static Identifier id(int n) { return Identifier.of("deathclientdlc", "custom_gui_image_" + n); }

    private static void ensureLoaded(int n) {
        if (loaded[n]) return;
        loaded[n] = true;
        Path p = file(n);
        try {
            if (Files.exists(p)) { show(n, Files.readAllBytes(p)); return; }       // your own picture wins
            byte[] def = builtIn(n);
            if (def != null) show(n, def);
        } catch (Exception e) { has[n] = false; }
    }

    /** The pictures that come with the mod (slots 1-4): assets/deathclientdlc/gui_defaults/<n>.png, or null. */
    private static byte[] builtIn(int n) {
        if (n > BUILT_IN) return null;
        try (var in = GuiImage.class.getResourceAsStream("/assets/deathclientdlc/gui_defaults/" + n + ".png")) {
            return in == null ? null : in.readAllBytes();
        } catch (IOException e) {
            return null;
        }
    }

    /** Is the current slot filled? */
    static boolean has() {
        int n = current();
        ensureLoaded(n);
        return has[n];
    }

    /** Takes a png / jpg from anywhere on disk and puts it into the current slot. */
    static void set(Path src) throws Exception {
        int n = current();
        byte[] png = MenuCustom.toPng(Files.readAllBytes(src));
        Files.createDirectories(DIR);
        Files.write(DIR.resolve(n + ".png"), png);
        loaded[n] = true;
        show(n, png);
    }

    /** Empties the current slot (slots 1-4 get their built-in picture back). */
    static void reset() {
        int n = current();
        try { Files.deleteIfExists(DIR.resolve(n + ".png")); } catch (IOException ignored) {}
        has[n] = false;
        loaded[n] = false;                                       // loaded again at the next draw: built-in picture or empty
    }

    /** Called by the ClickGUI screens when files are dropped on the window. Returns true if a picture or a font was set. */
    static boolean handleDrop(List<Path> paths) {
        if (paths == null || paths.isEmpty()) return false;
        try {
            if (CustomFontPack.isFontFile(paths.get(0))) {            // a font file: the Custom Font module takes it
                CustomFontPack.installAndUse(MinecraftClient.getInstance(), paths.get(0));
                return true;
            }
            set(paths.get(0));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void show(int n, byte[] png) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        int iw = img.getWidth(), ih = img.getHeight();
        AbstractTexture tex = MenuCustom.makeTexture(img);
        MinecraftClient.getInstance().getTextureManager().registerTexture(id(n), tex);
        w[n] = iw;
        h[n] = ih;
        has[n] = true;
    }

    /** Where the picture is on a screen of sw x sh: {x, y, width, height}, or null when it is not shown. */
    private static int[] rect(int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (m == null || !m.isEnabled()) return null;
        int n = current();
        ensureLoaded(n);
        if (!has[n]) return null;
        int dh = Math.round(sh * (float) (m.size.get() / 100.0));
        int dw = Math.round(dh * w[n] / (float) h[n]);
        if (dw > sw) { dw = sw; dh = Math.round(dw * h[n] / (float) w[n]); }     // never wider than the screen
        return new int[]{sw - dw + (int) m.offsetX.get(), sh - dh + (int) m.offsetY.get(), dw, dh};
    }

    /** Mouse pressed on the picture: starts moving it. Returns true if the click was on the picture. */
    static boolean press(double mx, double my, int sw, int sh) {
        int[] r = rect(sw, sh);
        if (r == null || mx < r[0] || mx >= r[0] + r[2] || my < r[1] || my >= r[1] + r[3]) return false;
        dragging = true;
        grabX = (int) mx - r[0];
        grabY = (int) my - r[1];
        return true;
    }

    /** Mouse moved with the button held: moves the picture (Offset X / Y of the module). */
    static boolean drag(double mx, double my, int sw, int sh) {
        if (!dragging) return false;
        int[] r = rect(sw, sh);
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (r == null || m == null) { dragging = false; return false; }
        m.offsetX.set((int) mx - grabX - (sw - r[2]));
        m.offsetY.set((int) my - grabY - (sh - r[3]));
        return true;
    }

    static void release() { dragging = false; }

    /** Opens the pictures folder in the file manager; the picture is then chosen there and dropped on the ClickGUI. */
    static void openFolder() {
        try {
            Files.createDirectories(DIR);
            Util.getOperatingSystem().open(DIR.toFile());
        } catch (Exception ignored) {}
    }

    private static final int BTN_W = 150, BTN_H = 20;

    private static int btnX(int sw) { return sw - BTN_W - 8; }
    private static int btnY(int sh) { return sh - BTN_H - 8; }

    /** The "ДОБАВИТЬ ФОТО" button in the bottom-right corner, while GUI Image is on. */
    static void drawAddButton(DrawContext ctx, int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (m == null || !m.isEnabled()) return;
        int x = btnX(sw), y = btnY(sh);
        ClickGuiScreen.rrect(ctx, x, y, BTN_W, BTN_H, 0xE0101016, 5);
        ClickGuiScreen.rrect(ctx, x, y + BTN_H - 2, BTN_W, 2, Theme.current().accent() | 0xFF000000, 1);
        var tr = MinecraftClient.getInstance().textRenderer;
        String t = "ДОБАВИТЬ ФОТО";
        Fonts.draw(ctx, tr, t, x + (BTN_W - Fonts.width(tr, t)) / 2, y + 6, 0xFFFFFFFF);
    }

    static boolean clickAddButton(double mx, double my, int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        if (m == null || !m.isEnabled()) return false;
        int x = btnX(sw), y = btnY(sh);
        if (mx < x || mx >= x + BTN_W || my < y || my >= y + BTN_H) return false;
        openFolder();
        return true;
    }

    /** Draws the current picture (call before the window, so the window stays on top). */
    static void draw(DrawContext ctx, int sw, int sh) {
        GuiImageModule m = ModuleManager.get(GuiImageModule.class);
        int[] r = rect(sw, sh);
        if (m == null || r == null) return;
        int n = current();
        int a = Math.round(255f * (float) (m.opacity.get() / 100.0));
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id(n), r[0], r[1], 0f, 0f, r[2], r[3], w[n], h[n], w[n], h[n], (a << 24) | 0xFFFFFF);
    }
}
