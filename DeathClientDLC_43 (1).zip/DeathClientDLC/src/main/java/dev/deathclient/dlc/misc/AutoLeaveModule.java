package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/** AutoLeave: leaves the server when your health drops to the set value. */
public class AutoLeaveModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 6, 1, 20, 1));

    public AutoLeaveModule() { super("AutoLeave", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || p.isDead() || p.getHealth() > health.get()) return;
        p.networkHandler.getConnection().disconnect(Text.literal("AutoLeave: здоровье " + (int) p.getHealth()));
        toggle();
    }
}
