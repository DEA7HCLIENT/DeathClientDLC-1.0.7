package dev.deathclient.dlc;

/**
 * NoSlow: eating, drawing a bow or blocking no longer slows you down (hook: mixin.NoSlowMixin). No server-specific
 * tuning: a server that checks this movement will still flag it.
 */
public class NoSlowModule extends Module {
    public NoSlowModule() { super("NoSlow", Category.MOVEMENT); }
}
