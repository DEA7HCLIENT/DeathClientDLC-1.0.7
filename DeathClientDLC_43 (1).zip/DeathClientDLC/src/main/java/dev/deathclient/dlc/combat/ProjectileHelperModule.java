package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/**
 * ProjectileHelper: while you draw a bow it aims at the nearest target and works out the arc (gravity, drag and the
 * target's movement) from the charge you have right now.
 */
public class ProjectileHelperModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 40, 10, 100, 5));
    public final NumberSetting fov = add(new NumberSetting("FOV", 60, 10, 360, 5));
    public final NumberSetting speed = add(new NumberSetting("Speed", 12, 1, 40, 0.5));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    private int lastId = -1;
    private Vec3d lastPos = Vec3d.ZERO;

    public ProjectileHelperModule() { super("ProjectileHelper", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null || !p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return;
        LivingEntity t = AimUtil.pick(c, p, range.get(), fov.get(), playersOnly.get());
        if (t == null) return;

        double pull = Math.min(1.0, p.getItemUseTime() / 20.0);
        double v0 = ((pull * pull + pull * 2.0) / 3.0) * 3.0;           // arrow speed in blocks per tick
        if (v0 < 0.3) return;

        Vec3d eye = p.getEyePos();
        Vec3d center = t.getBoundingBox().getCenter();
        // Target velocity per tick from its position one tick ago (tracked here, no dependence on entity fields).
        Vec3d now = Util.pos(t);
        Vec3d vel = lastId == t.getId() ? now.subtract(lastPos) : Vec3d.ZERO;
        lastId = t.getId();
        lastPos = now;
        double flight = center.distanceTo(eye) / v0;                     // rough flight time in ticks
        Vec3d aim = center.add(vel.multiply(flight));

        double dx = aim.x - eye.x, dz = aim.z - eye.z, d = Math.hypot(dx, dz), dy = aim.y - eye.y;
        double bestPitch = Double.NaN, bestErr = Double.MAX_VALUE;
        for (double pitch = -80; pitch <= 80; pitch += 0.5) {
            double rad = Math.toRadians(pitch);
            double vx = v0 * Math.cos(rad), vy = -v0 * Math.sin(rad), x = 0, y = 0;
            for (int i = 0; i < 160; i++) {
                x += vx; y += vy;
                vx *= 0.99; vy *= 0.99; vy -= 0.05;
                if (x >= d) {
                    double err = Math.abs(y - dy);
                    if (err < bestErr) { bestErr = err; bestPitch = pitch; }
                    break;
                }
            }
        }
        if (Double.isNaN(bestPitch)) return;
        // Point at a spot that gives exactly this pitch over the horizontal distance.
        Vec3d point = new Vec3d(aim.x, eye.y - Math.tan(Math.toRadians(bestPitch)) * d, aim.z);
        AimUtil.turn(c, p, point, speed.get());
    }
}
