package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/** Top-center "Dynamic Island" status pilland a top-right module list (active effects live in the separate Effects HUD module). */
final class Hud {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final Identifier D_ART = Identifier.of("deathclientdlc", "textures/gui/death_d.png");
    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;
    private static final String[] ROMAN = {"", " I", " II", " III", " IV", " V"};

    /** Toggled by the ".spec" chat command: hides every DeathClientDLC overlay (island, list). */
    static boolean hidden;

    private static final long NOTICE_MS = 1800;

    // Function notice: when a module is switched the island shows its name and ВКЛ / ВЫКЛ for a moment.
    private static final Map<Module, Boolean> seen = new HashMap<>();
    private static Module noticeMod;
    private static boolean noticeOn;
    private static long noticeAt;

    private Hud() {}

    /** Remembers each module's state; a change starts the notice. The first pass only records. */
    private static void trackFunctions() {
        long now = System.currentTimeMillis();
        for (Module m : ModuleManager.all()) {
            boolean on = m.isEnabled();
            Boolean prev = seen.put(m, on);
            if (prev != null && prev != on) {
                noticeMod = m;
                noticeOn = on;
                noticeAt = now;
            }
        }
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        DynamicIslandModule isl = ModuleManager.get(DynamicIslandModule.class);
        if (isl == null || !isl.isEnabled()) return;
        trackFunctions();

        var tr = c.textRenderer;
        int pad = 6, h = 26, av = 18, gap = 6;
        boolean notice = noticeMod != null && System.currentTimeMillis() - noticeAt < NOTICE_MS;

        String title, sub, clock = null;
        if (notice) {
            title = noticeMod.getName();
            sub = noticeOn ? "ВКЛ" : "ВЫКЛ";
        } else {
            title = "Death Client";
            sub = "Connected" + (isl.showConfig.get() ? "  ·  " + Config.currentName() : "");
            if (isl.showClock.get()) clock = LocalTime.now().format(CLOCK);
        }
        int ping = 0;
        var nh = c.getNetworkHandler();
        var entry = nh == null ? null : nh.getPlayerListEntry(c.player.getUuid());
        if (entry != null) ping = entry.getLatency();
        int bars = ping <= 0 ? 4 : ping < 60 ? 4 : ping < 110 ? 3 : ping < 200 ? 2 : 1;

        int dotW = notice ? 0 : 8;
        int textW = Math.max(Fonts.width(tr, title), Fonts.width(tr, sub) + dotW);
        int rightW = notice ? 0 : 11 + (clock != null ? Fonts.width(tr, clock) + 6 : 0);
        int w = Math.max(112, pad + av + gap + textW + (rightW > 0 ? 12 + rightW : 0) + pad + 2);
        int sw = c.getWindow().getScaledWidth();
        int x = (sw - w) / 2 + (int) isl.islandX.get(), y = 4 + (int) isl.islandY.get();
        final int islW = w;
        HudEdit.track(x, y, w, h, (nx, ny) -> {
            isl.islandX.set(nx - (sw - islW) / 2);
            isl.islandY.set(ny - 4);
        });
        int accent = Theme.current().accent() | 0xFF000000;
        Shapes.panel(ctx, x, y, w, h, BG);
        ClickGuiScreen.outline(ctx, x, y, w, h, (0xB0 << 24) | (accent & 0xFFFFFF), h / 2);

        // Avatar: the "D" picture in a dark circle with a theme-coloured ring.
        int ax = x + pad, ay = y + (h - av) / 2;
        ClickGuiScreen.rrect(ctx, ax, ay, av, av, 0xFF0B0714, av / 2);
        ClickGuiScreen.outline(ctx, ax, ay, av, av, accent, av / 2);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, D_ART, ax + 2, ay + 2, 0f, 0f, av - 4, av - 4, 128, 128, 128, 128, 0xFFFFFFFF);

        int tx = ax + av + gap;
        Fonts.draw(ctx, tr, title, tx, y + 4, WHITE);
        if (notice) {
            Fonts.draw(ctx, tr, sub, tx, y + 14, noticeOn ? accent : MUTED);
        } else {
            ClickGuiScreen.rrect(ctx, tx, y + 15, 4, 4, 0xFF3DDC5A, 2);
            Fonts.draw(ctx, tr, sub, tx + dotW, y + 14, MUTED);
            int rx = x + w - pad - 2 - 11;
            for (int i = 0; i < 4; i++) {                    // signal bars: the louder, the better the ping
                int bh = 3 + i * 2;
                ctx.fill(rx + i * 3, y + (h + 10) / 2 - bh, rx + i * 3 + 2, y + (h + 10) / 2, i < bars ? WHITE : 0x55FFFFFF);
            }
            if (clock != null) Fonts.draw(ctx, tr, clock, rx - 6 - Fonts.width(tr, clock), y + 9, WHITE);
        }

        renderList(ctx, c, isl);
    }

    private static void renderList(DrawContext ctx, MinecraftClient c, DynamicIslandModule isl) {
        var tr = c.textRenderer;
        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.isEnabled() && m.getCategory() != Category.MISC) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> Fonts.width(tr, m.getName())).reversed());
        if (active.isEmpty()) return;
        int y = 4 + (int) isl.listY.get();
        final int baseRight = c.getWindow().getScaledWidth() - 6;
        int right = baseRight + (int) isl.listX.get();
        int accent = Theme.current().accent();
        final int maxW = Fonts.width(tr, active.get(0).getName());     // sorted: the first is the widest
        HudEdit.track(right - maxW, y, maxW, active.size() * 10, (nx, ny) -> {
            isl.listX.set(nx + maxW - baseRight);
            isl.listY.set(ny - 4);
        });
        for (Module m : active) {
            String n = m.getName();
            int w = Fonts.width(tr, n);
            Fonts.draw(ctx, tr, n, right - w, y, accent);
            y += 10;
        }
    }
}
