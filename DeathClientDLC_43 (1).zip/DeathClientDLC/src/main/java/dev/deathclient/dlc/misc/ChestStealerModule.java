package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** ChestStealer: with a chest / barrel open it shift-clicks the items out one by one. */
public class ChestStealerModule extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 2, 0, 20, 1));
    public final BoolSetting autoClose = add(new BoolSetting("Close when empty", true));
    private int wait;

    public ChestStealerModule() { super("ChestStealer", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null || c.interactionManager == null || !(c.currentScreen instanceof GenericContainerScreen gs)) return;
        if (wait > 0) { wait--; return; }
        GenericContainerScreenHandler h = gs.getScreenHandler();
        int n = h.getRows() * 9;
        for (int i = 0; i < n; i++) {
            if (!h.getSlot(i).hasStack()) continue;
            c.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, c.player);
            wait = (int) delay.get();
            return;
        }
        if (autoClose.get()) c.player.closeHandledScreen();
    }
}
