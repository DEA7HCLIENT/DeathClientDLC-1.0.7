package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Circles around the nearest target while in melee range, instead of standing still. */
public class TargetStrafeModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2, 8, 0.5));
    public final NumberSetting radius = add(new NumberSetting("Radius", 2.2, 1.0, 4.0, 0.1));
    /** Orbit angular speed, degrees per tick. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 2.5, 0.5, 6.0, 0.1));
    /** How fast you actually move along the circle (blocks per tick); this used to be a hard-coded 0.2. */
    public final NumberSetting moveSpeed = add(new NumberSetting("Move speed", 0.5, 0.1, 2.0, 0.01));
    public final BoolSetting autoJump = add(new BoolSetting("Auto jump", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting reverse = add(new BoolSetting("Reverse", false));
    /** On: your camera turns to the target. Off: only the server is told the look, your view stays put. */
    public final BoolSetting camera = add(new BoolSetting("Camera", true));

    private double angle;

    public TargetStrafeModule() { super("Target Strafe", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity target = nearest(c, p);
        if (target == null) return;

        int dirSign = reverse.get() ? -1 : 1;
        angle += Math.toRadians(speed.get()) * dirSign;
        Vec3d center = Util.pos(target);
        Vec3d rel = Util.pos(p).subtract(center);
        double curR = Math.hypot(rel.x, rel.z);

        // Old approach aimed at a single point on the circle; as you neared it the aim vector shrank towards zero
        // and the next tick's point snapped the direction the rest of the way round, which read as jerking.
        // Moving tangentially (the direction you'd already be travelling on a smooth circle) with only a gentle
        // pull back onto the right radius keeps the step the same size every tick, so it stays "like circle speed".
        double tx = -Math.sin(angle) * dirSign, tz = Math.cos(angle) * dirSign;
        double rx = curR > 1.0E-4 ? rel.x / curR : tx, rz = curR > 1.0E-4 ? rel.z / curR : tz;
        double radErr = radius.get() - curR;                                // + too close to the centre, - too far out
        double corrGain = 0.15;                                             // soft correction: no snapping back
        double mvx = tx + rx * radErr * corrGain, mvz = tz + rz * radErr * corrGain;
        double len = Math.hypot(mvx, mvz);
        if (len < 1.0E-4) return;

        double ms = moveSpeed.get();
        p.setSprinting(true);
        double vy = autoJump.get() && p.isOnGround() ? 0.42 : p.getVelocity().y;   // vanilla jump impulse
        p.setVelocity(mvx / len * ms, vy, mvz / len * ms);                  // constant length every tick
        double dx = center.x - p.getX(), dz = center.z - p.getZ(), dy = target.getEyeY() - p.getEyeY();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        if (camera.get()) {
            // Take the short way round, so the camera does not spin a full turn when the angle wraps at +-180.
            p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yaw - p.getYaw()));
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        } else if (c.getNetworkHandler() != null) {
            ServerRotation.set(yaw, MathHelper.clamp(pitch, -90f, 90f), 400);   // third-person model shows the aim
            c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
        }
    }

    private LivingEntity nearest(MinecraftClient c, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestD = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            double d = p.distanceTo(le);
            if (d <= bestD) { bestD = d; best = le; }
        }
        return best;
    }
}
