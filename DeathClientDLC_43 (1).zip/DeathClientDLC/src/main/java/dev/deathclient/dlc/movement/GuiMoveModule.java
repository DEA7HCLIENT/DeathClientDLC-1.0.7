package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** GuiMove: you keep walking, jumping and sprinting with an inventory / chest open (read from the keyboard directly). */
public class GuiMoveModule extends Module {
    public GuiMoveModule() { super("GuiMove", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null || !(c.currentScreen instanceof HandledScreen<?>) || c.currentScreen instanceof ChatScreen) return;
        long win = c.getWindow().getHandle();
        KeyBinding[] keys = {c.options.forwardKey, c.options.backKey, c.options.leftKey, c.options.rightKey,
                c.options.jumpKey, c.options.sprintKey};
        for (KeyBinding k : keys) {
            int code = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode();
            k.setPressed(code > 0 && GLFW.glfwGetKey(win, code) == GLFW.GLFW_PRESS);
        }
    }
}
