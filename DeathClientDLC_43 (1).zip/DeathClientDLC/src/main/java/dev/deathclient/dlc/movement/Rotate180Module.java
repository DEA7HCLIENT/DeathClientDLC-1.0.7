package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Rotate 180: spins your view by 180 degrees (a full about-face) to the right or to the left, at a speed you
 * choose (50 to 360 degrees per second), and switches itself off when the turn is done. Put it on a key (bind)
 * and every press is one half turn: at 360 the turn takes half a second, at 50 about three and a half seconds.
 * "Instant" skips the animation entirely and snaps the view straight to the result on the very next tick.
 * "Snap to 90" first rounds your direction to the nearest multiple of 90 degrees, so repeated turns always end
 * on one of the four straight directions even if you started a little off.
 * It turns the real view (the camera and what the server sees); the game draws it smoothly between ticks.
 */
public class Rotate180Module extends Module {
    /** Degrees per second; ignored while Instant is on. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 180, 50, 360, 10));
    public final NumberSetting direction = add(new NumberSetting("Direction", 1, 1, 2, 1).labels("Right", "Left"));
    public final BoolSetting instant = add(new BoolSetting("Instant", true));
    public final BoolSetting snapToGrid = add(new BoolSetting("Snap to 90", false));

    private boolean started;
    private float target;

    public Rotate180Module() { super("Rotate 180", Category.MOVEMENT); }

    @Override
    protected void onDisable() { started = false; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null) return;
        if (!started) {                                                    // the first tick after it was switched on
            float base = p.getYaw();
            if (snapToGrid.get()) base = Math.round(base / 90f) * 90f;
            target = base + ((int) direction.get() == 1 ? 180f : -180f);  // a bigger yaw is a turn to the right
            started = true;
            if (instant.get()) {
                p.setYaw(target);
                toggle();                                                 // done: switch itself off
                return;
            }
        }
        float diff = target - p.getYaw();
        float step = (float) (speed.get() / 20.0);                         // a tick is 1/20 second
        if (Math.abs(diff) <= step) {
            p.setYaw(target);
            toggle();                                                      // done: switch itself off
        } else {
            p.setYaw(p.getYaw() + Math.copySign(step, diff));
        }
    }
}
