package dev.deathclient.dlc;

/**
 * Liquid Glass: HUD panels, the main menu buttons, the glass menu cards and the ClickGUI window get a clear, light
 * "liquid glass" look: a faint frosted body (so text stays readable on bright backgrounds), a bright rim that catches
 * light at the top-left and bottom-right, a colour fringe on the inner edge (light splitting, like thick glass), a glow
 * along the bottom inside edge, a gloss on top and a slow light sweep. On the main menu a glass lens glides to the
 * button under the cursor and stretches a little while it moves.
 * The drawing lives in LiquidGlass; this class only holds the settings.
 * It does not refract or blur what is behind the glass (that needs a shader), it imitates the look.
 */
public class LiquidGlassModule extends Module {
    /** How strong the glass body is, in percent (lower = clearer). */
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 26, 5, 70, 1));
    /** Frosted layer under the glass, in percent: higher = text is easier to read on bright backgrounds. */
    public final NumberSetting contrast = add(new NumberSetting("Contrast", 45, 0, 100, 5));
    /** How much of the theme colour is mixed into the glass, in percent. */
    public final NumberSetting tint = add(new NumberSetting("Tint", 15, 0, 100, 5));
    /** Brightness of the rim, in percent. */
    public final NumberSetting rim = add(new NumberSetting("Rim", 70, 10, 100, 5));
    /** Corner radius limit in pixels: panels are rounded up to this (or fully, when they are low). */
    public final NumberSetting radius = add(new NumberSetting("Roundness", 14, 2, 30, 1));
    public final BoolSetting fringe = add(new BoolSetting("Colour fringe", true));
    public final BoolSetting sweep = add(new BoolSetting("Light sweep", true));
    public final BoolSetting lens = add(new BoolSetting("Menu lens", true));

    public LiquidGlassModule() { super("Liquid Glass", Category.MISC); }
}
