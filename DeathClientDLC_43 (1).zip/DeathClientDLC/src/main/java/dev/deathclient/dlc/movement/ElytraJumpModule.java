package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** ElytraJump: hold jump while gliding and you rise. */
public class ElytraJumpModule extends Module {
    public final NumberSetting power = add(new NumberSetting("Power", 0.1, 0.02, 0.5, 0.01));
    public final NumberSetting max = add(new NumberSetting("Max rise", 0.8, 0.2, 2.0, 0.05));

    public ElytraJumpModule() { super("ElytraJump", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || !p.isGliding() || !c.options.jumpKey.isPressed()) return;
        Vec3d v = p.getVelocity();
        if (v.y < max.get()) p.setVelocity(v.x, Math.min(max.get(), v.y + power.get()), v.z);
    }
}
