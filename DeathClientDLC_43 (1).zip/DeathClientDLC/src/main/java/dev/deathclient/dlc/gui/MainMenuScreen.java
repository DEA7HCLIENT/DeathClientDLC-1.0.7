package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Replacement title screen: the current account (top left), a greeting, the heading and the
 * button column on the left, and the "Фоны" (background picker) and "Cheat Menu" buttons bottom right.
 * Right-click anywhere switches the move / resize mode for the buttons: drag a button, resize it with the corner square.
 */
public class MainMenuScreen extends Screen {
    private static final int GAP = 6;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFA9ACB8;
    private static final int BTN = 0xD04A4D5A, BTN_HOVER = 0xE0636674, BTN_LINE = 0x48FFFFFF;
    private static final int MIN_W = 40, MAX_W = 300, MIN_H = 16, MAX_H = 60, HANDLE = 8;
    private static final int BAR_ITEMS = 5;

    private static final String[] I_GLOBE = {"..#####..", ".#..#..#.", "#...#...#", "#########", "#...#...#", "#########", "#...#...#", ".#..#..#.", "..#####.."};
    private static final String[] I_SINGLE = {".#######.", ".#.....#.", ".#.###.#.", ".#.....#.", ".#.###.#.", ".#.....#.", ".#######.", "....#....", "..#####.."};
    private static final String[] I_PERSON = {"...###...", "..#####..", "..#####..", "...###...", ".#######.", "#########", "#########", "#########"};
    private static final String[] I_GEAR = {"...#.#...", ".#######.", "..##.##..", "###...###", "..#...#..", "###...###", "..##.##..", ".#######.", "...#.#..."};
    private static final String[] I_QUIT = {"#####....", "#...#.#..", "#...#.##.", "#...#####", "#...#.##.", "#...#.#..", "#####...."};
    private static final String[] I_MENU = {"#.#.#.#.#", ".#######.", "#########", ".#######.", "#.#.#.#.#"};
    private static final String[] I_IMAGE = {"#########", "#.......#", "#.#.....#", "#...#.#.#", "#..###..#", "#.#####.#", "#########"};

    private record Item(String label, String[] icon, Runnable action) {}

    private final List<Item> items = new ArrayList<>();
    private boolean editing;
    private int dragIndex = -1, resizeIndex = -1, grabDX, grabDY;
    private String status = "";
    private long statusUntil;

    public MainMenuScreen() { super(Text.literal("Death Client")); }

    @Override
    protected void init() {
        MenuCustom.ensureLoaded();
        items.clear();
        items.add(new Item("Multiplayer", I_GLOBE, () -> client.setScreen(new MultiplayerScreen(this))));
        items.add(new Item("Singleplayer", I_SINGLE, () -> client.setScreen(new SelectWorldScreen(this))));
        items.add(new Item("Сменить аккаунт", I_PERSON, () -> client.setScreen(new AccountsScreen(this))));
        items.add(new Item("Options...", I_GEAR, () -> client.setScreen(new OptionsScreen(this, client.options))));
        items.add(new Item("Quit Game", I_QUIT, () -> client.scheduleStop()));
        items.add(new Item("Cheat Menu", I_MENU, () -> client.setScreen(GuiStyleModule.create())));
        items.add(new Item("Фоны", I_IMAGE, () -> client.setScreen(new BackgroundsScreen(this))));
    }

    // ------------------------------------------------------------------ layout (scales with the screen)

    private int colX() { return Math.round(width * 0.046f); }
    private int colW() { return clamp(Math.round(width * 0.254f), 130, 230); }
    private int bh0() { return clamp(Math.round(height * 0.076f), 20, 30); }
    private int gap0() { return Math.max(4, Math.round(height * 0.02f)); }
    private int y0() { return Math.round(height * 0.535f); }
    private int fw() { return clamp(Math.round(width * 0.098f), 56, 90); }

    private int baseW(int i) {
        if (i <= 2) return colW();
        if (i <= 4) return (colW() - GAP) / 2;
        return fw();
    }

    private int baseH(int i) { return i <= 4 ? bh0() : Math.max(18, bh0() - 5); }

    private int baseX(int i) {
        if (i <= 3) return colX();
        if (i == 4) return colX() + (colW() - GAP) / 2 + GAP;
        int fx = width - fw() - Math.round(width * 0.022f);
        return i == 6 ? fx : fx - fw() - GAP;
    }

    private int baseY(int i) {
        if (i <= 2) return y0() + i * (bh0() + gap0());
        if (i <= 4) return y0() + 3 * (bh0() + gap0());
        return Math.min(Math.round(height * 0.889f), height - baseH(i) - 4);
    }

    private int bw(int i) { return MenuCustom.sizeW[i] > 0 ? MenuCustom.sizeW[i] : baseW(i); }
    private int bh(int i) { return MenuCustom.sizeH[i] > 0 ? MenuCustom.sizeH[i] : baseH(i); }
    private int bx(int i) { return clamp(baseX(i) + MenuCustom.offX[i], 0, Math.max(0, width - bw(i))); }
    private int by(int i) { return clamp(baseY(i) + MenuCustom.offY[i], 0, Math.max(0, height - bh(i))); }

    // edit bar
    private int barW() { return Math.min(120, (width - 36) / BAR_ITEMS); }
    private int barX(int k) {
        int bw = barW();
        int total = bw * BAR_ITEMS + 6 * (BAR_ITEMS - 1);
        return (width - total) / 2 + k * (bw + 6);
    }
    private int barY() { return height - 58; }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean onHandle(double mx, double my, int i) {
        return in(mx, my, bx(i) + bw(i) - HANDLE, by(i) + bh(i) - HANDLE, HANDLE, HANDLE);
    }

    private void setStatus(String s) {
        status = s;
        statusUntil = System.currentTimeMillis() + 4000;
    }

    // ------------------------------------------------------------------ drawing helpers

    private static void icon(DrawContext ctx, String[] rows, int x, int y, int color, int px) {
        for (int j = 0; j < rows.length; j++) {
            String row = rows[j];
            for (int i = 0; i < row.length(); i++) {
                if (row.charAt(i) == '#') ctx.fill(x + i * px, y + j * px, x + (i + 1) * px, y + (j + 1) * px, color);
            }
        }
    }

    private static void outline(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    private static int alpha(int argb, float a) {
        return (Math.round(((argb >>> 24) & 0xFF) * a) << 24) | (argb & 0xFFFFFF);
    }

    private static int lighten(int argb, float t) { return ClickGuiScreen.mix(argb, 0xFFFFFFFF, t); }

    // ------------------------------------------------------------------ background

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        int ox = 0, oy = 0;
        if (MenuCustom.hasBackground()) MenuCustom.drawBackground(ctx, width, height, ox, oy);
        else Ui.drawBackground(ctx, width, height, ox, oy);
        ctx.fill(0, 0, width, height, 0x22000000);                // slight dim so white text stays readable
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        PhotoButton.draw(ctx, width, height);
        renderMenu(ctx, mx, my, delta);
        float fade = SplashScreen.introFade();                       // coming out of black after the start-up screen
        if (fade > 0f) ctx.fill(0, 0, width, height, ((int) (fade * 255f) << 24));
    }

    private void renderMenu(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int acc = Theme.current().accent();

        renderAccount(ctx);
        renderTexts(ctx, acc);

        for (int i = 0; i < items.size(); i++) renderButton(ctx, i, mx, my, acc);

        if (LiquidGlass.on() && !editing) {                          // the glass lens glides to the button under the cursor
            int hov = -1;
            for (int i = 0; i < items.size(); i++) if (in(mx, my, bx(i), by(i), bw(i), bh(i))) { hov = i; break; }
            if (hov >= 0) LiquidGlass.lens(ctx, true, bx(hov), by(hov), bw(hov), bh(hov));
            else LiquidGlass.lens(ctx, false, 0, 0, 0, 0);
        }

        if (editing) {
            String hint = "Тяни кнопки мышью, квадрат в углу меняет размер. Картинку можно перетащить в окно - она станет фоном.";
            ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui(hint), width / 2, barY() - 14, WHITE);
            if (System.currentTimeMillis() < statusUntil) {
                ctx.drawCenteredTextWithShadow(textRenderer, Fonts.gui(status), width / 2, barY() - 26, 0xFFFFD866);
            }
            String[] labels = {"Сбросить фон", "Сбросить кнопки", "Тема: " + Theme.current().label, "Стиль: " + MenuCustom.STYLE_NAMES[MenuCustom.style], "Готово"};
            for (int k = 0; k < BAR_ITEMS; k++) {
                int x = barX(k), y = barY(), bw = barW();
                boolean h = in(mx, my, x, y, bw, 22);
                ClickGuiScreen.rrect(ctx, x, y, bw, 22, h ? (acc | 0xFF000000) : BTN, 6);
                ctx.drawTextWithShadow(textRenderer, Fonts.gui(labels[k]), x + (bw - Fonts.guiWidth(textRenderer, labels[k])) / 2, y + 7, WHITE);
            }
        }
    }

    /** Top left: the current account. */
    private void renderAccount(DrawContext ctx) {
        int x = Math.round(width * 0.031f), y = 14;
        Fonts.draw(ctx, textRenderer, "Текущий аккаунт", x, y + 3, 0xB0FFFFFF);
        ctx.drawTextWithShadow(textRenderer, Fonts.bold(Accounts.currentName()), x, y + 14, WHITE);
    }

    /** Greeting, heading and subtitle above the button column. */
    private void renderTexts(DrawContext ctx, int acc) {
        int x = colX(), y0 = y0();
        int headW = Math.round(width * 0.36f);                                // heading picture width
        int headH = Ui.headingHeight(headW);

        int subY = y0 - 14;
        int headY = subY - 6 - headH;
        int greetY = headY - 14;

        String name = Accounts.currentName();
        Fonts.draw(ctx, textRenderer, "РАД ВИДЕТЬ, " + name.toUpperCase(), x, greetY, lighten(acc | 0xFF000000, 0.35f));
        Ui.drawHeading(ctx, x, headY, headW);
        Fonts.draw(ctx, textRenderer, "Куда отправимся сегодня - на сервер или в свой мир?", x, subY, 0xFFB9BCC8);
    }

    private List<String> wrap(String s, float f, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (cur.length() > 0 && textRenderer.getWidth(Fonts.bold(t)) * f > maxW) {
                out.add(cur.toString());
                cur = new StringBuilder(word);
            } else {
                cur = new StringBuilder(t);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private void renderButton(DrawContext ctx, int i, int mx, int my, int acc) {
        int x = bx(i), y = by(i), w = bw(i), h = bh(i);
        Item it = items.get(i);
        boolean hover = in(mx, my, x, y, w, h);
        boolean active = editing ? (dragIndex == i || resizeIndex == i) : hover;
        int shape = Shapes.shape();
        boolean glass = Shapes.glass(shape);
        int r = Math.min(Shapes.corner(shape) == 0 ? 0 : Shapes.radius() + 3, h / 2);   // main menu buttons are a bit rounder
        int accent = acc | 0xFF000000;

        if (LiquidGlass.on()) {                            // Liquid Glass: clear pill, the lens marks the hovered one
            LiquidGlass.card(ctx, x, y, w, h, h / 2, 1f);
        } else if (MenuCustom.style == 1) {                // Pills: fully rounded, accent when hovered
            int pr = h / 2;
            ClickGuiScreen.rrect(ctx, x, y, w, h, active ? accent : 0xE0181822, pr);
            ClickGuiScreen.outline(ctx, x, y, w, h, active ? 0xFFFFFFFF : (accent & 0x80FFFFFF), pr);
        } else if (MenuCustom.style == 2) {                // Minimal: no box, an accent line under the label when hovered
            if (active) ctx.fill(x + 10, y + h - 2, x + w - 10, y + h - 1, accent);
        } else if (MenuCustom.style == 3) {                // Bar: a square panel with an accent bar on the left
            ctx.fill(x, y, x + w, y + h, active ? 0xE0202030 : 0xC0141420);
            ctx.fill(x, y, x + 3, y + h, accent);
        } else if (glass) {
            ClickGuiScreen.rrect(ctx, x - 1, y - 1, w + 2, h + 2, active ? 0x70FFFFFF : 0x50FFFFFF, r + 1);
            ClickGuiScreen.rrect(ctx, x, y, w, h, active ? 0x90303848 : Shapes.glassFill(1f), r);
            ctx.fillGradient(x + r, y + 1, x + w - r, y + h / 2, 0x30FFFFFF, 0x00FFFFFF);
            ctx.fill(x + r, y + 1, x + w - r, y + 2, 0x80FFFFFF);
        } else {
            ClickGuiScreen.rrect(ctx, x - 1, y - 1, w + 2, h + 2, BTN_LINE, r + 1);
            ClickGuiScreen.rrect(ctx, x, y, w, h, active ? BTN_HOVER : BTN, r);
            ctx.fill(x + r, y + h - 2, x + w - r, y + h - 1, 0x30000000);   // darker lower edge
        }

        if (editing) {
            outline(ctx, x - 1, y - 1, w + 2, h + 2, WHITE);
            ctx.fill(x + w - HANDLE, y + h - HANDLE, x + w, y + h, WHITE);
            ctx.fill(x + w - HANDLE + 2, y + h - HANDLE + 2, x + w - 2, y + h - 2, Theme.current().dim());
        }

        int ih = it.icon().length;
        icon(ctx, it.icon(), x + 10, y + (h - ih) / 2, WHITE, 1);
        Fonts.draw(ctx, textRenderer, it.label(), x + 10 + 9 + 8, y + (h - 8) / 2, WHITE);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0 && PhotoButton.click(click.x(), click.y(), width, height, MenuCustom.backgroundsDir())) return true;
        if (click.button() == 1) {                                                 // right click: move / resize mode
            editing = !editing;
            dragIndex = -1;
            resizeIndex = -1;
            return true;
        }
        if (click.button() == 0) {
            double mx = click.x(), my = click.y();

            if (editing) {
                for (int k = 0; k < BAR_ITEMS; k++) {
                    if (in(mx, my, barX(k), barY(), barW(), 22)) {
                        if (k == 0) { MenuCustom.resetBackground(); setStatus("Фон сброшен"); }
                        else if (k == 1) { MenuCustom.resetButtons(); setStatus("Кнопки сброшены"); }
                        else if (k == 2) { Theme.cycle(); setStatus("Тема: " + Theme.current().label); }
                        else if (k == 3) { MenuCustom.cycleStyle(); setStatus("Стиль: " + MenuCustom.STYLE_NAMES[MenuCustom.style]); }
                        else { editing = false; }
                        return true;
                    }
                }
                for (int i = items.size() - 1; i >= 0; i--) {
                    if (onHandle(mx, my, i)) { resizeIndex = i; return true; }
                }
                for (int i = items.size() - 1; i >= 0; i--) {
                    if (in(mx, my, bx(i), by(i), bw(i), bh(i))) {
                        dragIndex = i;
                        grabDX = (int) mx - bx(i);
                        grabDY = (int) my - by(i);
                        return true;
                    }
                }
                return true;
            }
            for (int i = 0; i < items.size(); i++) {
                if (in(mx, my, bx(i), by(i), bw(i), bh(i))) {
                    items.get(i).action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (editing && resizeIndex >= 0 && click.button() == 0) {
            int i = resizeIndex;
            MenuCustom.sizeW[i] = clamp((int) click.x() - bx(i), MIN_W, Math.max(MIN_W, Math.min(MAX_W, width - bx(i))));
            MenuCustom.sizeH[i] = clamp((int) click.y() - by(i), MIN_H, Math.max(MIN_H, Math.min(MAX_H, height - by(i))));
            return true;
        }
        if (editing && dragIndex >= 0 && click.button() == 0) {
            int nx = clamp((int) click.x() - grabDX, 0, Math.max(0, width - bw(dragIndex)));
            int ny = clamp((int) click.y() - grabDY, 0, Math.max(0, height - bh(dragIndex)));
            MenuCustom.offX[dragIndex] = nx - baseX(dragIndex);
            MenuCustom.offY[dragIndex] = ny - baseY(dragIndex);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragIndex >= 0 || resizeIndex >= 0) {
            dragIndex = -1;
            resizeIndex = -1;
            MenuCustom.save();
            return true;
        }
        return super.mouseReleased(click);
    }

    // Dropping an image file onto the game window (the method name differs between mappings, so both are defined).
    public void filesDragged(List<Path> paths) { handleDrop(paths); }

    public void onFilesDropped(List<Path> paths) { handleDrop(paths); }

    private void handleDrop(List<Path> paths) {
        if (paths == null || paths.isEmpty()) return;
        try {
            if (CustomFontPack.isFontFile(paths.get(0))) {
                CustomFontPack.installAndUse(client, paths.get(0));
                setStatus("Шрифт установлен, ресурсы перезагружаются");
                return;
            }
            MenuCustom.addAndUse(paths.get(0));            // copied into the backgrounds folder, so it shows up in "Фоны"
            setStatus("Фон установлен");
        } catch (Exception e) {
            setStatus("Не удалось загрузить файл (картинка png / jpg или шрифт ttf / otf)");
        }
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
