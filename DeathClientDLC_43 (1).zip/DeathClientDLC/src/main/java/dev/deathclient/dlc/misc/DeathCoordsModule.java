package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.text.Text;

/** DeathCoords: when you die, the coordinates and dimension of the place are written to your chat. */
public class DeathCoordsModule extends Module {
    private boolean wasDead;
    private static String last = "";

    public DeathCoordsModule() { super("DeathCoords", Category.MISC); }

    public static String last() { return last; }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null || c.world == null) return;
        boolean dead = c.currentScreen instanceof DeathScreen || c.player.isDead();
        if (dead && !wasDead) {
            last = (int) c.player.getX() + " " + (int) c.player.getY() + " " + (int) c.player.getZ()
                    + " (" + c.world.getRegistryKey().getValue().getPath() + ")";
            c.player.sendMessage(Text.literal("[Death] Вы умерли на " + last), false);
        }
        wasDead = dead;
    }
}
