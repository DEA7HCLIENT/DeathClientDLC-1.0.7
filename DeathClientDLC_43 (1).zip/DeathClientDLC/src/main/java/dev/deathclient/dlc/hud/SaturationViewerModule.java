package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** SaturationViewer: a small box with your hunger and saturation (the hidden part of the food bar). */
public class SaturationViewerModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 600, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 60, 0, 400, 1));

    public SaturationViewerModule() { super("SaturationViewer", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        SaturationViewerModule m = ModuleManager.get(SaturationViewerModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden || c.currentScreen != null) return;
        var tr = c.textRenderer;
        int food = c.player.getHungerManager().getFoodLevel();
        String s = "Еда " + food + "/20  ·  Сытость " + String.format("%.1f", c.player.getHungerManager().getSaturationLevel());
        int w = Fonts.width(tr, s) + 10, x0 = (int) m.x.get(), y0 = (int) m.y.get();
        HudEdit.track(x0, y0, w, 14, (nx, ny) -> { m.x.set(nx); m.y.set(ny); });
        Shapes.panel(ctx, x0, y0, w, 14, 0xB0101010);
        Fonts.draw(ctx, tr, s, x0 + 5, y0 + 3, (Theme.current().accent()) | 0xFF000000);
    }
}
