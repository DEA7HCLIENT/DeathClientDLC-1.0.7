package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

/**
 * All rotation logic of Kill Aura, kept apart from the module: the profiles (Silent, Smooth, Neuro, VodkaCraft, HvH,
 * Bezier, Spring, Focus, Snap, Grim, Matrix, Monday), the held server-side view and the look packets.
 * KillAuraModule only picks targets and attacks; per tick it calls {@link #update}, and around every hit
 * {@link #beforeHit} / {@link #afterHits}. The settings it reads (Turn speed, Aim point, Hit check, Visual camera,
 * Range) stay on the module so the menu and saved configs do not change.
 * All profiles except None / Silent / Smooth / HvH are heuristics; none has been checked against a particular
 * server's anti-cheat.
 */
final class KillAuraRotation {
    static final int NONE = 1, SILENT = 2, SMOOTH = 3, NEURO = 4, VODKA = 5, HVH = 6,
            BEZIER = 7, SPRING = 8, FOCUS = 9, SNAP = 10, GRIM = 11, MATRIX = 12, MONDAY = 13;

    static final String[] LABELS = {"None", "Silent", "Smooth", "Neuro", "VodkaCraft", "HvH",
            "Bezier", "Spring", "Focus", "Snap", "Grim", "Matrix", "Monday"};

    private final KillAuraModule ka;
    private final MondayRotation monday = new MondayRotation();

    /** Server-side rotation held by the server-side profiles while a target exists. */
    private boolean srvActive;
    private float srvYaw, srvPitch;
    /** Neuro / Matrix / Wander aim point offset inside the hitbox, re-rolled every few ticks. */
    private Vec3d aimOffset = Vec3d.ZERO;
    private int aimTicks;
    /** Bezier: size of the turn when it started, and which side the arc bends to. */
    private float bzStart, bzSign = 1f;
    /** Spring: angular velocity in degrees per tick. */
    private float velYaw, velPitch;
    /** Matrix: ticks the aim rests for (a hand does not move every tick), and this hit's cooldown threshold. */
    private int mxPause;
    private float matrixNeed = 0.95f;

    KillAuraRotation(KillAuraModule ka) { this.ka = ka; }

    // ---- what a mode implies for the module ----

    /** Modes that keep a server-side view between ticks. */
    static boolean held(int mode) {
        return mode == VODKA || mode == HVH || mode == FOCUS || mode == GRIM || mode == MATRIX || mode == MONDAY;
    }

    /** Camera modes; with Visual camera off they run on a hidden server view. */
    static boolean cameraMode(int mode) {
        return mode == SMOOTH || mode == NEURO || mode == BEZIER || mode == SPRING;
    }

    /** Modes that aim at one target at a time. */
    static boolean singleTarget(int mode) {
        return mode == NEURO || mode == VODKA || mode == BEZIER || mode == SPRING || mode == FOCUS
                || mode == GRIM || mode == MATRIX || mode == MONDAY;
    }

    /** Modes that stay under 2.95 blocks of reach. */
    static boolean strictReach(int mode) { return mode == GRIM || mode == MATRIX; }

    /** Weapon cooldown needed before a hit in this mode, given the module's own value. */
    float minCooldown(int mode, float base) {
        if (mode == GRIM) return Math.max(base, 0.95f);          // full cooldown, like a player who waits for it
        if (mode == MATRIX) return Math.max(base, matrixNeed);   // the threshold differs from hit to hit
        return base;
    }

    /** True when this mode must not hit right now (eating / blocking; Matrix also needs line of sight). */
    boolean hitBlocked(ClientPlayerEntity p, LivingEntity t, int mode) {
        if (mode == GRIM) return p.isUsingItem() || p.isBlocking();
        if (mode == MATRIX) return p.isUsingItem() || p.isBlocking() || !p.canSee(t);
        return false;
    }

    // ---- per-tick lifecycle ----

    /** A different target became the primary one: drop the per-target aim state. */
    void onNewTarget() {
        aimTicks = 0;
        bzStart = 0;
        velYaw = velPitch = 0;
        bzSign = ThreadLocalRandom.current().nextBoolean() ? 1f : -1f;
    }

    /** Runs the mode for this tick; returns whether the aim is good enough to hit. */
    boolean update(MinecraftClient c, ClientPlayerEntity p, LivingEntity t, int mode) {
        // Camera modes with Visual camera off: run them on a hidden "server view" so your real camera stays put.
        boolean srvCam = !ka.visualCamera.get() && cameraMode(mode);
        if (!held(mode) && !srvCam) release(c, p);

        float realYaw = 0f, realPitch = 0f;
        if (srvCam) {
            if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
            realYaw = p.getYaw(); realPitch = p.getPitch();
            p.setYaw(srvYaw); p.setPitch(srvPitch);                      // the mode below turns this view, not yours
        }

        boolean aligned = true;
        switch (mode) {
            case SMOOTH -> turnToward(p, t);
            case NEURO -> aligned = neuro(c, p, t);
            case VODKA -> aligned = vodka(c, p, t);
            case HVH -> hvhLock(c, p, t);
            case BEZIER -> aligned = bezier(c, p, t);
            case SPRING -> aligned = spring(c, p, t);
            case FOCUS -> aligned = focus(c, p, t);
            case GRIM -> aligned = grim(c, p, t);
            case MATRIX -> aligned = matrix(c, p, t);
            case MONDAY -> aligned = monday(c, p, t);
            default -> {}
        }
        if (srvCam) {
            srvYaw = p.getYaw(); srvPitch = p.getPitch();
            p.setYaw(realYaw); p.setPitch(realPitch);                    // your camera goes back untouched
            sendLook(c, p, srvYaw, srvPitch);
        }
        return aligned;
    }

    /** Right before hit number {@code index} (0 = first target): the per-hit looks of Silent / Snap / HvH. */
    void beforeHit(MinecraftClient c, ClientPlayerEntity p, LivingEntity t, int mode, int index) {
        if (mode == SILENT || (mode == HVH && index > 0)) {
            sendLook(c, p, wantYaw(p, t), wantPitch(p, t));              // server sees the aim for this hit
        } else if (mode == SNAP) {
            float[] r = snapRotation(c, p, t);
            sendLook(c, p, r[0], r[1]);
        }
    }

    /** After the hits of this tick: Matrix re-rolls its cooldown; Silent / Snap tell the server the real view again. */
    void afterHits(MinecraftClient c, ClientPlayerEntity p, int mode, int hits) {
        if (mode == MATRIX) matrixNeed = 0.93f + ThreadLocalRandom.current().nextFloat() * 0.07f;
        if (mode == SILENT || mode == SNAP) sendLook(c, p, p.getYaw(), p.getPitch());                  // back to the real view
        else if (mode == HVH && hits > 1) sendLook(c, p, srvYaw, srvPitch);                           // back to the lock
    }

    /** Ends a held server-side rotation by telling the server the real view again. */
    void release(MinecraftClient c, ClientPlayerEntity p) {
        monday.reset();
        if (!srvActive) return;
        srvActive = false;
        if (p != null) sendLook(c, p, p.getYaw(), p.getPitch());
    }

    // ---- rotation profiles ----

    /** Camera rotation: speed eases with the remaining angle, aim point wanders inside the hitbox, deltas sit on the mouse grid. */
    private boolean neuro(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (aimTicks-- <= 0) {
            Box b = t.getBoundingBox();
            aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                    (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                    r.nextDouble(-0.25, 0.25) * b.getLengthZ());
            aimTicks = r.nextInt(5, 11);
        }
        float[] want = Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter().add(aimOffset));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float gcd = Rotations.gcd(c);
        float max = (float) ka.turnSpeed.get();
        p.setYaw(p.getYaw() + Rotations.snap(humanStep(dy, max, r), gcd));
        p.setPitch(MathHelper.clamp(p.getPitch() + Rotations.snap(humanStep(dp, max * 0.6f, r), gcd), -90f, 90f));
        return Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw())) <= 20f && Math.abs(want[1] - p.getPitch()) <= 20f;
    }

    /** Server-side rotation: held between ticks, advanced by a limited, slightly randomized step on the mouse grid. */
    private boolean vodka(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d point = new Vec3d(b.getCenter().x, b.minY + b.getLengthY() * 0.7 + r.nextDouble(-0.03, 0.03), b.getCenter().z);
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float gcd = Rotations.gcd(c);
        float max = (float) ka.turnSpeed.get();
        srvYaw += Rotations.snap(MathHelper.clamp(dy, -max, max) * (float) r.nextDouble(0.85, 1.0), gcd);
        srvPitch = MathHelper.clamp(srvPitch + Rotations.snap(MathHelper.clamp(dp, -max * 0.5f, max * 0.5f) * (float) r.nextDouble(0.85, 1.0), gcd), -90f, 90f);
        sendLook(c, p, srvYaw, srvPitch);
        return Math.abs(MathHelper.wrapDegrees(want[0] - srvYaw)) <= 12f && Math.abs(want[1] - srvPitch) <= 12f;
    }

    /** Server-side rotation: snaps onto the hitbox center every tick and stays there. */
    private void hvhLock(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        srvActive = true;
        srvYaw = wantYaw(p, t);
        srvPitch = wantPitch(p, t);
        sendLook(c, p, srvYaw, srvPitch);
    }

    /**
     * Grim profile: the aim is held on the server side, and every angle sent sits exactly on the mouse-sensitivity
     * grid relative to the last one (so the changes look like real mouse counts). Steps are limited and a little random,
     * a look packet identical to the previous one is never sent (a real client does not repeat one), the aim point is
     * inside the hitbox (not on its edge), and the hit goes out only when the look ray the server knows crosses the
     * hitbox shrunk by 0.03 within 2.95 blocks. No hit while eating or blocking, full weapon cooldown, one target.
     * This follows what is publicly known about Grim's aim and reach checks; it has not been tested against Grim.
     */
    private boolean grim(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d point = new Vec3d(b.getCenter().x + r.nextDouble(-0.12, 0.12) * b.getLengthX(),
                b.minY + b.getLengthY() * (0.62 + r.nextDouble(-0.08, 0.08)),
                b.getCenter().z + r.nextDouble(-0.12, 0.12) * b.getLengthZ());
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float max = (float) ka.turnSpeed.get();
        float gcd = Rotations.gcd(c);
        float ny = srvYaw + Rotations.snap(focusStep(dy, max, r), gcd);
        float np = MathHelper.clamp(srvPitch + Rotations.snap(focusStep(dp, max * 0.6f, r), gcd), -90f, 90f);
        if (ny != srvYaw || np != srvPitch) {                                // never repeat an identical look packet
            srvYaw = ny;
            srvPitch = np;
            sendLook(c, p, srvYaw, srvPitch);
        } else {
            ServerRotation.set(srvYaw, srvPitch, 400);
        }
        return Rotations.rayHits(p.getEyePos(), srvYaw, srvPitch, b.contract(0.03), 2.95, 0.0);
    }

    /**
     * Matrix profile: a held server-side aim made to look like a hand on a mouse rather than a lock. The aim point
     * wanders inside the upper body; the turn is fast when far and slow when close (never more than 20 degrees a tick);
     * steps are on the sensitivity grid and never identical packets; every few ticks the aim rests for a moment, and when
     * it is on target the pitch is nudged by one grid step now and then, so it never sits at a constant angle. The hit
     * waits for the look ray to cross the hitbox within 2.95 blocks, needs a clear line of sight, uses a cooldown
     * threshold that changes from hit to hit (0.93-1.0, so the gaps between hits are not even), and is never sent while
     * eating or blocking. Built from the usual aim / reach / click-pattern checks of such anti-cheats; not tested against Matrix.
     */
    private boolean matrix(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); mxPause = 0; aimTicks = 0; }
        Box b = t.getBoundingBox();
        if (aimTicks-- <= 0) {                                                 // the aim point drifts inside the upper body
            aimOffset = new Vec3d(r.nextDouble(-0.18, 0.18) * b.getLengthX(),
                    (r.nextDouble(-0.02, 0.2)) * b.getLengthY(),
                    r.nextDouble(-0.18, 0.18) * b.getLengthZ());
            aimTicks = r.nextInt(4, 10);
        }
        float[] want = Util.rotationsTo(p.getEyePos(), b.getCenter().add(aimOffset));
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float dist = (float) Math.sqrt(dy * dy + dp * dp);
        float gcd = Rotations.gcd(c);

        if (mxPause > 0) {
            mxPause--;
        } else {
            if (dist < 6f && r.nextInt(8) == 0) mxPause = r.nextInt(1, 3);
            float max = Math.min((float) ka.turnSpeed.get(), 20f);
            float ny = srvYaw + Rotations.snap(humanStep(dy, max, r), gcd);
            float np = srvPitch + Rotations.snap(humanStep(dp, max * 0.5f, r), gcd);
            if (dist < 2f && r.nextInt(4) == 0) np += (r.nextBoolean() ? 1 : -1) * gcd;     // never a constant angle
            np = MathHelper.clamp(np, -90f, 90f);
            if (ny != srvYaw || np != srvPitch) {                                // never repeat an identical look packet
                srvYaw = ny;
                srvPitch = np;
                sendLook(c, p, srvYaw, srvPitch);
            }
        }
        ServerRotation.set(srvYaw, srvPitch, 400);
        return Rotations.rayHits(p.getEyePos(), srvYaw, srvPitch, b.contract(0.02), 2.95, 0.0);
    }

    /**
     * Monday profile: server-side, held. {@link MondayRotation} picks a visible point from its point table (weighted
     * body zones, held for a few ticks) and returns the next step on the mouse grid. Only changed angles are sent.
     * The hit goes out while the look ray the server knows crosses the hitbox within the module's Range.
     * Aim points are limited to Range + 0.6 from the eyes (0.6 is about the hitbox half-width, since points sit on the
     * hitbox, not at its nearest edge); not tested against any server's anti-cheat.
     */
    private boolean monday(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        MondayRotation.Rot r = monday.update(t, srvYaw, srvPitch, ka.range.get() + 0.6);
        if (r.yaw() != srvYaw || r.pitch() != srvPitch) {
            srvYaw = r.yaw();
            srvPitch = r.pitch();
            sendLook(c, p, srvYaw, srvPitch);
        } else {
            ServerRotation.set(srvYaw, srvPitch, 400);
        }
        return Rotations.rayHits(p.getEyePos(), srvYaw, srvPitch, t.getBoundingBox(), ka.range.get() + 0.1, 0.0);
    }

    // ---- aim point + other profiles ----

    /** Aim point inside the target's hitbox for the profiles that honour the "Aim point" setting. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t, float fromYaw, float fromPitch) {
        Box b = t.getBoundingBox();
        Vec3d c = b.getCenter();
        double h = b.getLengthY();
        switch ((int) ka.aimPoint.get()) {
            case 2: return new Vec3d(c.x, b.minY + h * 0.65, c.z);
            case 3: return new Vec3d(c.x, b.minY + h * 0.90, c.z);
            case 4: return Rotations.nearestPoint(p.getEyePos(), fromYaw, fromPitch, b);
            case 5: {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                if (aimTicks-- <= 0) {
                    aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                            (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                            r.nextDouble(-0.25, 0.25) * b.getLengthZ());
                    aimTicks = r.nextInt(5, 11);
                }
                return c.add(aimOffset);
            }
            default: return c;
        }
    }

    /** "Aligned" for Bezier / Spring / Focus: the look ray really hits the hitbox, or (Hit check off) the error is small. */
    private boolean aligned(ClientPlayerEntity p, LivingEntity t, float yaw, float pitch, float[] want, float tolerance) {
        if (ka.hitCheck.get()) return Rotations.rayHits(p.getEyePos(), yaw, pitch, t.getBoundingBox(), ka.range.get() + 0.1, 0.0);
        return Math.abs(MathHelper.wrapDegrees(want[0] - yaw)) <= tolerance && Math.abs(want[1] - pitch) <= tolerance;
    }

    /**
     * Camera rotation along a curve: starts slow, is fastest in the middle, slows down on arrival, and the
     * path bends slightly sideways in between (a hand does not move in a straight line). Close to the
     * target it only follows, with a little lag.
     */
    private boolean bezier(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float dist = (float) Math.sqrt(dy * dy + dp * dp);
        if (dist > bzStart) bzStart = dist;
        if (dist > 0.01f) {
            float progress = bzStart > 1f ? MathHelper.clamp(1f - dist / bzStart, 0f, 1f) : 1f;
            float bell = (float) Math.sin(Math.PI * progress);                 // 0 at both ends, 1 in the middle
            float max = (float) ka.turnSpeed.get() * (0.3f + 0.7f * bell) * (float) r.nextDouble(0.9, 1.1);
            float step = Math.min(dist, Math.min(dist * 0.6f + 0.5f, max));
            float k = step / dist;
            float arc = step * 0.25f * bell * bzSign;                          // sideways push, vanishes on arrival
            float gcd = Rotations.gcd(c);
            p.setYaw(p.getYaw() + Rotations.snap(dy * k - dp / dist * arc, gcd));
            p.setPitch(MathHelper.clamp(p.getPitch() + Rotations.snap(dp * k + dy / dist * arc, gcd), -90f, 90f));
        }
        return aligned(p, t, p.getYaw(), p.getPitch(), want, 15f);
    }

    /** Camera rotation with inertia: accelerates toward the target, overshoots a hair and settles. */
    private boolean spring(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        float max = (float) ka.turnSpeed.get();
        velYaw = MathHelper.clamp((velYaw + dy * 0.14f) * 0.62f * (float) r.nextDouble(0.95, 1.05), -max, max);
        velPitch = MathHelper.clamp((velPitch + dp * 0.14f) * 0.62f * (float) r.nextDouble(0.95, 1.05), -max * 0.6f, max * 0.6f);
        float gcd = Rotations.gcd(c);
        p.setYaw(p.getYaw() + Rotations.snap(velYaw, gcd));
        p.setPitch(MathHelper.clamp(p.getPitch() + Rotations.snap(velPitch, gcd), -90f, 90f));
        return aligned(p, t, p.getYaw(), p.getPitch(), want, 15f);
    }

    /**
     * Server-side rotation, held between ticks: each tick closes a fraction of the remaining angle (never
     * less than a small floor so it does not crawl), on the mouse grid. The hit only goes out while the
     * server-side look ray crosses the hitbox.
     */
    private boolean focus(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, srvYaw, srvPitch));
        float dy = MathHelper.wrapDegrees(want[0] - srvYaw);
        float dp = want[1] - srvPitch;
        float max = (float) ka.turnSpeed.get();
        float gcd = Rotations.gcd(c);
        srvYaw += Rotations.snap(focusStep(dy, max, r), gcd);
        srvPitch = MathHelper.clamp(srvPitch + Rotations.snap(focusStep(dp, max * 0.6f, r), gcd), -90f, 90f);
        sendLook(c, p, srvYaw, srvPitch);
        return aligned(p, t, srvYaw, srvPitch, want, 12f);
    }

    /** Snap: one turn to the aim point, quantized to the mouse grid relative to the real view. */
    private float[] snapRotation(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        float[] want = Util.rotationsTo(p.getEyePos(), aimPoint(p, t, p.getYaw(), p.getPitch()));
        float gcd = Rotations.gcd(c);
        float yaw = p.getYaw() + Rotations.snap(MathHelper.wrapDegrees(want[0] - p.getYaw()), gcd);
        float pitch = MathHelper.clamp(p.getPitch() + Rotations.snap(want[1] - p.getPitch(), gcd), -90f, 90f);
        return new float[]{yaw, pitch};
    }

    /** Smooth mode: turns the camera at most turnSpeed degrees this tick, the shorter way around. */
    private void turnToward(ClientPlayerEntity p, LivingEntity target) {
        float step = (float) ka.turnSpeed.get();
        float yawDiff = MathHelper.wrapDegrees(wantYaw(p, target) - p.getYaw());
        float pitchDiff = MathHelper.wrapDegrees(wantPitch(p, target) - p.getPitch());
        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }

    // ---- step helpers ----

    /** Fast when far, slow when close, never overshoots. */
    private static float humanStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.min(max, mag * 0.45f + 0.8f) * (float) r.nextDouble(0.85, 1.15);
        return Math.copySign(Math.min(step, mag), diff);
    }

    private static float focusStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.max(mag * 0.55f, 0.6f) * (float) r.nextDouble(0.92, 1.08);
        return Math.copySign(Math.min(Math.min(step, max), mag), diff);
    }

    private static float wantYaw(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[0];
    }

    private static float wantPitch(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[1];
    }

    // ---- packets ----

    private void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        ServerRotation.set(yaw, MathHelper.clamp(pitch, -90f, 90f), 400);   // third-person model shows the aim
        // Visual camera: the local view turns to the same angles the server is told, so you see the aim too.
        if (ka.visualCamera.get()) {
            p.setYaw(yaw);
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        }
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }
}
