package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** MiddleClickFriend: the mouse wheel button on a player adds him to the friend list (or removes him). */
public class MiddleClickFriendModule extends Module {
    private boolean down;

    public MiddleClickFriendModule() { super("MiddleClickFriend", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null || c.currentScreen != null) { down = false; return; }
        boolean now = GLFW.glfwGetMouseButton(c.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        if (now && !down && c.targetedEntity instanceof PlayerEntity pe) {
            String name = pe.getName().getString();
            boolean added = !Friends.has(name);
            if (added) Friends.add(name); else Friends.remove(name);
            c.player.sendMessage(Text.literal("[Friends] " + name + (added ? " добавлен в друзья" : " удалён из друзей")), false);
        }
        down = now;
    }
}
