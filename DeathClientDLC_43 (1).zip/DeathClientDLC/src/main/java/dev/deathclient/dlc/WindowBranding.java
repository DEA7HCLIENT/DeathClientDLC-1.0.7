package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryStack;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;

/** Renames the OS window to "DeathClient" and swaps its taskbar/title-bar icon for the "D" artwork. */
public final class WindowBranding {
    private WindowBranding() {}

    public static void apply(MinecraftClient client) {
        long handle = client.getWindow().getHandle();
        org.lwjgl.glfw.GLFW.glfwSetWindowTitle(handle, "DeathClient");
        try (MemoryStack stack = MemoryStack.stackPush()) {
            GLFWImage.Buffer icons = GLFWImage.malloc(2, stack);
            icons.put(0, icon("/assets/deathclientdlc/icon_16x16.png"));
            icons.put(1, icon("/assets/deathclientdlc/icon_32x32.png"));
            org.lwjgl.glfw.GLFW.glfwSetWindowIcon(handle, icons);
        } catch (Exception ignored) {}
    }

    private static GLFWImage icon(String resource) throws Exception {
        try (InputStream in = WindowBranding.class.getResourceAsStream(resource)) {
            BufferedImage img = ImageIO.read(in);
            int w = img.getWidth(), h = img.getHeight();
            ByteBuffer buf = Util.make(ByteBuffer.allocateDirect(w * h * 4), b -> {
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                    int p = img.getRGB(x, y);
                    b.put((byte) ((p >> 16) & 0xFF)).put((byte) ((p >> 8) & 0xFF)).put((byte) (p & 0xFF)).put((byte) ((p >> 24) & 0xFF));
                }
                b.flip();
            });
            return GLFWImage.malloc().set(w, h, buf);
        }
    }
}
