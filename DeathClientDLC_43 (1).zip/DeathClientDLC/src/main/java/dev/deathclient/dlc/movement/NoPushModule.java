package dev.deathclient.dlc;

/** NoPush: other players and mobs no longer push you (hook: mixin.NoPushMixin). */
public class NoPushModule extends Module {
    public NoPushModule() { super("NoPush", Category.MOVEMENT); }
}
