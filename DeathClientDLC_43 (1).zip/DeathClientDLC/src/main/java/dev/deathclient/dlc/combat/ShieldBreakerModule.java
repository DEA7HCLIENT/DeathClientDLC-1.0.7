package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Shield Breaker: an axe knocks a shield out of use, so when a player blocks you with one, this takes the axe from
 * the hotbar, waits until it has recharged, hits once and gives you your weapon back.
 * <ul>
 *   <li>Target "Crosshair": the player you are looking at. "Nearest": the closest player in reach, which the module turns
 *       to (Rotation: None / Silent / Camera) before the hit.</li>
 *   <li>"Only when blocking": acts while the shield is actually raised and turned toward you; off, it acts as soon as the
 *       target holds a shield, so the axe is already in your hand when they raise it.</li>
 *   <li>"Auto attack" off: it only switches to the axe and back, the hit is yours (or KillAura's).</li>
 * </ul>
 * Switching items restarts the attack charge, so the hit comes about a second later (an axe is slow): this is normal.
 */
public class ShieldBreakerModule extends Module {
    private static final int IDLE = 0, HIT = 1, BACK = 2;
    private static final Item[] AXES = {Items.NETHERITE_AXE, Items.DIAMOND_AXE, Items.IRON_AXE, Items.STONE_AXE,
            Items.GOLDEN_AXE, Items.WOODEN_AXE};

    /** 1 = the player under the crosshair, 2 = the nearest one in reach. */
    public final NumberSetting target = add(new NumberSetting("Target", 1, 1, 2, 1).labels("Crosshair", "Nearest"));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final NumberSetting reach = add(new NumberSetting("Reach", 3.0, 2, 6, 0.5));
    public final BoolSetting onlyBlocking = add(new BoolSetting("Only when blocking", true));
    public final BoolSetting autoAttack = add(new BoolSetting("Auto attack", true));
    /** How charged the axe must be before the hit (1 = full). */
    public final NumberSetting charge = add(new NumberSetting("Min charge", 0.9, 0.5, 1.0, 0.05));
    /** Ticks between the hit and giving the weapon back. */
    public final NumberSetting delay = add(new NumberSetting("Delay back", 2, 1, 10, 1));
    /** Ticks to rest after a hit before the next one. */
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 10, 0, 40, 1));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));

    private int state = IDLE, prevSlot = -1, axeSlot = -1, wait, life, rest;
    private PlayerEntity victim;

    public ShieldBreakerModule() { super("Shield Breaker", Category.COMBAT); }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) giveBack(c.player);
        state = IDLE;
        victim = null;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null || c.currentScreen != null) return;
        if (rest > 0) rest--;

        switch (state) {
            case IDLE -> {
                if (rest > 0 || p.isUsingItem()) return;
                PlayerEntity t = pick(c, p);
                if (t == null) return;
                int axe = axeSlot(p);
                if (axe < 0) return;                                        // no axe on the hotbar: nothing to do
                prevSlot = p.getInventory().getSelectedSlot();
                axeSlot = axe;
                if (axe != prevSlot) p.getInventory().setSelectedSlot(axe);
                victim = t;
                life = 60;
                state = HIT;
            }
            case HIT -> {
                // The target left, stopped blocking, or you changed the slot yourself: give up.
                if (--life <= 0 || victim == null || !victim.isAlive() || p.distanceTo(victim) > reach.get() + 0.5
                        || p.getInventory().getSelectedSlot() != axeSlot || !wanted(p, victim)) {
                    finish(p);
                    return;
                }
                if (p.getAttackCooldownProgress(0f) < charge.get()) return;     // the axe is still recharging
                if (autoAttack.get()) {
                    int rot = (int) rotation.get();
                    if ((int) target.get() == 2) AuraRotation.face(c, p, victim.getBoundingBox().getCenter(), rot);
                    c.interactionManager.attackEntity(p, victim);
                    if (swing.get()) p.swingHand(Hand.MAIN_HAND);
                    if ((int) target.get() == 2) AuraRotation.restore(c, p, rot);
                } else if (!stillBlocking(victim)) {
                    finish(p);                                                   // you hit it yourself
                    return;
                } else return;                                                   // wait for your own hit
                wait = (int) delay.get();
                state = BACK;
            }
            default -> {                                                         // BACK
                if (wait-- > 0) return;
                finish(p);
            }
        }
    }

    private void finish(ClientPlayerEntity p) {
        giveBack(p);
        victim = null;
        state = IDLE;
        rest = (int) cooldown.get();
    }

    private void giveBack(ClientPlayerEntity p) {
        if (restoreSlot.get() && prevSlot >= 0 && p.getInventory().getSelectedSlot() == axeSlot) {
            p.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
        axeSlot = -1;
    }

    // ------------------------------------------------------------------ choosing the target

    private PlayerEntity pick(MinecraftClient c, ClientPlayerEntity p) {
        if ((int) target.get() == 1) {
            if (c.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity e
                    && usable(p, e) && wanted(p, e)) return e;
            return null;
        }
        PlayerEntity best = null;
        double bestD = reach.get();
        for (PlayerEntity e : c.world.getPlayers()) {
            if (!usable(p, e) || !wanted(p, e)) continue;
            double d = p.distanceTo(e);
            if (d <= bestD) { bestD = d; best = e; }
        }
        return best;
    }

    private boolean usable(ClientPlayerEntity p, PlayerEntity e) {
        return e != p && e.isAlive() && !e.isSpectator() && !Friends.isFriend(e) && p.distanceTo(e) <= reach.get() + 0.5;
    }

    /** Is this player worth the axe: blocking toward you (or holding a shield, when Only when blocking is off). */
    private boolean wanted(ClientPlayerEntity p, PlayerEntity e) {
        if (onlyBlocking.get()) return stillBlocking(e) && shieldFacesMe(p, e);
        return e.getMainHandStack().isOf(Items.SHIELD) || e.getOffHandStack().isOf(Items.SHIELD);
    }

    private static boolean stillBlocking(PlayerEntity e) { return e.isBlocking(); }

    /** A shield only stops what comes from the front: is the player turned toward you? */
    private static boolean shieldFacesMe(ClientPlayerEntity p, PlayerEntity e) {
        Vec3d look = e.getRotationVec(1f);
        Vec3d toMe = p.getEntityPos().subtract(e.getEntityPos());
        double lx = look.x, lz = look.z, tx = toMe.x, tz = toMe.z;
        double ll = Math.hypot(lx, lz), tl = Math.hypot(tx, tz);
        if (ll < 1e-6 || tl < 1e-6) return true;
        return (lx * tx + lz * tz) / (ll * tl) > 0.0;
    }

    private static int axeSlot(ClientPlayerEntity p) {
        for (Item axe : AXES) {
            int s = Util.findHotbar(p, axe);
            if (s >= 0) return s;
        }
        for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).getItem() instanceof AxeItem) return i;
        return -1;
    }
}
