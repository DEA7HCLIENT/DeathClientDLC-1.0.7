package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;

/** AutoPotion: with low health it throws a splash potion from the hotbar at your own feet. */
public class AutoPotionModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 12, 2, 20, 1));
    public final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 20, 5, 100, 1));
    private int cooldown;

    public AutoPotionModule() { super("AutoPotion", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.interactionManager == null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (p.getHealth() > health.get()) return;
        int slot = Util.findHotbar(p, Items.SPLASH_POTION);
        if (slot < 0) return;

        int prev = p.getInventory().getSelectedSlot();
        float yaw = p.getYaw(), pitch = p.getPitch();
        p.getInventory().setSelectedSlot(slot);
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, 90f, p.isOnGround(), p.horizontalCollision));
        c.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
        p.getInventory().setSelectedSlot(prev);
        cooldown = (int) delay.get();
    }
}
