package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;

/** Drawing for the Liquid Glass module: the glass card and the gliding lens of the main menu. */
final class LiquidGlass {
    private LiquidGlass() {}

    static LiquidGlassModule module() {
        LiquidGlassModule m = ModuleManager.get(LiquidGlassModule.class);
        return m != null && m.isEnabled() ? m : null;
    }

    static boolean on() { return module() != null; }

    private static int argb(int rgb, float alpha) {
        int a = Math.max(1, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static final int CLEAR = 0x01FFFFFF;                         // nearly invisible end of a gradient

    /** A pane of liquid glass at x, y, w, h. alpha scales the whole card (1 = full). */
    static void card(DrawContext ctx, int x, int y, int w, int h, int radius, float alpha) {
        LiquidGlassModule m = module();
        if (m == null || w < 4 || h < 4) return;
        int r = Math.max(1, Math.min(Math.min(w, h) / 2, Math.min(radius, (int) m.radius.get())));
        float body = (float) m.opacity.get() / 100f, rim = (float) m.rim.get() / 100f;
        float frost = (float) m.contrast.get() / 100f * 0.45f;
        int tint = ClickGuiScreen.mix(0xFFEAF0FA, Theme.current().accent(), (float) m.tint.get() / 100f) & 0xFFFFFF;
        int span = Math.max(0, w - 2 * r), vspan = Math.max(0, h - 2 * r);

        // soft shadow around the pane, so it lifts off the background
        ClickGuiScreen.rrect(ctx, x - 2, y - 1, w + 4, h + 4, argb(0x000008, 0.07f * alpha), r + 2);
        ClickGuiScreen.rrect(ctx, x - 1, y, w + 2, h + 2, argb(0x000008, 0.10f * alpha), r + 1);

        // frosted base (dark, bluish) keeps text readable, then the clear tinted body on top of it
        if (frost > 0f) ClickGuiScreen.rrect(ctx, x, y, w, h, argb(0x0C1426, frost * alpha), r);
        ClickGuiScreen.rrect(ctx, x, y, w, h, argb(tint, body * 0.55f * alpha), r);
        if (h > 8) ctx.fillGradient(x + r / 2, y + h / 2, x + w - r / 2, y + h - 2, CLEAR, argb(tint, body * 0.45f * alpha));

        // glow along the bottom inside edge: light gathering in the thick part of the glass
        if (h > 12 && span > 0) ctx.fillGradient(x + r, y + h - Math.max(4, h / 4), x + w - r, y + h - 2, CLEAR, argb(0xFFFFFF, 0.12f * alpha));

        // rim: the whole edge is lit softly, the top-left and bottom-right catch more light
        ClickGuiScreen.outline(ctx, x, y, w, h, argb(0xFFFFFF, 0.30f * rim * alpha), r);
        ctx.fill(x + r, y, x + r + span * 7 / 10, y + 1, argb(0xFFFFFF, 0.95f * rim * alpha));
        ctx.fill(x, y + r, x + 1, y + r + vspan * 7 / 10, argb(0xFFFFFF, 0.85f * rim * alpha));
        ctx.fill(x + w - r - span / 2, y + h - 1, x + w - r, y + h, argb(0xFFFFFF, 0.70f * rim * alpha));
        ctx.fill(x + w - 1, y + h - r - vspan / 2, x + w, y + h - r, argb(0xFFFFFF, 0.60f * rim * alpha));

        if (w > 8 && h > 8) {
            // inner edge: a dark hairline just inside the rim gives the glass thickness
            ClickGuiScreen.outline(ctx, x + 1, y + 1, w - 2, h - 2, argb(0x101830, 0.22f * alpha), Math.max(0, r - 1));
            // colour fringe: the light splits a little at the inner edge (cool at the top-left, warm at the bottom-right)
            if (m.fringe.get() && w > 14 && h > 14) {
                ctx.fill(x + r, y + 2, x + r + span * 6 / 10, y + 3, argb(0x6FE3FF, 0.28f * rim * alpha));
                ctx.fill(x + 2, y + r, x + 3, y + r + vspan * 6 / 10, argb(0x6FE3FF, 0.22f * rim * alpha));
                ctx.fill(x + w - r - span * 4 / 10, y + h - 3, x + w - r, y + h - 2, argb(0xFF8AD8, 0.26f * rim * alpha));
                ctx.fill(x + w - 3, y + h - r - vspan * 4 / 10, x + w - 2, y + h - r, argb(0xFF8AD8, 0.20f * rim * alpha));
            }
        }

        // gloss on top, fading out well before the middle, and a small bright spot at the top-left corner
        if (h > 10) ctx.fillGradient(x + r, y + 2, x + w - r, y + Math.max(4, h * 2 / 5), argb(0xFFFFFF, 0.20f * alpha), CLEAR);
        if (w > 20 && h > 10) ClickGuiScreen.rrect(ctx, x + r / 2 + 2, y + 2, Math.max(5, Math.min(18, w / 8)), 2, argb(0xFFFFFF, 0.65f * rim * alpha), 1);

        // slow light sweep: a narrow bright band crossing the card
        if (m.sweep.get() && w > 24 && h > 10) {
            float t = (System.currentTimeMillis() % 5000L) / 5000f;               // 0..1
            int cx = x - 12 + Math.round(t * (w + 24));
            for (int k = -6; k <= 6; k++) {
                int cxk = cx + k;
                if (cxk <= x + r || cxk >= x + w - r - 1) continue;
                float f = 1f - Math.abs(k) / 7f;
                ctx.fillGradient(cxk, y + 2, cxk + 1, y + h - 2, argb(0xFFFFFF, 0.09f * f * alpha), CLEAR);
            }
        }
    }

    // ---- the gliding lens (main menu) ----

    private static float lx, ly, lw, lh, lvis;
    private static long lastFrame;

    /**
     * Call once per frame. With a target the lens glides to it and fades in; without one it fades out where it was.
     * The first appearance starts directly on the target. While it moves it stretches along the way, like a drop of liquid.
     */
    static void lens(DrawContext ctx, boolean has, int x, int y, int w, int h) {
        LiquidGlassModule m = module();
        if (m == null || !m.lens.get()) { lvis = 0f; return; }
        long now = System.currentTimeMillis();
        float dt = lastFrame == 0 ? 16f : Math.min(100f, now - lastFrame);
        lastFrame = now;
        float k = 1f - (float) Math.exp(-dt / 70f);                                   // easing, frame-rate independent
        float stretchX = 0f, stretchY = 0f;
        if (has) {
            if (lvis < 0.02f) { lx = x; ly = y; lw = w; lh = h; }
            stretchX = Math.min(16f, Math.abs(x - lx) * 0.18f);
            stretchY = Math.min(16f, Math.abs(y - ly) * 0.18f);
            lx += (x - lx) * k; ly += (y - ly) * k; lw += (w - lw) * k; lh += (h - lh) * k;
            lvis = Math.min(1f, lvis + dt / 120f);
        } else {
            lvis = Math.max(0f, lvis - dt / 160f);
        }
        if (lvis < 0.02f) return;

        int sx = Math.round(stretchX), sy = Math.round(stretchY);
        int px = Math.round(lx) - 3 - sx / 2, py = Math.round(ly) - 3 - sy / 2;
        int pw = Math.round(lw) + 6 + sx, ph = Math.round(lh) + 6 + sy - Math.round(stretchX * 0.25f);   // a bit thinner while it moves sideways
        int r = ph / 2;
        float a = lvis;
        ClickGuiScreen.rrect(ctx, px - 2, py - 1, pw + 4, ph + 4, argb(0x000010, 0.18f * a), r + 2);        // soft shadow under the lens
        ClickGuiScreen.rrect(ctx, px, py, pw, ph, argb(0xFFFFFF, 0.15f * a), r);                            // brighter body
        ctx.fillGradient(px + r / 2, py + ph / 2, px + pw - r / 2, py + ph - 2, CLEAR, argb(0xFFFFFF, 0.14f * a));   // glow at the bottom inside
        ClickGuiScreen.outline(ctx, px, py, pw, ph, argb(0xFFFFFF, 0.90f * a), r);                          // bright rim
        ClickGuiScreen.outline(ctx, px + 1, py + 1, pw - 2, ph - 2, argb(0xFFFFFF, 0.28f * a), Math.max(0, r - 1));
        if (m.fringe.get() && pw > 14 && ph > 14) {
            ctx.fill(px + r, py + 2, px + pw / 2, py + 3, argb(0x6FE3FF, 0.45f * a));                      // cool fringe, top left
            ctx.fill(px + pw / 2, py + ph - 3, px + pw - r, py + ph - 2, argb(0xFF8AD8, 0.40f * a));       // warm fringe, bottom right
        }
        ctx.fillGradient(px + r, py + 2, px + pw - r, py + ph / 2, argb(0xFFFFFF, 0.22f * a), CLEAR);       // gloss
    }
}
