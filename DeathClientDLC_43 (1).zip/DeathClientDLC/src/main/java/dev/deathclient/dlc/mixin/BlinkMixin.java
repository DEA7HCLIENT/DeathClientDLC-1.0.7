package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.PacketHooks;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Blink / AirStuck: outgoing movement packets can be held back or dropped. require = 0: skipped if sendPacket is named differently. */
@Mixin(ClientCommonNetworkHandler.class)
public abstract class BlinkMixin {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$movementPackets(Packet<?> packet, CallbackInfo ci) {
        if (PacketHooks.consume(packet)) ci.cancel();
    }
}
