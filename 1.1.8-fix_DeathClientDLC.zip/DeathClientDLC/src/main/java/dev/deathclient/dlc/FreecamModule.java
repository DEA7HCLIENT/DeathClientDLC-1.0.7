package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam: the camera detaches from the player and flies freely (WASD, Space up, Shift down, mouse to look).
 * The real player stays where it is and stops reacting to movement keys (see mixin.KeyboardInputMixin).
 * Implemented with a dummy camera entity, the same way vanilla spectating works.
 * The camera is moved every frame (not every tick), so it needs no previous-position interpolation:
 * copyPositionAndRotation() resets the entity's interpolation state to the new values.
 */
public class FreecamModule extends Module {
    /** Blocks per tick (20 ticks = 1 second); movement itself is scaled by frame time. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.8, 0.1, 5.0, 0.1));
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.6, 0.1, 3.0, 0.1));

    private static volatile FreecamModule instance;

    private OtherClientPlayerEntity cam;
    private OtherClientPlayerEntity scratch;   // staging entity: set values here, then copy them to cam
    private ClientWorld camWorld;
    private float savedYaw, savedPitch;
    private long lastNanos;

    public FreecamModule() {
        super("Freecam", Category.RENDER);
        instance = this;
    }

    /** True while the camera is detached; read by the input mixin. */
    public static boolean active() {
        FreecamModule m = instance;
        return m != null && m.isEnabled() && m.cam != null;
    }

    @Override
    protected void onEnable() { start(MinecraftClient.getInstance()); }

    @Override
    protected void onDisable() { stop(MinecraftClient.getInstance()); }

    private void start(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        cam = new OtherClientPlayerEntity(c.world, p.getGameProfile());
        scratch = new OtherClientPlayerEntity(c.world, p.getGameProfile());
        camWorld = c.world;
        cam.copyPositionAndRotation(p);
        cam.noClip = true;
        scratch.copyPositionAndRotation(p);
        savedYaw = p.getYaw();
        savedPitch = p.getPitch();
        lastNanos = System.nanoTime();
        c.setCameraEntity(cam);
    }

    private void stop(MinecraftClient c) {
        if (cam == null) return;
        cam = null;
        scratch = null;
        camWorld = null;
        ClientPlayerEntity p = c.player;
        if (p != null) {
            c.setCameraEntity(p);
            p.setYaw(savedYaw);
            p.setPitch(savedPitch);
        }
    }

    @Override
    public void onTick(MinecraftClient c) {
        // Re-create the camera after a world change (the game resets the camera entity on join).
        if (cam == null || camWorld != c.world) start(c);
        if (cam != null && c.getCameraEntity() != cam) c.setCameraEntity(cam);
    }

    /** HUD callback, runs every frame: moves and turns the camera smoothly (no tick lag, no interpolation needed). */
    static void frame() {
        FreecamModule m = instance;
        if (m == null || !m.isEnabled() || m.cam == null) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return;
        m.step(c);
    }

    private void step(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        long now = System.nanoTime();
        double ticks = Math.min((now - lastNanos) / 5.0e7, 3.0);   // frame time in ticks, capped
        lastNanos = now;

        double x = cam.getX(), y = cam.getY(), z = cam.getZ();
        if (c.currentScreen == null) {
            Vec3d d = Util.inputDir(c, p);   // horizontal, from the (mouse-driven) player yaw
            double vy = ((c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0)) * vertical.get();
            x += d.x * speed.get() * ticks;
            y += vy * ticks;
            z += d.z * speed.get() * ticks;
        }
        scratch.setPosition(x, y, z);
        scratch.setYaw(p.getYaw());
        scratch.setPitch(p.getPitch());
        cam.copyPositionAndRotation(scratch);
    }
}
