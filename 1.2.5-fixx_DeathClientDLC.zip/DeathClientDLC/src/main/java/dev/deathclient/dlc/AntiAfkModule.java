package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Anti AFK: every Interval seconds it does something small so the server does not kick you for idling: a hop, a swing of
 * the hand and a slight turn of the view (each can be turned off). It does nothing while you press movement keys.
 */
public class AntiAfkModule extends Module {
    public final NumberSetting interval = add(new NumberSetting("Interval", 30, 5, 120, 5));
    public final BoolSetting jump = add(new BoolSetting("Jump", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting look = add(new BoolSetting("Look around", true));

    private int ticks;

    public AntiAfkModule() { super("Anti AFK", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (Util.inputDir(c, p) != Vec3d.ZERO || c.currentScreen != null) { ticks = 0; return; }
        if (++ticks < interval.get() * 20) return;
        ticks = 0;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (jump.get() && p.isOnGround()) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, 0.42, v.z); }
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        if (look.get()) p.setYaw(p.getYaw() + (float) r.nextDouble(-20, 20));
    }
}
