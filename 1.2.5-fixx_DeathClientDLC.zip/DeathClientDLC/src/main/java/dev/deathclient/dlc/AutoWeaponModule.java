package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/**
 * Auto Weapon: right before you attack, the best sword on your hotbar goes into your hand (netherite first, wood last).
 * With "Axe on shield" an axe is taken instead when the target is blocking with a shield. A mace in your hand stays there.
 * Called from ClientPlayerInteractionManagerMixin on every attack.
 */
public class AutoWeaponModule extends Module {
    private static final Item[] SWORDS = {Items.NETHERITE_SWORD, Items.DIAMOND_SWORD, Items.IRON_SWORD, Items.STONE_SWORD, Items.GOLDEN_SWORD, Items.WOODEN_SWORD};
    private static final Item[] AXES = {Items.NETHERITE_AXE, Items.DIAMOND_AXE, Items.IRON_AXE, Items.STONE_AXE, Items.GOLDEN_AXE, Items.WOODEN_AXE};

    public final BoolSetting axeOnShield = add(new BoolSetting("Axe on shield", true));

    public AutoWeaponModule() { super("Auto Weapon", Category.COMBAT); }

    public static void attack(Object player, Entity target) {
        AutoWeaponModule m = ModuleManager.get(AutoWeaponModule.class);
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (m == null || !m.isEnabled() || p == null || player != p || p.getMainHandStack().isOf(Items.MACE)) return;
        boolean shield = m.axeOnShield.get() && target instanceof LivingEntity le && le.isBlocking();
        int slot = best(p, shield ? AXES : SWORDS);
        if (slot < 0) slot = best(p, shield ? SWORDS : AXES);
        if (slot >= 0 && slot != p.getInventory().getSelectedSlot()) p.getInventory().setSelectedSlot(slot);
    }

    private static int best(ClientPlayerEntity p, Item[] order) {
        for (Item item : order) {
            int slot = Util.findHotbar(p, item);
            if (slot >= 0) return slot;
        }
        return -1;
    }
}
