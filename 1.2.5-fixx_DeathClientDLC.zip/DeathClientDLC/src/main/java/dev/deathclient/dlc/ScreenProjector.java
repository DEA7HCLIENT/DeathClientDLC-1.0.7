package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** Projects world positions to scaled-GUI screen coordinates (camera = player's eye, 4 blocks back in third person). */
final class ScreenProjector {
    private Vec3d eye;
    private double fx, fy, fz, rx, rz, ux, uy, uz;
    private int sw, sh;
    /** tan(fov / 2); a world length L at depth z covers L / (z * tan) * (sh / 2) GUI pixels. */
    double tan;

    /** Result of project(): screen x, y and camera depth. */
    final double[] out = new double[3];

    void begin(MinecraftClient c, float delta) {
        // Follow whatever the game renders from (the player, or the Freecam camera entity).
        Entity p = c.getCameraEntity() != null ? c.getCameraEntity() : c.player;
        float yaw = p.getYaw(delta), pitch = p.getPitch(delta);
        eye = p.getLerpedPos(delta).add(0, p.getEyeHeight(p.getPose()), 0);
        var persp = c.options.getPerspective();
        boolean detached = p != c.player;
        if (!detached && persp.isFrontView()) { yaw += 180f; pitch = -pitch; }
        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        fx = -Math.sin(yr) * Math.cos(pr); fy = -Math.sin(pr); fz = Math.cos(yr) * Math.cos(pr);
        if (!detached && !persp.isFirstPerson()) eye = eye.subtract(fx * 4.0, fy * 4.0, fz * 4.0);
        rx = -Math.cos(yr); rz = -Math.sin(yr);          // right vector (y = 0)
        ux = -rz * fy; uy = rz * fx - rx * fz; uz = rx * fy; // up = right x forward
        sw = c.getWindow().getScaledWidth();
        sh = c.getWindow().getScaledHeight();
        tan = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
    }

    /** Fills out[] and returns true when the point is in front of the camera. */
    boolean project(Vec3d w) {
        double dx = w.x - eye.x, dy = w.y - eye.y, dz = w.z - eye.z;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.1) return false;
        double sx = dx * rx + dz * rz;
        double sy = dx * ux + dy * uy + dz * uz;
        out[0] = sw / 2.0 + (sx / (depth * tan * sw / sh)) * (sw / 2.0);
        out[1] = sh / 2.0 - (sy / (depth * tan)) * (sh / 2.0);
        out[2] = depth;
        return true;
    }

    /** Camera depth of a world point (negative = behind the camera). */
    double depth(Vec3d w) {
        return (w.x - eye.x) * fx + (w.y - eye.y) * fy + (w.z - eye.z) * fz;
    }

    /**
     * Projects the 3D segment a-b, cutting the part that is behind the camera off first, so an edge that
     * runs past the viewer still gets drawn up to the screen edge. Fills o = {x1, y1, x2, y2}.
     * Returns false if the whole segment is behind the camera.
     */
    boolean segment(Vec3d a, Vec3d b, double[] o) {
        final double near = 0.12;
        double da = depth(a), db = depth(b);
        if (da < near && db < near) return false;
        if (da < near) a = a.add(b.subtract(a).multiply((near - da) / (db - da)));
        else if (db < near) b = b.add(a.subtract(b).multiply((near - db) / (da - db)));
        if (!project(a)) return false;
        o[0] = out[0]; o[1] = out[1];
        if (!project(b)) return false;
        o[2] = out[0]; o[3] = out[1];
        return true;
    }

    /** Camera position of the last begin(). */
    Vec3d eye() { return eye; }

    int screenHeight() { return sh; }

    /** Right vector of the camera on the ground plane (y = 0). */
    double rightX() { return rx; }

    double rightZ() { return rz; }
}
