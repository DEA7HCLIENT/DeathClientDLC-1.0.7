package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;

/** Auto Respawn: presses "Respawn" on the death screen for you, after Delay ticks. */
public class AutoRespawnModule extends Module {
    public final NumberSetting delay = add(new NumberSetting("Delay", 5, 0, 40, 1));

    private int wait;

    public AutoRespawnModule() { super("Auto Respawn", Category.MISC); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (!(c.currentScreen instanceof DeathScreen)) { wait = 0; return; }
        if (++wait > delay.get()) { p.requestRespawn(); wait = 0; }
    }
}
