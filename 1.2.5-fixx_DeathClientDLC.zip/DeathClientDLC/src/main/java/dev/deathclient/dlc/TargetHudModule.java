package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Target HUD: a small panel with the name and health of your target: the entity under your crosshair, or the one you
 * hit in the last 4 seconds. The bar eases to the new health. Offset X/Y move the panel from its default place
 * (right under the crosshair, a little to the right).
 */
public class TargetHudModule extends Module {
    private static LivingEntity last;
    private static long lastTime;

    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final NumberSetting offsetX = add(new NumberSetting("Offset X", 0, -300, 300, 5));
    public final NumberSetting offsetY = add(new NumberSetting("Offset Y", 0, -200, 200, 5));

    private float shown = -1f;
    private LivingEntity shownFor;

    public TargetHudModule() { super("Target HUD", Category.VISUALS); }

    public static void attack(Object player, Entity target) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null && player == p && target instanceof LivingEntity le) { last = le; lastTime = System.currentTimeMillis(); }
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetHudModule m = ModuleManager.get(TargetHudModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || Hud.hidden || c.player == null || c.world == null || c.options.hudHidden) return;
        LivingEntity t = null;
        if (c.targetedEntity instanceof LivingEntity le && le != c.player) t = le;
        else if (last != null && last.isAlive() && !last.isRemoved() && System.currentTimeMillis() - lastTime < 4000) t = last;
        if (t == null || (m.playersOnly.get() && !(t instanceof PlayerEntity))) { m.shownFor = null; return; }
        m.draw(ctx, c, t);
    }

    private void draw(DrawContext ctx, MinecraftClient c, LivingEntity t) {
        float max = Math.max(1f, t.getMaxHealth()), hp = MathHelper.clamp(t.getHealth(), 0f, max);
        if (shownFor != t || shown < 0) { shownFor = t; shown = hp; }
        shown += (hp - shown) * 0.15f;

        var tr = c.textRenderer;
        String name = t.getName().getString();
        String text = String.format("%.1f / %.0f", hp, max);
        int w = Math.max(120, Math.max(Fonts.width(tr, name), Fonts.width(tr, text)) + 16), h = 34;
        int x = c.getWindow().getScaledWidth() / 2 + 24 + (int) offsetX.get();
        int y = c.getWindow().getScaledHeight() / 2 + 24 + (int) offsetY.get();
        int accent = 0xFF000000 | (Theme.current().accent() & 0xFFFFFF);

        ctx.fill(x, y, x + w, y + h, 0xC0101014);
        ctx.fill(x, y, x + w, y + 2, accent);
        Fonts.draw(ctx, tr, name, x + 6, y + 6, 0xFFFFFFFF);
        Fonts.draw(ctx, tr, text, x + w - 6 - Fonts.width(tr, text), y + 6, 0xFFB0B0B8);
        int bx = x + 6, bw = w - 12, by = y + 21;
        ctx.fill(bx, by, bx + bw, by + 6, 0xFF2A2A32);
        ctx.fill(bx, by, bx + Math.round(bw * MathHelper.clamp(shown / max, 0f, 1f)), by + 6, accent);
    }
}
