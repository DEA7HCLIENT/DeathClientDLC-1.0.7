package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * Criticals: every hit you make on the ground counts as a critical hit. Just before the attack the server is sent a
 * short "hop" in position packets (the real position does not change). Packet: 0.0625 up, back down. Strict: three
 * smaller steps (0.11, 0.1100013579, 0.0000013579), for anti-cheats that look for the first pattern. No effect in water,
 * on ladders, in a vehicle or in the air, and none with a mace (its smash needs the fall). Called from
 * ClientPlayerInteractionManagerMixin on every attack. These patterns are heuristics; they have not been checked against any server.
 */
public class CriticalsModule extends Module {
    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 2, 1).labels("Packet", "Strict"));

    public CriticalsModule() { super("Criticals", Category.COMBAT); }

    public static void attack(Object player, Entity target) {
        CriticalsModule m = ModuleManager.get(CriticalsModule.class);
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (m == null || !m.isEnabled() || p == null || player != p || !(target instanceof LivingEntity)) return;
        if (!p.isOnGround() || p.isTouchingWater() || p.isClimbing() || p.hasVehicle() || p.getAbilities().flying) return;
        if (p.getMainHandStack().isOf(Items.MACE) || p.networkHandler == null) return;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        double[] hops = (int) m.mode.get() == 2 ? new double[]{0.11, 0.1100013579, 0.0000013579} : new double[]{0.0625, 0.0};
        for (double h : hops) p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + h, z, false, false));
    }
}
