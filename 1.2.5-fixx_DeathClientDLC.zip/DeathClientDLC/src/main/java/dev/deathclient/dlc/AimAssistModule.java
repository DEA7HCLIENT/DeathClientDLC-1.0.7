package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Aim Assist: a gentle pull of the camera toward the target closest to your crosshair, only inside the FOV cone around
 * where you look and within Range. Strength is the most degrees per tick it can turn you. With "Only on attack" it pulls
 * only while you hold the attack button. Unlike Free Lock it never takes the aim from you.
 */
public class AimAssistModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 5, 2, 8, 0.5));
    public final NumberSetting fov = add(new NumberSetting("FOV", 60, 10, 180, 5));
    public final NumberSetting strength = add(new NumberSetting("Strength", 6, 1, 40, 1));
    public final BoolSetting onlyOnAttack = add(new BoolSetting("Only on attack", true));
    public final BoolSetting visibleOnly = add(new BoolSetting("Visible only", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public AimAssistModule() { super("Aim Assist", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (c.currentScreen != null || !p.isAlive() || p.isSpectator()) return;
        if (onlyOnAttack.get() && !c.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        LivingEntity best = null;
        double bestAngle = Math.toRadians(fov.get() / 2.0);
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p || !le.isAlive() || le.isSpectator() || Friends.skip(le)) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (p.distanceTo(le) > range.get() || (visibleOnly.get() && !p.canSee(le))) continue;
            Vec3d to = le.getBoundingBox().getCenter().subtract(eye).normalize();
            double angle = Math.acos(MathHelper.clamp(look.dotProduct(to), -1.0, 1.0));
            if (angle < bestAngle) { bestAngle = angle; best = le; }
        }
        if (best == null) return;

        float[] want = Util.rotationsTo(eye, best.getBoundingBox().getCenter());
        float max = (float) strength.get();
        p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(want[0] - p.getYaw()), -max, max));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(want[1] - p.getPitch(), -max, max), -90f, 90f));
    }
}
