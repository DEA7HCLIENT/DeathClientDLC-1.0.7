package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Anti Bot: fake players (NPCs, hologram stands, spawned bots) are skipped by every combat and target module, the same
 * way friends are (it hooks Friends.skip). A player counts as a bot when he is not in the tab list (Tab list), has a name
 * that cannot be a real nickname (Name: not 3-16 letters, digits and underscores), or shares his name with another player
 * in view (Duplicates). These are heuristics and can be wrong on servers with unusual setups.
 */
public class AntiBotModule extends Module {
    public final BoolSetting tabList = add(new BoolSetting("Tab list", true));
    public final BoolSetting name = add(new BoolSetting("Name", true));
    public final BoolSetting duplicates = add(new BoolSetting("Duplicates", true));

    public AntiBotModule() { super("Anti Bot", Category.COMBAT); }

    /** True when the module is on and this entity looks like a fake player. */
    static boolean isBot(Entity e) {
        AntiBotModule m = ModuleManager.get(AntiBotModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || !(e instanceof PlayerEntity pe) || c.player == null || c.world == null || pe == c.player) return false;
        String n = pe.getName().getString();
        if (m.name.get() && !n.matches("[A-Za-z0-9_]{3,16}")) return true;
        ClientPlayNetworkHandler nh = c.getNetworkHandler();
        if (m.tabList.get() && nh != null && nh.getPlayerListEntry(pe.getUuid()) == null) return true;
        if (m.duplicates.get()) {
            int same = 0;
            for (PlayerEntity o : c.world.getPlayers()) if (o.getName().getString().equals(n)) same++;
            if (same > 1) return true;
        }
        return false;
    }
}
