package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.slot.SlotActionType;

/** Inventory clicks on the player's own screen handler (container 0), which works with no screen open. */
final class Inv {
    private Inv() {}

    /** Container slot of PlayerInventory index i (0-8 hotbar, 9-35 main): hotbar is 36-44, the main part keeps its number. */
    static int container(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }

    static void click(MinecraftClient c, ClientPlayerEntity p, int slot, int button, SlotActionType type) {
        c.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, button, type, p);
    }

    /** True when another container (chest, furnace...) is open: the player's own clicks would not match it. */
    static boolean otherContainerOpen(MinecraftClient c) {
        return c.currentScreen instanceof HandledScreen<?> && !(c.currentScreen instanceof InventoryScreen);
    }
}
