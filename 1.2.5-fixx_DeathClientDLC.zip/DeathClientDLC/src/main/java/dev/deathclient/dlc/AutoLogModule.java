package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/**
 * Auto Log: leaves the server when your health (with absorption) drops to Health or lower, or, if "Player nearby" is
 * on, when a player who is not a friend comes within Radius blocks. The module turns itself off after it logs you out.
 */
public class AutoLogModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 4, 1, 20, 1));
    public final BoolSetting playerNearby = add(new BoolSetting("Player nearby", false));
    public final NumberSetting radius = add(new NumberSetting("Radius", 8, 2, 30, 1));

    public AutoLogModule() { super("Auto Log", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (!p.isAlive() || p.networkHandler == null) return;
        String reason = null;
        if (p.getHealth() + p.getAbsorptionAmount() <= health.get()) {
            reason = "здоровье " + Math.round(p.getHealth() * 10) / 10.0;
        } else if (playerNearby.get() && Util.nearestPlayer(c, radius.get()) != null) {
            reason = "игрок рядом";
        }
        if (reason == null) return;
        toggle();                                                // off first, so it does not fire again after you rejoin
        p.networkHandler.getConnection().disconnect(Text.literal("Auto Log: " + reason));
    }
}
