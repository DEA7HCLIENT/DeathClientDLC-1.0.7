package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import java.util.concurrent.ThreadLocalRandom;

/** Hit Effects: a burst of particles inside the target each time you attack it. Called from ClientPlayerInteractionManagerMixin. */
public class HitEffectsModule extends Module {
    public final NumberSetting style = add(Fx.styleSetting());
    public final NumberSetting amount = add(new NumberSetting("Amount", 8, 1, 30, 1));

    public HitEffectsModule() { super("Hit Effects", Category.VISUALS); }

    public static void attack(Object player, Entity target) {
        HitEffectsModule m = ModuleManager.get(HitEffectsModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (m == null || !m.isEnabled() || p == null || player != p || !(target instanceof LivingEntity)) return;
        Box b = target.getBoundingBox();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        var effect = Fx.style(m.style);
        for (int i = 0; i < (int) m.amount.get(); i++) {
            Fx.spawn(c, effect, b.minX + r.nextDouble() * (b.maxX - b.minX),
                    b.minY + r.nextDouble() * (b.maxY - b.minY), b.minZ + r.nextDouble() * (b.maxZ - b.minZ));
        }
    }
}
