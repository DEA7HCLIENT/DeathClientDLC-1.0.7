package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * AutoTotem: keeps a totem of undying in your off hand. Health: the totem is put there only when health (with
 * absorption) is at or below this; 20 = always. Hotbar only: look for the totem on the hotbar only, not the whole inventory.
 */
public class AutoTotemModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 20, 1, 20, 1));
    public final NumberSetting delay = add(new NumberSetting("Delay", 1, 0, 10, 1));
    public final BoolSetting hotbarOnly = add(new BoolSetting("Hotbar only", false));

    private int wait;

    public AutoTotemModule() { super("AutoTotem", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (wait > 0) { wait--; return; }
        if (!p.isAlive() || Inv.otherContainerOpen(c) || p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (p.getHealth() + p.getAbsorptionAmount() > health.get()) return;
        for (int i = 0; i < (hotbarOnly.get() ? 9 : 36); i++) {
            if (!p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            Inv.click(c, p, Inv.container(i), 40, SlotActionType.SWAP);      // button 40 = swap with the off hand
            wait = (int) delay.get();
            return;
        }
    }
}
