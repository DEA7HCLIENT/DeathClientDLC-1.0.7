package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;

/**
 * Auto Gapple: eats a golden apple from the hotbar when your health is at or below Health. It switches to the apple,
 * holds the use key until it is eaten, then gives the slot and the key back. "Prefer" picks which apple goes first.
 */
public class AutoGappleModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 10, 1, 20, 1));
    public final NumberSetting prefer = add(new NumberSetting("Prefer", 1, 1, 2, 1).labels("Enchanted", "Golden"));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private boolean eating;
    private int prevSlot, idle;

    public AutoGappleModule() { super("Auto Gapple", Category.COMBAT); }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (eating && c.player != null) stop(c, c.player);
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (eating) {
            boolean holding = p.getMainHandStack().isOf(Items.GOLDEN_APPLE) || p.getMainHandStack().isOf(Items.ENCHANTED_GOLDEN_APPLE);
            if (!p.isAlive() || !holding || (!p.isUsingItem() && ++idle > 4)) { stop(c, p); return; }
            c.options.useKey.setPressed(true);
            return;
        }
        if (c.currentScreen != null || p.isUsingItem() || !p.isAlive() || p.getHealth() > health.get()) return;
        var first = prefer.get() < 1.5 ? Items.ENCHANTED_GOLDEN_APPLE : Items.GOLDEN_APPLE;
        var second = first == Items.GOLDEN_APPLE ? Items.ENCHANTED_GOLDEN_APPLE : Items.GOLDEN_APPLE;
        int slot = Util.findHotbar(p, first);
        if (slot < 0) slot = Util.findHotbar(p, second);
        if (slot < 0) return;
        prevSlot = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        eating = true;
        idle = 0;
        c.options.useKey.setPressed(true);
    }

    private void stop(MinecraftClient c, ClientPlayerEntity p) {
        eating = false;
        c.options.useKey.setPressed(false);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prevSlot);
    }
}
