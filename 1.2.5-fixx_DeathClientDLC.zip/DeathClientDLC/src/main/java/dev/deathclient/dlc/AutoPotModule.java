package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Auto Pot: throws splash potions from the hotbar at your own feet: healing when your health is at or below Health, and
 * (if on) strength, speed and fire resistance whenever you do not have the effect. The aim goes straight down, silently
 * (the camera does not move). One throw per Delay ticks.
 */
public class AutoPotModule extends Module {
    public final NumberSetting health = add(new NumberSetting("Health", 12, 1, 20, 1));
    public final BoolSetting strength = add(new BoolSetting("Strength", true));
    public final BoolSetting speed = add(new BoolSetting("Speed", true));
    public final BoolSetting fireResistance = add(new BoolSetting("Fire resistance", false));
    public final NumberSetting delay = add(new NumberSetting("Delay", 8, 2, 40, 1));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private int wait;

    public AutoPotModule() { super("Auto Pot", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (wait > 0) { wait--; return; }
        if (c.currentScreen != null || p.isUsingItem() || !p.isAlive()) return;

        RegistryEntry<StatusEffect> want = null;
        if (p.getHealth() <= health.get()) want = StatusEffects.INSTANT_HEALTH;
        else if (strength.get() && !p.hasStatusEffect(StatusEffects.STRENGTH)) want = StatusEffects.STRENGTH;
        else if (speed.get() && !p.hasStatusEffect(StatusEffects.SPEED)) want = StatusEffects.SPEED;
        else if (fireResistance.get() && !p.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) want = StatusEffects.FIRE_RESISTANCE;
        if (want == null) return;

        int slot = -1;
        for (int i = 0; i < 9 && slot < 0; i++) if (isPotion(p.getInventory().getStack(i), want)) slot = i;
        if (slot < 0) return;

        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        AuraRotation.face(c, p, Util.pos(p).add(0, -1.5, 0), AuraRotation.SILENT);
        c.interactionManager.interactItem(p, Hand.MAIN_HAND);
        AuraRotation.restore(c, p, AuraRotation.SILENT);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        wait = (int) delay.get();
    }

    private static boolean isPotion(ItemStack s, RegistryEntry<StatusEffect> effect) {
        if (!s.isOf(Items.SPLASH_POTION)) return false;
        PotionContentsComponent pc = s.get(DataComponentTypes.POTION_CONTENTS);
        if (pc == null) return false;
        for (StatusEffectInstance e : pc.getEffects()) if (e.getEffectType().equals(effect)) return true;
        return false;
    }
}
