package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Auto Web: puts a cobweb (hotbar) on the feet of the nearest player in Range, by clicking the floor under him, so he is
 * stuck. Waits Delay ticks between webs and does nothing while his block is already taken.
 */
public class AutoWebModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2, 6, 0.5));
    public final NumberSetting delay = add(new NumberSetting("Delay", 4, 1, 20, 1));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private int wait;

    public AutoWebModule() { super("Auto Web", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (wait > 0) { wait--; return; }
        if (c.currentScreen != null || !p.isAlive()) return;
        int slot = Util.findHotbar(p, Items.COBWEB);
        if (slot < 0) return;
        PlayerEntity target = Util.nearestPlayer(c, range.get());
        if (target == null) return;

        BlockPos feet = target.getBlockPos(), floor = feet.down();
        if (!c.world.getBlockState(feet).isAir() || !c.world.getBlockState(floor).isSolidBlock(c.world, floor)) return;
        Vec3d hitPos = Vec3d.ofCenter(floor).add(0, 0.5, 0);
        if (p.getEyePos().distanceTo(hitPos) > range.get() + 1.0) return;

        int prev = p.getInventory().getSelectedSlot(), mode = (int) rotation.get();
        p.getInventory().setSelectedSlot(slot);
        AuraRotation.face(c, p, hitPos, mode);
        c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hitPos, Direction.UP, floor, false));
        p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, mode);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        wait = (int) delay.get();
    }
}
