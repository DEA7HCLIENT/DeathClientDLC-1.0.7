package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Surround: puts blocks on the four sides of the block you stand in (obsidian, else crying obsidian, else an ender chest from
 * the hotbar), so crystals and anvils cannot get at your feet. It refills any side that gets broken. Per tick = blocks
 * placed per tick. Turns itself off when you jump (Disable on jump).
 */
public class SurroundModule extends Module {
    private static final Direction[] SIDES = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    public final NumberSetting perTick = add(new NumberSetting("Per tick", 2, 1, 4, 1));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final BoolSetting disableOnJump = add(new BoolSetting("Disable on jump", true));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private int warnWait;

    public SurroundModule() { super("Surround", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (warnWait > 0) warnWait--;
        if (c.currentScreen != null || !p.isAlive()) return;
        if (disableOnJump.get() && !p.isOnGround() && p.getVelocity().y > 0.1) { toggle(); return; }

        int slot = Util.findHotbar(p, Items.OBSIDIAN);
        if (slot < 0) slot = Util.findHotbar(p, Items.CRYING_OBSIDIAN);
        if (slot < 0) slot = Util.findHotbar(p, Items.ENDER_CHEST);

        BlockPos feet = p.getBlockPos();
        int prev = p.getInventory().getSelectedSlot(), placed = 0, mode = (int) rotation.get();
        for (Direction side : SIDES) {
            BlockPos pos = feet.offset(side);
            if (!c.world.getBlockState(pos).isAir()) continue;
            if (slot < 0) {
                if (warnWait == 0) { warnWait = 100; p.sendMessage(Text.literal("Surround: нужен обсидиан на хотбаре"), true); }
                return;
            }
            if (placed >= perTick.get()) break;
            if (place(c, p, pos, slot, mode)) placed++;
        }
        if (placed > 0) {
            AuraRotation.restore(c, p, mode);
            if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        }
    }

    /** Places a block at pos by clicking a solid neighbour (the floor first). */
    private boolean place(MinecraftClient c, ClientPlayerEntity p, BlockPos pos, int slot, int mode) {
        for (Direction dir : Direction.values()) {
            BlockPos neighbor = pos.offset(dir);
            if (!c.world.getBlockState(neighbor).isSolidBlock(c.world, neighbor)) continue;
            Direction face = dir.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(neighbor).add(Vec3d.of(face.getVector()).multiply(0.5));
            p.getInventory().setSelectedSlot(slot);
            AuraRotation.face(c, p, hitPos, mode);
            c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, neighbor, false));
            p.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }
}
