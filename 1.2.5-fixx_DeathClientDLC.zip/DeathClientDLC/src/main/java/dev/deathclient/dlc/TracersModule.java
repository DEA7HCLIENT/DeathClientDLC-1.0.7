package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Tracers: a line from the middle of the screen (or its bottom edge) to every player in Range, so you can tell where
 * they are. Friends are cyan, everyone else uses the theme color. Players behind you are not drawn (see Arrows for those).
 */
public class TracersModule extends Module {
    public final NumberSetting from = add(new NumberSetting("From", 1, 1, 2, 1).labels("Crosshair", "Bottom"));
    public final NumberSetting range = add(new NumberSetting("Range", 100, 10, 256, 10));
    public final NumberSetting thickness = add(new NumberSetting("Thickness", 1, 1, 3, 1));

    private final ScreenProjector proj = new ScreenProjector();

    public TracersModule() { super("Tracers", Category.RENDER); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TracersModule m = ModuleManager.get(TracersModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        int w = c.getWindow().getScaledWidth(), h = c.getWindow().getScaledHeight();
        int sx = w / 2, sy = (int) from.get() == 2 ? h : h / 2;
        Vec3d eye = c.player.getLerpedPos(delta);
        int th = (int) thickness.get(), theme = 0xFF000000 | (Theme.current().accent() & 0xFFFFFF);
        for (PlayerEntity o : c.world.getPlayers()) {
            if (o == c.player || !o.isAlive() || o.isSpectator()) continue;
            Vec3d p = o.getLerpedPos(delta);
            if (p.distanceTo(eye) > range.get()) continue;
            if (!proj.project(p.add(0, o.getHeight() / 2, 0))) continue;
            int color = Friends.isFriend(o) ? 0xFF4FD6D6 : theme;
            EspModule.line(ctx, sx, sy, (int) Math.round(proj.out[0]), (int) Math.round(proj.out[1]), th, color);
        }
    }
}
