package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.AutoWeaponModule;
import dev.deathclient.dlc.CriticalsModule;
import dev.deathclient.dlc.HitEffectsModule;
import dev.deathclient.dlc.TargetHudModule;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Attack hooks (Auto Weapon, Criticals, Hit Effects, Target HUD) run right before the attack packet. require = 0: skipped if the method differs here. */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"), require = 0)
    private void deathclientdlc$criticals(PlayerEntity player, Entity target, CallbackInfo ci) {
        AutoWeaponModule.attack(player, target);          // first: the weapon is in hand before the other hooks look at it
        CriticalsModule.attack(player, target);
        HitEffectsModule.attack(player, target);
        TargetHudModule.attack(player, target);
    }
}
