package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Sprint: you sprint on your own while you hold forward (not while sneaking, using an item, hungry or against a wall). */
public class SprintModule extends Module {
    public SprintModule() { super("Sprint", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (c.currentScreen != null || !c.options.forwardKey.isPressed()) return;
        if (p.isSneaking() || p.isUsingItem() || p.horizontalCollision || p.getHungerManager().getFoodLevel() <= 6) return;
        p.setSprinting(true);
    }
}
