package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Item ESP: marks dropped items through walls with a box and, if Names is on, "name xcount". Drawn as a screen overlay. */
public class ItemEspModule extends Module {
    private static final int MAX_ITEMS = 60;

    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 4));
    public final BoolSetting fill = add(new BoolSetting("Fill", true));
    public final BoolSetting names = add(new BoolSetting("Names", true));

    private final ScreenProjector proj = new ScreenProjector();

    public ItemEspModule() { super("Item ESP", Category.RENDER); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        ItemEspModule m = ModuleManager.get(ItemEspModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        Vec3d from = c.player.getLerpedPos(delta);
        List<ItemEntity> items = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e instanceof ItemEntity ie && !ie.isRemoved() && ie.getLerpedPos(delta).distanceTo(from) <= range.get()) items.add(ie);
        }
        items.sort(Comparator.comparingDouble(ie -> ie.getLerpedPos(delta).distanceTo(from)));
        proj.begin(c, delta);
        int rgb = Theme.current().accent() & 0xFFFFFF;
        for (int i = 0; i < Math.min(MAX_ITEMS, items.size()); i++) {
            ItemEntity ie = items.get(i);
            Vec3d p = ie.getLerpedPos(delta);
            Box b = ie.getBoundingBox().offset(p.x - ie.getX(), p.y - ie.getY(), p.z - ie.getZ());
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean ok = true;
            for (int k = 0; k < 8 && ok; k++) {
                Vec3d w = new Vec3d((k & 1) == 0 ? b.minX : b.maxX, (k & 2) == 0 ? b.minY : b.maxY, (k & 4) == 0 ? b.minZ : b.maxZ);
                if (!proj.project(w)) { ok = false; break; }
                minX = Math.min(minX, proj.out[0]); maxX = Math.max(maxX, proj.out[0]);
                minY = Math.min(minY, proj.out[1]); maxY = Math.max(maxY, proj.out[1]);
            }
            if (!ok) continue;
            int x0 = (int) Math.round(minX) - 2, y0 = (int) Math.round(minY) - 2, x1 = (int) Math.round(maxX) + 2, y1 = (int) Math.round(maxY) + 2;
            if (x1 - x0 > 2000 || y1 - y0 > 2000) continue;
            int color = 0xFF000000 | rgb;
            if (fill.get()) ctx.fill(x0, y0, x1, y1, 0x30000000 | rgb);
            ctx.fill(x0, y0, x1, y0 + 1, color);
            ctx.fill(x0, y1 - 1, x1, y1, color);
            ctx.fill(x0, y0, x0 + 1, y1, color);
            ctx.fill(x1 - 1, y0, x1, y1, color);
            if (names.get()) {
                var stack = ie.getStack();
                String label = stack.getName().getString() + (stack.getCount() > 1 ? " x" + stack.getCount() : "");
                ctx.drawCenteredTextWithShadow(c.textRenderer, label, (x0 + x1) / 2, y0 - 10, 0xFFFFFFFF);
            }
        }
    }
}
