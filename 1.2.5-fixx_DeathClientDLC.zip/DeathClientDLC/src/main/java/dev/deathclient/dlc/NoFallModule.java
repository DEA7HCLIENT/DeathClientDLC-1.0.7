package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * No Fall: while you fall further than Distance blocks the server is told you are on the ground, so the landing does no
 * fall damage. Not used in water or while gliding. A heuristic; some anti-cheats flag a ground flag with no ground under you.
 */
public class NoFallModule extends Module {
    public final NumberSetting distance = add(new NumberSetting("Distance", 2.5, 1.0, 10.0, 0.5));

    public NoFallModule() { super("No Fall", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.networkHandler == null || p.isOnGround() || p.isTouchingWater() || p.isGliding() || p.getAbilities().flying) return;
        if (p.fallDistance > distance.get()) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
