package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.function.BiFunction;

/**
 * Cosmetics on your own model: wings (they flap), a cape (it streams back when you run), a hat (crown, top hat or
 * wizard hat), a halo and an aura of particles. Seen in third person and from Freecam.
 * Wings, cape, hat and halo are screen overlays glued to the model with the same projection as China Hat: a part is
 * cut into thin strips and each strip is placed by projecting its two ends (the hat is a sprite that always faces the
 * camera). Wings and cape fade out when the camera is in front of you, because they hang on your back.
 * Client-side only: other players do not see them.
 */
public class CosmeticsModule extends Module {
    private static final double TAU = Math.PI * 2;
    private static final Identifier WING_R = tex("cos_wing_r"), WING_L = tex("cos_wing_l"), CAPE = tex("cos_cape"),
            HALO = tex("cos_halo"), CROWN = tex("cos_hat_crown"), TOP = tex("cos_hat_top"), WIZARD = tex("cos_hat_wizard");

    public final BoolSetting wings = add(new BoolSetting("Wings", true));
    public final NumberSetting wingSize = add(new NumberSetting("Wing size", 1.0, 0.5, 2.0, 0.1));
    public final NumberSetting flapSpeed = add(new NumberSetting("Flap speed", 1.0, 0.2, 3.0, 0.1));
    public final BoolSetting cape = add(new BoolSetting("Cape", false));
    public final NumberSetting capeLength = add(new NumberSetting("Cape length", 1.1, 0.6, 1.6, 0.1));
    public final NumberSetting hat = add(new NumberSetting("Hat", 1, 1, 4, 1).labels("Off", "Crown", "Top hat", "Wizard"));
    public final BoolSetting halo = add(new BoolSetting("Halo", true));
    public final NumberSetting aura = add(new NumberSetting("Aura", 1, 1, 6, 1)
            .labels("Off", "End rod", "Flame", "Soul flame", "Crit", "Happy villager"));
    /** Wings and cape take the theme's accent color; off = plain white. */
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 95, 10, 100, 5));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    private final ScreenProjector proj = new ScreenProjector();
    private int age;

    public CosmeticsModule() { super("Cosmetics", Category.VISUALS); }

    private static Identifier tex(String name) { return Identifier.of("deathclientdlc", "textures/gui/" + name + ".png"); }

    // ---- aura: particles spiralling up around you ----

    @Override
    public void onTick(MinecraftClient c) {
        age++;
        ClientPlayerEntity p = c.player;
        int a = (int) aura.get();
        if (p == null || a < 2) return;
        var effect = Fx.style(a - 1);
        int n = 3;
        for (int i = 0; i < n; i++) {
            double ang = age * 0.35 + i * TAU / n;
            double t = (age * 0.04 + i / (double) n) % 1.0;
            double r = 0.65 + 0.08 * Math.sin(age * 0.1);
            Fx.spawn(c, effect, p.getX() + Math.cos(ang) * r, p.getY() + t * p.getHeight(), p.getZ() + Math.sin(ang) * r);
        }
    }

    // ---- overlay parts ----

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CosmeticsModule m = ModuleManager.get(CosmeticsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        proj.begin(c, delta);
        Vec3d pos = p.getLerpedPos(delta);
        double dy = p.isSneaking() ? -0.2 : 0.0;
        double yaw = Math.toRadians(p.getBodyYaw());
        Vec3d fwd = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3d back = fwd.multiply(-1);
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        double time = System.nanoTime() / 1.0e9;
        double alpha = opacity.get() / 100.0 * 255;
        int tint = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;

        // 1 = the camera is behind you (parts on the back show fully), 0 or less = in front of you (they are hidden)
        Vec3d eye = proj.eye();
        double vx = eye.x - pos.x, vz = eye.z - pos.z, len = Math.sqrt(vx * vx + vz * vz);
        double behind = len < 1.0E-3 ? 1.0 : (vx * back.x + vz * back.z) / len;
        double fade = MathHelper.clamp((behind + 0.1) / 0.5, 0.0, 1.0);

        if (wings.get() && fade > 0.02) {
            double size = wingSize.get();
            double a = 0.5 + 0.3 * Math.sin(time * TAU * 0.6 * flapSpeed.get());          // angle between the wing and your side
            int color = ((int) (alpha * fade) << 24) | tint;
            for (int side = 1; side >= -1; side -= 2) {
                Vec3d base = pos.add(0, 1.42 + dy, 0).add(back.multiply(0.14)).add(right.multiply(0.1 * side));
                Vec3d u = right.multiply(side * Math.cos(a)).add(back.multiply(Math.sin(a))).multiply(1.3 * size);
                Vec3d v = new Vec3d(0, -1.2 * size, 0);
                quad(ctx, side > 0 ? WING_R : WING_L, 128, 128, 32, color, (s, t) -> base.add(u.multiply(s)).add(v.multiply(t)));
            }
        }

        if (cape.get() && fade > 0.02) {
            double length = capeLength.get();
            double running = MathHelper.clamp((p.getVelocity().x * fwd.x + p.getVelocity().z * fwd.z) / 0.25, -0.3, 1.0);
            double top = 1.42 + dy;
            int color = ((int) (alpha * fade) << 24) | tint;
            quad(ctx, CAPE, 64, 128, 32, color, (s, t) -> {
                double out = 0.14 + t * t * (0.1 + 0.55 * running) + 0.04 * t * Math.sin(time * 2.0 + t * 3.0);
                return pos.add(0, top - length * t, 0).add(back.multiply(out)).add(right.multiply(-0.3 + 0.6 * s));
            });
        }

        int h = (int) hat.get();
        if (h >= 2) {
            Vec3d base = pos.add(0, p.getHeight() + dy - 0.12, 0);       // bottom middle of the hat sprite
            Vec3d cam = new Vec3d(proj.rightX(), 0, proj.rightZ());
            double size = 0.8;
            Vec3d tl = base.subtract(cam.multiply(size / 2)).add(0, size, 0);
            Vec3d br = base.add(cam.multiply(size / 2));
            if (proj.project(tl)) {
                double x0 = proj.out[0], y0 = proj.out[1];
                if (proj.project(br)) {
                    int ix0 = (int) Math.round(Math.min(x0, proj.out[0])), ix1 = (int) Math.round(Math.max(x0, proj.out[0]));
                    int iy0 = (int) Math.round(Math.min(y0, proj.out[1])), iy1 = (int) Math.round(Math.max(y0, proj.out[1]));
                    int w = ix1 - ix0, hh = iy1 - iy0;
                    if (w >= 1 && hh >= 1 && w < 4000 && hh < 4000) {
                        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, h == 2 ? CROWN : h == 3 ? TOP : WIZARD,
                                ix0, iy0, 0f, 0f, w, hh, 128, 128, 128, 128, ((int) alpha << 24) | 0xFFFFFF);
                    }
                }
            }
        }

        if (halo.get()) {
            double r = 0.38;
            Vec3d center = pos.add(0, p.getHeight() + dy + 0.32 + 0.03 * Math.sin(time * 2.0), 0);
            Vec3d cr = new Vec3d(proj.rightX(), 0, proj.rightZ());
            Vec3d away = new Vec3d(cr.z, 0, -cr.x);                      // ground direction pointing away from the camera
            Vec3d origin = center.add(away.multiply(r)).subtract(cr.multiply(r));
            quad(ctx, HALO, 128, 128, 32, ((int) alpha << 24) | 0xFFFFFF,
                    (s, t) -> origin.add(cr.multiply(2 * r * s)).subtract(away.multiply(2 * r * t)));
        }
    }

    /**
     * Draws a texture on the world-space parallelogram {@code at(s, t)}, s and t from 0 to 1 (s across, t down the
     * texture), as {@code rows} strips: each strip is placed by projecting its two ends.
     */
    private void quad(DrawContext ctx, Identifier tex, int tw, int th, int rows, int color, BiFunction<Double, Double, Vec3d> at) {
        int rowH = Math.max(1, th / rows);
        double[] xl = new double[rows + 1], xr = new double[rows + 1], yy = new double[rows + 1];
        boolean[] ok = new boolean[rows + 1];
        for (int k = 0; k <= rows; k++) {
            double t = k / (double) rows;
            if (!proj.project(at.apply(0.0, t))) continue;
            double lx = proj.out[0], ly = proj.out[1];
            if (!proj.project(at.apply(1.0, t))) continue;
            xl[k] = lx;
            xr[k] = proj.out[0];
            yy[k] = (ly + proj.out[1]) / 2.0;
            ok[k] = true;
        }
        for (int k = 0; k < rows; k++) {
            if (!ok[k] || !ok[k + 1]) continue;                      // a strip behind the camera is dropped
            double ax = (xl[k] + xl[k + 1]) / 2.0, bx = (xr[k] + xr[k + 1]) / 2.0;
            int x0 = (int) Math.round(Math.min(ax, bx)), x1 = (int) Math.round(Math.max(ax, bx));
            int y0 = (int) Math.round(Math.min(yy[k], yy[k + 1])), y1 = (int) Math.round(Math.max(yy[k], yy[k + 1]));
            int w = x1 - x0, h = Math.max(1, y1 - y0);
            if (w < 1 || w > 4000 || h > 600) continue;
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, x0, y0, 0f, (float) (k * rowH), w, h, tw, rowH, tw, th, color);
        }
    }
}
