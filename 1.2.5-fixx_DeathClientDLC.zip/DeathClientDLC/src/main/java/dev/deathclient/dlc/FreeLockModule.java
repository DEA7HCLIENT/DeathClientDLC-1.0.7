package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Free Lock: your camera locks on a target and follows it, while you move freely (WASD, jumps and hits work as usual,
 * and movement keys act relative to the target). Target: the nearest one in Range, or the one closest to your crosshair.
 * Sticky keeps the same target until it dies, leaves Range or (with Visible only) hides; off = the best target is
 * re-picked every tick. Turn speed is the most degrees the camera turns per tick (low = smooth, high = snaps).
 */
public class FreeLockModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 20, 3, 50, 1));
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 40, 5, 180, 5));
    public final NumberSetting aim = add(new NumberSetting("Aim", 2, 1, 3, 1).labels("Head", "Chest", "Feet"));
    public final NumberSetting mode = add(new NumberSetting("Target", 1, 1, 2, 1).labels("Nearest", "Crosshair"));
    public final BoolSetting sticky = add(new BoolSetting("Sticky", true));
    public final BoolSetting visibleOnly = add(new BoolSetting("Visible only", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));

    private LivingEntity locked;

    public FreeLockModule() { super("Free Lock", Category.COMBAT); }

    @Override
    protected void onDisable() { locked = null; }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (c.currentScreen != null || !p.isAlive() || p.isSpectator()) return;

        if (locked != null && (!sticky.get() || !valid(p, locked))) locked = null;
        if (locked == null) locked = pick(c, p);
        if (locked == null) return;

        Vec3d point = switch ((int) aim.get()) {
            case 1 -> locked.getEyePos();
            case 3 -> Util.pos(locked).add(0, 0.2, 0);
            default -> locked.getBoundingBox().getCenter();
        };
        float[] want = Util.rotationsTo(p.getEyePos(), point);
        float max = (float) turnSpeed.get();
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dy, -max, max));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp, -max, max), -90f, 90f));
    }

    private boolean valid(ClientPlayerEntity p, LivingEntity le) {
        if (le == p || le.isRemoved() || !le.isAlive() || le.isSpectator() || Friends.skip(le)) return false;
        if (playersOnly.get() && !(le instanceof PlayerEntity)) return false;
        if (!invisible.get() && le.isInvisible()) return false;
        if (p.distanceTo(le) > range.get()) return false;
        return !visibleOnly.get() || p.canSee(le);
    }

    private LivingEntity pick(MinecraftClient c, ClientPlayerEntity p) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(p, le)) continue;
            double score;
            if ((int) mode.get() == 2) {                           // smallest angle between the crosshair and the target
                Vec3d to = le.getBoundingBox().getCenter().subtract(eye).normalize();
                score = Math.acos(MathHelper.clamp(look.dotProduct(to), -1.0, 1.0));
            } else {
                score = p.distanceTo(le);
            }
            if (score < bestScore) { bestScore = score; best = le; }
        }
        return best;
    }
}
