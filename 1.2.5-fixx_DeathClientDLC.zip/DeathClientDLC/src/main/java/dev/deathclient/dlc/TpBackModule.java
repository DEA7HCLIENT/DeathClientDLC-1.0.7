package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * TP Back: one press (turn it on, or use its bind) teleports you to the spot right behind a player: the one you look at
 * if "Look target first" is on, otherwise (or if you look at nobody) the nearest one in Range. The spot is "Distance"
 * blocks behind his back (the way his body faces), on a free square; the module then switches itself off again.
 * Position packets go in hops of at most 8 blocks (same as TPAura); the server still decides whether it accepts the move.
 */
public class TpBackModule extends Module {
    private static final double STEP = 8.0;
    private static final int MAX_CANDIDATES = 5;

    public final NumberSetting range = add(new NumberSetting("Range", 30, 5, 100, 1));
    public final NumberSetting behind = add(new NumberSetting("Distance", 1.5, 1.0, 3.0, 0.1));
    public final BoolSetting aimFirst = add(new BoolSetting("Look target first", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting throughWalls = add(new BoolSetting("Through walls", false));
    public final BoolSetting face = add(new BoolSetting("Face target", true));
    public final BoolSetting hit = add(new BoolSetting("Hit after", false));

    public TpBackModule() { super("TP Back", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.networkHandler != null) run(c, p);
        toggle();                                                // one-shot: off again until the next press
    }

    private void run(MinecraftClient c, ClientPlayerEntity p) {
        List<LivingEntity> candidates = new ArrayList<>();
        if (aimFirst.get()) {
            LivingEntity looked = pointed(c, p);
            if (looked != null) candidates.add(looked);
        }
        List<LivingEntity> near = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator() || !valid(le)) continue;
            if (p.distanceTo(le) <= range.get() && !candidates.contains(le)) near.add(le);
        }
        near.sort(Comparator.comparingDouble(p::distanceTo));
        candidates.addAll(near);

        int tried = 0;
        for (LivingEntity target : candidates) {
            if (tried++ >= MAX_CANDIDATES) break;
            Vec3d dest = spotBehind(c, p, target);
            if (dest == null) continue;
            Vec3d start = Util.pos(p);
            List<Vec3d> path = path(start, dest);
            if (!throughWalls.get() && !isClear(c, p, path)) continue;

            for (int i = 0; i < path.size(); i++) {
                Vec3d v = path.get(i);
                boolean ground = i == path.size() - 1 && groundAt(c, p, v);
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(v.x, v.y, v.z, ground, false));
            }
            p.setPosition(dest.x, dest.y, dest.z);
            p.setVelocity(Vec3d.ZERO);
            if (face.get()) {
                Vec3d eye = dest.add(0, p.getEyeHeight(p.getPose()), 0);
                float[] rot = Util.rotationsTo(eye, target.getBoundingBox().getCenter());
                p.setYaw(p.getYaw() + MathHelper.wrapDegrees(rot[0] - p.getYaw()));
                p.setPitch(MathHelper.clamp(rot[1], -90f, 90f));
            }
            if (hit.get()) {
                c.interactionManager.attackEntity(p, target);
                p.swingHand(Hand.MAIN_HAND);
            }
            p.sendMessage(Text.literal("TP Back: " + target.getName().getString()), true);
            return;
        }
        p.sendMessage(Text.literal("TP Back: нет цели в радиусе " + (int) range.get()), true);
    }

    private boolean valid(LivingEntity le) {
        return !(playersOnly.get() && !(le instanceof PlayerEntity)) && !Friends.skip(le);
    }

    /** The player under the crosshair within Range (the ray is a bit fatter than the hitbox), or null. */
    private LivingEntity pointed(MinecraftClient c, ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVec(1.0f).multiply(range.get()));
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (PlayerEntity o : c.world.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator() || Friends.skip(o)) continue;
            Optional<Vec3d> hitPoint = o.getBoundingBox().expand(0.4).raycast(eye, end);
            if (hitPoint.isEmpty()) continue;
            double d = hitPoint.get().squaredDistanceTo(eye);
            if (d < bestD) { bestD = d; best = o; }
        }
        return best;
    }

    /** A free spot behind the target's back; closer to him if the full distance is blocked, one block up as a fallback. */
    private Vec3d spotBehind(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        double yaw = Math.toRadians(t.getBodyYaw());
        Vec3d back = new Vec3d(Math.sin(yaw), 0, -Math.cos(yaw));        // opposite of the way the body faces
        for (double d = behind.get(); d >= 1.0 - 1.0E-6; d -= 0.5) {
            Vec3d v = Util.pos(t).add(back.multiply(d));
            for (double up : new double[]{0.0, 1.0}) {
                Vec3d w = v.add(0, up, 0);
                if (free(c, p, w)) return w;
            }
        }
        return null;
    }

    private static boolean free(MinecraftClient c, ClientPlayerEntity p, Vec3d v) {
        return c.world.isSpaceEmpty(p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ()));
    }

    private static boolean groundAt(MinecraftClient c, ClientPlayerEntity p, Vec3d v) {
        Box box = p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ());
        return c.world.isSpaceEmpty(box) && !c.world.isSpaceEmpty(box.offset(0, -0.05, 0));
    }

    /** Points from (excluded) to to (included), at most STEP apart. */
    private static List<Vec3d> path(Vec3d from, Vec3d to) {
        int n = Math.max(1, (int) Math.ceil(from.distanceTo(to) / STEP));
        List<Vec3d> points = new ArrayList<>();
        for (int i = 1; i <= n; i++) points.add(from.lerp(to, (double) i / n));
        return points;
    }

    private static boolean isClear(MinecraftClient c, ClientPlayerEntity p, List<Vec3d> points) {
        for (Vec3d v : points) if (!free(c, p, v)) return false;
        return true;
    }
}
