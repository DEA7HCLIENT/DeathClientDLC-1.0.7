package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Auto Armor: puts on better armor from your inventory (and the hotbar). "Better" is the material, best first:
 * netherite, diamond, iron, chainmail, gold, (turtle helmet), leather; enchantments are not compared.
 * The piece is swapped in with three inventory clicks, one piece per Delay ticks. Keep elytra leaves a worn elytra alone.
 */
public class AutoArmorModule extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Item[][] ORDER = {
            {Items.NETHERITE_HELMET, Items.DIAMOND_HELMET, Items.IRON_HELMET, Items.CHAINMAIL_HELMET, Items.GOLDEN_HELMET, Items.TURTLE_HELMET, Items.LEATHER_HELMET},
            {Items.NETHERITE_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.IRON_CHESTPLATE, Items.CHAINMAIL_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.LEATHER_CHESTPLATE},
            {Items.NETHERITE_LEGGINGS, Items.DIAMOND_LEGGINGS, Items.IRON_LEGGINGS, Items.CHAINMAIL_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.LEATHER_LEGGINGS},
            {Items.NETHERITE_BOOTS, Items.DIAMOND_BOOTS, Items.IRON_BOOTS, Items.CHAINMAIL_BOOTS, Items.GOLDEN_BOOTS, Items.LEATHER_BOOTS}};

    public final NumberSetting delay = add(new NumberSetting("Delay", 2, 0, 10, 1));
    public final BoolSetting keepElytra = add(new BoolSetting("Keep elytra", true));

    private int wait;

    public AutoArmorModule() { super("Auto Armor", Category.COMBAT); }

    /** Higher = better, -1 = not a piece for this slot. */
    private static int rank(int slot, Item item) {
        Item[] order = ORDER[slot];
        for (int i = 0; i < order.length; i++) if (order[i] == item) return order.length - i;
        return -1;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (wait > 0) { wait--; return; }
        if (!p.isAlive() || Inv.otherContainerOpen(c)) return;
        for (int s = 0; s < 4; s++) {
            var worn = p.getEquippedStack(SLOTS[s]);
            if (s == 1 && keepElytra.get() && worn.isOf(Items.ELYTRA)) continue;
            int best = rank(s, worn.getItem()), bestSlot = -1;
            for (int i = 0; i < 36; i++) {
                int r = rank(s, p.getInventory().getStack(i).getItem());
                if (r > best) { best = r; bestSlot = i; }
            }
            if (bestSlot < 0) continue;
            int from = Inv.container(bestSlot), armor = 5 + s;               // armor slots are 5 (head) to 8 (feet)
            Inv.click(c, p, from, 0, SlotActionType.PICKUP);                 // take the new piece
            Inv.click(c, p, armor, 0, SlotActionType.PICKUP);                // swap it with the worn one
            Inv.click(c, p, from, 0, SlotActionType.PICKUP);                 // the old piece goes where the new one was
            wait = (int) delay.get();
            return;
        }
    }
}
