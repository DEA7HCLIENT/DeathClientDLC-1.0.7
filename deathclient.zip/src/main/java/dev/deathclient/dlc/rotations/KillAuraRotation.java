package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

/**
 * All rotation logic of Kill Aura, kept apart from the module. Modes: None, Silent (the server is told the aim for
 * each hit only, your view never moves) and the nine held server-side profiles in {@link ExtraRotations}
 * (ReallyWorld, MLSAC, Sloth, SpookyTime, FTAngle, FunTime New, LegitSnap, Matrix2, Grim2).
 * KillAuraModule only picks targets and attacks; per tick it calls {@link #update}, and around every hit
 * {@link #beforeHit} / {@link #afterHits}. The settings it reads (Aim point, Hit check, Visual camera, Range) stay on
 * the module so the menu does not change. Mode numbers changed when the old profiles were removed, so a saved
 * Rotation value from an older config may point at another mode.
 */
final class KillAuraRotation {
    static final int NONE = 1, SILENT = 2,
            // ExtraRotations profiles: ReallyWorld, MLSAC, Sloth, SpookyTime, FTAngle, FunTime New, LegitSnap, Matrix2, Grim2
            MN_FIRST = 3, MN_LAST = 11;

    static final String[] LABELS = {"None", "Silent",
            "ReallyWorld", "MLSAC", "Sloth", "SpookyTime", "FTAngle", "FunTime New", "LegitSnap", "Matrix2", "Grim2"};

    private final KillAuraModule ka;
    /** Profiles, created once per mode so each keeps its own state; hit bookkeeping they read. */
    private final ExtraRotations.Profile[] dk = new ExtraRotations.Profile[MN_LAST - MN_FIRST + 1];
    private long lastHitMs = 0L;
    private int hitCount;

    /** Server-side rotation held by the profiles while a target exists. */
    private boolean srvActive;
    private float srvYaw, srvPitch;
    /** Aim point offset inside the hitbox ("Aim point: Random"), re-rolled every few ticks. */
    private Vec3d aimOffset = Vec3d.ZERO;
    private int aimTicks;

    KillAuraRotation(KillAuraModule ka) { this.ka = ka; }

    // ---- what a mode implies for the module ----

    /** Modes that keep a server-side view between ticks. */
    static boolean held(int mode) { return isDk(mode); }

    static boolean isDk(int mode) { return mode >= MN_FIRST && mode <= MN_LAST; }

    /** Modes that aim at one target at a time. */
    static boolean singleTarget(int mode) { return isDk(mode); }

    /** No mode limits reach any more (Grim / Matrix profiles were removed); kept for the module. */
    static boolean strictReach(int mode) { return false; }

    /** Weapon cooldown needed before a hit in this mode, given the module's own value. */
    float minCooldown(int mode, float base) { return base; }

    /** True when this mode must not hit right now. */
    boolean hitBlocked(ClientPlayerEntity p, LivingEntity t, int mode) { return false; }

    // ---- per-tick lifecycle ----

    /** A different target became the primary one: drop the per-target aim state. */
    void onNewTarget() {
        aimTicks = 0;
        java.util.Arrays.fill(dk, null);                                   // the profiles start fresh on a new target
    }

    /** Runs the mode for this tick; returns whether the aim is good enough to hit. */
    boolean update(MinecraftClient c, ClientPlayerEntity p, LivingEntity t, int mode) {
        if (!held(mode)) release(c, p);
        if (isDk(mode)) return extra(c, p, t, mode);
        return true;
    }

    /** Right before hit number {@code index} (0 = first target): Silent tells the server the aim for this hit. */
    void beforeHit(MinecraftClient c, ClientPlayerEntity p, LivingEntity t, int mode, int index) {
        if (mode == SILENT) sendLook(c, p, wantYaw(p, t), wantPitch(p, t));
    }

    /** After the hits of this tick: Silent tells the server the real view again. */
    void afterHits(MinecraftClient c, ClientPlayerEntity p, int mode, int hits) {
        lastHitMs = System.currentTimeMillis();
        hitCount += hits;
        if (mode == SILENT) sendLook(c, p, p.getYaw(), p.getPitch());      // back to the real view
    }

    /** Ends a held server-side rotation by telling the server the real view again. */
    void release(MinecraftClient c, ClientPlayerEntity p) {
        if (!srvActive) return;
        srvActive = false;
        if (p != null) sendLook(c, p, p.getYaw(), p.getPitch());
    }

    // ---- profiles ----

    /**
     * Runs one of the profiles ported (ReallyWorld, MLSAC, Sloth, SpookyTime, FTAngle, FunTime New,
     * LegitSnap, Matrix2, Grim2) as a held server-side rotation: the profile proposes the next angle, which is put on the
     * mouse grid relative to the last angle the server got (what the original Angle.adjustSensitivity did) and sent only
     * when it changed. The hit goes out while the look ray the server knows crosses the hitbox within Range.
     */
    private boolean extra(MinecraftClient c, ClientPlayerEntity p, LivingEntity t, int mode) {
        int i = mode - MN_FIRST;
        if (dk[i] == null) dk[i] = ExtraRotations.create(i);
        if (!srvActive) { srvActive = true; srvYaw = p.getYaw(); srvPitch = p.getPitch(); }
        Box b = t.getBoundingBox();
        Vec3d eye = p.getEyePos();
        double range = ka.range.get();

        ExtraRotations.State s = new ExtraRotations.State();
        s.curYaw = srvYaw; s.curPitch = srvPitch;
        float[] want = Util.rotationsTo(eye, aimPoint(p, t, srvYaw, srvPitch));
        s.tYaw = want[0]; s.tPitch = want[1];
        Vec3d near = new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX), MathHelper.clamp(eye.y, b.minY, b.maxY), MathHelper.clamp(eye.z, b.minZ, b.maxZ));
        float[] close = Util.rotationsTo(eye, near);
        s.closeYaw = close[0]; s.closePitch = close[1];
        s.viewYaw = p.getYaw(); s.viewPitch = p.getPitch();
        s.distance = p.distanceTo(t); s.range = range;
        s.cooldown = p.getAttackCooldownProgress(0.5f);
        s.ready = s.cooldown >= 0.9f;
        s.sinceHitMs = lastHitMs == 0L ? Long.MAX_VALUE / 2 : System.currentTimeMillis() - lastHitMs;
        s.hits = hitCount;
        s.rayHit = Rotations.rayHits(eye, srvYaw, srvPitch, b, range + 0.1, 0.0);
        s.rayHitNear = Rotations.rayHits(eye, srvYaw, srvPitch, b, 4.0, 0.0);
        s.rayHitShort = Rotations.rayHits(eye, srvYaw, srvPitch, b, Math.max(0.5, range - 0.5), 0.0);

        float[] r = dk[i].step(s);
        float gcd = Rotations.gcd(c);
        float ny = srvYaw + Rotations.snap(MathHelper.wrapDegrees(r[0] - srvYaw), gcd);
        float np = MathHelper.clamp(srvPitch + Rotations.snap(r[1] - srvPitch, gcd), -90f, 90f);
        if (ny != srvYaw || np != srvPitch) {                                // never repeat an identical look packet
            srvYaw = ny;
            srvPitch = np;
            sendLook(c, p, srvYaw, srvPitch);
        } else {
            ServerRotation.set(srvYaw, srvPitch, 400);
        }
        return Rotations.rayHits(eye, srvYaw, srvPitch, b, range + 0.1, 0.0);
    }

    // ---- aim point ----

    /** Aim point inside the target's hitbox for the profiles that honour the "Aim point" setting. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t, float fromYaw, float fromPitch) {
        Box b = t.getBoundingBox();
        Vec3d c = b.getCenter();
        double h = b.getLengthY();
        switch ((int) ka.aimPoint.get()) {
            case 2: return new Vec3d(c.x, b.minY + h * 0.65, c.z);
            case 3: return new Vec3d(c.x, b.minY + h * 0.90, c.z);
            case 4: return Rotations.nearestPoint(p.getEyePos(), fromYaw, fromPitch, b);
            case 5: {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                if (aimTicks-- <= 0) {
                    aimOffset = new Vec3d(r.nextDouble(-0.25, 0.25) * b.getLengthX(),
                            (r.nextDouble(0.55, 0.85) - 0.5) * b.getLengthY(),
                            r.nextDouble(-0.25, 0.25) * b.getLengthZ());
                    aimTicks = r.nextInt(5, 11);
                }
                return c.add(aimOffset);
            }
            default: return c;
        }
    }

    // ---- helpers / packets ----

    private static float wantYaw(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[0];
    }

    private static float wantPitch(ClientPlayerEntity p, Entity t) {
        return Util.rotationsTo(p.getEyePos(), t.getBoundingBox().getCenter())[1];
    }

    // ---- packets ----

    private void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        ServerRotation.set(yaw, MathHelper.clamp(pitch, -90f, 90f), 400);   // third-person model shows the aim
        // Visual camera: the local view turns to the same angles the server is told, so you see the aim too.
        if (ka.visualCamera.get()) {
            p.setYaw(yaw);
            p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
        }
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }
}
