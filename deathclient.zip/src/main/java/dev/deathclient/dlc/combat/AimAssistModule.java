package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AimAssist: smoothly pulls your crosshair towards the nearest target in front of you.
 * <ul>
 *   <li>Basic: the original pull towards the centre of the hitbox (Speed, Smoothing).</li>
 *   <li>Legit: a hand-like assist. It reacts a few ticks after a target enters the FOV, aims at a point near where
 *       you already look (not the exact centre) that drifts a little, pulls only part of the way (Strength), moves
 *       less vertically than horizontally, varies its step a little and stops inside a small dead zone instead of
 *       correcting every tiny error. Turns are rounded to what the mouse can do.</li>
 * </ul>
 */
public class AimAssistModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 5.0, 2.0, 10.0, 0.5));
    public final NumberSetting fov = add(new NumberSetting("FOV", 90, 10, 360, 5));
    public final NumberSetting speed = add(new NumberSetting("Speed", 6, 1, 30, 0.5));
    /** Share of the remaining angle covered per tick: low = slow, soft, no snapping; 1.0 = full Speed all the way. */
    public final NumberSetting smoothing = add(new NumberSetting("Smoothing", 0.25, 0.05, 1.0, 0.05));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting onClick = add(new BoolSetting("Only while attacking", false));
    /** Draws a circle on the screen around the crosshair: targets inside it can be picked up by the assist. */
    public final BoolSetting showFov = add(new BoolSetting("Show FOV", true));
    public final NumberSetting mode = add(new NumberSetting("Rotation", 2, 1, 2, 1).labels("Basic", "Legit"));
    /** Legit: how much of the pull is applied (low = a light nudge, 1.0 = the full pull). */
    public final NumberSetting strength = add(new NumberSetting("Strength", 0.5, 0.1, 1.0, 0.05));
    /** Legit: share of the pull applied to the pitch (a hand corrects height less than direction). */
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.5, 0.0, 1.0, 0.1));
    /** Legit: ticks to wait after a target enters the FOV before the assist starts (plus 0-2 random). */
    public final NumberSetting reaction = add(new NumberSetting("Reaction (ticks)", 3, 0, 10, 1));
    /** Legit: no pull while the error is smaller than this many degrees. */
    public final NumberSetting deadZone = add(new NumberSetting("Dead zone", 0.8, 0.0, 3.0, 0.1));

    private LivingEntity current;
    private int waitTicks, offsetTicks;
    private Vec3d offset = Vec3d.ZERO;

    public AimAssistModule() { super("AimAssist", Category.COMBAT); }

    @Override
    protected void onDisable() { current = null; }

    /** HUD callback, see DeathClientDLC: the FOV circle. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        AimAssistModule m = ModuleManager.get(AimAssistModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || !m.showFov.get() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.drawFov(ctx, c);
    }

    /**
     * The assist takes targets whose angle from the crosshair is below FOV / 2, so on screen that is a circle around
     * the centre with radius (height / 2) * tan(FOV / 2) / tan(game FOV / 2). It turns brighter while a target is held.
     */
    private void drawFov(DrawContext ctx, MinecraftClient c) {
        double half = fov.get() / 2.0;
        if (half >= 85.0) return;                                   // the circle would be larger than any screen
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        double tanGame = Math.tan(Math.toRadians(c.options.getFov().getValue()) / 2.0);
        double r = (sh / 2.0) * Math.tan(Math.toRadians(half)) / tanGame;
        if (r < 3 || r > 4000) return;
        int color = (current != null ? 0xFF55FF55 : 0xB0000000 | Theme.current().accent());
        double cx = sw / 2.0, cy = sh / 2.0;
        int seg = (int) Math.max(32, Math.min(96, r / 3));
        int px = (int) Math.round(cx + r), py = (int) Math.round(cy);
        for (int i = 1; i <= seg; i++) {
            double a = Math.PI * 2 * i / seg;
            int x = (int) Math.round(cx + Math.cos(a) * r), y = (int) Math.round(cy + Math.sin(a) * r);
            EspModule.line(ctx, px, py, x, y, 1, color);
            px = x; py = y;
        }
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.currentScreen != null) return;
        if (onClick.get() && !c.options.attackKey.isPressed()) { current = null; return; }
        LivingEntity t = AimUtil.pick(c, p, range.get(), fov.get(), playersOnly.get());
        if ((int) mode.get() == 1) {
            if (t != null) AimUtil.turn(c, p, t.getBoundingBox().getCenter(), speed.get(), smoothing.get());
            return;
        }
        legit(c, p, t);
    }

    private void legit(MinecraftClient c, ClientPlayerEntity p, LivingEntity t) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        if (t != current) {                                     // a new target: "notice" it first
            current = t;
            waitTicks = (int) reaction.get() + (reaction.get() > 0 ? rnd.nextInt(3) : 0);
            offsetTicks = 0;
        }
        if (t == null) return;
        if (waitTicks > 0) { waitTicks--; return; }

        var eye = p.getEyePos();
        var box = t.getBoundingBox();
        if (--offsetTicks <= 0) {                               // the aim point drifts every 0.4 - 1.1 s
            offsetTicks = 8 + rnd.nextInt(14);
            offset = new Vec3d(rnd.nextGaussian() * 0.05, rnd.nextGaussian() * 0.08, rnd.nextGaussian() * 0.05);
        }
        Vec3d point = Rotations.nearestPoint(eye, p.getYaw(), p.getPitch(), box).add(offset);
        float[] r = Util.rotationsTo(eye, point);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        if (Math.hypot(dyaw, dpitch) < deadZone.get()) return;

        double k = strength.get() * smoothing.get();
        double jitter = 1.0 + (rnd.nextDouble() - 0.5) * 0.3;   // +-15 % step to step
        double cap = speed.get();
        float sy = (float) MathHelper.clamp(dyaw * k * jitter, -cap, cap);
        float sp = (float) MathHelper.clamp(dpitch * k * vertical.get() * jitter, -cap, cap);
        float g = Rotations.gcd(c);
        p.setYaw(p.getYaw() + Rotations.snap(sy, g));
        p.setPitch(MathHelper.clamp(p.getPitch() + Rotations.snap(sp, g), -90f, 90f));
    }
}
