package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Single-window ClickGUI: sidebar with categories (+ Configs / Themes), search bar and a two-column
 * grid of module cards. Enabled modules are filled with the theme accent.
 * LMB card: toggle. RMB card or gear: settings. MMB card or chain icon: bind. Click the search field and type.
 */
public class ClickGuiScreen extends Screen {
    private static final int WW = 380, WH = 244, SW = 96, CARD_H = 36, GAP = 6, SET_H = 26, ROW = 16, KB_H = 18;
    /** Corner radius in GUI pixels (shared with the main menu and HUD). */
    private static final int R = 4;

    private static final int WIN_BG = 0xF2101016, CARD_BG = 0xFF16161F, CARD_HOVER = 0xFF1F1F2A, CARD_LINE = 0xFF23232F;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFF8C8C99, SOFT = 0xFFB8B8C4;

    private enum Tab { CATEGORY, CONFIGS, THEMES, KEYBINDS }

    // Kept between openings.
    private static int winX, winY;
    private static boolean placed;
    private static Category selCat = Category.COMBAT;
    private static Tab tab = Tab.CATEGORY;

    /** Opacity multiplier of everything the GUI draws (the Fade animation); 1 outside the GUI's own render. */
    private static float fadeA = 1f;

    private static int fa(int argb) {
        if (fadeA >= 1f) return argb;
        return ((int) ((argb >>> 24) * fadeA) << 24) | (argb & 0xFFFFFF);
    }

    // Open / close animation (GuiAnimationModule).
    private final long animStart = System.nanoTime();
    private boolean closing;
    private long closeStart;

    private final List<Category> cats = new ArrayList<>();
    private List<String> cfgs = List.of();
    private Module openModule;
    private double scroll;
    private String query = "";
    private boolean searchFocused;

    private boolean draggingWin;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;

    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private long repeatAt;

    public ClickGuiScreen() {
        super(Text.literal("Death Client"));
    }

    @Override
    protected void init() {
        cats.clear();
        for (Category c : Category.values()) if (!ModuleManager.of(c).isEmpty()) cats.add(c);
        if (!cats.contains(selCat) && !cats.isEmpty()) selCat = cats.get(0);
        if (!placed) {
            winX = (width - WW) / 2;
            winY = (height - WH) / 2;
            placed = true;
        }
        winX = clamp(winX, 0, Math.max(0, width - WW));
        winY = clamp(winY, 0, Math.max(0, height - WH));
        refreshCfgs();
    }

    // ------------------------------------------------------------------ helpers

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(r * r - dy * dy));
    }

    /** Filled rect with optional rounded top and/or bottom corners (one scanline per corner row). */
    static void rect(DrawContext ctx, int x, int y, int w, int h, int color, boolean top, boolean bottom) {
        color = fa(color);
        int r = Math.min(R, h / 2);
        int t = top ? r : 0, b = bottom ? r : 0;
        for (int i = 0; i < t; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
        for (int i = 0; i < b; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + t, x + w, y + h - b, color);
    }

    /** Fully rounded rectangle with its own corner radius. */
    static void rrect(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        color = fa(color);
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t), g = (int) (ag + (bg - ag) * t), bl = (int) (ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------------ glass menu / theme gradient helpers

    /** Set at the start of every frame: Glass Menu is on. */
    private boolean glass;

    private int cardBg()      { return glass ? 0x26FFFFFF : CARD_BG; }
    private int cardHover()   { return glass ? 0x3CFFFFFF : CARD_HOVER; }
    private int cardLine()    { return glass ? 0x4DFFFFFF : CARD_LINE; }
    private int field()       { return glass ? 0x22FFFFFF : 0xFF171720; }
    private int fieldFocus()  { return glass ? 0x3AFFFFFF : 0xFF22222E; }
    private int track()       { return glass ? 0x66000000 : 0xFF2C2C38; }

    /** One-pixel rounded outline (the glass edge); the inside is left untouched. */
    static void outline(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        color = fa(color);
        r = Math.min(r, Math.min(w, h) / 2);
        int i0 = inset(r, 0);
        ctx.fill(x + i0, y, x + w - i0, y + 1, color);
        ctx.fill(x + i0, y + h - 1, x + w - i0, y + h, color);
        ctx.fill(x, y + r, x + 1, y + h - r, color);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 1; i < r; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + in + 1, y + i + 1, color);
            ctx.fill(x + w - in - 1, y + i, x + w - in, y + i + 1, color);
            ctx.fill(x + in, y + h - 1 - i, x + in + 1, y + h - i, color);
            ctx.fill(x + w - in - 1, y + h - 1 - i, x + w - in, y + h - i, color);
        }
    }

    /** Card with a border. Glass: translucent fill + outline drawn on top; normal: border rect under the fill. */
    private void cardBox(DrawContext ctx, int x, int y, int w, int h, int line, int fill, int r) {
        if (glass) {
            if ((fill >>> 24) != 0) rrect(ctx, x, y, w, h, fill, r);
            outline(ctx, x, y, w, h, line, r);
        } else {
            rrect(ctx, x - 1, y - 1, w + 2, h + 2, line, r);
            if ((fill >>> 24) != 0) rrect(ctx, x, y, w, h, fill, r);
        }
    }

    /** Rounded rect in the theme colour; a gradient theme is laid out left to right across the whole window. */
    private void accentRect(DrawContext ctx, int x, int y, int w, int h, int r) {
        Theme t = Theme.current();
        int a = glass ? 0xC8 : 0xFF;
        if (!t.gradient()) { rrect(ctx, x, y, w, h, (a << 24) | (t.accent() & 0xFFFFFF), r); return; }
        gradRect(ctx, x, y, w, h, r, t, (x - winX) / (float) WW, (x + w - winX) / (float) WW, a);
    }

    /** Rounded rect filled with the theme gradient from position u0 to u1 (0..1), in 1-4 px wide slices. */
    private static void gradRect(DrawContext ctx, int x, int y, int w, int h, int r, Theme t, float u0, float u1, int alpha) {
        if (!t.gradient()) { rrect(ctx, x, y, w, h, (alpha << 24) | (t.accent() & 0xFFFFFF), r); return; }
        r = Math.min(r, Math.min(w, h) / 2);
        for (int c = 0; c < w; ) {
            boolean edge = c < r || c >= w - r;
            int step = edge ? 1 : Math.max(1, Math.min(4, (w - r) - c));
            int v = edge ? inset(r, Math.min(c, w - 1 - c)) : 0;
            float u = u0 + (u1 - u0) * ((c + step / 2f) / w);
            ctx.fill(x + c, y + v, x + c + step, y + h - v, fa((alpha << 24) | (t.at(u) & 0xFFFFFF)));
            c += step;
        }
    }

    private static int accent() { return Theme.current().accent(); }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        color = fa(color);
        if ((color >>> 24) < 4) return;                       // the game draws near-zero alpha text as opaque
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    // Tiny pixel icons.
    private static final String[] ICON_COMBAT = {"...#...", ".#.#.#.", "..###..", "#######", "..###..", ".#.#.#.", "...#..."};
    private static final String[] ICON_MOVE = {"#..#...", "##.##..", ".##.##.", "..##.##", ".##.##.", "##.##..", "#..#..."};
    private static final String[] ICON_EYE = {"..###..", ".#...#.", "#..#..#", ".#...#.", "..###.."};
    private static final String[] ICON_STAR = {"...#...", "..###..", ".#####.", "#######", ".#####.", "..###..", "...#..."};
    private static final String[] ICON_BOX = {"#######", "#.....#", "#.###.#", "#.###.#", "#.###.#", "#.....#", "#######"};
    private static final String[] ICON_FOLDER = {"###....", "#######", "#.....#", "#.....#", "#.....#", "#######"};
    private static final String[] ICON_DROP = {"...#...", "..###..", ".#####.", "#######", "#######", ".#####.", "..###.."};
    private static final String[] ICON_EXIT = {"####...", "#..#...", "#..#.#.", "#..####", "#..#.#.", "#..#...", "####..."};
    private static final String[] ICON_SEARCH = {".###...", "#...#..", "#...#..", "#...#..", ".###...", ".....#.", "......#"};
    private static final String[] ICON_GEAR = {"..#.#..", ".#####.", "###.###", ".#...#.", "###.###", ".#####.", "..#.#.."};
    private static final String[] ICON_LINK = {".###.###.", "#..#.#..#", "#.#####.#", "#..#.#..#", ".###.###."};
    private static final String[] ICON_BACK = {"...#", "..##", ".###", "####", ".###", "..##", "...#"};
    private static final String[] ICON_KEY = {".###...", "#...#..", "#...#..", ".###...", "..#....", "..##...", "..#.#.."};
    private static final String[] ICON_USER = {"..###..", "..###..", "...#...", ".#####.", "#.###.#", "..#.#..", "..#.#.."};

    private static String[] iconFor(Category c) {
        return switch (c) {
            case COMBAT -> ICON_COMBAT;
            case MOVEMENT -> ICON_MOVE;
            case RENDER -> ICON_EYE;
            case VISUALS -> ICON_STAR;
            default -> ICON_BOX;
        };
    }

    private static void icon(DrawContext ctx, String[] rows, int x, int y, int color) {
        for (int j = 0; j < rows.length; j++) {
            String row = rows[j];
            for (int i = 0; i < row.length(); i++) {
                if (row.charAt(i) == '#') ctx.fill(x + i, y + j, x + i + 1, y + j + 1, fa(color));
            }
        }
    }

    private static void check(DrawContext ctx, int x, int y, int color) {
        int[][] px = {{0, 2}, {1, 3}, {2, 4}, {3, 3}, {4, 2}, {5, 1}, {6, 0}};
        for (int[] q : px) ctx.fill(x + q[0], y + q[1], x + q[0] + 1, y + q[1] + 2, fa(color));
    }

    /** Up to two lines of text that fit maxW, the last one cut with "..." if needed. */
    private List<String> wrap(String s, int maxW) {
        List<String> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        String[] words = s.split(" ");
        StringBuilder cur = new StringBuilder();
        int i = 0;
        for (; i < words.length && out.size() < 2; i++) {
            String t = cur.length() == 0 ? words[i] : cur + " " + words[i];
            if (textRenderer.getWidth(t) <= maxW || cur.length() == 0) {
                cur = new StringBuilder(t);
            } else {
                out.add(cur.toString());
                cur = new StringBuilder(words[i]);
                if (out.size() == 2) break;
            }
        }
        if (out.size() < 2 && cur.length() > 0) { out.add(cur.toString()); i = words.length; }
        if (i < words.length && !out.isEmpty()) {
            String last = out.get(out.size() - 1);
            while (last.length() > 1 && textRenderer.getWidth(last + "...") > maxW) last = last.substring(0, last.length() - 1);
            out.set(out.size() - 1, last + "...");
        }
        return out;
    }

    // ------------------------------------------------------------------ geometry

    private int cx() { return winX + SW + 10; }
    private int cw() { return WW - SW - 18; }
    private int listTop() { return winY + 34; }
    private int listBottom() { return winY + WH - 16; }
    private int cardW() { return (cw() - GAP) / 2; }
    private int navY(int i) { return winY + 52 + i * (ROW + 2); }
    private int configsY() { return navY(cats.size()) + 16; }
    private int themesY() { return configsY() + ROW + 2; }
    private int keybindsY() { return themesY() + ROW + 2; }
    private int accountsY() { return keybindsY() + ROW + 2; }
    private int searchW() { return cw() - 44; }

    private boolean inList(double mx, double my, int top) {
        return in(mx, my, cx(), top, cw(), listBottom() - top);
    }

    private List<Module> visible() {
        if (!query.isEmpty()) {
            String q = query.toLowerCase(Locale.ROOT).replace(" ", "");
            List<Module> out = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                if (m.getName().toLowerCase(Locale.ROOT).replace(" ", "").contains(q)) out.add(m);
            }
            return out;
        }
        return ModuleManager.of(selCat);
    }

    private void refreshCfgs() { cfgs = Config.list(); }

    /** Top of the scrolling area for the current view. */
    private int viewTop() {
        if (openModule != null || tab == Tab.CONFIGS || tab == Tab.KEYBINDS) return listTop() + 24;
        return listTop();
    }

    private int contentHeight() {
        if (openModule != null) return openModule.getSettings().size() * (SET_H + 4);
        if (tab == Tab.CONFIGS) return cfgs.size() * (ROW + 6);
        if (tab == Tab.KEYBINDS) return ModuleManager.all().size() * (KB_H + 4);
        int n = tab == Tab.THEMES ? Theme.values().length : visible().size();
        int rows = (n + 1) / 2;
        return rows == 0 ? 0 : rows * (CARD_H + GAP) - GAP;
    }

    private double maxScroll() { return Math.max(0, contentHeight() - (listBottom() - viewTop())); }

    // ------------------------------------------------------------------ typing (polled, layout-independent)

    private void pollTyping() {
        if (client == null) return;
        long win = client.getWindow().getHandle();
        boolean active = searchFocused && Binds.listening() == null;
        long now = System.currentTimeMillis();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_Z; k++) {
            boolean ok = k == GLFW.GLFW_KEY_SPACE || (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9) || (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z);
            if (!ok) continue;
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (active && down && !prevKey[k] && query.length() < 20) {
                char ch = k >= GLFW.GLFW_KEY_A ? (char) ('a' + (k - GLFW.GLFW_KEY_A)) : (char) k;
                typed(String.valueOf(ch));
            }
            prevKey[k] = down;
        }
        int bs = GLFW.GLFW_KEY_BACKSPACE;
        boolean down = GLFW.glfwGetKey(win, bs) == GLFW.GLFW_PRESS;
        if (active && down) {
            if (!prevKey[bs]) { backspace(); repeatAt = now + 350; }
            else if (now >= repeatAt) { backspace(); repeatAt = now + 45; }
        }
        prevKey[bs] = down;
    }

    private void typed(String s) {
        query += s;
        tab = Tab.CATEGORY;
        openModule = null;
        scroll = 0;
    }

    private void backspace() {
        if (query.isEmpty()) return;
        query = query.substring(0, query.length() - 1);
        scroll = 0;
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) Ui.drawWorldDim(ctx, width, height);
        else Ui.drawBackground(ctx, width, height);
        GuiImage.draw(ctx, width, height);                       // GUI Image module: picture in the bottom-right corner
    }

    // Dropping a png / jpg on the open ClickGUI sets the GUI Image (the method name differs between mappings).
    public void filesDragged(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    public void onFilesDropped(java.util.List<java.nio.file.Path> paths) { GuiImage.handleDrop(paths); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        double p = animProgress();
        if (closing && p <= 0) return;                         // finished: tick() closes the screen
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (p >= 1 || am == null || !am.isEnabled()) { renderGui(ctx, mx, my); return; }

        GuiAnimationModule.Pose pose = am.pose(p, winX, winY, WW, WH, width, height);
        float cx = winX + WW / 2f, cy = winY + WH / 2f;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) pose.dx(), (float) pose.dy());
        m.translate(cx, cy);
        m.scale((float) pose.scale(), (float) pose.scale());
        m.translate(-cx, -cy);
        fadeA = (float) pose.alpha();
        try {
            renderGui(ctx, mx, my);
        } finally {
            fadeA = 1f;
            m.popMatrix();
        }
    }

    /** How much of the window is shown, 0..1: grows while opening, shrinks while closing. 1 when there is no animation. */
    private double animProgress() {
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (am == null || !am.isEnabled()) return closing ? 0 : 1;
        double t = Math.min(1.0, (System.nanoTime() - (closing ? closeStart : animStart)) / 1.0e6 / am.durationMs());
        return closing ? 1 - t : t;
    }

    private boolean animating() { return closing || animProgress() < 1; }

    @Override
    public void close() {
        if (closing) return;
        GuiAnimationModule am = ModuleManager.get(GuiAnimationModule.class);
        if (am != null && am.isEnabled() && am.closeAnimation.get()) {
            closing = true;                                    // the real close happens in tick() once it has played
            closeStart = System.nanoTime();
        } else {
            super.close();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!closing && client != null && GuiStyleModule.style() != GuiStyleModule.CLASSIC) {   // style changed in the settings
            client.setScreen(GuiStyleModule.create());
            return;
        }
        if (closing && animProgress() <= 0) super.close();
    }

    private void renderGui(DrawContext ctx, int mx, int my) {
        pollTyping();
        scroll = Math.max(0, Math.min(scroll, maxScroll()));

        GlassMenuModule gm = ModuleManager.get(GlassMenuModule.class);
        glass = gm != null && gm.isEnabled();
        if (glass) {
            // Smoked glass: translucent tinted pane, bright rim, soft light band along the top edge.
            int a = (int) (gm.opacity.get() * 2.55);
            int body = mix(0xFF0B0D14, accent(), (float) (gm.tint.get() / 100.0) * 0.5f);
            rrect(ctx, winX, winY, WW, WH, (a << 24) | (body & 0xFFFFFF), 6);
            if (gm.shine.get()) {
                ctx.fillGradient(winX + 2, winY + 6, winX + WW - 2, winY + 6 + WH * 2 / 5, fa(0x30FFFFFF), fa(0x00FFFFFF));
            }
            if (gm.border.get()) {
                outline(ctx, winX, winY, WW, WH, 0x70FFFFFF, 6);
                outline(ctx, winX + 1, winY + 1, WW - 2, WH - 2, 0x14FFFFFF, 5);
            }
        } else {
            rrect(ctx, winX - 1, winY - 1, WW + 2, WH + 2, 0x33FFFFFF, 7);
            rrect(ctx, winX, winY, WW, WH, WIN_BG, 6);
        }
        ctx.fill(winX + SW, winY + 8, winX + SW + 1, winY + WH - 8, fa(0x22FFFFFF));

        renderSidebar(ctx, mx, my);
        renderTopBar(ctx, mx, my);

        if (openModule != null) renderSettings(ctx, mx, my);
        else if (tab == Tab.CONFIGS) renderConfigs(ctx, mx, my);
        else if (tab == Tab.THEMES) renderThemes(ctx, mx, my);
        else if (tab == Tab.KEYBINDS) renderKeybinds(ctx, mx, my);
        else renderModules(ctx, mx, my);

        text(ctx, tab == Tab.KEYBINDS && openModule == null ? "ЛКМ назначить   ПКМ сбросить" : "ЛКМ вкл   ПКМ настройки   СКМ бинд", cx(), winY + WH - 12, 0xFF5E5E6B);
    }

    private void navRow(DrawContext ctx, int mx, int my, int y, String[] ic, String label, boolean selected) {
        int x = winX + 6, w = SW - 12;
        boolean hover = in(mx, my, x, y, w, ROW);
        if (selected) accentRect(ctx, x, y, w, ROW, 5);
        else if (hover) rrect(ctx, x, y, w, ROW, 0x22FFFFFF, 5);
        icon(ctx, ic, x + 6, y + 4, selected ? WHITE : SOFT);
        text(ctx, label, x + 19, y + 4, selected ? WHITE : SOFT);
    }

    private void renderSidebar(DrawContext ctx, int mx, int my) {
        accentRect(ctx, winX + 8, winY + 8, 22, 22, 5);
        text(ctx, "D", winX + 16, winY + 15, WHITE);
        text(ctx, "Death", winX + 35, winY + 10, WHITE);     // two lines: the sidebar is too narrow for one
        text(ctx, "Client", winX + 35, winY + 20, SOFT);

        text(ctx, "Основные", winX + 10, winY + 40, MUTED);
        for (int i = 0; i < cats.size(); i++) {
            Category c = cats.get(i);
            navRow(ctx, mx, my, navY(i), iconFor(c), c.label, tab == Tab.CATEGORY && query.isEmpty() && c == selCat);
        }
        text(ctx, "Другие", winX + 10, navY(cats.size()) + 3, MUTED);
        navRow(ctx, mx, my, configsY(), ICON_FOLDER, "Configs", tab == Tab.CONFIGS);
        navRow(ctx, mx, my, themesY(), ICON_DROP, "Themes", tab == Tab.THEMES);
        navRow(ctx, mx, my, keybindsY(), ICON_KEY, "Keybinds", tab == Tab.KEYBINDS);
        navRow(ctx, mx, my, accountsY(), ICON_USER, "Accounts", false);
    }

    private void renderTopBar(DrawContext ctx, int mx, int my) {
        int sx = cx(), sy = winY + 8, sw = searchW();
        rrect(ctx, sx, sy, sw, 18, searchFocused ? fieldFocus() : field(), 5);
        icon(ctx, ICON_SEARCH, sx + 6, sy + 5, MUTED);
        boolean placeholder = query.isEmpty() && !searchFocused;
        String shown = placeholder ? "Поиск" : query + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        text(ctx, shown, sx + 18, sy + 5, placeholder ? MUTED : WHITE);

        int b1 = sx + sw + 4, b2 = b1 + 22;
        rrect(ctx, b1, sy, 18, 18, tab == Tab.CONFIGS ? accent() : (in(mx, my, b1, sy, 18, 18) ? cardHover() : field()), 5);
        icon(ctx, ICON_FOLDER, b1 + 6, sy + 6, WHITE);
        rrect(ctx, b2, sy, 18, 18, tab == Tab.THEMES ? accent() : (in(mx, my, b2, sy, 18, 18) ? cardHover() : field()), 5);
        icon(ctx, ICON_GEAR, b2 + 5, sy + 5, WHITE);
    }

    private int gearX(int x) { return x + cardW() - 14; }
    private int bindX(Module m, int x) { return x + cardW() - (m.getSettings().isEmpty() ? 16 : 30); }

    private void renderModules(DrawContext ctx, int mx, int my) {
        List<Module> mods = visible();
        int cw = cardW(), acc = accent();
        ctx.enableScissor(cx(), listTop(), cx() + cw(), listBottom());
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            if (y + CARD_H < listTop() || y > listBottom()) continue;
            boolean hover = inList(mx, my, listTop()) && in(mx, my, x, y, cw, CARD_H);
            boolean on = m.isEnabled();

            if (on) {
                accentRect(ctx, x, y, cw, CARD_H, 5);
                // Frame of an active module: bright rounded outline on the edge + a faint inner one.
                outline(ctx, x, y, cw, CARD_H, 0xE0000000 | (mix(acc, WHITE, 0.8f) & 0xFFFFFF), 5);
                outline(ctx, x + 2, y + 2, cw - 4, CARD_H - 4, 0x38FFFFFF, 3);
            } else cardBox(ctx, x, y, cw, CARD_H, cardLine(), hover ? cardHover() : cardBg(), 5);
            if (on) ctx.fill(x + 4, y + 1, x + cw - 4, y + 2, fa(0x30FFFFFF));

            text(ctx, m.getName(), x + 7, y + 5, on ? WHITE : 0xFFE8E8F0);
            if (!m.getSettings().isEmpty()) icon(ctx, ICON_GEAR, gearX(x), y + 5, on ? WHITE : MUTED);
            int bx = bindX(m, x);
            if (Binds.listening() == m) text(ctx, "...", bx + 9 - textRenderer.getWidth("..."), y + 5, WHITE);
            else if (m.getKey() != -1) {
                String k = "[" + Binds.name(m.getKey()) + "]";
                text(ctx, k, bx + 9 - textRenderer.getWidth(k), y + 5, on ? WHITE : MUTED);
            } else icon(ctx, ICON_LINK, bx, y + 7, on ? WHITE : MUTED);

            List<String> lines = wrap(ModuleInfo.desc(m), cw - 14);
            for (int l = 0; l < lines.size(); l++) {
                text(ctx, lines.get(l), x + 7, y + 17 + l * 9, on ? mix(acc, WHITE, 0.75f) : MUTED);
            }
        }
        ctx.disableScissor();
        if (mods.isEmpty()) text(ctx, query.isEmpty() ? "Здесь пока пусто" : "Ничего не найдено", cx() + 4, listTop() + 6, MUTED);
    }

    private void renderSettings(DrawContext ctx, int mx, int my) {
        Module m = openModule;
        int acc = accent();
        int top = listTop();
        rrect(ctx, cx(), top, 20, 18, in(mx, my, cx(), top, 20, 18) ? cardHover() : cardBg(), 5);
        icon(ctx, ICON_BACK, cx() + 8, top + 5, WHITE);
        text(ctx, m.getName(), cx() + 27, top + 5, WHITE);
        String bind = Binds.listening() == m ? "Нажми любую кнопку..." : "Бинд: " + Binds.name(m.getKey());
        text(ctx, bind, cx() + cw() - 4 - textRenderer.getWidth(bind), top + 5, MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (Setting s : m.getSettings()) {
            if (y + SET_H >= vt && y <= listBottom()) {
                rrect(ctx, cx(), y, cw(), SET_H, cardBg(), 5);
                if (s instanceof BoolSetting b) {
                    text(ctx, b.name, cx() + 8, y + 9, WHITE);
                    int tx = cx() + cw() - 8 - 22, ty = y + 8;
                    rrect(ctx, tx, ty, 22, 11, b.get() ? acc : track(), 5);
                    rrect(ctx, b.get() ? tx + 12 : tx + 1, ty + 1, 9, 9, WHITE, 4);
                } else if (s instanceof NumberSetting n) {
                    text(ctx, n.name, cx() + 8, y + 4, WHITE);
                    String v = n.label() != null ? n.label() : String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
                    text(ctx, v, cx() + cw() - 8 - textRenderer.getWidth(v), y + 4, MUTED);
                    int trackX = cx() + 8, trackW = cw() - 16, ty = y + SET_H - 8;
                    int fillW = (int) (trackW * (n.get() - n.min) / (n.max - n.min));
                    rrect(ctx, trackX, ty, trackW, 3, track(), 1);
                    rrect(ctx, trackX, ty, Math.max(2, fillW), 3, acc, 1);
                    rrect(ctx, trackX + fillW - 3, ty - 2, 6, 7, WHITE, 2);
                }
            }
            y += SET_H + 4;
        }
        ctx.disableScissor();
        if (m.getSettings().isEmpty()) text(ctx, "У этого модуля нет настроек", cx() + 4, vt + 6, MUTED);
    }

    private void renderConfigs(DrawContext ctx, int mx, int my) {
        int top = listTop(), acc = accent();
        rrect(ctx, cx(), top, 86, 18, in(mx, my, cx(), top, 86, 18) ? acc : cardBg(), 5);
        text(ctx, "Сохранить", cx() + 43 - textRenderer.getWidth("Сохранить") / 2, top + 5, WHITE);
        rrect(ctx, cx() + 92, top, 60, 18, in(mx, my, cx() + 92, top, 60, 18) ? acc : cardBg(), 5);
        text(ctx, "Новый", cx() + 122 - textRenderer.getWidth("Новый") / 2, top + 5, WHITE);
        String cur = "Текущий: " + Config.currentName();
        text(ctx, cur, cx() + cw() - 4 - textRenderer.getWidth(cur), top + 5, MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (String name : cfgs) {
            boolean active = name.equals(Config.currentName());
            boolean hover = inList(mx, my, vt) && in(mx, my, cx(), y, cw(), ROW + 2);
            rrect(ctx, cx(), y, cw(), ROW + 2, active ? mix(acc, 0xFF000000, 0.45f) : (hover ? cardHover() : cardBg()), 5);
            text(ctx, name, cx() + 8, y + 6, WHITE);
            if (active) check(ctx, cx() + cw() - 16, y + 5, WHITE);
            y += ROW + 6;
        }
        ctx.disableScissor();
        if (cfgs.isEmpty()) text(ctx, "Конфигов нет. Нажми «Сохранить».", cx() + 4, vt + 6, MUTED);
        else text(ctx, "ЛКМ загрузить   ПКМ удалить", cx() + cw() - 4 - textRenderer.getWidth("ЛКМ загрузить   ПКМ удалить"), winY + WH - 12, 0xFF5E5E6B);
    }

    private void renderThemes(DrawContext ctx, int mx, int my) {
        Theme[] themes = Theme.values();
        int cw = cardW();
        ctx.enableScissor(cx(), listTop(), cx() + cw(), listBottom());
        for (int i = 0; i < themes.length; i++) {
            Theme t = themes[i];
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            boolean active = t == Theme.current();
            boolean hover = inList(mx, my, listTop()) && in(mx, my, x, y, cw, CARD_H);
            cardBox(ctx, x, y, cw, CARD_H, active ? t.accent() : cardLine(), hover ? cardHover() : cardBg(), 5);
            gradRect(ctx, x + 6, y + 6, 24, 24, 6, t, 0f, 1f, 255);
            text(ctx, t.label, x + 38, y + 14, WHITE);
            if (active) check(ctx, x + cw - 14, y + 15, WHITE);
        }
        ctx.disableScissor();
    }

    // ------------------------------------------------------------------ input

    private void openSettings(Module m) {
        if (m.getSettings().isEmpty()) return;
        openModule = m;
        scroll = 0;
    }

    private void selectTab(Tab t) {
        tab = t;
        openModule = null;
        query = "";
        scroll = 0;
        searchFocused = false;
        if (t == Tab.CONFIGS) refreshCfgs();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (animating()) return true;                          // no clicks while the window is moving

        if (!in(mx, my, winX, winY, WW, WH)) {
            searchFocused = false;
            if (btn == 0 && GuiImage.press(mx, my, width, height)) return true;
            return super.mouseClicked(click, doubled);
        }

        // Drag the window by the logo area.
        if (btn == 0 && in(mx, my, winX, winY, SW, 36)) {
            draggingWin = true;
            dragDX = mx - winX;
            dragDY = my - winY;
            return true;
        }

        // Sidebar.
        if (btn == 0) {
            int x = winX + 6, w = SW - 12;
            for (int i = 0; i < cats.size(); i++) {
                if (in(mx, my, x, navY(i), w, ROW)) {
                    selCat = cats.get(i);
                    selectTab(Tab.CATEGORY);
                    return true;
                }
            }
            if (in(mx, my, x, configsY(), w, ROW)) { selectTab(Tab.CONFIGS); return true; }
            if (in(mx, my, x, themesY(), w, ROW)) { selectTab(Tab.THEMES); return true; }
            if (in(mx, my, x, keybindsY(), w, ROW)) { selectTab(Tab.KEYBINDS); return true; }
            if (in(mx, my, x, accountsY(), w, ROW)) { client.setScreen(new AccountsScreen(this)); return true; }
        }

        // Top bar.
        int sx = cx(), sy = winY + 8, sw = searchW();
        if (btn == 0 && in(mx, my, sx, sy, sw, 18)) { searchFocused = true; return true; }
        searchFocused = false;
        int b1 = sx + sw + 4, b2 = b1 + 22;
        if (btn == 0 && in(mx, my, b1, sy, 18, 18)) { selectTab(tab == Tab.CONFIGS ? Tab.CATEGORY : Tab.CONFIGS); return true; }
        if (btn == 0 && in(mx, my, b2, sy, 18, 18)) { selectTab(tab == Tab.THEMES ? Tab.CATEGORY : Tab.THEMES); return true; }

        if (openModule != null) return clickSettings(mx, my, btn);
        if (tab == Tab.CONFIGS) return clickConfigs(mx, my, btn);
        if (tab == Tab.THEMES) return clickThemes(mx, my, btn);
        if (tab == Tab.KEYBINDS) return clickKeybinds(mx, my, btn);
        return clickModules(mx, my, btn);
    }

    private boolean clickModules(double mx, double my, int btn) {
        if (!inList(mx, my, listTop())) return true;
        List<Module> mods = visible();
        int cw = cardW();
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            if (!in(mx, my, x, y, cw, CARD_H)) continue;
            boolean top = my < y + 15;
            if (btn == 0 && top && !m.getSettings().isEmpty() && in(mx, my, gearX(x) - 3, y, 13, 15)) { openSettings(m); return true; }
            if (btn == 0 && top && in(mx, my, bindX(m, x) - 3, y, 16, 15)) { Binds.listen(m); return true; }
            if (btn == 0) m.toggle();
            else if (btn == 1) openSettings(m);
            else if (btn == 2) Binds.listen(m);
            return true;
        }
        return true;
    }

    private boolean clickSettings(double mx, double my, int btn) {
        Module m = openModule;
        int top = listTop();
        if (btn == 0 && in(mx, my, cx(), top, 20, 18)) { openModule = null; scroll = 0; return true; }
        String bind = Binds.listening() == m ? "Нажми любую кнопку..." : "Бинд: " + Binds.name(m.getKey());
        int bw = textRenderer.getWidth(bind);
        if (btn == 0 && in(mx, my, cx() + cw() - 4 - bw - 2, top, bw + 6, 18)) { Binds.listen(m); return true; }

        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (Setting s : m.getSettings()) {
            if (btn == 0 && in(mx, my, cx(), y, cw(), SET_H)) {
                if (s instanceof BoolSetting b) b.toggle();
                else if (s instanceof NumberSetting n) { dragSetting = n; updateSlider(mx); }
                return true;
            }
            y += SET_H + 4;
        }
        return true;
    }

    private boolean clickConfigs(double mx, double my, int btn) {
        int top = listTop();
        if (btn == 0 && in(mx, my, cx(), top, 86, 18)) {
            Config.save(Config.currentName());
            refreshCfgs();
            return true;
        }
        if (btn == 0 && in(mx, my, cx() + 92, top, 60, 18)) {
            int n = 1;
            while (cfgs.contains("cfg" + n)) n++;
            Config.save("cfg" + n);
            refreshCfgs();
            return true;
        }
        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (String name : new ArrayList<>(cfgs)) {
            if (in(mx, my, cx(), y, cw(), ROW + 2)) {
                if (btn == 0) Config.load(name);
                else if (btn == 1) { Config.delete(name); refreshCfgs(); }
                return true;
            }
            y += ROW + 6;
        }
        return true;
    }

    private boolean clickThemes(double mx, double my, int btn) {
        if (btn != 0 || !inList(mx, my, listTop())) return true;
        Theme[] themes = Theme.values();
        int cw = cardW();
        for (int i = 0; i < themes.length; i++) {
            int x = cx() + (i % 2) * (cw + GAP);
            int y = listTop() + (i / 2) * (CARD_H + GAP) - (int) scroll;
            if (in(mx, my, x, y, cw, CARD_H)) { Theme.set(themes[i]); return true; }
        }
        return true;
    }

    private void renderKeybinds(DrawContext ctx, int mx, int my) {
        int top = listTop(), acc = accent();
        boolean lm = Binds.listeningMenu();
        boolean hover = in(mx, my, cx(), top, cw(), 18);
        rrect(ctx, cx(), top, cw(), 18, lm ? acc : (hover ? cardHover() : cardBg()), 5);
        text(ctx, "Клавиша меню", cx() + 8, top + 5, WHITE);
        String mk = lm ? "Нажми любую кнопку..." : "[" + Binds.name(Binds.menuKey()) + "]";
        text(ctx, mk, cx() + cw() - 8 - textRenderer.getWidth(mk), top + 5, lm ? WHITE : MUTED);

        int vt = viewTop();
        ctx.enableScissor(cx(), vt, cx() + cw(), listBottom());
        int y = vt - (int) scroll;
        for (Module m : ModuleManager.all()) {
            if (y + KB_H >= vt && y <= listBottom()) {
                boolean listening = Binds.listening() == m;
                boolean h = inList(mx, my, vt) && in(mx, my, cx(), y, cw(), KB_H);
                rrect(ctx, cx(), y, cw(), KB_H, listening ? acc : (h ? cardHover() : cardBg()), 5);
                text(ctx, m.getName(), cx() + 8, y + 5, WHITE);
                String k = listening ? "Нажми любую кнопку..." : (m.getKey() == -1 ? "none" : "[" + Binds.name(m.getKey()) + "]");
                int col = listening ? WHITE : (m.getKey() == -1 ? 0xFF5E5E6B : mix(acc, WHITE, 0.6f));
                text(ctx, k, cx() + cw() - 8 - textRenderer.getWidth(k), y + 5, col);
            }
            y += KB_H + 4;
        }
        ctx.disableScissor();
    }

    private boolean clickKeybinds(double mx, double my, int btn) {
        int top = listTop();
        if (btn == 0 && in(mx, my, cx(), top, cw(), 18)) { Binds.listenMenu(); return true; }
        int vt = viewTop();
        if (!inList(mx, my, vt)) return true;
        int y = vt - (int) scroll;
        for (Module m : ModuleManager.all()) {
            if (in(mx, my, cx(), y, cw(), KB_H)) {
                if (btn == 0) Binds.listen(m);
                else if (btn == 1) { m.setKey(-1); Binds.save(); }
                return true;
            }
            y += KB_H + 4;
        }
        return true;
    }

    private void updateSlider(double mx) {
        double t = Math.max(0, Math.min(1, (mx - (cx() + 8)) / (cw() - 16)));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (GuiImage.drag(click.x(), click.y(), width, height)) return true;
        if (draggingWin) {
            winX = clamp((int) (click.x() - dragDX), 0, Math.max(0, width - WW));
            winY = clamp((int) (click.y() - dragDY), 0, Math.max(0, height - WH));
            return true;
        }
        if (dragSetting != null) {
            updateSlider(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        GuiImage.release();
        draggingWin = false;
        dragSetting = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (in(mouseX, mouseY, winX + SW, winY, WW - SW, WH)) {
            scroll = Math.max(0, Math.min(scroll - verticalAmount * 14, maxScroll()));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() { return false; }
}
