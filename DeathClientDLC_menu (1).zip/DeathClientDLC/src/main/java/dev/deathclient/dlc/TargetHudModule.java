package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Locale;

/**
 * Target HUD: a card with the target's name, health bar, health, armor and distance. The target is KillAura's,
 * else the entity under the crosshair, else the nearest player in range. It fades in and out and the health bar
 * glides. Drag it with the left mouse button while the chat is open (it shows yourself as a preview then).
 *
 * Styles: Square, Rounded, Glass square, Glass rounded, Image rounded (your own picture in the card:
 * ".thud image <path to png/jpg>", or put config/deathclientdlc/target_hud.png), Neon, Minimal, Pill.
 */
public class TargetHudModule extends Module {
    private static final int SQUARE = 1, ROUNDED = 2, GLASS_SQUARE = 3, GLASS_ROUNDED = 4, IMAGE = 5, NEON = 6, MINIMAL = 7, PILL = 8;

    public final NumberSetting style = add(new NumberSetting("Style", ROUNDED, 1, 8, 1)
            .labels("Square", "Rounded", "Glass square", "Glass rounded", "Image rounded", "Neon", "Minimal", "Pill"));
    public final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.7, 2.0, 0.1));
    public final NumberSetting radius = add(new NumberSetting("Radius", 6, 2, 12, 1));
    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 30, 1));
    public final BoolSetting nearest = add(new BoolSetting("Nearest player", true));
    public final BoolSetting themeBar = add(new BoolSetting("Theme color bar", false));
    public final BoolSetting showArmor = add(new BoolSetting("Armor", true));
    public final BoolSetting showDistance = add(new BoolSetting("Distance", true));
    public final NumberSetting posX = add(new NumberSetting("X", 250, 0, 2000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 150, 0, 1200, 1));

    static final UserPicture PICTURE = new UserPicture("target_hud.png", "custom_target_hud");

    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFB4B7C2;

    private LivingEntity target;            // picked each tick
    private LivingEntity shown;             // what is drawn (kept while fading out)
    private float alpha, shownHp;
    private long lastFrame;

    public TargetHudModule() { super("Target HUD", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        target = pick(c);
    }

    @Override
    protected void onDisable() { target = null; shown = null; alpha = 0f; }

    private LivingEntity pick(MinecraftClient c) {
        KillAuraModule ka = ModuleManager.get(KillAuraModule.class);
        if (ka != null && ka.isEnabled()) {
            LivingEntity t = ka.currentTarget();
            if (t != null && t.isAlive()) return t;
        }
        if (c.targetedEntity instanceof LivingEntity le && le.isAlive() && le != c.player) return le;
        if (!nearest.get() || c.player == null || c.world == null) return null;
        LivingEntity best = null;
        double bestDist = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof PlayerEntity pe) || pe == c.player || !pe.isAlive() || pe.isSpectator()) continue;
            double d = c.player.distanceTo(pe);
            if (d <= bestDist) { bestDist = d; best = pe; }
        }
        return best;
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TargetHudModule m = ModuleManager.get(TargetHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c);
    }

    private static int a(int argb, float f) {
        int al = Math.round(((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, f)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    private static int healthColor(float f) {
        f = Math.max(0f, Math.min(1f, f));
        int r = Math.round(255 * Math.min(1f, 2f * (1f - f)));
        int g = Math.round(255 * Math.min(1f, 2f * f));
        return 0xFF000000 | (r << 16) | (g << 8) | 0x40;
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.1f, (now - lastFrame) / 1.0e9f);
        lastFrame = now;

        boolean preview = target == null && c.currentScreen instanceof ChatScreen;
        LivingEntity t = target != null ? target : (preview ? c.player : null);
        float want = t != null ? 1f : 0f;
        alpha += (want - alpha) * Math.min(1f, dt * 9f);
        if (t != null) {
            if (t != shown) { shown = t; shownHp = t.getHealth(); }
        }
        if (alpha < 0.03f || shown == null) return;
        LivingEntity e = shown;

        float max = Math.max(1f, e.getMaxHealth());
        float hp = Math.max(0f, e.getHealth());
        shownHp += (hp - shownHp) * Math.min(1f, dt * 10f);
        float frac = Math.max(0f, Math.min(1f, shownHp / max));

        var tr = c.textRenderer;
        int st = (int) style.get();
        int acc = Theme.current().accent() | 0xFF000000;
        int r = (int) radius.get();
        String name = e.getName().getString();
        String hpText = String.format(Locale.ROOT, "%.1f", hp);
        float abs = e.getAbsorptionAmount();
        if (abs > 0.05f) hpText += String.format(Locale.ROOT, " +%.0f", abs);
        String dist = String.format(Locale.ROOT, "%.1fm", c.player.distanceTo(e));
        int barCol = themeBar.get() ? acc : healthColor(frac);

        int nameW = tr.getWidth(Fonts.bold(name));
        int w, h;
        if (st == MINIMAL) { w = Math.max(110, nameW + 8); h = 24; }
        else if (st == PILL) { w = Math.max(110, 24 + nameW + 10 + tr.getWidth(hpText) + 10); h = 22; }
        else { w = Math.max(140, 44 + nameW + 8 + (showDistance.get() ? tr.getWidth(dist) + 8 : 0)); h = 44; }

        float s = (float) scale.get();
        int x = (int) posX.get(), y = (int) posY.get();
        HudEdit.track(x, y, Math.round(w * s), Math.round(h * s), (nx, ny) -> { posX.set(nx); posY.set(ny); });

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(s, s);

        // ---- card
        switch (st) {
            case SQUARE -> {
                ctx.fill(0, 0, w, h, a(0xD0101014, alpha));
                ctx.fill(0, h - 1, w, h, a(acc, alpha));
            }
            case ROUNDED, IMAGE -> ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xD0101014, alpha), r);
            case GLASS_SQUARE -> {
                ctx.fill(-1, -1, w + 1, h + 1, a(0x55FFFFFF, alpha));
                ctx.fill(0, 0, w, h, a(ClickGuiScreen.mix(0xFF141824, acc, 0.12f) & 0xFFFFFF | 0x78000000, alpha));
                ctx.fillGradient(0, 0, w, h / 2, a(0x30FFFFFF, alpha), 0x00FFFFFF);
                ctx.fill(2, 1, w - 2, 2, a(0x90FFFFFF, alpha));
            }
            case GLASS_ROUNDED -> {
                ClickGuiScreen.rrect(ctx, -1, -1, w + 2, h + 2, a(0x55FFFFFF, alpha), r + 1);
                ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(ClickGuiScreen.mix(0xFF141824, acc, 0.12f) & 0xFFFFFF | 0x78000000, alpha), r);
                ctx.fillGradient(r, 1, w - r, h / 2, a(0x30FFFFFF, alpha), 0x00FFFFFF);
                ctx.fill(r, 1, w - r, 2, a(0x90FFFFFF, alpha));
            }
            case NEON -> {
                for (int g = 4; g >= 1; g--) ClickGuiScreen.rrect(ctx, -g, -g, w + 2 * g, h + 2 * g, a(acc & 0xFFFFFF | 0x20000000, alpha), r + g);
                ClickGuiScreen.rrect(ctx, -1, -1, w + 2, h + 2, a(acc, alpha), r + 1);
                ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xF00A0A10, alpha), r);
            }
            case PILL -> ClickGuiScreen.rrect(ctx, 0, 0, w, h, a(0xD0101014, alpha), h / 2);
            default -> { }                                                   // Minimal: no card
        }

        // ---- content
        boolean rounded = st == ROUNDED || st == GLASS_ROUNDED || st == IMAGE || st == NEON;
        if (st == MINIMAL) {
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 0, 0, a(WHITE, alpha));
            bar(ctx, 0, 13, w - tr.getWidth(hpText) - 6, 4, frac, barCol, false, alpha);
            Fonts.draw(ctx, tr, hpText, w - tr.getWidth(hpText), 11, a(WHITE, alpha));
        } else if (st == PILL) {
            ClickGuiScreen.rrect(ctx, 3, 3, 16, 16, a(acc, alpha), 8);
            Fonts.drawScaled(ctx, tr, Fonts.bold(initial(name)), 8f, 5f, 1.0f, a(WHITE, alpha));
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 24, 7, a(WHITE, alpha));
            Fonts.draw(ctx, tr, hpText, w - 10 - tr.getWidth(hpText), 7, a(WHITE, alpha));
            ctx.fill(12, h - 3, w - 12, h - 2, a(0x40FFFFFF, alpha));
            ctx.fill(12, h - 3, 12 + Math.round((w - 24) * frac), h - 2, a(barCol, alpha));
        } else {
            // avatar: your own picture (Image rounded), else a tile with the first letter
            if (st == IMAGE && PICTURE.has()) {
                PICTURE.drawSquare(ctx, 6, 6, 32, a(WHITE, alpha));
            } else {
                if (rounded) ClickGuiScreen.rrect(ctx, 6, 6, 32, 32, a(ClickGuiScreen.mix(0xFF1C1C24, acc, 0.55f), alpha), 4);
                else ctx.fill(6, 6, 38, 38, a(ClickGuiScreen.mix(0xFF1C1C24, acc, 0.55f), alpha));
                Fonts.drawScaled(ctx, tr, Fonts.bold(initial(name)), 17f, 16f, 1.8f, a(WHITE, alpha));
            }
            ctx.drawTextWithShadow(tr, Fonts.bold(name), 44, 8, a(WHITE, alpha));
            if (showDistance.get()) Fonts.draw(ctx, tr, dist, w - 6 - tr.getWidth(dist), 8, a(MUTED, alpha));
            String line = "HP " + hpText + (showArmor.get() ? "   AR " + e.getArmor() : "");
            Fonts.draw(ctx, tr, line, 44, 20, a(MUTED, alpha));
            bar(ctx, 44, 32, w - 44 - 6, 6, frac, barCol, rounded, alpha);
        }
        m.popMatrix();
    }

    private static String initial(String name) {
        return name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
    }

    private static void bar(DrawContext ctx, int x, int y, int w, int h, float frac, int col, boolean round, float alpha) {
        int fw = Math.max(0, Math.round(w * frac));
        if (round) {
            ClickGuiScreen.rrect(ctx, x, y, w, h, a(0x50FFFFFF, alpha), h / 2);
            if (fw > 0) ClickGuiScreen.rrect(ctx, x, y, Math.max(fw, h), h, a(col, alpha), h / 2);
        } else {
            ctx.fill(x, y, x + w, y + h, a(0x50FFFFFF, alpha));
            if (fw > 0) ctx.fill(x, y, x + fw, y + h, a(col, alpha));
        }
    }
}
