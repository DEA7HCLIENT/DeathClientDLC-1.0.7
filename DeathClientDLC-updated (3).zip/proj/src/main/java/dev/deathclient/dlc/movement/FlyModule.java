package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * Velocity fly. As "NoClip Fly" it also passes through walls (see Phase): the floor still holds you up, and when you are
 * inside a block with no up / down key pressed you fall instead of hovering; jump (or sneak) flies you out of it.
 * NoClip Fly has the same two modes as NoClip: Singleplayer (the integrated server accepts positions inside blocks) and
 * Multiplayer (only your client moves through blocks; a server that checks movement pulls you back).
 */
public class FlyModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.5, 0.1, 3.0, 0.05));
    public final NumberSetting vertical = add(new NumberSetting("Vertical", 0.4, 0.1, 2.0, 0.05));
    private final boolean noClip;
    /** Only on NoClip Fly (null on plain Fly): Singleplayer / Multiplayer, as in NoClip. */
    public final NumberSetting mode;
    private boolean notified;

    public FlyModule(String name, boolean noClip) {
        super(name, Category.MOVEMENT);
        this.noClip = noClip;
        this.mode = noClip ? add(new NumberSetting("Mode", NoClipModule.SINGLEPLAYER, 1, 2, 1).labels("Singleplayer", "Multiplayer")) : null;
    }

    boolean isNoClip() { return noClip; }

    /** NoClip Fly only: whether its mode is meant for where you are now (a singleplayer world or a server). */
    boolean noClipAllowsHere(MinecraftClient c) {
        if (!noClip) return false;
        return (int) mode.get() == NoClipModule.SINGLEPLAYER ? c.isInSingleplayer() : !c.isInSingleplayer();
    }

    /** True while NoClip Fly is on in Singleplayer mode in a singleplayer world: the integrated server then accepts positions inside blocks. */
    boolean serverNoClip(MinecraftClient c) {
        return noClip && isEnabled() && (int) mode.get() == NoClipModule.SINGLEPLAYER && c.isInSingleplayer();
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (noClip) {
            if (!noClipAllowsHere(c)) {
                if (!notified) {
                    notified = true;
                    c.player.sendMessage(Text.literal("§7[§cDeath Client§7] §f" + getName() + ": режим " + ((int) mode.get() == NoClipModule.SINGLEPLAYER
                            ? "Singleplayer работает только в одиночной игре (для сервера выберите Multiplayer), стены не проходятся."
                            : "Multiplayer рассчитан на сервер (в одиночной игре выберите Singleplayer), стены не проходятся.")), false);
                }
            } else {
                notified = false;
                if ((int) mode.get() == NoClipModule.SINGLEPLAYER) NoClipModule.syncServerPlayer(c, true);   // Multiplayer: nothing is changed on any server
            }
        }
        Vec3d d = Util.inputDir(c, p);
        int dir = (c.options.jumpKey.isPressed() ? 1 : 0) - (c.options.sneakKey.isPressed() ? 1 : 0);
        double vy = dir * vertical.get();
        if (noClip && dir == 0 && Phase.inWall(c, p)) vy = p.getVelocity().y;     // inside a wall: gravity takes over
        p.setVelocity(d.x * speed.get(), vy, d.z * speed.get());
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (noClip && p != null) {
            p.noClip = false;
            NoClipModule.syncServerPlayer(MinecraftClient.getInstance(), false);    // NoClip, if it is on, sets it again on its next tick
        }
    }
}
