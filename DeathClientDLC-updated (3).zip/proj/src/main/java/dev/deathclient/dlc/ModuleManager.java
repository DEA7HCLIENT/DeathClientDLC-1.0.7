package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = List.of(
            // Combat
            new KillAuraModule(),
            new TpAuraModule(),
            new MaceKillerModule(),
            new MaceComboModule(),
            new ElytraMaceModule(),
            new CrystalAuraModule(),
            new AutoExplosionModule(),
            new AutoCrystalModule(),
            new AutoGAppleModule(),
            new ShiftTapModule(),
            new NoFriendDamageModule(),
            new AnchorAuraModule(),
            new AutoCartModule(),
            new XBowModule(),
            new ShieldBreakerModule(),
            new SpearDashModule(),
            new CriticalsModule(),
            new BackTracksModule(),
            new TpBackModule(),
            new NoCooldownModule(),
            new SprintResetModule(),
            new WTapModule(),
            new AutoBlockModule(),
            new GuiAnimationModule(),
            new GuiImageModule(),
            new CustomFontModule(),
            new CustomSkyModule(),
            new CustomFogModule(),
            new TargetHudModule(),
            new HudStyleModule(),
            new TriggerBotModule(),
            new HitboxModule(),
            new CrystalOptimizationModule(),
            new VelocityModule(),
            // Movement
            new SpeedModule(),
            new StrafeModule(),
            new ScaffoldModule(),
            new TargetStrafeModule(),
            new AirJumpModule(),
            new NoWebModule(),
            new FlyModule("Fly", false),
            new NoClipModule(),
            new FlyModule("NoClip Fly", true),
            new SpinModule(),
            new Rotate180Module(),
            new FastPeekModule(),
            // Render
            new EspModule(),
            new GlowEspModule(),
            new BlockEspModule(),
            new FreecamModule(),
            new ChamsModule(),
            new HitColorModule(),
            new NoRenderModule(),
            new AspectRatioModule(),
            new GlintModule(),
            new BlockOverlayModule(),
            new ArmorDurabilityModule(),
            new SeeInvisibleModule(),
            new ViewModelModule(),
            new SwingAnimationModule(),
            new VisualSpinModule(),
            // Visuals
            new PendingModule("Tracers", Category.VISUALS),
            new ArrowsModule(),
            new PendingModule("Line Trails", Category.VISUALS),
            new ArrowTrailsModule(),
            new TargetEspModule(),
            new PetModule(),
            new ZoomModule(),
            new AmbienceModule(),
            new FireFlyModule(),
            new WingsModule(),
            new FigureModule(),
            new NameTagsModule(),
            new DamageNumbersModule(),
            new JumpCircleModule(),
            new ParticlesModule(),
            new ChinaHatModule(),
            new GlassHandModule(),
            new EmotionsModule(),
            new TrailsModule(),
            new FullbrightModule(),
            new FovModule(),
            new KillEffectsModule(),
            // Misc
            new GuiStyleModule(),
            new CustomThemeModule(),
            new GlassMenuModule(),
            new LiquidGlassModule(),
            new ResourcePackModule(),
            new BedWarsHelperModule(),
            new DynamicIslandModule(),
            new KeybindsModule(),
            new VisualClientModule(),
            new CooldownsHudModule(),
            new StaffViewerHudModule(),
            new KeystrokesModule(),
            new EffectsHudModule(),
            new NotificationsModule(),
            new NukerModule(),
            new InfoHudModule(),
            new FriendListHudModule(),
            new CustomModelModule(),
            new CustomHotbarModule(),
            new ClientBadgeModule(),
            new FriendsModule(),
            new OptimizationModule(),
            new ExtraOptimizationModule(),
            new CrosshairModule(),
            new DamageVignetteModule(),
            new HitMarkerModule(),
            new SpeedLinesModule(),
            new CompassHudModule(),
            new ArmorHudModule(),
            new TimeHudModule(),
            new WatermarkModule(),
            // Added from the feature list
            new AutoSprintModule(), new AutoJumpModule(), new NoFallModule(), new SpiderModule(), new GuiMoveModule(),
            new NoSlowModule(), new NoPushModule(), new AutoTotemModule(), new AutoPotionModule(), new ClickPearlModule(),
            new AutoRespawnModule(), new DeathCoordsModule(), new AutoToolModule(), new AutoLeaveModule(),
            new ChestStealerModule(), new MiddleClickFriendModule(), new SaturationViewerModule(),
            new AimAssistModule(), new AntiBotModule(), new InterruptHealingModule(), new ItemReleaseModule(),
            new ProjectileHelperModule(), new ElytraTargetModule(), new AutoSwapModule(),
            new ElytraBoosterModule(), new ElytraMotionModule(), new DragonFlyModule(), new ElytraJumpModule(),
            new ElytraHelperModule(), new BlinkModule(), new AirStuckModule(),
            new JesusModule(), new ParkourModule(), new SafeWalkModule(), new AutoRodModule(), new ComboCounterModule(),
            new AutoReconnectModule(), new ScreenshotModule(), new AutoClickerModule(), new AutoArmorModule(), new StepModule(), new HighJumpModule(),
            new CpsHudModule(), new ItemCounterModule(), new ToggleSneakModule(), new WaypointsModule(), new FreelookModule());

    private ModuleManager() {}

    public static List<Module> all() { return MODULES; }

    /** The modules the menus, lists and chat commands may show: all of them, except what Visual Client hides. */
    public static List<Module> shown() {
        return VisualClientModule.hiding() ? MODULES.stream().filter(m -> !VisualClientModule.hides(m)).toList() : MODULES;
    }

    public static List<Module> of(Category c) {
        return shown().stream().filter(m -> m.getCategory() == c).toList();
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || Unhook.active()) return;
        Config.applyPendingEnabled();
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(client);
    }
}
