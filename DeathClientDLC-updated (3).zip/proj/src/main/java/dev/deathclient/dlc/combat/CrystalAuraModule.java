package dev.deathclient.dlc;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Fully automatic crystal fighting around the nearest player: every cycle it breaks a crystal near the target AND places a
 * new one on obsidian/bedrock next to the target, so crystals go down and blow up on their own, one after another.
 * Crystals are taken from the hotbar, the off hand or (From inventory) anywhere in the inventory, and the hotbar slot you
 * had selected comes back afterwards (Switch back).
 * No damage calculation: it only avoids crystals closer than MIN_SELF_DIST to you.
 */
public class CrystalAuraModule extends Module {
    private static final double MIN_SELF_DIST = 3.0;

    public final NumberSetting targetRange = add(new NumberSetting("Target range", 12, 4, 20, 1));
    public final NumberSetting placeRange = add(new NumberSetting("Place range", 4.5, 2, 6, 0.5));
    public final NumberSetting breakRange = add(new NumberSetting("Break range", 4.5, 2, 6, 0.5));
    public final NumberSetting delay = add(new NumberSetting("Delay", 2, 1, 10, 1));
    public final BoolSetting place = add(new BoolSetting("Place", true));
    public final BoolSetting breakCrystals = add(new BoolSetting("Break", true));
    public final BoolSetting fromInventory = add(new BoolSetting("From inventory", true));
    public final BoolSetting switchBack = add(new BoolSetting("Switch back", true));
    /** None / Silent (server only) / Camera: turn toward the crystal or the placement spot before each action. */
    public final NumberSetting rotation = add(AuraRotation.setting());

    private int ticks;
    private int returnSlot = -1, returnInv = -1, returnHot = -1, returnDelay;

    public CrystalAuraModule() { super("Crystal Aura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null) return;
        if (returnDelay > 0) { returnDelay--; if (returnDelay == 0) giveBack(c, p); }
        if (++ticks < (int) delay.get()) return;
        ticks = 0;
        PlayerEntity target = Util.nearestPlayer(c, targetRange.get());
        if (target == null) return;

        if (breakCrystals.get()) breakOne(c, p, target);
        if (place.get()) placeCrystal(c, p, target);               // in the same cycle: break one, put the next one down
    }

    private void breakOne(MinecraftClient c, ClientPlayerEntity p, PlayerEntity target) {
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity)) continue;
            double d = p.distanceTo(e);
            if (d <= breakRange.get() && d >= MIN_SELF_DIST && e.distanceTo(target) <= 6.0) {
                int rot = (int) rotation.get();
                AuraRotation.face(c, p, e.getBoundingBox().getCenter(), rot);
                c.interactionManager.attackEntity(p, e);
                p.swingHand(Hand.MAIN_HAND);
                AuraRotation.restore(c, p, rot);
                return;
            }
        }
    }

    /** After the crystal went down: the hotbar slot / inventory slot goes back to what it was. */
    private void giveBack(MinecraftClient c, ClientPlayerEntity p) {
        if (returnInv != -1 && returnHot != -1) {
            c.interactionManager.clickSlot(p.playerScreenHandler.syncId, returnInv, returnHot, SlotActionType.SWAP, p);
        }
        if (returnSlot != -1 && p.getInventory().getSelectedSlot() != returnSlot) p.getInventory().setSelectedSlot(returnSlot);
        returnSlot = -1; returnInv = -1; returnHot = -1;
    }

    private void placeCrystal(MinecraftClient c, ClientPlayerEntity p, PlayerEntity target) {
        BlockPos tp = target.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int x = -3; x <= 3; x++) for (int y = -3; y <= 1; y++) for (int z = -3; z <= 3; z++) {
            BlockPos b = tp.add(x, y, z);
            if (!(c.world.getBlockState(b).isOf(Blocks.OBSIDIAN) || c.world.getBlockState(b).isOf(Blocks.BEDROCK))) continue;
            if (!c.world.getBlockState(b.up()).isAir() || !c.world.getBlockState(b.up(2)).isAir()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(b)) > placeRange.get()) continue;
            Vec3d crystal = new Vec3d(b.getX() + 0.5, b.getY() + 1, b.getZ() + 0.5);
            if (Util.pos(p).distanceTo(crystal) < MIN_SELF_DIST) continue;
            Box space = new Box(b.getX(), b.getY() + 1, b.getZ(), b.getX() + 1, b.getY() + 3, b.getZ() + 1);
            if (!c.world.getOtherEntities(null, space).isEmpty()) continue;
            double d = crystal.distanceTo(Util.pos(target));
            if (d < bestD) { bestD = d; best = b; }
        }
        if (best == null) return;

        Hand hand;
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else {
            if (!p.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                int slot = Util.findHotbar(p, Items.END_CRYSTAL);
                if (slot >= 0) {
                    if (switchBack.get() && returnSlot == -1) returnSlot = p.getInventory().getSelectedSlot();
                    p.getInventory().setSelectedSlot(slot);
                } else if (fromInventory.get()) {                                    // none in the hotbar: swap one into the held slot
                    int inv = -1;
                    for (int i = 9; i < 36; i++) if (p.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) { inv = i; break; }
                    if (inv == -1) return;
                    int hot = p.getInventory().getSelectedSlot();
                    c.interactionManager.clickSlot(p.playerScreenHandler.syncId, inv, hot, SlotActionType.SWAP, p);
                    if (switchBack.get()) { returnInv = inv; returnHot = hot; }
                } else {
                    return;
                }
            }
            hand = Hand.MAIN_HAND;
        }
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(best).add(0, 0.5, 0), Direction.UP, best, false);
        int rot = (int) rotation.get();
        AuraRotation.face(c, p, hit.getPos(), rot);
        c.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
        AuraRotation.restore(c, p, rot);
        if (returnSlot != -1 || returnInv != -1) returnDelay = 2;                           // give the slot back in two ticks
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null && c.interactionManager != null) giveBack(c, c.player);
        returnDelay = 0;
    }
}
