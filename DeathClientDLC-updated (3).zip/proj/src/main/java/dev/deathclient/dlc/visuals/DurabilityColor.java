package dev.deathclient.dlc;

/** One colour scale for durability: full = green, half = yellow, nearly broken = red, smoothly in between (hue 120 to 0). */
final class DurabilityColor {
    private DurabilityColor() {}

    /** @param fraction 1 = undamaged, 0 = about to break */
    static int of(float fraction) {
        float f = Math.max(0f, Math.min(1f, fraction));
        return 0xFF000000 | (java.awt.Color.HSBtoRGB(f / 3f, 0.85f, 1f) & 0xFFFFFF);
    }
}
