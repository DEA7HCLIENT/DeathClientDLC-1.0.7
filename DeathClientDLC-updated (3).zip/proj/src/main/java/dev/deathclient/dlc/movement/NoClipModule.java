package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;

/**
 * NoClip: you walk through walls, but the floor still holds you up while you are not inside a block. Inside a block
 * (a wall) you fall down. "Fall in walls" off: you glide through walls at the same height instead of sinking.
 * The rule itself is in Phase (applied by PhaseMixin on every move).
 * <ul>
 *   <li>Singleplayer: also tells the integrated server to accept positions inside blocks, so nothing rolls you back.</li>
 *   <li>Multiplayer: only your own client moves through blocks; the packets are the normal ones, nothing is sent to
 *       make a server accept them. A server that checks movement will pull you back; one that does not lets you through.</li>
 * </ul>
 */
public class NoClipModule extends Module {
    public final NumberSetting mode = add(new NumberSetting("Mode", SINGLEPLAYER, 1, 2, 1).labels("Singleplayer", "Multiplayer"));
    public final BoolSetting fallInWalls = add(new BoolSetting("Fall in walls", true));
    /** Thickest wall (in blocks) you can pass through sideways. 96 means no limit at all. */
    public final NumberSetting maxThickness = add(new NumberSetting("Max wall thickness", 96, 1, 96, 1));

    public static final int SINGLEPLAYER = 1, MULTIPLAYER = 2;

    public NoClipModule() { super("NoClip", Category.MOVEMENT); }

    /** Whether the chosen mode is meant for where you are now (a singleplayer world or a server). */
    public boolean allowsHere(MinecraftClient c) {
        return (int) mode.get() == SINGLEPLAYER ? c.isInSingleplayer() : !c.isInSingleplayer();
    }

    /** True while NoClip is on in a singleplayer world: the integrated server then accepts positions inside blocks. */
    public static boolean serverNoClip() {
        NoClipModule m = ModuleManager.get(NoClipModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m != null && m.isEnabled() && (int) m.mode.get() == SINGLEPLAYER && c.isInSingleplayer()) return true;
        for (Module o : ModuleManager.all()) if (o instanceof FlyModule f && f.serverNoClip(c)) return true;     // NoClip Fly in Singleplayer mode
        return false;
    }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.player == null) return;
        if (!allowsHere(c)) {
            if (!notified) {
                notified = true;
                String hint = (int) mode.get() == SINGLEPLAYER ? "режим Singleplayer работает только в одиночной игре (для сервера выберите Multiplayer)."
                        : "режим Multiplayer рассчитан на сервер (в одиночной игре выберите Singleplayer).";
                c.player.sendMessage(Text.literal("§7[§cDeath Client§7] §fNoClip: " + hint), false);
            }
            return;
        }
        notified = false;
        if ((int) mode.get() == SINGLEPLAYER) syncServerPlayer(c, isEnabled());        // Multiplayer: nothing is changed on any server
    }

    /**
     * In singleplayer the integrated server checks your movement too, and it does not know the client-side noClip
     * flag, so it can roll the player back. Mirror the flag onto the server-side player. Runs on the server thread.
     */
    static void syncServerPlayer(MinecraftClient c, boolean on) {
        var server = c.getServer();
        if (server == null || c.player == null) return;
        var id = c.player.getUuid();
        server.execute(() -> {
            var sp = server.getPlayerManager().getPlayer(id);
            if (sp != null) sp.noClip = on;
        });
    }

    private boolean notified;

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.noClip = false;
        syncServerPlayer(MinecraftClient.getInstance(), false);
    }
}
