package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Spear Dash: with a spear in your hand, the use button (right mouse) held and a player in your line of sight (as far as
 * Max range, up to 60 blocks: look at him, you do not have to be within arm's reach), you fly
 * at that player at high speed, jab him, fly back to where you started, and do it again, until he is dead, or you let
 * go of the use button, or he gets out of range. When you let go (or he dies) you fly back to the start.
 *
 * The flight is real movement (your velocity is set every tick), not teleporting: the servers' normal movement check
 * lets about 10 blocks per tick pass, so keep Speed below that. The spear's own charge attack hits along the line you
 * look, so you turn to the target on the way there (Rotation: None / Silent / Camera, see AuraRotation).
 * "Auto jab" also hits him once on arrival. Not checked against any server's anti-cheat.
 */
public class SpearDashModule extends Module {
    private static final int IDLE = 0, TO = 1, BACK = 2;

    /** Blocks per tick; 2.5 is about 50 blocks per second. */
    public final NumberSetting speed = add(new NumberSetting("Speed", 2.5, 0.5, 90.0, 0.25));
    /** How close you fly to the target before turning back. */
    public final NumberSetting stopDistance = add(new NumberSetting("Hit distance", 2.0, 1.0, 8.0, 0.25));
    /** The dash stops if the target is farther than this from you. */
    public final NumberSetting maxRange = add(new NumberSetting("Max range", 30, 10, 60, 1));
    /** How far past the hitbox your look may miss and still count as looking at the player (helps at 30 blocks). */
    public final NumberSetting aimTolerance = add(new NumberSetting("Aim tolerance", 0.5, 0.0, 2.0, 0.1));
    /** Only players you can see: a block between you and him means he is not picked. */
    public final BoolSetting wallCheck = add(new BoolSetting("Wall check", true));
    public final NumberSetting rotation = add(AuraRotation.setting());
    public final BoolSetting autoJab = add(new BoolSetting("Auto jab", true));
    /** Fly back to where you started when it ends. */
    public final BoolSetting returnToStart = add(new BoolSetting("Return to start", true));
    public final BoolSetting noFall = add(new BoolSetting("No fall damage", true));
    /** Ticks to rest at the start before the next dash. */
    public final NumberSetting pause = add(new NumberSetting("Pause", 0, 0, 10, 1));

    private int state = IDLE, rest, stuck;
    private boolean ending;
    private Vec3d origin;
    private PlayerEntity target;

    public SpearDashModule() { super("Spear Dash", Category.COMBAT); }

    /** A spear of any material: the item id ends with "_spear". */
    private static boolean isSpear(ItemStack stack) {
        return !stack.isEmpty() && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear");
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) {
            AuraRotation.restore(c, c.player, (int) rotation.get());
            c.player.setVelocity(Vec3d.ZERO);
        }
        reset();
    }

    private void reset() {
        state = IDLE;
        ending = false;
        target = null;
        origin = null;
        stuck = 0;
        rest = 0;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.interactionManager == null || c.currentScreen != null) return;
        boolean armed = isSpear(p.getMainHandStack()) && c.options.useKey.isPressed();

        switch (state) {
            case IDLE -> {
                if (!armed) return;
                PlayerEntity e = lookedAt(c, p);
                if (e == null) return;
                target = e;
                origin = p.getEntityPos();
                ending = false;
                stuck = 0;
                state = TO;
            }
            case TO -> {
                if (!armed || !valid(p, target)) { beginEnd(c, p); return; }
                dashTo(c, p);
            }
            default -> {                                                        // BACK
                if (!ending && (!armed || !valid(p, target))) ending = true;
                flyBack(c, p);
            }
        }
    }

    /** The nearest player your view points at, within Max range (not only the one in arm's reach); null if none. */
    private PlayerEntity lookedAt(MinecraftClient c, ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        double range = maxRange.get();
        PlayerEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (PlayerEntity e : c.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator() || Friends.skip(e)) continue;
            double d = p.distanceTo(e);
            if (d > range || d >= bestD) continue;
            if (!Rotations.rayHits(eye, p.getYaw(), p.getPitch(), e.getBoundingBox(), range, aimTolerance.get())) continue;
            if (wallCheck.get() && blocked(c, p, eye, e.getBoundingBox().getCenter())) continue;
            best = e;
            bestD = d;
        }
        return best;
    }

    private static boolean blocked(MinecraftClient c, ClientPlayerEntity p, Vec3d from, Vec3d to) {
        BlockHitResult hit = c.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        return hit.getType() != HitResult.Type.MISS;
    }

    private boolean valid(ClientPlayerEntity p, PlayerEntity t) {
        return t != null && t.isAlive() && p.distanceTo(t) <= maxRange.get();
    }

    private void beginEnd(MinecraftClient c, ClientPlayerEntity p) {
        ending = true;
        AuraRotation.restore(c, p, (int) rotation.get());
        if (returnToStart.get() && origin != null) state = BACK; else { p.setVelocity(Vec3d.ZERO); reset(); }
    }

    // ------------------------------------------------------------------ the flight

    /** Towards the target at full speed; at the hit distance: jab and turn back. */
    private void dashTo(MinecraftClient c, ClientPlayerEntity p) {
        int rot = (int) rotation.get();
        AuraRotation.face(c, p, target.getBoundingBox().getCenter(), rot);        // the spear hits along your look
        Vec3d to = target.getEntityPos().subtract(p.getEntityPos());
        double dist = to.length();
        double hit = stopDistance.get();
        if (dist <= hit + 0.3) {                                                  // arrived
            if (autoJab.get() && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                c.interactionManager.attackEntity(p, target);
                p.swingHand(Hand.MAIN_HAND);
            }
            AuraRotation.restore(c, p, rot);
            state = BACK;
            stuck = 0;
            rest = (int) pause.get();
            return;
        }
        fly(p, to.normalize().multiply(Math.min(speed.get(), dist - hit)));
    }

    /** Back to where the dash started; then the next dash, if the use button is still held and he is alive. */
    private void flyBack(MinecraftClient c, ClientPlayerEntity p) {
        Vec3d to = origin.subtract(p.getEntityPos());
        double dist = to.length();
        if (dist <= 0.5) {                                                        // home
            p.setVelocity(Vec3d.ZERO);
            if (ending) { reset(); return; }
            if (rest > 0) { rest--; return; }
            state = TO;
            stuck = 0;
            return;
        }
        fly(p, to.normalize().multiply(Math.min(speed.get(), dist)));
    }

    /** Sets the velocity for the next tick; gives up if something blocks the way for a second. */
    private void fly(ClientPlayerEntity p, Vec3d v) {
        p.setVelocity(v);
        if (noFall.get()) p.fallDistance = 0;
        if (p.horizontalCollision || p.verticalCollision) {
            if (++stuck > 20) { p.setVelocity(Vec3d.ZERO); reset(); }
        } else stuck = 0;
    }
}
