package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoPushModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NoPush: your own player is not pushed away from other entities (Players) and not carried by water and lava (Water). require = 0: skipped if a method is named differently. */
@Mixin(Entity.class)
public abstract class NoPushMixin {
    @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noPush(Entity other, CallbackInfo ci) {
        if (NoPushModule.players() && (Object) this == MinecraftClient.getInstance().player) ci.cancel();
    }

    @Inject(method = "isPushedByFluids", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noFluidPush(CallbackInfoReturnable<Boolean> cir) {
        if (NoPushModule.water() && (Object) this == MinecraftClient.getInstance().player) cir.setReturnValue(false);
    }
}
