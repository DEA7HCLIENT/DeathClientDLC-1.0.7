package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Block Overlay: marks the block you are looking at.
 * <ul>
 *   <li>Mode: outline (the 12 edges), fill (the faces) or both.</li>
 *   <li>Opacity: 0 to 100 percent.</li>
 *   <li>Colour: the theme colour, or your own (Свой цвет + the palette / Red, Green, Blue).</li>
 *   <li>Through walls: off = only the faces and edges turned towards you (like a solid box); on = the whole box including the back.</li>
 * </ul>
 * Drawn as a screen overlay with ScreenProjector, so it needs no render-pipeline hooks (same as ESP).
 */
public class BlockOverlayModule extends Module {
    public final NumberSetting mode = add(new NumberSetting("Mode", 3, 1, 3, 1).labels("Контур", "Заливка", "Оба"));
    public final NumberSetting opacity = add(new NumberSetting("Прозрачность", 60, 0, 100, 5));
    public final BoolSetting throughWalls = add(new BoolSetting("Сквозь стены", false));
    public final BoolSetting customColor = add(new BoolSetting("Свой цвет", false));
    public final ButtonSetting palette = add(new ButtonSetting("Палитра цвета", () -> ColorPickerScreen.open("Block Overlay", ColorPickerScreen.rgb(this.red, this.green, this.blue))));
    public final NumberSetting red = add(new NumberSetting("Red", 160, 0, 255, 5));
    public final NumberSetting green = add(new NumberSetting("Green", 120, 0, 255, 5));
    public final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 5));

    private final ScreenProjector proj = new ScreenProjector();

    public BlockOverlayModule() { super("Block Overlay", Category.RENDER); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        BlockOverlayModule m = ModuleManager.get(BlockOverlayModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        if (!(c.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        BlockState state = c.world.getBlockState(pos);
        var shape = state.getOutlineShape(c.world, pos);
        if (shape.isEmpty()) return;
        Box b = shape.getBoundingBox().offset(pos);

        int alpha = (int) Math.round(opacity.get() * 2.55);
        if (alpha <= 0) return;
        int rgb = customColor.get() ? ((int) red.get() << 16) | ((int) green.get() << 8) | (int) blue.get() : Theme.current().accent() & 0xFFFFFF;
        int md = (int) mode.get();                                   // 1 outline, 2 fill, 3 both

        proj.begin(c, delta);
        Vec3d eye = proj.eye();
        // vis[axis][side]: that face of the box looks at the camera (side 0 = the min side)
        boolean all = throughWalls.get();
        boolean[][] vis = {
                {all || eye.x < b.minX, all || eye.x > b.maxX},
                {all || eye.y < b.minY, all || eye.y > b.maxY},
                {all || eye.z < b.minZ, all || eye.z > b.maxZ}};

        double[][] p = new double[8][];                              // corners: bit 0 = x, bit 1 = y, bit 2 = z (1 = max)
        for (int i = 0; i < 8; i++) {
            Vec3d w = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (proj.project(w)) p[i] = new double[]{proj.out[0], proj.out[1]};
        }

        if (md == 2 || md == 3) {
            int fillA = (int) Math.round(alpha * (md == 3 ? 0.4 : 0.8));
            int col = (Math.min(255, fillA) << 24) | rgb;
            int[][][] faces = {                                       // [axis][side] -> the 4 corners in loop order
                    {{0, 2, 6, 4}, {1, 3, 7, 5}},
                    {{0, 1, 5, 4}, {2, 3, 7, 6}},
                    {{0, 1, 3, 2}, {4, 5, 7, 6}}};
            for (int axis = 0; axis < 3; axis++) {
                for (int side = 0; side < 2; side++) {
                    if (!vis[axis][side]) continue;
                    int[] f = faces[axis][side];
                    if (p[f[0]] == null || p[f[1]] == null || p[f[2]] == null || p[f[3]] == null) continue;
                    QuadFill.quad(ctx, p[f[0]], p[f[1]], p[f[2]], p[f[3]], col);
                }
            }
        }
        if (md == 1 || md == 3) {
            int col = (Math.min(255, alpha) << 24) | rgb;
            double[] seg = new double[4];
            for (int i = 0; i < 8; i++) {
                for (int axis = 0; axis < 3; axis++) {
                    if ((i & (1 << axis)) != 0) continue;             // each edge once, from its min end
                    int j = i | (1 << axis);
                    // the two faces that share this edge sit on the other two axes, on the side of corner i
                    int a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
                    boolean visible = vis[a1][(i >> a1) & 1] || vis[a2][(i >> a2) & 1];
                    if (!visible) continue;
                    Vec3d wa = corner(b, i), wb = corner(b, j);
                    if (proj.segment(wa, wb, seg)) {
                        EspModule.line(ctx, (int) Math.round(seg[0]), (int) Math.round(seg[1]), (int) Math.round(seg[2]), (int) Math.round(seg[3]), 1, col);
                    }
                }
            }
        }
    }

    private static Vec3d corner(Box b, int i) {
        return new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
    }
}
