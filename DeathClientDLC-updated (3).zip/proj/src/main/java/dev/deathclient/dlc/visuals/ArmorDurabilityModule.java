package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Armor Durability: shows the armour other players wear, coloured by how worn it is. Each piece sits in a tinted slot with
 * a bar and (optionally) the percentage, all in one smooth scale: green = whole, yellow = half worn, red = about to
 * break. Above the player or in a column beside him. Drawn as an overlay at the projected position (see ScreenProjector).
 */
public class ArmorDurabilityModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 4));
    public final NumberSetting maxPlayers = add(new NumberSetting("Max players", 12, 1, 40, 1));
    public final NumberSetting layout = add(new NumberSetting("Layout", 1, 1, 2, 1).labels("Сверху", "Сбоку"));
    public final BoolSetting tinted = add(new BoolSetting("Цветная подложка", true));
    public final BoolSetting percent = add(new BoolSetting("Проценты", true));
    public final BoolSetting bar = add(new BoolSetting("Полоска", true));

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final ScreenProjector proj = new ScreenProjector();

    public ArmorDurabilityModule() { super("Armor Durability", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        ArmorDurabilityModule m = ModuleManager.get(ArmorDurabilityModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tick.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        List<PlayerEntity> near = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e instanceof PlayerEntity pl && pl != c.player && pl.isAlive() && !pl.isSpectator() && c.player.distanceTo(pl) <= range.get()) near.add(pl);
        }
        near.sort(Comparator.comparingDouble(c.player::distanceTo));
        int shown = 0;
        boolean above = (int) layout.get() == 1;
        for (PlayerEntity pl : near) {
            if (shown >= maxPlayers.get()) break;
            List<ItemStack> pieces = new ArrayList<>();
            for (EquipmentSlot s : SLOTS) {
                ItemStack st = pl.getEquippedStack(s);
                if (!st.isEmpty()) pieces.add(st);
            }
            if (pieces.isEmpty()) continue;
            // above: over the head (higher than the Name Tags tag so both can be on); beside: at chest height, to the right
            Vec3d at = pl.getLerpedPos(delta).add(0, above ? pl.getHeight() + 1.0 : pl.getHeight() * 0.85, 0);
            if (!proj.project(at)) continue;
            int x = (int) proj.out[0], y = (int) proj.out[1];
            shown++;
            if (above) drawRow(ctx, c, pieces, x - pieces.size() * 21 / 2, y - 34);
            else drawColumn(ctx, c, pieces, x + 24, y);
        }
    }

    private void drawRow(DrawContext ctx, MinecraftClient c, List<ItemStack> pieces, int x, int y) {
        for (ItemStack st : pieces) {
            slot(ctx, c, st, x, y, true);
            x += 21;
        }
    }

    private void drawColumn(DrawContext ctx, MinecraftClient c, List<ItemStack> pieces, int x, int y) {
        for (ItemStack st : pieces) {
            slot(ctx, c, st, x, y, false);
            y += 20;
        }
    }

    /** One armour piece: tinted square, icon, bar and percentage in the durability colour. Text is under the icon (row) or beside it (column). */
    private void slot(DrawContext ctx, MinecraftClient c, ItemStack st, int x, int y, boolean textBelow) {
        boolean wears = st.isDamageable() && st.getMaxDamage() > 0;
        float f = wears ? Math.max(0f, 1f - (float) st.getDamage() / st.getMaxDamage()) : 1f;
        int col = DurabilityColor.of(f);
        if (tinted.get()) {
            ctx.fill(x, y, x + 18, y + 18, 0x55000000 | (col & 0xFFFFFF) & 0xFFFFFF | 0x33000000);
            ctx.fill(x, y, x + 18, y + 1, col);                                   // a bright top edge in the same colour
        }
        ctx.drawItem(st, x + 1, y + 1);
        if (bar.get() && wears) {
            ctx.fill(x, y + 17, x + 18, y + 18, 0xA0000000);
            ctx.fill(x, y + 17, x + Math.round(18 * f), y + 18, col);
        }
        if (percent.get() && wears) {
            String t = Math.round(f * 100) + "%";
            if (textBelow) ctx.drawTextWithShadow(c.textRenderer, t, x + 9 - c.textRenderer.getWidth(t) / 2, y + 20, col);
            else ctx.drawTextWithShadow(c.textRenderer, t, x + 21, y + 5, col);
        }
    }
}
