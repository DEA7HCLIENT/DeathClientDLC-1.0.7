package dev.deathclient.dlc;

import java.util.function.Function;

/**
 * NoPush: you are not pushed by
 * <ul>
 *   <li>Players: other players, mobs and boats (collision push),</li>
 *   <li>Blocks: being squeezed out of a block you stand in (the suffocation shove),</li>
 *   <li>Water: the current of water and lava.</li>
 * </ul>
 * Each part is its own switch and only works while the module is on. Hooks: NoPushMixin (players, water),
 * ClientPlayerEntityMixin (blocks).
 */
public class NoPushModule extends Module {
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting blocks = add(new BoolSetting("Blocks", true));
    public final BoolSetting water = add(new BoolSetting("Water", true));

    public NoPushModule() { super("NoPush", Category.MOVEMENT); }

    private static boolean on(Function<NoPushModule, BoolSetting> option) {
        NoPushModule m = ModuleManager.get(NoPushModule.class);
        return m != null && m.isEnabled() && option.apply(m).get();
    }

    public static boolean players() { return on(m -> m.players); }
    public static boolean blocks() { return on(m -> m.blocks); }
    public static boolean water() { return on(m -> m.water); }
}
