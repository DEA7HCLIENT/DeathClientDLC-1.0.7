package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Name Tags: a clean tag above every player. Top row: the items they carry (main hand, off hand, helmet, chestplate,
 * leggings, boots) with a durability bar under each. Below it the name, health and distance, then a health bar and
 * the name of the held item. Friends are green, players who sneak are greyed. Drawn as an overlay at the projected
 * position (the game's own tag stays too).
 */
public class NameTagsModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 48, 8, 128, 4));
    public final BoolSetting health = add(new BoolSetting("Health", true));
    /** Item icons (hands) in the top row; the name of the held item under the tag is "Item name". */
    public final BoolSetting heldItem = add(new BoolSetting("Held item", true));
    public final BoolSetting armor = add(new BoolSetting("Armor", true));
    public final BoolSetting durability = add(new BoolSetting("Durability", true));
    public final BoolSetting distance = add(new BoolSetting("Distance", true));
    public final BoolSetting healthBar = add(new BoolSetting("Health bar", true));
    /** Only the nearest players get a tag, and the item row is drawn only up close: keeps big servers cheap. */
    public final NumberSetting maxTags = add(new NumberSetting("Max tags", 16, 1, 40, 1));
    public final NumberSetting itemRange = add(new NumberSetting("Item range", 24, 4, 64, 4));
    public final BoolSetting itemName = add(new BoolSetting("Item name", true));

    private final ScreenProjector proj = new ScreenProjector();

    public NameTagsModule() { super("Name Tags", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tick) {
        NameTagsModule m = ModuleManager.get(NameTagsModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tick.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        var tr = c.textRenderer;
        List<PlayerEntity> near = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (e instanceof PlayerEntity pl && pl != c.player && pl.isAlive() && !pl.isSpectator() && c.player.distanceTo(pl) <= range.get()) near.add(pl);
        }
        near.sort(java.util.Comparator.comparingDouble(c.player::distanceTo));
        int shown = 0;
        for (PlayerEntity pl : near) {
            if (shown >= maxTags.get()) break;
            double dist = c.player.distanceTo(pl);
            Vec3d at = pl.getLerpedPos(delta).add(0, pl.getHeight() + 0.55, 0);
            if (!proj.project(at)) continue;
            int x = (int) proj.out[0], y = (int) proj.out[1];
            shown++;

            // --- the tag: name, health, distance ---
            String name = pl.getName().getString();
            String hp = health.get() ? "  " + Math.round(pl.getHealth() + pl.getAbsorptionAmount()) : "";
            String dst = distance.get() ? "  " + Math.round(dist) + "m" : "";
            int w = tr.getWidth(name + hp + dst) + 8;
            ctx.fill(x - w / 2, y - 12, x + w / 2, y, 0x90000000);
            int nameCol = Friends.skip(pl) ? 0xFF6BFF8A : pl.isSneaking() ? 0xFFB0B0B0 : 0xFFFFFFFF;
            int tx = x - w / 2 + 4;
            ctx.drawTextWithShadow(tr, name, tx, y - 10, nameCol);
            tx += tr.getWidth(name);
            if (health.get()) {
                float f = Math.max(0f, Math.min(1f, pl.getHealth() / pl.getMaxHealth()));
                int col = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8) | 0x40;
                ctx.drawTextWithShadow(tr, hp, tx, y - 10, col);
                tx += tr.getWidth(hp);
            }
            if (distance.get()) ctx.drawTextWithShadow(tr, dst, tx, y - 10, 0xFF9AA0B8);

            // --- health bar under the tag ---
            int below = y + 1;
            if (healthBar.get()) {
                float f = Math.max(0f, Math.min(1f, pl.getHealth() / pl.getMaxHealth()));
                int col = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8) | 0x40;
                ctx.fill(x - w / 2, y, x + w / 2, y + 2, 0xA0000000);
                ctx.fill(x - w / 2, y, x - w / 2 + Math.round(w * f), y + 2, col);
                below = y + 4;
            }
            if (itemName.get() && !pl.getMainHandStack().isEmpty()) {
                ctx.drawCenteredTextWithShadow(tr, pl.getMainHandStack().getName().getString(), x, below, 0xFFB8B8D0);
            }

            // --- item row above the tag ---
            List<ItemStack> items = new ArrayList<>();
            if (heldItem.get()) { items.add(pl.getMainHandStack()); items.add(pl.getOffHandStack()); }
            if (armor.get()) {
                items.add(pl.getEquippedStack(EquipmentSlot.HEAD));
                items.add(pl.getEquippedStack(EquipmentSlot.CHEST));
                items.add(pl.getEquippedStack(EquipmentSlot.LEGS));
                items.add(pl.getEquippedStack(EquipmentSlot.FEET));
            }
            if (dist > itemRange.get()) continue;
            items.removeIf(ItemStack::isEmpty);
            if (items.isEmpty()) continue;
            int rowW = items.size() * 18, ix = x - rowW / 2, iy = y - 32;
            for (ItemStack s : items) {
                ctx.drawItem(s, ix, iy);
                if (durability.get() && s.isDamageable() && s.getMaxDamage() > 0) {
                    float f = Math.max(0f, 1f - (float) s.getDamage() / s.getMaxDamage());
                    int col = DurabilityColor.of(f);
                    ctx.fill(ix + 1, iy + 15, ix + 15, iy + 16, 0xA0000000);
                    ctx.fill(ix + 1, iy + 15, ix + 1 + Math.round(14 * f), iy + 16, col);
                }
                ix += 18;
            }
        }
    }
}
