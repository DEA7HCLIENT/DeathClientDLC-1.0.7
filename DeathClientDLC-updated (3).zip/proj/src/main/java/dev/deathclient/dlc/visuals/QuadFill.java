package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;

/** A filled convex quad from two triangles (the same scanline fill the China Hat uses). */
final class QuadFill {
    private QuadFill() {}

    static void quad(DrawContext ctx, double[] a, double[] b, double[] c, double[] d, int argb) {
        ChinaHatModule.fillTriangle(ctx, a, b, c, argb);
        ChinaHatModule.fillTriangle(ctx, a, c, d, argb);
    }
}
