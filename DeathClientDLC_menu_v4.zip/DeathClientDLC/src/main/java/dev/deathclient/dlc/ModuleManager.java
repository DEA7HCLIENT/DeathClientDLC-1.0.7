package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = List.of(
            // Combat
            new KillAuraModule(),
            new TpAuraModule(),
            new MaceKillerModule(),
            new ElytraMaceModule(),
            new CrystalAuraModule(),
            new AnchorAuraModule(),
            new AutoCartModule(),
            new GuiAnimationModule(),
            new GuiImageModule(),
            new CustomFontModule(),
            new TargetHudModule(),
            new HudStyleModule(),
            new TriggerBotModule(),
            new HitboxModule(),
            new CrystalOptimizationModule(),
            new VelocityModule(),
            // Movement
            new SpeedModule(),
            new StrafeModule(),
            new ScaffoldModule(),
            new TargetStrafeModule(),
            new FlyModule("Fly", false),
            new NoClipModule(),
            new FlyModule("NoClip Fly", true),
            new SpinModule(),
            // Render
            new EspModule(),
            new GlowEspModule(),
            new BlockEspModule(),
            new FreecamModule(),
            new PendingModule("Chams", Category.RENDER),
            new NoRenderModule(),
            new ViewModelModule(),
            new SwingAnimationModule(),
            new VisualSpinModule(),
            // Visuals
            new PendingModule("Tracers", Category.VISUALS),
            new ArrowsModule(),
            new PendingModule("Line Trails", Category.VISUALS),
            new TargetEspModule(),
            new TargetEspImageModule(),
            new TargetEspGhostModule(),
            new JumpCircleModule(),
            new ChinaHatModule(),
            new GlassHandModule(),
            new EmotionsModule(),
            new TrailsModule(),
            new FullbrightModule(),
            new FovModule(),
            // Misc
            new GuiStyleModule(),
            new CustomThemeModule(),
            new GlassMenuModule(),
            new ResourcePackModule(),
            new BedWarsHelperModule(),
            new DynamicIslandModule(),
            new KeybindsModule(),
            new InfoHudModule(),
            new ClientBadgeModule(),
            new FriendsModule(),
            new OptimizationModule());

    private ModuleManager() {}

    public static List<Module> all() { return MODULES; }

    public static List<Module> of(Category c) {
        return MODULES.stream().filter(m -> m.getCategory() == c).toList();
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module m : MODULES) if (type.isInstance(m)) return type.cast(m);
        return null;
    }

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || Unhook.active()) return;
        Config.applyPendingEnabled();
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(client);
    }
}
