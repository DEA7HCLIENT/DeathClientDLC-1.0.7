package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * FireFly: glowing fireflies (or falling snowflakes) drift through the air around you. They live in the world, so they
 * stay put when you turn your head and parallax like real objects. Drawn on the screen with ScreenProjector (like Particles),
 * so only you see them. Textures: textures/gui/particle/firefly.png and snowflake.png (white, tinted by the colour setting).
 */
public class FireFlyModule extends Module {
    private static final Identifier FIREFLY = Identifier.of("deathclientdlc", "textures/gui/particle/firefly.png");
    private static final Identifier SNOWFLAKE = Identifier.of("deathclientdlc", "textures/gui/particle/snowflake.png");
    private static final int TEX_PX = 256;
    private static final int FLY = 1, SNOW = 2, BOTH = 3;

    public final NumberSetting style = add(new NumberSetting("Style", FLY, 1, 3, 1).labels("Firefly", "Snowflake", "Both"));
    public final NumberSetting amount = add(new NumberSetting("Amount", 40, 5, 200, 5));
    public final NumberSetting radius = add(new NumberSetting("Radius (blocks)", 12, 4, 32, 1));
    public final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.25, 3.0, 0.25));
    public final NumberSetting size = add(new NumberSetting("Size", 0.22, 0.05, 0.8, 0.01));
    public final NumberSetting glow = add(new NumberSetting("Glow", 1.0, 0.0, 2.0, 0.25));
    public final BoolSetting flicker = add(new BoolSetting("Flicker", true));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", false));

    private static final class F {
        Vec3d pos, prev, vel;
        boolean snow;
        float phase, rate, scale, rot, rotSpeed;
        int rgb;
    }

    private final List<F> list = new ArrayList<>();
    private final Random rnd = new Random();
    private final ScreenProjector proj = new ScreenProjector();

    public FireFlyModule() { super("FireFly", Category.VISUALS); }

    @Override
    protected void onDisable() { list.clear(); }

    private boolean wantSnow(int i) {
        int st = (int) style.get();
        return st == SNOW || (st == BOTH && i % 2 == 1);
    }

    private void spawn(F f, Vec3d c, double r, boolean anywhere, int i) {
        f.snow = wantSnow(i);
        double ang = rnd.nextDouble() * Math.PI * 2, d = Math.sqrt(rnd.nextDouble()) * r;
        double y = f.snow ? (anywhere ? rnd.nextDouble() * r * 0.8 : r * 0.8) : -0.5 + rnd.nextDouble() * 4.5;
        f.pos = new Vec3d(c.x + Math.cos(ang) * d, c.y + y, c.z + Math.sin(ang) * d);
        f.prev = f.pos;
        f.vel = Vec3d.ZERO;
        f.phase = rnd.nextFloat() * 6.2832f;
        f.rate = 1.2f + rnd.nextFloat() * 2.0f;
        f.scale = 0.7f + rnd.nextFloat() * 0.7f;
        f.rot = rnd.nextFloat() * 6.2832f;
        f.rotSpeed = (rnd.nextFloat() - 0.5f) * 0.08f;
        Theme th = Theme.current();
        if (themeColor.get()) f.rgb = th.at(rnd.nextFloat()) & 0xFFFFFF;
        else f.rgb = f.snow ? 0xFFFFFF : 0xFFE46B;
    }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null) return;
        Vec3d center = p.getPos();
        double r = radius.get(), sp = speed.get();
        int want = (int) amount.get();
        while (list.size() > want) list.remove(list.size() - 1);
        while (list.size() < want) { F f = new F(); spawn(f, center, r, true, list.size()); list.add(f); }

        for (int i = 0; i < list.size(); i++) {
            F f = list.get(i);
            if (f.snow != wantSnow(i)) { spawn(f, center, r, true, i); continue; }
            f.prev = f.pos;
            if (f.snow) {
                double sway = Math.sin((p.age + f.phase * 10) * 0.05) * 0.012;
                f.vel = new Vec3d(sway * sp, -(0.03 + f.scale * 0.02) * sp, Math.cos((p.age + f.phase * 10) * 0.045) * 0.012 * sp);
            } else {
                // wander: small random pushes, damped, so the path bends smoothly
                Vec3d push = new Vec3d(rnd.nextGaussian() * 0.006, rnd.nextGaussian() * 0.004, rnd.nextGaussian() * 0.006).multiply(sp);
                f.vel = f.vel.multiply(0.94).add(push);
                double max = 0.06 * sp;
                if (f.vel.lengthSquared() > max * max) f.vel = f.vel.normalize().multiply(max);
            }
            f.pos = f.pos.add(f.vel);
            f.rot += f.rotSpeed;
            double dx = f.pos.x - center.x, dz = f.pos.z - center.z;
            boolean out = dx * dx + dz * dz > r * r || f.pos.y < center.y - 2.5 || f.pos.y > center.y + (f.snow ? r : 6);
            if (out) spawn(f, center, r, false, i);
        }
    }

    // ---- drawing ----

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        FireFlyModule m = ModuleManager.get(FireFlyModule.class);
        if (m == null || !m.isEnabled() || m.list.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        double base = size.get(), g = glow.get(), r = radius.get();
        Vec3d pc = c.player.getLerpedPos(delta);
        double time = (c.player.age + delta) * 0.05;
        List<double[]> items = new ArrayList<>(list.size());
        List<F> src = new ArrayList<>(list);
        for (int i = 0; i < src.size(); i++) {
            F f = src.get(i);
            Vec3d at = f.prev.add(f.pos.subtract(f.prev).multiply(delta));
            if (!proj.project(at)) continue;
            double px = base * f.scale * (proj.screenHeight() / 2.0) / (proj.tan * proj.out[2]);
            px = Math.max(3, Math.min(70, px));
            double dx = at.x - pc.x, dz = at.z - pc.z;
            double edge = Math.sqrt(dx * dx + dz * dz) / r;                   // fade out near the border so they don't pop
            double fade = Math.max(0.0, Math.min(1.0, (1.0 - edge) * 4.0));
            double pulse = flicker.get() ? 0.35 + 0.65 * Math.pow(Math.sin(time * f.rate + f.phase), 2) : 1.0;
            items.add(new double[]{proj.out[2], proj.out[0], proj.out[1], px, fade * (f.snow ? 0.9 : pulse), i});
        }
        items.sort((a, b) -> Double.compare(b[0], a[0]));
        var mat = ctx.getMatrices();
        for (double[] it : items) {
            F f = src.get((int) it[5]);
            int a = (int) Math.round(255 * Math.max(0.0, Math.min(1.0, it[4])));
            if (a < 6) continue;
            int sz = (int) Math.round(it[3]);
            Identifier tex = f.snow ? SNOWFLAKE : FIREFLY;
            mat.pushMatrix();
            mat.translate((float) it[1], (float) it[2]);
            if (f.snow) mat.rotate(f.rot);
            if (!f.snow && g > 0) {                                           // soft halo behind the core
                int hs = (int) Math.round(sz * (2.2 + 0.6 * g)), ha = (int) Math.round(a * 0.22 * Math.min(1.5, g));
                if (ha > 3) ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, -hs / 2, -hs / 2, 0f, 0f, hs, hs, TEX_PX, TEX_PX, TEX_PX, TEX_PX, (ha << 24) | f.rgb);
            }
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex, -sz / 2, -sz / 2, 0f, 0f, sz, sz, TEX_PX, TEX_PX, TEX_PX, TEX_PX, (a << 24) | f.rgb);
            mat.popMatrix();
        }
    }
}
