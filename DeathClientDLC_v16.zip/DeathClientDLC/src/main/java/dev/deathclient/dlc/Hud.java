package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

/** Top-center "Dynamic Island" status pill, an active-effects row below it, and a top-right module list. */
final class Hud {
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static final int BG = 0xD0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;
    private static final String[] ROMAN = {"", " I", " II", " III", " IV", " V"};

    /** Toggled by the ".spec" chat command: hides every DeathClientDLC overlay (island, effects, list). */
    static boolean hidden;

    private static final long NOTICE_MS = 1800;

    // Function notice: when a module is switched the island shows its name and ВКЛ / ВЫКЛ for a moment.
    private static final Map<Module, Boolean> seen = new HashMap<>();
    private static Module noticeMod;
    private static boolean noticeOn;
    private static long noticeAt;

    private Hud() {}

    /** Remembers each module's state; a change starts the notice. The first pass only records. */
    private static void trackFunctions() {
        long now = System.currentTimeMillis();
        for (Module m : ModuleManager.all()) {
            boolean on = m.isEnabled();
            Boolean prev = seen.put(m, on);
            if (prev != null && prev != on) {
                noticeMod = m;
                noticeOn = on;
                noticeAt = now;
            }
        }
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        DynamicIslandModule isl = ModuleManager.get(DynamicIslandModule.class);
        if (isl == null || !isl.isEnabled()) return;
        trackFunctions();

        var tr = c.textRenderer;
        int pad = 10, h = 16, logo = 10, gap = 6;
        boolean notice = noticeMod != null && System.currentTimeMillis() - noticeAt < NOTICE_MS;

        String left, right = null;
        if (notice) {
            left = noticeMod.getName();
            right = noticeOn ? "ВКЛ" : "ВЫКЛ";
        } else {
            List<String> seg = new ArrayList<>();
            if (isl.showClock.get()) seg.add(LocalTime.now().format(CLOCK));
            seg.add("Death Client");
            seg.add(Theme.current().label);
            if (isl.showConfig.get()) seg.add(Config.currentName());
            left = String.join("   ", seg);
        }
        int textW = Fonts.width(tr, left) + (right == null ? 0 : 8 + Fonts.width(tr, right));
        int w = pad + logo + gap + textW + pad;
        int sw = c.getWindow().getScaledWidth();
        int x = (sw - w) / 2 + (int) isl.islandX.get(), y = 4 + (int) isl.islandY.get();
        final int islW = w;
        HudEdit.track(x, y, w, h, (nx, ny) -> {
            isl.islandX.set(nx - (sw - islW) / 2);
            isl.islandY.set(ny - 4);
        });
        int accent = Theme.current().accent() | 0xFF000000;
        Shapes.panel(ctx, x, y, w, h, BG);
        Shapes.bottomStrip(ctx, x, y, w, h, Theme.current().accent());
        Ui.drawLogo(ctx, x + pad, y + 3, logo, accent);
        int tx = x + pad + logo + gap;
        Fonts.draw(ctx, tr, left, tx, y + 4, WHITE);
        if (right != null) {
            Fonts.draw(ctx, tr, right, tx + Fonts.width(tr, left) + 8, y + 4, noticeOn ? accent : MUTED);
        }

        if (isl.showEffects.get()) renderEffects(ctx, c, x + w / 2, y + h + 4);
        renderList(ctx, c, isl);
    }

    private static void renderEffects(DrawContext ctx, MinecraftClient c, int cx, int top) {
        var tr = c.textRenderer;
        List<StatusEffectInstance> effects = new ArrayList<>(c.player.getStatusEffects());
        if (effects.isEmpty()) return;
        int y = top;
        for (StatusEffectInstance e : effects) {
            String name = Text.translatable(e.getEffectType().value().getTranslationKey()).getString();
            int amp = Math.max(0, Math.min(e.getAmplifier() + 1, ROMAN.length - 1));
            int seconds = Math.max(0, e.getDuration() / 20);
            String text = name + ROMAN[amp] + "  " + (seconds / 60) + ":" + String.format("%02d", seconds % 60);
            int w = Fonts.width(tr, text) + 12;
            int x = cx - w / 2;
            Shapes.panel(ctx, x, y, w, 12, BG);
            Fonts.draw(ctx, tr, text, x + 6, y + 2, MUTED);
            y += 14;
        }
    }

    private static void renderList(DrawContext ctx, MinecraftClient c, DynamicIslandModule isl) {
        var tr = c.textRenderer;
        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m.isEnabled() && m.getCategory() != Category.MISC) active.add(m);
        active.sort(Comparator.comparingInt((Module m) -> Fonts.width(tr, m.getName())).reversed());
        if (active.isEmpty()) return;
        int y = 4 + (int) isl.listY.get();
        final int baseRight = c.getWindow().getScaledWidth() - 6;
        int right = baseRight + (int) isl.listX.get();
        int accent = Theme.current().accent();
        final int maxW = Fonts.width(tr, active.get(0).getName());     // sorted: the first is the widest
        HudEdit.track(right - maxW, y, maxW, active.size() * 10, (nx, ny) -> {
            isl.listX.set(nx + maxW - baseRight);
            isl.listY.set(ny - 4);
        });
        for (Module m : active) {
            String n = m.getName();
            int w = Fonts.width(tr, n);
            Fonts.draw(ctx, tr, n, right - w, y, accent);
            y += 10;
        }
    }
}
