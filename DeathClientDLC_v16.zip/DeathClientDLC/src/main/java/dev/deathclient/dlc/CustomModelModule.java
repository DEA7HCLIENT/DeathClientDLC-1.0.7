package dev.deathclient.dlc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

/**
 * Custom Model: little models attached to the player's head and back, drawn as shaded shapes on the screen (the same
 * way as China Hat). Bunny: long ears and a round tail. Demon: curved horns, a spade tail and bat wings. White demon:
 * the same shape in white and silver. The body itself is not replaced: this only adds the parts above.
 */
public class CustomModelModule extends Module {
    public final NumberSetting model = add(new NumberSetting("Model", 1, 1, 7, 1)
            .labels("Bunny", "Demon", "White demon", "Cat", "Angel", "Fox", "Dragon"));
    /** Size of the attached parts, percent. */
    public final NumberSetting scale = add(new NumberSetting("Scale", 100, 50, 200, 5));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 95, 10, 100, 5));
    public final BoolSetting thirdPersonOnly = add(new BoolSetting("Third person only", true));

    private final ScreenProjector proj = new ScreenProjector();

    // Per-frame basis: origin of the model, body right (rx, rz) and body forward (fx, fz), and the size factor.
    private double ox, oy, oz, rx, rz, fx, fz, sc;
    private int alphaByte;

    public CustomModelModule() { super("Custom Model", Category.VISUALS); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CustomModelModule m = ModuleManager.get(CustomModelModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p == null || c.world == null || c.options.hudHidden) return;
        boolean freecam = c.getCameraEntity() != null && c.getCameraEntity() != p;
        if (m.thirdPersonOnly.get() && !freecam && c.options.getPerspective().isFirstPerson()) return;
        m.draw(ctx, c, p, tickCounter.getTickProgress(false));
    }

    private static final class Tri {
        final double[] a, b, c;
        final double depth;
        final int color;
        Tri(double[] a, double[] b, double[] c, int color) {
            this.a = a; this.b = b; this.c = c; this.color = color;
            this.depth = (a[2] + b[2] + c[2]) / 3.0;
        }
    }

    private final List<Tri> tris = new ArrayList<>();

    private void draw(DrawContext ctx, MinecraftClient c, ClientPlayerEntity p, float delta) {
        proj.begin(c, delta);
        Vec3d base = p.getLerpedPos(delta);
        double yaw = Math.toRadians(p.getYaw());
        // Body forward and right on the ground (Minecraft: forward = (-sin, cos), right = (-cos, -sin)).
        fx = -Math.sin(yaw); fz = Math.cos(yaw);
        rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        ox = base.x; oy = base.y + p.getHeight() - 0.25; oz = base.z;     // head centre
        sc = scale.get() / 100.0;
        alphaByte = ((int) Math.round(opacity.get() / 100.0 * 255)) << 24;
        tris.clear();

        switch ((int) Math.round(model.get())) {
            case 1 -> bunny();
            case 2 -> demon(false);
            case 3 -> demon(true);
            case 4 -> cat();
            case 5 -> angel();
            case 6 -> fox();
            default -> dragon();
        }

        tris.sort((x, y) -> Double.compare(y.depth, x.depth));                  // far first, near last
        for (Tri t : tris) ChinaHatModule.fillTriangle(ctx, t.a, t.b, t.c, t.color);
    }

    // ------------------------------------------------------------------ geometry

    /** A point in model space (x = right, y = up, z = forward, all in blocks before the size factor), on the screen. */
    private double[] pr(double x, double y, double z) {
        double X = x * sc, Y = y * sc, Z = z * sc;
        Vec3d w = new Vec3d(ox + rx * X + fx * Z, oy + Y, oz + rz * X + fz * Z);
        if (!proj.project(w)) return null;
        return new double[]{proj.out[0], proj.out[1], proj.out[2]};
    }

    private void tri(double[] a, double[] b, double[] c, int rgb) {
        if (a == null || b == null || c == null) return;
        tris.add(new Tri(a, b, c, alphaByte | (rgb & 0xFFFFFF)));
    }

    /** A flat ribbon along the centre line: width across the model's x axis, colour fades from base to tip. */
    private void ribbon(double[][] centre, double[] widths, int base, int tip) {
        for (int i = 0; i + 1 < centre.length; i++) {
            double[] c0 = centre[i], c1 = centre[i + 1];
            double[] l0 = pr(c0[0] - widths[i] / 2, c0[1], c0[2]), r0 = pr(c0[0] + widths[i] / 2, c0[1], c0[2]);
            double[] l1 = pr(c1[0] - widths[i + 1] / 2, c1[1], c1[2]), r1 = pr(c1[0] + widths[i + 1] / 2, c1[1], c1[2]);
            double t = i / (double) (centre.length - 1);
            int col = mix(base, tip, t);
            tri(l0, r0, r1, col);
            tri(l0, r1, l1, col);
        }
    }

    /** A filled polygon from one corner: used for the wings and the spade. */
    private void fan(double[] apex, double[][] rim, int rgb) {
        double[] a = pr(apex[0], apex[1], apex[2]);
        for (int k = 0; k + 1 < rim.length; k++) {
            tri(a, pr(rim[k][0], rim[k][1], rim[k][2]), pr(rim[k + 1][0], rim[k + 1][1], rim[k + 1][2]), rgb);
        }
    }

    private static int mix(int a, int b, double t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    // ------------------------------------------------------------------ models

    /** Bunny: two long ears (white, pink inside) and a round white tail behind. */
    private void bunny() {
        for (int side = -1; side <= 1; side += 2) {
            double[][] ear = {{side * 0.12, 0.18, 0}, {side * 0.14, 0.5, 0}, {side * 0.15, 0.8, 0}, {side * 0.14, 1.0, 0}};
            double[] w = {0.17, 0.16, 0.14, 0.1};
            ribbon(ear, w, 0xEFEFEF, 0xFFFFFF);
            double[][] inner = {{side * 0.12, 0.2, -0.01}, {side * 0.14, 0.5, -0.01}, {side * 0.15, 0.8, -0.01}, {side * 0.14, 0.95, -0.01}};
            ribbon(inner, new double[]{0.08, 0.07, 0.05, 0.03}, 0xFF9AB8, 0xFFC4D6);
        }
        // Round tail: a disc of the tail's colour behind the head.
        int seg = 14;
        double[] centre = pr(0, 0.05, -0.42);
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            tri(centre, pr(Math.cos(a0) * 0.14, 0.05 + Math.sin(a0) * 0.14, -0.42),
                    pr(Math.cos(a1) * 0.14, 0.05 + Math.sin(a1) * 0.14, -0.42), 0xFAFAFA);
        }
    }

    /** Demon (white = false) or White demon (white = true). */
    private void demon(boolean white) {
        int horn = white ? 0xD8DEE8 : 0x5A0A12, hornTip = white ? 0xFFFFFF : 0xE8E2D0;
        int wing = white ? 0xF0F4FF : 0x3A0830, bone = white ? 0xB8C4D8 : 0xB01A2A;
        int tail = white ? 0xE6ECF6 : 0x7A0C18, spade = white ? 0xFFFFFF : 0xB01020;

        // Curved horns.
        for (int side = -1; side <= 1; side += 2) {
            double[][] h = {{side * 0.2, 0.2, 0}, {side * 0.32, 0.42, -0.02}, {side * 0.4, 0.6, -0.04},
                            {side * 0.38, 0.8, -0.02}, {side * 0.3, 0.92, 0.02}};
            ribbon(h, new double[]{0.14, 0.12, 0.09, 0.05, 0.02}, horn, hornTip);
        }

        // Wings: a membrane fanned from the shoulder, with bones to each tip.
        for (int side = -1; side <= 1; side += 2) {
            double[] shoulder = {side * 0.18, 0.6, -0.2};
            double[][] rim = {{side * 0.95, 0.95, -0.35}, {side * 1.0, 0.55, -0.45},
                              {side * 0.7, 0.25, -0.3}, {side * 0.3, 0.3, -0.2}};
            fan(shoulder, new double[][]{rim[0], rim[1], rim[2]}, wing);
            fan(shoulder, new double[][]{rim[0], rim[2], rim[3]}, wing);
            for (double[] tip : rim) {
                ribbon(new double[][]{shoulder, tip}, new double[]{0.03, 0.02}, bone, bone);
            }
        }

        // Tail: a thin curve going back and down, ending in a spade.
        double[][] t = {{0, 0.1, -0.2}, {0, -0.05, -0.5}, {0.08, -0.2, -0.75}, {0.18, -0.3, -0.9}};
        ribbon(t, new double[]{0.08, 0.07, 0.05, 0.03}, tail, tail);
        fan(new double[]{0.18, -0.3, -0.9}, new double[][]{{0.12, -0.36, -0.92}, {0.22, -0.4, -0.94}, {0.3, -0.34, -0.92}}, spade);
    }

    /** Cat: pointed ears with dark insides and a long tail that curls up at the end. */
    private void cat() {
        for (int side = -1; side <= 1; side += 2) {
            ribbon(new double[][]{{side * 0.12, 0.18, 0}, {side * 0.16, 0.45, 0}, {side * 0.14, 0.7, 0}},
                    new double[]{0.2, 0.12, 0.02}, 0xE8902A, 0xFFB366);
            ribbon(new double[][]{{side * 0.12, 0.2, -0.01}, {side * 0.15, 0.42, -0.01}, {side * 0.14, 0.6, -0.01}},
                    new double[]{0.1, 0.06, 0.01}, 0x3A1F12, 0x5C3A22);
        }
        ribbon(new double[][]{{0, 0.0, -0.35}, {0, 0.22, -0.6}, {0, 0.5, -0.7}, {0, 0.75, -0.66}, {0, 0.9, -0.55}},
                new double[]{0.09, 0.08, 0.07, 0.06, 0.05}, 0xE8902A, 0xFFB366);
    }

    /** Angel: a golden halo above the head and white feathered wings. */
    private void angel() {
        int seg = 28;
        double yH = 0.62, rO = 0.3, rI = 0.24;
        for (int i = 0; i < seg; i++) {
            double a0 = i * 2 * Math.PI / seg, a1 = (i + 1) * 2 * Math.PI / seg;
            double[] o0 = pr(Math.cos(a0) * rO, yH, Math.sin(a0) * rO), o1 = pr(Math.cos(a1) * rO, yH, Math.sin(a1) * rO);
            double[] i0 = pr(Math.cos(a0) * rI, yH, Math.sin(a0) * rI), i1 = pr(Math.cos(a1) * rI, yH, Math.sin(a1) * rI);
            tri(i0, o0, o1, 0xFFD84A);
            tri(i0, o1, i1, 0xFFE890);
        }
        for (int side = -1; side <= 1; side += 2) {
            double[] sh = {side * 0.16, 0.7, -0.22};
            double[][] rim = {{side * 0.9, 1.15, -0.3}, {side * 1.05, 0.8, -0.42}, {side * 0.85, 0.45, -0.36}, {side * 0.4, 0.35, -0.22}};
            fan(sh, rim, 0xFFFFFF);
            for (double[] tip : rim) ribbon(new double[][]{sh, tip}, new double[]{0.03, 0.02}, 0xDDEBFF, 0xDDEBFF);
        }
    }

    /** Fox: orange ears with black tips and a big bushy tail with a white tip. */
    private void fox() {
        for (int side = -1; side <= 1; side += 2) {
            ribbon(new double[][]{{side * 0.13, 0.18, 0}, {side * 0.2, 0.6, 0}, {side * 0.14, 0.7, 0}},
                    new double[]{0.2, 0.14, 0.02}, 0xE87A2A, 0xE87A2A);
            ribbon(new double[][]{{side * 0.18, 0.5, 0}, {side * 0.14, 0.7, 0}}, new double[]{0.08, 0.02}, 0x2A1A10, 0x2A1A10);
        }
        ribbon(new double[][]{{0, 0.05, -0.35}, {0, 0.12, -0.7}, {0, 0.3, -0.9}, {0, 0.5, -0.85}},
                new double[]{0.14, 0.22, 0.24, 0.18}, 0xE87A2A, 0xFFFFFF);
    }

    /** Dragon: swept-back gold horns, a green crest and big bat wings. */
    private void dragon() {
        for (int side = -1; side <= 1; side += 2) {
            ribbon(new double[][]{{side * 0.18, 0.3, 0}, {side * 0.26, 0.55, -0.1}, {side * 0.22, 0.75, -0.25}},
                    new double[]{0.1, 0.07, 0.02}, 0x8A6A2A, 0xE8D08A);
        }
        for (int k = 0; k < 4; k++) {
            double z = -0.05 - k * 0.16, y0 = 0.55 - k * 0.05;
            tri(pr(-0.04, y0, z), pr(0.04, y0, z), pr(0, y0 + 0.16, z - 0.04), 0x2E7D4A);
        }
        for (int side = -1; side <= 1; side += 2) {
            double[] sh = {side * 0.2, 0.55, -0.2};
            double[][] rim = {{side * 1.1, 0.95, -0.3}, {side * 1.2, 0.5, -0.5}, {side * 0.9, 0.2, -0.55}, {side * 0.5, 0.25, -0.25}};
            fan(sh, rim, 0x2E7D4A);
            for (double[] tip : rim) ribbon(new double[][]{sh, tip}, new double[]{0.035, 0.02}, 0x1B4D2E, 0x1B4D2E);
        }
    }
}
