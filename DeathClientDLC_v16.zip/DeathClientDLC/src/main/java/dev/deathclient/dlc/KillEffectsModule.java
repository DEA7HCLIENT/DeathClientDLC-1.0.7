package dev.deathclient.dlc;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.Vec3d;

/**
 * Kill Effects: when a living entity dies near you, an animated effect plays where it fell. Everything is drawn as
 * flat 2D pieces on the screen, placed with ScreenProjector, so it needs no render-pipeline hooks. Each effect has a
 * soft glow, moving particles, a fade-in and a fade-out. Only you see them; they do not change gameplay.
 */
public class KillEffectsModule extends Module {
    private static final int DURATION = 70;
    private static final double RANGE = 48;
    private static final ScreenProjector PROJ = new ScreenProjector();

    static final String[] NAMES = {
        "Black hole", "Ghost", "Chains", "Fire pillar", "Soul helix", "Lightning", "Halo",
        "Snowfall", "Shatter", "Totem", "Dragon breath", "Hearts"
    };

    public final NumberSetting effect = add(new NumberSetting("Effect", 0, 0, NAMES.length - 1, 1).labels(NAMES));

    /** A dead entity's last known place. Stored at death, because the body is removed a few seconds later. */
    private static final class Anim {
        final Vec3d pos;
        final double w, h;
        final int start, seed;
        Anim(Vec3d pos, double w, double h, int start, int seed) {
            this.pos = pos; this.w = w; this.h = h; this.start = start; this.seed = seed;
        }
    }

    private int tick;
    private final Map<Integer, Anim> active = new HashMap<>();

    public KillEffectsModule() { super("Kill Effects", Category.RENDER); }

    @Override
    public void onTick(MinecraftClient c) {
        if (c.world == null || c.player == null) { active.clear(); return; }
        tick++;
        for (LivingEntity le : c.world.getEntitiesByClass(LivingEntity.class,
                c.player.getBoundingBox().expand(RANGE), e -> e != c.player)) {
            if (le.getHealth() <= 0 && !active.containsKey(le.getId())) {
                active.put(le.getId(), new Anim(new Vec3d(le.getX(), le.getY(), le.getZ()),
                        le.getWidth(), le.getHeight(), tick, le.getId() * 31 + tick));
            }
        }
        Iterator<Map.Entry<Integer, Anim>> it = active.entrySet().iterator();
        while (it.hasNext()) if (tick - it.next().getValue().start > DURATION) it.remove();
    }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        KillEffectsModule m = ModuleManager.get(KillEffectsModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.world == null) return;
        if (Hud.hidden || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    // ------------------------------------------------------------------ drawing

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        if (active.isEmpty()) return;
        PROJ.begin(c, delta);
        int mode = (int) Math.round(effect.get());
        for (Anim a : active.values()) {
            double age = (tick - a.start) + delta;
            if (age < 0 || age > DURATION) continue;
            double t = age / DURATION;
            switch (mode) {
                case 0 -> blackHole(ctx, a, age, t);
                case 1 -> ghost(ctx, a, age, t);
                case 2 -> chains(ctx, a, age, t);
                case 3 -> firePillar(ctx, a, age, t);
                case 4 -> soulHelix(ctx, a, age, t);
                case 5 -> lightning(ctx, a, age, t);
                case 6 -> halo(ctx, a, age, t);
                case 7 -> snowfall(ctx, a, age, t);
                case 8 -> shatter(ctx, a, age, t);
                case 9 -> totem(ctx, a, age, t);
                case 10 -> dragonBreath(ctx, a, age, t);
                default -> hearts(ctx, a, age, t);
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Pixels per world block at the point's depth. Valid only right after a successful project(). */
    private static double scale() { return (PROJ.screenHeight() / 2.0) / (PROJ.tan * PROJ.out[2]); }

    /** A projected world point: {screenX, screenY, pixelsPerBlock}, or null when it is behind the camera. */
    private static double[] at(Vec3d p) {
        if (!PROJ.project(p)) return null;
        return new double[]{PROJ.out[0], PROJ.out[1], scale()};
    }

    private static int argb(double a, int rgb) {
        int ai = (int) Math.max(0, Math.min(255, Math.round(a)));
        return (ai << 24) | (rgb & 0xFFFFFF);
    }

    private static int mixWhite(int rgb, double k) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return ((int) (r + (255 - r) * k) << 16) | ((int) (g + (255 - g) * k) << 8) | (int) (b + (255 - b) * k);
    }

    /** Smooth in and out: 0..1 over the effect's life. */
    private static double fade(double t) {
        if (t < 0.08) return t / 0.08;
        if (t > 0.7) return Math.max(0, (1 - t) / 0.3);
        return 1;
    }

    private static double easeOut(double t) { double u = 1 - Math.min(1, Math.max(0, t)); return 1 - u * u * u; }

    /** Deterministic pseudo-random 0..1 for (seed, k), so particles keep their place frame to frame. */
    private static double rnd(int seed, int k) {
        double v = Math.sin(seed * 12.9898 + k * 78.233) * 43758.5453;
        return v - Math.floor(v);
    }

    /** A filled disc (rows of ctx.fill). */
    private static void disc(DrawContext ctx, double cx, double cy, double r, int col) {
        if (r < 1) return;
        r = Math.min(r, 160);
        int top = (int) Math.round(cy - r), bot = (int) Math.round(cy + r);
        for (int y = top; y <= bot; y++) {
            double dy = y - cy;
            double half = Math.sqrt(Math.max(0, r * r - dy * dy));
            ctx.fill((int) Math.round(cx - half), y, (int) Math.round(cx + half), y + 1, col);
        }
    }

    /** Soft light: a few discs of falling opacity, brightest in the middle. */
    private static void glow(DrawContext ctx, double x, double y, double r, int rgb, double a) {
        for (int i = 4; i >= 1; i--) disc(ctx, x, y, r * i / 4.0, argb(a / (i + 1.5), rgb));
    }

    /** A dot of the given pixel size centred on (x, y). */
    private static void dot(DrawContext ctx, double x, double y, double size, int col) {
        double r = Math.max(0.5, size / 2);
        if (r <= 1.2) {
            int xi = (int) Math.round(x), yi = (int) Math.round(y);
            ctx.fill(xi, yi, xi + 1, yi + 1, col);
        } else {
            disc(ctx, x, y, r, col);
        }
    }

    /** A line with a soft outer halo and a bright core. */
    private static void glowLine(DrawContext ctx, double x1, double y1, double x2, double y2, double w, int rgb, double a) {
        int core = argb(a, mixWhite(rgb, 0.45));
        lineDots(ctx, x1, y1, x2, y2, w * 3.2, argb(a * 0.12, rgb));
        lineDots(ctx, x1, y1, x2, y2, w * 1.7, argb(a * 0.35, rgb));
        lineDots(ctx, x1, y1, x2, y2, Math.max(1, w), core);
    }

    private static void lineDots(DrawContext ctx, double x1, double y1, double x2, double y2, double thick, int col) {
        double len = Math.hypot(x2 - x1, y2 - y1);
        int steps = Math.max(1, (int) Math.min(300, len));
        for (int i = 0; i <= steps; i++) {
            double f = i / (double) steps;
            dot(ctx, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, thick, col);
        }
    }

    private static final String[] HEART = {"0110110", "1111111", "1111111", "0111110", "0011100", "0001000"};

    // ------------------------------------------------------------------ effects

    /** A violet singularity: it collapses, a glowing accretion disc spins around it, then it fades. */
    private void blackHole(DrawContext ctx, Anim a, double age, double t) {
        double[] p = at(a.pos.add(0, a.h / 2, 0));
        if (p == null) return;
        double k = p[2], f = fade(t);
        double R = k * 0.42 * (1 - 0.55 * easeOut(t));
        glow(ctx, p[0], p[1], R * 3.2, 0x7A3CFF, 150 * f);
        for (int j = 0; j < 42; j++) {
            double ang = age * 0.12 * (1 + (j % 3) * 0.4) + j * Math.PI * 2 / 42;
            double rr = R * (1.3 + (j % 5) * 0.22) * (1 - t * 0.3);
            double x = p[0] + Math.cos(ang) * rr;
            double y = p[1] + Math.sin(ang) * rr * 0.35;
            int rgb = j % 4 == 0 ? 0xFFFFFF : (j % 2 == 0 ? 0xC48BFF : 0x8E4BFF);
            dot(ctx, x, y, Math.max(1.5, k * 0.05), argb(255 * f, rgb));
        }
        disc(ctx, p[0], p[1], R * 1.05, argb(235 * f, 0x08000F));
        disc(ctx, p[0], p[1], R * 0.6, argb(255 * f, 0x000000));
    }

    /** A pale ghost of the body that floats up, with flickering wisps around it. */
    private void ghost(DrawContext ctx, Anim a, double age, double t) {
        double[] feet = at(a.pos);
        if (feet == null) return;
        double k = feet[2], f = fade(t);
        double bw = a.w * k * 1.1, bh = a.h * k;
        double rise = easeOut(t) * a.h * k * 0.9;
        double top = feet[1] - rise - bh, bottom = feet[1] - rise;
        glow(ctx, feet[0], (top + bottom) / 2, Math.max(bw, bh) * 0.9, 0xBFEFFF, 90 * f);
        ctx.fill((int) Math.round(feet[0] - bw / 2), (int) Math.round(top),
                 (int) Math.round(feet[0] + bw / 2), (int) Math.round(bottom), argb(120 * f, 0xD8F0FF));
        ctx.fill((int) Math.round(feet[0] - bw / 2 - 1), (int) Math.round(top - 1),
                 (int) Math.round(feet[0] + bw / 2 + 1), (int) Math.round(top), argb(180 * f, 0xFFFFFF));
        for (int w = 0; w < 8; w++) {
            double ph = age * 0.08 + w * 0.9;
            double x = feet[0] + Math.sin(ph * 1.3 + w) * bw * 0.7;
            double y = top - (w * 3.1 % 6) * k * 0.08 - Math.abs(Math.sin(ph)) * k * 0.2;
            dot(ctx, x, y, Math.max(2, k * 0.06), argb(200 * f, 0xE6F7FF));
        }
    }

    /** Chains that drag the body down into the ground: the links sparkle as they sink. */
    private void chains(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        double sink = easeOut(t) * 2.4;
        for (double off : new double[]{-0.32, 0.32}) {
            double[] prev = null;
            for (double dy = 0; dy <= sink; dy += 0.22) {
                double[] p = at(a.pos.add(off, -dy, 0));
                if (p == null) { prev = null; continue; }
                if (prev != null) glowLine(ctx, prev[0], prev[1], p[0], p[1], Math.max(1.5, p[2] * 0.05), 0xB8B8C4, 255 * f);
                double shine = (Math.sin(age * 0.4 + dy * 9) + 1) / 2;
                if (shine > 0.8) dot(ctx, p[0], p[1], Math.max(2, p[2] * 0.07), argb(255 * f, 0xFFFFFF));
                prev = p;
            }
        }
    }

    /** A column of fire that rises from the ground, sways, and throws embers. */
    private void firePillar(DrawContext ctx, Anim a, double age, double t) {
        double[] base = at(a.pos);
        if (base == null) return;
        double k = base[2], f = fade(t);
        double height = a.h * 2.6 * easeOut(t * 2.5);
        glow(ctx, base[0], base[1], k * 1.4, 0xFF7A1A, 170 * f);
        int steps = 16;
        for (int i = 0; i <= steps; i++) {
            double s = i / (double) steps;
            double[] p = at(a.pos.add(Math.sin(age * 0.25 + s * 6) * 0.12 * s, height * s, 0));
            if (p == null) continue;
            double w = k * 0.55 * (1 - s * 0.75);
            int rgb = s < 0.35 ? 0xFFD15A : (s < 0.7 ? 0xFF8A2A : 0xFF3A1A);
            ctx.fill((int) Math.round(p[0] - w / 2), (int) Math.round(p[1]),
                     (int) Math.round(p[0] + w / 2), (int) Math.round(p[1] + Math.max(2, k * 0.22)),
                     argb(230 * f * (1 - s * 0.5), rgb));
        }
        for (int e = 0; e < 14; e++) {
            double life = (age * 0.03 + rnd(a.seed, e)) % 1.0;
            double x = a.pos.x + (rnd(a.seed, e + 40) - 0.5) * a.w * 2.2;
            double z = a.pos.z + (rnd(a.seed, e + 80) - 0.5) * a.w * 2.2;
            double[] p = at(new Vec3d(x + Math.sin(life * 5 + e) * 0.15, a.pos.y + life * height * 1.1, z));
            if (p != null) dot(ctx, p[0], p[1], Math.max(2, k * 0.08), argb(255 * f * (1 - life), 0xFFC040));
        }
    }

    /** Light blue strands spiral up from the body, with motes flowing along them. */
    private void soulHelix(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        double height = a.h * 1.8 * easeOut(t * 1.6);
        for (int strand = 0; strand < 2; strand++) {
            double phase = strand * Math.PI;
            double[] prev = null;
            for (int i = 0; i <= 36; i++) {
                double s = i / 36.0;
                double ang = age * 0.18 + s * 4 * Math.PI + phase;
                double[] p = at(a.pos.add(Math.cos(ang) * 0.55, height * s, Math.sin(ang) * 0.55));
                if (p != null && prev != null) glowLine(ctx, prev[0], prev[1], p[0], p[1], Math.max(1.5, p[2] * 0.035),
                        s > 0.5 ? 0x7A8BFF : 0x5FE6FF, 255 * f);
                prev = p;
            }
        }
        for (int m = 0; m < 10; m++) {
            double s = (age * 0.02 + m / 10.0) % 1.0;
            double ang = age * 0.18 + s * 4 * Math.PI + (m % 2) * Math.PI;
            double[] p = at(a.pos.add(Math.cos(ang) * 0.55, height * s, Math.sin(ang) * 0.55));
            if (p != null) glow(ctx, p[0], p[1], Math.max(3, p[2] * 0.12), 0xBDF6FF, 180 * f);
        }
    }

    /** A jagged bolt that flashes down onto the body, with a branch or two and a ground flash. */
    private void lightning(DrawContext ctx, Anim a, double age, double t) {
        if (t > 0.3) return;
        double f = fade(t / 0.3) * (1 - t / 0.3) * 1.6;
        int flicker = (int) Math.floor(age / 2.0);
        double[] ground = at(a.pos);
        if (ground != null) glow(ctx, ground[0], ground[1], ground[2] * 1.6, 0xB8E8FF, 200 * Math.min(1, f));
        double[] top = at(a.pos.add(0, a.h + 14, 0));
        double[] bottom = ground == null ? null : new double[]{ground[0], ground[1]};
        if (top == null || bottom == null) return;
        bolt(ctx, top[0], top[1], bottom[0], bottom[1], 4, 0.15 + rnd(a.seed, flicker) * 0.1, a.seed + flicker, f, 0xE0F7FF);
    }

    private void bolt(DrawContext ctx, double x1, double y1, double x2, double y2, int depth, double jitter,
                      int seed, double f, int rgb) {
        if (depth == 0) {
            glowLine(ctx, x1, y1, x2, y2, 2.2, rgb, 255 * Math.min(1, f));
            return;
        }
        double mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
        double len = Math.hypot(x2 - x1, y2 - y1);
        double off = (rnd(seed, depth * 17 + (int) mx) - 0.5) * len * jitter * 2;
        double nx = mx - (y2 - y1) / Math.max(1, len) * off, ny = my + (x2 - x1) / Math.max(1, len) * off;
        bolt(ctx, x1, y1, nx, ny, depth - 1, jitter, seed + 1, f, rgb);
        bolt(ctx, nx, ny, x2, y2, depth - 1, jitter, seed + 2, f, rgb);
        if (depth == 2 && rnd(seed, 99) > 0.5) {
            bolt(ctx, nx, ny, nx + (x2 - x1) * 0.4 + off, ny + (y2 - y1) * 0.4, depth - 2, jitter, seed + 3, f * 0.7, rgb);
        }
    }

    /** A golden ring that spins above the body, with sparkles at its points. */
    private void halo(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        double y = a.h + 0.5 - easeOut(t) * 0.5;
        double r = 0.42 + easeOut(t) * 0.1;
        double spin = age * 0.06;
        double[] prev = null, first = null;
        for (int k = 0; k <= 32; k++) {
            double ang = k * Math.PI / 16 + spin;
            double[] p = at(a.pos.add(Math.cos(ang) * r, y, Math.sin(ang) * r));
            if (p != null && prev != null) glowLine(ctx, prev[0], prev[1], p[0], p[1], Math.max(1.5, p[2] * 0.035), 0xFFD84A, 255 * f);
            if (p != null && first == null) first = p;
            prev = p;
        }
        for (int s = 0; s < 6; s++) {
            double ang = s * Math.PI / 3 + spin;
            double[] p = at(a.pos.add(Math.cos(ang) * r, y, Math.sin(ang) * r));
            if (p == null) continue;
            double tw = (Math.sin(age * 0.5 + s) + 1) / 2;
            glow(ctx, p[0], p[1], Math.max(2, p[2] * 0.12), 0xFFF2A0, 200 * f * tw);
        }
    }

    /** Snowflakes drift down around the body, swaying, and fade out. */
    private void snowfall(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        for (int k = 0; k < 40; k++) {
            double life = (age * 0.025 + rnd(a.seed, k)) % 1.0;
            double ang = rnd(a.seed, k + 100) * Math.PI * 2;
            double rad = a.w * (0.6 + rnd(a.seed, k + 200) * 1.2);
            double y = a.pos.y + a.h * (1.3 - life * 1.5);
            double sway = Math.sin(age * 0.15 + k) * 0.15;
            double[] p = at(new Vec3d(a.pos.x + Math.cos(ang) * rad + sway, y, a.pos.z + Math.sin(ang) * rad));
            if (p == null) continue;
            double size = 2 + rnd(a.seed, k + 300) * 2.5;
            dot(ctx, p[0], p[1], size, argb(230 * f * (1 - life * 0.5), 0xFFFFFF));
            glow(ctx, p[0], p[1], size * 1.2, 0xDDEEFF, 40 * f);
        }
    }

    /** Shards fly out from the body and fall under gravity; each one glows as it flies. */
    private void shatter(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        Vec3d core = a.pos.add(0, a.h / 2, 0);
        for (int k = 0; k < 26; k++) {
            double ux = rnd(a.seed, k) * 2 - 1, uy = rnd(a.seed, k + 50) * 2 - 1, uz = rnd(a.seed, k + 90) * 2 - 1;
            double len = Math.max(0.2, Math.sqrt(ux * ux + uy * uy + uz * uz));
            ux /= len; uy /= len; uz /= len;
            double spread = easeOut(t) * (1.8 + rnd(a.seed, k + 120) * 1.4);
            double drop = t * t * 1.3;
            Vec3d c = core.add(ux * spread, uy * spread - drop, uz * spread);
            double ang = age * 0.2 + k;
            Vec3d d = new Vec3d(Math.cos(ang) * 0.12, Math.sin(ang) * 0.12, 0);
            double[] p0 = at(c.subtract(d)), p1 = at(c.add(d));
            if (p0 != null && p1 != null) {
                int rgb = k % 3 == 0 ? 0xFFE08A : (k % 3 == 1 ? 0xFF6A3C : 0xFF3A6A);
                glowLine(ctx, p0[0], p0[1], p1[0], p1[1], Math.max(2, p1[2] * 0.06), rgb, 255 * f);
            }
        }
    }

    /** Two golden rings expand from the body and a shower of sparks rises from it. */
    private void totem(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        Vec3d core = a.pos.add(0, a.h / 2, 0);
        for (int ring = 0; ring < 2; ring++) {
            double rt = (t + ring * 0.35) % 1.0;
            double r = easeOut(rt) * 1.9;
            double[] prev = null;
            for (int k = 0; k <= 36; k++) {
                double ang = k * Math.PI / 18;
                double[] p = at(core.add(Math.cos(ang) * r, 0, Math.sin(ang) * r));
                if (p != null && prev != null) glowLine(ctx, prev[0], prev[1], p[0], p[1], Math.max(1.5, p[2] * 0.04),
                        ring == 0 ? 0xFFD84A : 0x7CFF6B, 220 * f * (1 - rt));
                prev = p;
            }
        }
        for (int k = 0; k < 40; k++) {
            double life = (age * 0.02 + rnd(a.seed, k) ) % 1.0;
            double ang = k * 2.39 + age * 0.08;
            double r = 0.3 + life * 0.8;
            double[] p = at(core.add(Math.cos(ang) * r, a.h * 0.5 * life * 1.5, Math.sin(ang) * r));
            if (p != null) glow(ctx, p[0], p[1], Math.max(2, p[2] * 0.05), k % 2 == 0 ? 0xFFD84A : 0x7CFF6B, 220 * f * (1 - life));
        }
    }

    /** Violet smoke swirls around the body in a slow cloud and fades out. */
    private void dragonBreath(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        for (int k = 0; k < 7; k++) {
            double ang = age * 0.05 + k * Math.PI * 2 / 7;
            double pulse = (Math.sin(age * 0.1 + k) + 1) / 2;
            double rad = a.w * (1.0 + 0.4 * pulse);
            double[] p = at(a.pos.add(Math.cos(ang) * rad, a.h * (0.35 + 0.35 * Math.sin(age * 0.08 + k)), Math.sin(ang) * rad));
            if (p == null) continue;
            double size = p[2] * (0.4 + 0.15 * pulse);
            glow(ctx, p[0], p[1], size, 0xA040FF, 170 * f);
            dot(ctx, p[0], p[1], Math.max(2, size * 0.35), argb(200 * f, 0xE6C4FF));
        }
    }

    /** Hearts pop up from the body, grow, and float away. */
    private void hearts(DrawContext ctx, Anim a, double age, double t) {
        double f = fade(t);
        for (int h = 0; h < 6; h++) {
            double life = (age * 0.018 + h / 6.0) % 1.0;
            double x = a.pos.x + (rnd(a.seed, h) - 0.5) * a.w * 2.5 + Math.sin(age * 0.1 + h) * 0.15;
            double y = a.pos.y + a.h * 0.6 + easeOut(life) * a.h * 1.4;
            double z = a.pos.z + (rnd(a.seed, h + 20) - 0.5) * a.w * 2.5;
            double[] p = at(new Vec3d(x, y, z));
            if (p == null) continue;
            double s = Math.max(2, Math.round(p[2] * 0.05 * (0.6 + 0.6 * easeOut(life))));
            int col = argb(255 * f * (1 - life * 0.6), 0xFF4D7A);
            for (int row = 0; row < HEART.length; row++) {
                for (int c2 = 0; c2 < HEART[row].length(); c2++) {
                    if (HEART[row].charAt(c2) != '1') continue;
                    int x0 = (int) Math.round(p[0] + (c2 - 3) * s), y0 = (int) Math.round(p[1] + (row - 3) * s);
                    ctx.fill(x0, y0, x0 + (int) s, y0 + (int) s, col);
                }
            }
        }
    }
}
