package dev.deathclient.dlc.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render: HUD pieces drawn by InGameHud. Every hook only cancels the drawing and reads no arguments (except the
 * texture name of the pumpkin / powder snow overlay), so none depends on the method signature.
 * require = 0: a method that is named differently in this build is skipped, the other hooks keep working.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudNoRenderMixin {
    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noVignette(CallbackInfo ci) {
        if (NoRenderModule.vignette()) ci.cancel();
    }

    @Inject(method = "renderPortalOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noPortal(CallbackInfo ci) {
        if (NoRenderModule.portalOverlay()) ci.cancel();
    }

    @Inject(method = "renderSpyglassOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noSpyglass(CallbackInfo ci) {
        if (NoRenderModule.spyglassOverlay()) ci.cancel();
    }

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noScoreboard(CallbackInfo ci) {
        if (NoRenderModule.scoreboard()) ci.cancel();
    }

    @Inject(method = "renderTitleAndSubtitle", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noTitles(CallbackInfo ci) {
        if (NoRenderModule.titles()) ci.cancel();
    }

    /** Custom Hotbar's "Hide vanilla": the game's own hotbar is not drawn. require = 0 keeps the mod working if the name differs. */
    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noVanillaHotbar(CallbackInfo ci) {
        if (dev.deathclient.dlc.CustomHotbarModule.hidesVanilla()) ci.cancel();
    }

    /** The full-screen pictures (pumpkin blur, powder snow outline): dropped when their texture is one of those. */
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noOverlays(CallbackInfo ci, @Local(argsOnly = true) Identifier texture) {
        if (!NoRenderModule.overlays()) return;
        String path = texture.getPath();
        if (path.contains("pumpkinblur") || path.contains("powder_snow")) ci.cancel();
    }
}
