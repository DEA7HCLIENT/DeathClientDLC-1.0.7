package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;

/** Panel backgrounds in the shape chosen by the HUD Style module (shared by the HUD panels and the main menu buttons). */
final class Shapes {
    private Shapes() {}

    /** The chosen shape, or ROUNDED when the module is missing or off. */
    static int shape() {
        HudStyleModule m = ModuleManager.get(HudStyleModule.class);
        return m != null && m.isEnabled() ? (int) m.shape.get() : HudStyleModule.ROUNDED;
    }

    static int radius() {
        HudStyleModule m = ModuleManager.get(HudStyleModule.class);
        return m != null && m.isEnabled() ? (int) m.radius.get() : 4;
    }

    static boolean glass(int shape) { return shape == HudStyleModule.GLASS_SQUARE || shape == HudStyleModule.GLASS_ROUNDED; }

    /** Corner radius for this shape (0 for the square ones). */
    static int corner(int shape) {
        return shape == HudStyleModule.SQUARE || shape == HudStyleModule.GLASS_SQUARE ? 0 : radius();
    }

    /** Translucent glass colour: a lighter tint of the theme colour, see-through enough to show the game behind. */
    static int glassFill(float alpha) {
        int rgb = ClickGuiScreen.mix(0xFF1E2434, Theme.current().accent(), 0.18f) & 0xFFFFFF;
        return (Math.round(0x58 * alpha) << 24) | rgb;
    }

    /** A panel background at x, y, w, h. bg is the flat colour used by the non-glass shapes. */
    static void panel(DrawContext ctx, int x, int y, int w, int h, int bg) {
        int shape = shape(), r = corner(shape);
        if (!glass(shape)) {
            ClickGuiScreen.rrect(ctx, x, y, w, h, bg, r);
            return;
        }
        glassCard(ctx, x, y, w, h, r, 1f);
    }

    private static int withAlpha(int argb, float k) {
        return (Math.round((argb >>> 24) * k) << 24) | (argb & 0xFFFFFF);
    }

    /**
     * Looking through glass: the middle is almost clear with a light tint, the edges catch more light (fresnel),
     * the top-left edge is bright and the bottom-right edge falls off into shade.
     * alpha scales the whole card (1 = full strength).
     */
    static void glassCard(DrawContext ctx, int x, int y, int w, int h, int r, float alpha) {
        r = Math.min(r, Math.min(w, h) / 2);
        // body: a faint tinted layer, so the world behind shows through
        ClickGuiScreen.rrect(ctx, x, y, w, h, withAlpha(glassFill(1f), 0.55f * alpha), r);
        // silver bevel, like a chrome frame around glass: bright outer edge, dark band, light inner line
        if (w > 4 && h > 4) {
            ClickGuiScreen.outline(ctx, x, y, w, h, withAlpha(0xFFD8DEE6, alpha), r);
            ClickGuiScreen.outline(ctx, x + 1, y + 1, w - 2, h - 2, withAlpha(0xFF6E7784, alpha), Math.max(0, r - 1));
            if (w > 6 && h > 6) ClickGuiScreen.outline(ctx, x + 2, y + 2, w - 4, h - 4, withAlpha(0xFFFFFFFF, 0.45f * alpha), Math.max(0, r - 2));
        }
        // sheen from the top, fading out well before the middle
        ctx.fillGradient(x + r, y + 3, x + w - r, y + Math.max(5, h / 2), withAlpha(0xFFFFFFFF, 0.22f * alpha), 0x00FFFFFF);
        // darker band along the bottom edge of the metal
        ctx.fill(x + r, y + h - 2, x + w - r, y + h - 1, withAlpha(0xFF3A414B, 0.6f * alpha));
    }

    /** The coloured strip along the bottom edge of a panel. */
    static void bottomStrip(DrawContext ctx, int x, int y, int w, int h, int color) {
        int r = corner(shape());
        if (r == 0) ctx.fill(x, y + h - 2, x + w, y + h, color);
        else ClickGuiScreen.rect(ctx, x, y + h - 2, w, 2, color, false, true);
    }
}
