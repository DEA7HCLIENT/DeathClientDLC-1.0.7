package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;

/**
 * Custom Hotbar: the nine hotbar slots drawn by the client in one of several styles (Glass, Minimal, Solid, Outline,
 * Pill). Drag it in the open chat (HudEdit). Hide vanilla turns off the game's own hotbar (see InGameHudNoRenderMixin).
 */
public class CustomHotbarModule extends Module {
    public static final int GLASS = 1, MINIMAL = 2, SOLID = 3, OUTLINE = 4, PILL = 5;

    public final NumberSetting style = add(new NumberSetting("Style", GLASS, 1, 5, 1)
            .labels("Glass", "Minimal", "Solid", "Outline", "Pill"));
    public final BoolSetting hideVanilla = add(new BoolSetting("Hide vanilla", true));
    public final BoolSetting showCount = add(new BoolSetting("Item count", true));
    /** Offsets from the centred bottom position, set by dragging in the open chat. */
    public final NumberSetting posX = add(new NumberSetting("X", 0, -1000, 1000, 1));
    public final NumberSetting posY = add(new NumberSetting("Y", 0, -1000, 1000, 1));

    private static final int SLOT = 22, GAP = 2, PAD = 4, SLOTS = 9;
    private static final int DARK = 0xD0101010, SILVER = 0xFFD8DEE6;
    private static final long DOUBLE_MS = 400;

    // Last frame's bar geometry (for clicks in the open chat) and the highlighted slot (-1 = none).
    private static boolean barShown;
    private static int barX, barY, marked = -1, lastSlot = -1;
    private static long lastClick;
    private static boolean wasDown;

    public CustomHotbarModule() { super("Custom Hotbar", Category.MISC, true); }

    /** Used by the mixin: true when the vanilla hotbar must not be drawn. */
    public static boolean hidesVanilla() {
        CustomHotbarModule m = ModuleManager.get(CustomHotbarModule.class);
        return m != null && m.isEnabled() && m.hideVanilla.get();
    }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        CustomHotbarModule m = ModuleManager.get(CustomHotbarModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;

        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        int bw = SLOTS * SLOT + (SLOTS - 1) * GAP + PAD * 2, bh = SLOT + PAD * 2;
        final int baseY = sh - bh - 6;
        final int x = (sw - bw) / 2 + (int) m.posX.get();
        final int y = baseY + (int) m.posY.get();
        barShown = true; barX = x; barY = y;
        HudEdit.track(x, y, bw, bh, (nx, ny) -> {
            m.posX.set(nx - (sw - bw) / 2);
            m.posY.set(ny - baseY);
        });

        int sty = (int) m.style.get();
        int acc = Theme.current().accent() & 0xFFFFFF;
        int selected = c.player.getInventory().getSelectedSlot();

        // bar background
        switch (sty) {
            case GLASS -> Shapes.glassCard(ctx, x, y, bw, bh, 8, 1f);
            case SOLID -> ClickGuiScreen.rrect(ctx, x, y, bw, bh, DARK, 4);
            case OUTLINE -> {
                ClickGuiScreen.rrect(ctx, x, y, bw, bh, DARK, 4);
                ClickGuiScreen.outline(ctx, x, y, bw, bh, SILVER, 4);
            }
            case PILL -> ClickGuiScreen.rrect(ctx, x, y, bw, bh, 0xC0101010, bh / 2);
            default -> { }   // minimal: no background
        }

        for (int i = 0; i < SLOTS; i++) {
            int sx = x + PAD + i * (SLOT + GAP), sy = y + PAD;
            if (i == selected) drawSelected(ctx, sty, sx, sy, acc);
            if (i == marked) {
                ClickGuiScreen.rrect(ctx, sx - 1, sy - 1, SLOT + 2, SLOT + 2, (0x44 << 24) | acc, 6);
                ClickGuiScreen.outline(ctx, sx - 2, sy - 2, SLOT + 4, SLOT + 4, 0xFF000000 | acc, 6);
            }

            ItemStack st = c.player.getInventory().getStack(i);
            if (!st.isEmpty()) {
                ctx.drawItem(st, sx + 3, sy + 3);
                if (m.showCount.get()) ctx.drawStackOverlay(c.textRenderer, st, sx + 3, sy + 3);
            }
        }
    }

    /** Slot under the mouse in the bar drawn this frame, or -1. */
    private static int slotAt(int mx, int my) {
        if (!barShown) return -1;
        int rel = mx - (barX + PAD), ry = my - (barY + PAD);
        if (rel < 0 || ry < 0 || ry >= SLOT) return -1;
        int i = rel / (SLOT + GAP);
        if (i >= SLOTS || rel % (SLOT + GAP) >= SLOT) return -1;
        return i;
    }

    /** Called by HudEdit every frame while the chat is open: a double click on a slot highlights it, again clears it. */
    static void chatUpdate(int mx, int my, boolean down) {
        boolean press = down && !wasDown;
        wasDown = down;
        barShown = barShown && ModuleManager.get(CustomHotbarModule.class) != null;
        if (!press) return;
        int s = slotAt(mx, my);
        if (s < 0) return;
        long now = System.currentTimeMillis();
        if (s == lastSlot && now - lastClick < DOUBLE_MS) {
            marked = marked == s ? -1 : s;
            lastSlot = -1;
        } else {
            lastSlot = s;
            lastClick = now;
        }
    }

    private static void drawSelected(DrawContext ctx, int sty, int sx, int sy, int acc) {
        switch (sty) {
            case GLASS -> ClickGuiScreen.rrect(ctx, sx, sy, SLOT, SLOT, (0x66 << 24) | acc, 5);
            case MINIMAL -> ctx.fill(sx + 2, sy + SLOT + 1, sx + SLOT - 2, sy + SLOT + 3, 0xFF000000 | acc);
            case SOLID -> ClickGuiScreen.rrect(ctx, sx, sy, SLOT, SLOT, (0xA0 << 24) | acc, 4);
            case OUTLINE -> ClickGuiScreen.outline(ctx, sx - 1, sy - 1, SLOT + 2, SLOT + 2, 0xFF000000 | acc, 4);
            case PILL -> ClickGuiScreen.rrect(ctx, sx, sy, SLOT, SLOT, (0x90 << 24) | acc, SLOT / 2);
            default -> { }
        }
    }
}
