package dev.deathclient.dlc;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Shared background and title drawing for the main menu and the ClickGUI. */
final class Ui {
    private static final Identifier BACKGROUND = Identifier.of("deathclientdlc", "textures/gui/background.png");
    private static final Identifier TITLE = Identifier.of("deathclientdlc", "textures/gui/title.png");
    private static final int BG_W = 848, BG_H = 428;
    private static final int TITLE_W = 1100, TITLE_H = 230;
    /** Title width in GUI pixels; height follows the texture ratio. */
    static final int TITLE_GUI_W = 200;
    static final int TITLE_TOP = 14;
    /** Extra picture around the screen so the parallax shift never shows an edge. */
    static final int PAD = 10;

    private Ui() {}

    /** Cover-fit the image to the screen, anchored right so the character stays visible. */
    static void drawBackground(DrawContext ctx, int width, int height) { drawBackground(ctx, width, height, 0, 0); }

    /** Same, drawn a little larger and shifted by ox, oy pixels (the main menu's mouse parallax). */
    static void drawBackground(DrawContext ctx, int width, int height, int ox, int oy) {
        double scale = Math.max((double) width / BG_W, (double) height / BG_H);
        int rw = (int) Math.min(BG_W, Math.ceil(width / scale));
        int rh = (int) Math.min(BG_H, Math.ceil(height / scale));
        float u = BG_W - rw;
        float v = (BG_H - rh) / 2f;
        int m = (ox != 0 || oy != 0) ? PAD : 0;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BACKGROUND, -m + ox, -m + oy, u, v, width + 2 * m, height + 2 * m, rw, rh, BG_W, BG_H);
    }

    static void drawTitle(DrawContext ctx, int width) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TITLE, (width - TITLE_GUI_W) / 2, TITLE_TOP,
                0f, 0f, TITLE_GUI_W, titleHeight(), TITLE_W, TITLE_H, TITLE_W, TITLE_H,
                Theme.current().accent() | 0xFF000000);   // the texture is white: it takes the theme colour
    }

    private static final Identifier LOGO = Identifier.of("deathclientdlc", "textures/gui/logo_d.png");
    private static final int LOGO_PX = 128;

    /** The D logo, square, size in GUI pixels. The texture is white, so the colour (ARGB) tints it. */
    static void drawLogo(DrawContext ctx, int x, int y, int size, int color) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, LOGO, x, y, 0f, 0f, size, size, LOGO_PX, LOGO_PX, LOGO_PX, LOGO_PX, color);
    }

    private static final Identifier HEADING = Identifier.of("deathclientdlc", "textures/gui/heading_line.png");
    private static final int HEADING_W = 2041, HEADING_H = 360;

    /** Height of the heading picture when it is w GUI pixels wide. */
    static int headingHeight(int w) { return Math.round(w * HEADING_H / (float) HEADING_W); }

    /** "DEATH CLIENT" on one line, tinted with the theme colour (the texture is white). */
    static void drawHeading(DrawContext ctx, int x, int y, int w) {
        int color = Theme.current().accent() | 0xFF000000;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, HEADING, x, y, 0f, 0f, w, headingHeight(w), HEADING_W, HEADING_H, HEADING_W, HEADING_H, color);
    }

    static final Identifier CHECK = Identifier.of("deathclientdlc", "textures/gui/check.png");
    static final Identifier CROSS = Identifier.of("deathclientdlc", "textures/gui/cross.png");
    static final Identifier INFO = Identifier.of("deathclientdlc", "textures/gui/info.png");

    /** A 32x32 icon drawn at size x size GUI pixels (colours are the picture's own). */
    static void drawIcon(DrawContext ctx, Identifier id, int x, int y, int size) {
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, size, size, 32, 32, 32, 32, 0xFFFFFFFF);
    }

    static int titleHeight() { return TITLE_GUI_W * TITLE_H / TITLE_W; }

    // Dim over the world instead of vanilla blur: vanilla blur can run only once per frame and crashes when several screens draw it.
    static void drawWorldDim(DrawContext ctx, int width, int height) {
        ctx.fill(0, 0, width, height, 0xB0000000);
    }
}
