package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/**
 * Time HUD: the in-game clock (HH:MM, 24-hour) and the weather (clear, rain, thunder) in a small box.
 * Minecraft day starts at 6:00 in the clock, so world time 0 is 06:00 and 18000 is midnight.
 */
public class TimeHudModule extends Module {
    public final NumberSetting x = add(new NumberSetting("X", 6, 0, 400, 1));
    public final NumberSetting y = add(new NumberSetting("Y", 6, 0, 400, 1));
    public final BoolSetting weather = add(new BoolSetting("Weather", true));
    public final BoolSetting theme = add(new BoolSetting("Theme color", true));

    private static final int BG = 0xB0101010, WHITE = 0xFFFFFFFF, MUTED = 0xFF8A8A94;

    public TimeHudModule() { super("Time HUD", Category.MISC, true); }

    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        TimeHudModule m = ModuleManager.get(TimeHudModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden || c.currentScreen != null) return;
        m.draw(ctx, c);
    }

    /** Clock text from world time: ticks since the day began, shifted so 0 means 06:00. */
    static String clock(long worldTime) {
        long t = Math.floorMod(worldTime, 24000L);
        long totalMinutes = (t * 60 / 1000 + 6 * 60) % (24 * 60);   // 1000 ticks = 1 hour, minutes = t * 60 / 1000
        return String.format("%02d:%02d", totalMinutes / 60, totalMinutes % 60);
    }

    private void draw(DrawContext ctx, MinecraftClient c) {
        int x0 = (int) x.get(), y0 = (int) y.get();
        int accent = (theme.get() ? Theme.current().accent() : 0xFFFFFF) | 0xFF000000;
        String time = clock(c.world.getTimeOfDay());
        String line2 = null;
        if (weather.get()) {
            if (c.world.isThundering()) line2 = "Гроза";
            else if (c.world.isRaining()) line2 = "Дождь";
            else line2 = "Ясно";
        }
        int w = Fonts.width(c.textRenderer, time);
        if (line2 != null) w = Math.max(w, Fonts.width(c.textRenderer, line2));
        int h = line2 == null ? 14 : 26;
        Shapes.panel(ctx, x0, y0, w + 10, h, BG);
        Fonts.draw(ctx, c.textRenderer, time, x0 + 5, y0 + 3, accent);
        if (line2 != null) Fonts.draw(ctx, c.textRenderer, line2, x0 + 5, y0 + 14, MUTED);
    }
}
