package dev.deathclient.dlc;

/** HUD toggle: the top status pill (clock, client name, theme, config) and the active-effects row. */
public class DynamicIslandModule extends Module {
    public final BoolSetting showClock = add(new BoolSetting("Clock", true));
    public final BoolSetting showEffects = add(new BoolSetting("Effects", true));
    public final BoolSetting showConfig = add(new BoolSetting("Config name", true));

    public DynamicIslandModule() { super("Dynamic Island", Category.MISC, true); }
}
