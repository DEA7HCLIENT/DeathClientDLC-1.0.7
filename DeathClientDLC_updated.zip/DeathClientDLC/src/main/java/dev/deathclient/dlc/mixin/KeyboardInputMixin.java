package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.FreecamModule;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While Freecam is on, the real player ignores movement keys (the keys fly the camera instead). */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void deathclientdlc$freecamFreeze(CallbackInfo ci) {
        if (!FreecamModule.active()) return;
        Input self = (Input) (Object) this;
        self.playerInput = PlayerInput.DEFAULT;
        self.movementForward = 0f;
        self.movementSideways = 0f;
    }
}
