package dev.deathclient.dlc;

/** Accent color schemes for the ClickGUI, the main menu and the HUD. */
public enum Theme {
    CRIMSON("Crimson", 0xFFB3202A, 0xFF4A0D12),
    CYAN("Cyan", 0xFF1FA8C9, 0xFF0C4452),
    VIOLET("Violet", 0xFF8A4FD6, 0xFF3A1F5C),
    EMERALD("Emerald", 0xFF2FA86B, 0xFF12452C),
    MONO("Mono", 0xFF8A8A8A, 0xFF3A3A3A);

    public final String label;
    private final int accent, dim;

    Theme(String label, int accent, int dim) {
        this.label = label;
        this.accent = accent;
        this.dim = dim;
    }

    private static int index = 0;

    public static Theme current() { return values()[index]; }

    public static void set(Theme t) { index = t.ordinal(); }

    public static void set(int i) { index = ((i % values().length) + values().length) % values().length; }

    public static void cycle() { set(index + 1); }

    public int accent() { return accent; }
    public int dim() { return dim; }
    public int index() { return ordinal(); }
}
