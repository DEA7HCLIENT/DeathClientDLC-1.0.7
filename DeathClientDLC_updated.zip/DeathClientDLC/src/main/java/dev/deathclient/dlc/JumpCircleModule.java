package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Jump Circle without particles: when you jump, a glowing ring spreads over the ground at your
 * feet. Two or three thin rings with bright arcs swirl around it and fade out. Drawn as a screen
 * overlay with the soft glow sprite (textures/gui/ghost.png), projected onto the ground plane.
 */
public class JumpCircleModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/ghost.png");
    private static final int TEX = 256;
    private static final int MAX_CIRCLES = 6;
    private static final double GROW_SECONDS = 0.30;

    public final NumberSetting radius = add(new NumberSetting("Radius", 1.5, 0.5, 4.0, 0.1));
    public final NumberSetting duration = add(new NumberSetting("Duration", 1.2, 0.4, 3.0, 0.1));
    public final NumberSetting rings = add(new NumberSetting("Rings", 2, 1, 3, 1));
    public final NumberSetting points = add(new NumberSetting("Points", 64, 32, 96, 8));
    public final NumberSetting thickness = add(new NumberSetting("Thickness", 1.0, 0.4, 2.5, 0.1));
    public final NumberSetting spin = add(new NumberSetting("Spin speed", 1.0, 0.0, 3.0, 0.1));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));

    private record Circle(double x, double y, double z, long start) {}

    private final List<Circle> circles = new ArrayList<>();
    private final ScreenProjector proj = new ScreenProjector();
    private boolean wasOnGround;

    public JumpCircleModule() { super("Jump Circle", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        boolean onGround = p.isOnGround();
        if (wasOnGround && !onGround && p.getVelocity().y > 0.1) {
            circles.add(new Circle(p.getX(), p.getY() + 0.03, p.getZ(), System.nanoTime()));
            if (circles.size() > MAX_CIRCLES) circles.remove(0);
        }
        wasOnGround = onGround;
    }

    @Override
    protected void onDisable() { circles.clear(); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        JumpCircleModule m = ModuleManager.get(JumpCircleModule.class);
        if (m == null || !m.isEnabled() || m.circles.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        long now = System.nanoTime();
        double life = duration.get();
        int seg = (int) points.get(), ringCount = (int) rings.get();
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;

        circles.removeIf(ci -> (now - ci.start()) / 1.0e9 > life);

        for (Circle ci : circles) {
            double age = (now - ci.start()) / 1.0e9;
            double t = age / life;                                   // 0..1 over the lifetime
            double grow = Math.min(1.0, age / GROW_SECONDS);
            double ease = 1 - Math.pow(1 - grow, 3);                 // fast start, soft landing
            double fade = Math.min(1.0, age / 0.06) * Math.pow(1 - t, 1.3); // quick fade-in, slow fade-out
            double r0 = radius.get() * ease * (1.0 + 0.12 * t);
            double spinNow = age * 2.6 * spin.get();

            for (int ring = 0; ring < ringCount; ring++) {
                double r = r0 * (1.0 - 0.07 * ring);
                double dir = ring % 2 == 0 ? 1 : -1;               // neighbouring rings swirl opposite ways
                for (int i = 0; i < seg; i++) {
                    double a = 2 * Math.PI * i / seg;
                    // Bright arcs travelling around the ring.
                    double b = 0.5 + 0.5 * Math.sin(a * 3 + dir * spinNow + ring * 2.1);
                    b = b * b;
                    int alpha = (int) Math.round(255 * fade * (0.12 + 0.88 * b) * 0.85);
                    if (alpha < 5) continue;

                    Vec3d w = new Vec3d(ci.x() + Math.cos(a) * r, ci.y() + ring * 0.01, ci.z() + Math.sin(a) * r);
                    if (!proj.project(w)) continue;
                    double world = 0.2 * thickness.get() * (0.6 + 0.4 * b);
                    int h = (int) Math.round(world / (proj.out[2] * proj.tan) * (proj.screenHeight() / 2.0));
                    h = Math.max(2, Math.min(h, 40));
                    int x = (int) Math.round(proj.out[0]) - h, y = (int) Math.round(proj.out[1]) - h;
                    ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, x, y, 0f, 0f,
                            h * 2, h * 2, TEX, TEX, TEX, TEX, (alpha << 24) | rgb);
                }
            }
        }
    }
}
