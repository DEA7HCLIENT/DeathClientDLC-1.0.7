package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Kill Aura: automatically attacks every valid target in reach, no clicking and no aiming needed.
 * <ul>
 *   <li>Rotation 1 = none (attack only), 2 = silent (the server is told where you "look" for the
 *       hit, your own camera never moves), 3 = smooth (the camera eases toward the target).</li>
 *   <li>Reach is measured to the target's hitbox, the way the server measures it.</li>
 *   <li>Normal mode waits for the weapon cooldown; HvH mode hits every tick.</li>
 * </ul>
 */
public class KillAuraModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    /** 1 = none, 2 = silent, 3 = smooth (camera). */
    public final NumberSetting rotation = add(new NumberSetting("Rotation", 2, 1, 3, 1));
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 18, 4, 60, 1));
    public final BoolSetting hvh = add(new BoolSetting("HvH mode", false));
    public final NumberSetting cooldown = add(new NumberSetting("Cooldown", 0.95, 0.0, 1.0, 0.05));
    public final NumberSetting targets = add(new NumberSetting("Targets", 1, 1, 5, 1));
    /** 1 = nearest first, 2 = lowest health first. */
    public final NumberSetting priority = add(new NumberSetting("Priority", 1, 1, 2, 1));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));
    public final BoolSetting inGui = add(new BoolSetting("Attack in GUI", false));

    public KillAuraModule() { super("KillAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (!inGui.get() && c.currentScreen != null) return;
        if (!p.isAlive() || p.isSpectator()) return;

        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (!invisible.get() && le.isInvisible()) continue;
            if (reach(p, le) <= range.get()) list.add(le);
        }
        if (list.isEmpty()) return;

        if ((int) priority.get() == 2) list.sort(Comparator.comparingDouble(LivingEntity::getHealth));
        else list.sort(Comparator.comparingDouble(e -> reach(p, e)));

        int mode = (int) rotation.get();
        LivingEntity primary = list.get(0);
        if (mode == 3) turnToward(p, primary);

        float need = hvh.get() ? 0f : (float) cooldown.get();
        if (p.getAttackCooldownProgress(0.5f) < need) return;

        int count = Math.min(list.size(), (int) targets.get());
        for (int i = 0; i < count; i++) {
            LivingEntity t = list.get(i);
            if (mode == 2) sendLook(c, p, wantYaw(p, t), wantPitch(p, t));   // server sees the aim
            c.interactionManager.attackEntity(p, t);
        }
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        if (mode == 2) sendLook(c, p, p.getYaw(), p.getPitch());             // back to the real view
    }

    /** Distance from the player's eyes to the nearest point of the target's hitbox. */
    private static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        double dx = Math.max(Math.max(b.minX - eye.x, 0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0), eye.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static float wantYaw(ClientPlayerEntity p, Entity t) {
        Vec3d eye = p.getEyePos();
        Vec3d c = t.getBoundingBox().getCenter();
        return (float) (Math.toDegrees(Math.atan2(c.z - eye.z, c.x - eye.x)) - 90.0);
    }

    private static float wantPitch(ClientPlayerEntity p, Entity t) {
        Vec3d eye = p.getEyePos();
        Vec3d c = t.getBoundingBox().getCenter();
        double dx = c.x - eye.x, dz = c.z - eye.z;
        return (float) -Math.toDegrees(Math.atan2(c.y - eye.y, Math.sqrt(dx * dx + dz * dz)));
    }

    private static void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }

    /** Smooth mode: turns the camera at most turnSpeed degrees this tick, the shorter way around. */
    private void turnToward(ClientPlayerEntity p, LivingEntity target) {
        float step = (float) turnSpeed.get();
        float yawDiff = MathHelper.wrapDegrees(wantYaw(p, target) - p.getYaw());
        float pitchDiff = MathHelper.wrapDegrees(wantPitch(p, target) - p.getPitch());
        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }
}
