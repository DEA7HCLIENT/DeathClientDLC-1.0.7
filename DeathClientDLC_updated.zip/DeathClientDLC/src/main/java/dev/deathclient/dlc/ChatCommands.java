package dev.deathclient.dlc;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import java.util.List;

/**
 * Local-only chat commands: typed in the normal chat box, caught before they leave the client.
 *   .bind <module|menu> <key|clear>   .bind list
 *   .cfg save|load|delete <name>      .cfg list
 *   .friend add [name]|remove <name>|list|clear   (add without a name = player under the crosshair)
 *   .spec                             toggles the HUD (island, effects, module list) on/off
 */
final class ChatCommands {
    private ChatCommands() {}

    static void init() {
        ClientSendMessageEvents.ALLOW_CHAT.register(ChatCommands::handle);
    }

    private static boolean handle(String message) {
        if (!message.startsWith(".")) return true;   // not ours: send normally
        String[] a = message.substring(1).trim().split("\\s+");
        String cmd = a.length > 0 ? a[0].toLowerCase() : "";
        switch (cmd) {
            case "bind" -> bind(a);
            case "cfg", "config" -> cfg(a);
            case "spec" -> spec();
            case "friend", "friends", "f" -> friend(a);
            default -> reply("Unknown command. Available: .bind .cfg .friend .spec");
        }
        return false;   // always swallow messages starting with "."
    }

    private static void bind(String[] a) {
        if (a.length == 1) { reply("Usage: .bind <module|menu> <key|clear>  or  .bind list"); return; }
        if (a[1].equalsIgnoreCase("list")) {
            reply("menu: [" + Binds.name(Binds.menuKey()) + "]");
            for (Module m : ModuleManager.all()) {
                if (m.getKey() != -1) reply(m.getName() + ": [" + Binds.name(m.getKey()) + "]");
            }
            return;
        }
        if (a.length < 3) { reply("Usage: .bind <module|menu> <key|clear>"); return; }
        int key = Binds.keyByName(a[2]);
        if (key == -2) { reply("Unknown key: " + a[2]); return; }

        if (a[1].equalsIgnoreCase("menu")) {
            Binds.setMenuKey(key);
            reply("Menu bound to " + Binds.name(key));
            return;
        }
        Module m = find(a[1]);
        if (m == null) { reply("Unknown module: " + a[1]); return; }
        m.setKey(key);
        Binds.save();
        reply(m.getName() + " bound to " + Binds.name(key));
    }

    private static void cfg(String[] a) {
        if (a.length < 2) { reply("Usage: .cfg save|load|delete <name>  or  .cfg list"); return; }
        String sub = a[1].toLowerCase();
        if (sub.equals("list")) {
            List<String> names = Config.list();
            reply(names.isEmpty() ? "No saved configs yet. Current: " + Config.currentName()
                    : "Configs: " + String.join(", ", names) + "  (current: " + Config.currentName() + ")");
            return;
        }
        if (a.length < 3) { reply("Usage: .cfg " + sub + " <name>"); return; }
        String name = a[2];
        switch (sub) {
            case "save" -> { Config.save(name); reply("Saved config: " + name); }
            case "load" -> reply(Config.load(name) ? "Loaded config: " + name : "No such config: " + name);
            case "delete" -> reply(Config.delete(name) ? "Deleted config: " + name : "No such config: " + name);
            default -> reply("Usage: .cfg save|load|delete <name>  or  .cfg list");
        }
    }

    private static void friend(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                String name = a.length > 2 ? a[2] : null;
                if (name == null) {
                    var t = MinecraftClient.getInstance().targetedEntity;
                    if (t instanceof net.minecraft.entity.player.PlayerEntity pe) name = pe.getName().getString();
                }
                if (name == null) { reply("Usage: .friend add <name>  (or look at a player)"); return; }
                reply(Friends.add(name) ? name + " added to friends." : name + " is already a friend.");
            }
            case "remove", "del" -> {
                if (a.length < 3) { reply("Usage: .friend remove <name>"); return; }
                reply(Friends.remove(a[2]) ? a[2] + " removed from friends." : a[2] + " is not a friend.");
            }
            case "clear" -> { Friends.clear(); reply("Friend list cleared."); }
            case "list" -> {
                List<String> l = Friends.list();
                reply(l.isEmpty() ? "No friends yet." : "Friends: " + String.join(", ", l));
            }
            default -> reply("Usage: .friend add [name] | remove <name> | list | clear");
        }
    }

    private static void spec() {
        Hud.hidden = !Hud.hidden;
        reply("Client HUD " + (Hud.hidden ? "hidden" : "shown") + ".");
    }

    /** Exact name match first, otherwise the first module whose name contains the query. */
    private static Module find(String query) {
        Module partial = null;
        for (Module m : ModuleManager.all()) {
            if (m.getName().equalsIgnoreCase(query)) return m;
            if (partial == null && m.getName().toLowerCase().contains(query.toLowerCase())) partial = m;
        }
        return partial;
    }

    private static void reply(String s) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal("§7[§cDeathClient§7] §f" + s), false);
    }
}
