package dev.deathclient.dlc;

import net.minecraft.client.gui.DrawContext;

/** Shared "glass" drawing: a translucent tinted body, a top sheen and a thin rim. Used by the menus and HUD. */
final class Glass {
    private static final int BODY = 0x0B0D14;

    private Glass() {}

    static GlassMenuModule cfg() { return ModuleManager.get(GlassMenuModule.class); }

    /** True when the Glass Menu module is on: the ClickGUI window and main menu buttons use glass. */
    static boolean on() {
        GlassMenuModule g = cfg();
        return g != null && g.isEnabled();
    }

    static boolean buttonsOn() {
        GlassMenuModule g = cfg();
        return g != null && g.isEnabled() && g.buttons.get();
    }

    private static int alpha(double pct) {
        return Math.max(0, Math.min(255, (int) Math.round(pct / 100.0 * 255)));
    }

    /** Frosted window or HUD panel. */
    static void panel(DrawContext ctx, int x, int y, int w, int h, int r, int accent) {
        GlassMenuModule g = cfg();
        double opacity = g != null ? g.opacity.get() : 55;
        double sheen = g != null ? g.sheen.get() : 35;
        boolean accentRim = g == null || g.accentRim.get();
        int rim = accentRim ? (0x66000000 | (accent & 0xFFFFFF)) : 0x44FFFFFF;
        ClickGuiScreen.rrect(ctx, x - 1, y - 1, w + 2, h + 2, rim, r + 1);
        ClickGuiScreen.rrect(ctx, x, y, w, h, (alpha(opacity) << 24) | BODY, r);
        sheenBands(ctx, x, y, w, h, r, alpha(sheen));
        ctx.fill(x + r, y, x + w - r, y + 1, 0x55FFFFFF);          // bright top edge
    }

    /** Glass button: a plain glass body, or the accent color when active / hovered. */
    static void button(DrawContext ctx, int x, int y, int w, int h, boolean active, int accent) {
        GlassMenuModule g = cfg();
        double opacity = g != null ? g.opacity.get() : 55;
        int r = Math.min(5, h / 2);
        int rim = active ? (0x88000000 | (accent & 0xFFFFFF)) : 0x33FFFFFF;
        ClickGuiScreen.rrect(ctx, x - 1, y - 1, w + 2, h + 2, rim, r + 1);
        int body = active ? (0xB0000000 | (accent & 0xFFFFFF)) : ((alpha(opacity) << 24) | BODY);
        ClickGuiScreen.rrect(ctx, x, y, w, h, body, r);
        sheenBands(ctx, x, y, w, h, r, alpha(g != null ? g.sheen.get() : 35));
    }

    /** Six thin bands over the top third, fading down: reads as light on glass. */
    private static void sheenBands(DrawContext ctx, int x, int y, int w, int h, int r, int maxA) {
        if (maxA <= 0 || w <= 2 * r) return;
        int n = 6;
        int bandH = Math.max(1, h / 3 / n);
        for (int i = 0; i < n; i++) {
            int a = Math.max(1, maxA / (n * 2) * (n - i) / n);
            ctx.fill(x + r, y + i * bandH, x + w - r, y + (i + 1) * bandH, (a << 24) | 0xFFFFFF);
        }
    }
}
