package dev.deathclient.dlc;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * First-person swing animation. Mode: Default (vanilla), Swipe (sideways slash), Down (chop down),
 * Custom (your own rotation / offset at the peak of the swing). Duration overrides the swing length
 * (LivingEntityMixin, vanilla is 6 ticks). The matrix is changed by HeldItemRendererMixin.
 */
public class SwingAnimationModule extends Module {
    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 4, 1)
            .labels("Default", "Swipe", "Down", "Custom"));
    public final NumberSetting duration = add(new NumberSetting("Duration", 6, 1, 20, 1));
    // Custom mode: values reached at the peak of the swing (the defaults reproduce the vanilla swing).
    public final NumberSetting rotX = add(new NumberSetting("Custom rot X", -80, -180, 180, 5));
    public final NumberSetting rotY = add(new NumberSetting("Custom rot Y", -20, -180, 180, 5));
    public final NumberSetting rotZ = add(new NumberSetting("Custom rot Z", -20, -180, 180, 5));
    public final NumberSetting moveX = add(new NumberSetting("Custom move X", 0, -0.5, 0.5, 0.01));
    public final NumberSetting moveY = add(new NumberSetting("Custom move Y", 0, -0.5, 0.5, 0.01));
    public final NumberSetting moveZ = add(new NumberSetting("Custom move Z", 0, -0.5, 0.5, 0.01));

    public SwingAnimationModule() { super("Swing Animation", Category.RENDER); }

    public int duration() { return (int) duration.get(); }

    /**
     * Replaces vanilla's applySwingOffset. Returns true when the swing was applied here (the vanilla one is
     * cancelled), false for Default / module off.
     */
    public static boolean apply(MatrixStack m, Arm arm, float progress) {
        SwingAnimationModule s = ModuleManager.get(SwingAnimationModule.class);
        if (s == null || !s.isEnabled()) return false;
        int mode = (int) s.mode.get();
        if (mode == 1) return false;

        float rx, ry, rz, mx = 0, my = 0, mz = 0;
        switch (mode) {
            case 2 -> { rx = -20; ry = -70; rz = -45; }                 // Swipe
            case 3 -> { rx = 60; ry = 0; rz = 0; my = -0.10f; }         // Down
            default -> {                                                 // Custom
                rx = (float) s.rotX.get(); ry = (float) s.rotY.get(); rz = (float) s.rotZ.get();
                mx = (float) s.moveX.get(); my = (float) s.moveY.get(); mz = (float) s.moveZ.get();
            }
        }
        int side = arm == Arm.RIGHT ? 1 : -1;
        float k = MathHelper.sin(MathHelper.sqrt(progress) * (float) Math.PI);   // 0 -> 1 -> 0 over the swing
        m.translate(side * mx * k, my * k, mz * k);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (45f + ry * k)));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * rz * k));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx * k));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -45f));
        return true;
    }
}
