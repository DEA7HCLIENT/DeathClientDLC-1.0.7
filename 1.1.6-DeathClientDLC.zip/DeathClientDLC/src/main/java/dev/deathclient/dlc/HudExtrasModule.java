package dev.deathclient.dlc;

/** HUD Extras: watermark, info panel (FPS / ping / time), coordinates, armor and held-item durability. */
public class HudExtrasModule extends Module {
    public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    public final BoolSetting info = add(new BoolSetting("Info: FPS, ping, time", true));
    public final BoolSetting coords = add(new BoolSetting("Coordinates", true));
    public final BoolSetting armor = add(new BoolSetting("Armor & durability", true));
    /** Offsets set by dragging in the open chat. */
    public final NumberSetting wmX = add(new NumberSetting("Watermark X", 0, -1000, 1000, 1));
    public final NumberSetting wmY = add(new NumberSetting("Watermark Y", 0, -1000, 1000, 1));
    public final NumberSetting infoX = add(new NumberSetting("Info X", 0, -1000, 1000, 1));
    public final NumberSetting infoY = add(new NumberSetting("Info Y", 0, -1000, 1000, 1));
    public final NumberSetting coordX = add(new NumberSetting("Coords X", 0, -1000, 1000, 1));
    public final NumberSetting coordY = add(new NumberSetting("Coords Y", 0, -1000, 1000, 1));
    public final NumberSetting armorX = add(new NumberSetting("Armor X", 0, -1000, 1000, 1));
    public final NumberSetting armorY = add(new NumberSetting("Armor Y", 0, -1000, 1000, 1));

    public HudExtrasModule() { super("HUD Extras", Category.MISC, true); }
}
