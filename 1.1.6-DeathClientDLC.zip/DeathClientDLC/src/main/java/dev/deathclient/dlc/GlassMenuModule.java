package dev.deathclient.dlc;

/** Glass Menu: frosted-glass look for the ClickGUI window, the main menu buttons and the HUD panels. */
public class GlassMenuModule extends Module {
    public final NumberSetting opacity = add(new NumberSetting("Opacity %", 55, 10, 100, 5));
    public final NumberSetting sheen = add(new NumberSetting("Sheen %", 35, 0, 100, 5));
    public final BoolSetting accentRim = add(new BoolSetting("Accent rim", true));
    public final BoolSetting buttons = add(new BoolSetting("Glass buttons", true));

    public GlassMenuModule() { super("Glass Menu", Category.MISC, true); }
}
